"""EV figures. Every function returns a matplotlib Figure.

Same conventions as fsae_pt.plots_pt: categorical colours in fixed order, one-hue ramps for
magnitudes, one y-scale per axes (two measures are two panels), what-limits-the-car colours
shared between the trace band and the track map.
"""
from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch

from ._paths import LAPSIM_ROOT  # noqa: F401
from fsae_pt.plots_pt import CAT, INK, INK2, GRID, SEQ          # also applies the shared rcParams
from fsae_vd.units import G0

from .lapsim_ev import LIMITS, LIMIT_COLORS, LIMIT_HELP, energy_breakdown
from .powertrain import CODES, PackState

DRIVE, REGEN = CAT[0], CAT[2]


def _banner(fig, note):
    if note:
        fig.text(0.995, 0.995, note, ha="right", va="top", fontsize=8, color="#b3261e")


def _limit_band(ax, lr, frac=0.045):
    """Thin strip along the bottom of an axes, coloured by what limits the car."""
    y0, y1 = ax.get_ylim()
    h = (y1 - y0) * frac
    idx = np.array([LIMITS.index(c) if c in LIMITS else len(LIMITS) - 1 for c in lr.limit])
    cuts = np.r_[0, np.flatnonzero(np.diff(idx)) + 1, len(idx) - 1]
    for a, b in zip(cuts[:-1], cuts[1:]):
        ax.fill_between([lr.s[a], lr.s[b]], y0, y0 + h, color=LIMIT_COLORS[LIMITS[idx[a]]], lw=0)
    ax.set_ylim(y0, y1)


def _limit_legend(ax_or_fig, lr=None, **kw):
    used = [k for k in LIMITS if lr is None or np.any(lr.limit == k)]
    return ax_or_fig.legend(handles=[Patch(color=LIMIT_COLORS[k], label=f"{k.replace('_', ' ')}: {LIMIT_HELP[k]}")
                                     for k in used], fontsize=8, **kw)


# =========================================================================== POWERTRAIN
def powertrain_envelope(veh, tggv, socs=(0.98, 0.50, 0.15), note=None):
    """Motor torque, accumulator power and tractive force against speed, at three states of charge."""
    ep = veh.ep
    fig, ax = plt.subplots(1, 3, figsize=(17, 4.8))
    st0 = ep.initial_state()
    for c, soc in zip(CAT, socs):
        T = veh.tables(PackState(soc, st0.temp, motor_temp=st0.motor_temp))
        ok = T.v <= T.v_top
        lab = f"SOC {100 * soc:.0f} %"
        ax[0].plot(T.rpm[ok], T.T[ok], color=c, label=lab)
        ax[1].plot(3.6 * T.v[ok], T.P_acc[ok] / 1e3, color=c, label=lab)
        ax[2].plot(3.6 * T.v[ok], T.F[ok], color=c, label=lab)
    T = veh.tables0
    ok = T.v <= T.v_top
    ax[0].plot(T.rpm[ok], -T.T_regen[ok], color=INK2, ls="--", lw=1.4, label="regen limit (start SOC)")
    if not np.any(T.T_regen > 0):
        ax[0].annotate("no regen at the start SOC\n(above regen.max_soc)", (0.03, 0.06), xycoords="axes fraction",
                       fontsize=8, color=INK2)
    ax[0].axhline(0, color=INK2, lw=0.8)
    ax[0].set(title="Motor torque available", xlabel="motor speed [rpm]", ylabel="shaft torque [N m]")
    ax[1].axhline(ep.pack.lim.max_power / 1e3, color=INK2, ls=":", lw=1.2)
    ax[1].annotate("rules limit", (0.02, ep.pack.lim.max_power / 1e3), xycoords=("axes fraction", "data"),
                   xytext=(0, 4), textcoords="offset points", fontsize=8, color=INK2)
    ax[1].set(title="Accumulator power at full throttle", xlabel="speed [km/h]", ylabel="power [kW]")
    vv = np.linspace(1.0, min(float(tggv.v[-1]), T.v_top), 80)
    f_trac = (np.array([tggv.acc(v, 0.0) for v in vv]) * veh.m + veh.resist(vv))
    ax[2].plot(3.6 * vv, f_trac, color=LIMIT_COLORS["traction"], ls="--", lw=1.4, label="rear tire traction limit")
    ax[2].plot(3.6 * T.v[ok], T.R[ok], color=INK2, lw=1.4, label="drag + rolling resistance")
    ax[2].set(title="Tractive force at the wheels", xlabel="speed [km/h]", ylabel="force [N]")
    for a in ax:
        a.legend(fontsize=8)
    _banner(fig, note)
    fig.tight_layout()
    return fig


def motor_map(veh, lr=None, title="Motor + inverter efficiency and where the lap runs", note=None):
    ep, m = veh.ep, veh.ep.motor
    rpm = np.linspace(50, m.c.max_rpm, 140)
    tq = np.linspace(1, m.c.peak_torque, 120)
    eff = 100 * m.efficiency_map(rpm, tq)
    lim, _ = m.torque_limit(rpm, m.c.rated_voltage)
    eff = np.where(tq[:, None] <= lim[None, :], eff, np.nan)
    fig, ax = plt.subplots(figsize=(9.5, 5.4))
    cs = ax.contourf(rpm, tq, eff, levels=[60, 70, 80, 85, 88, 90, 92, 94, 95, 96, 97, 98], cmap=SEQ)
    fig.colorbar(cs, ax=ax, label="efficiency [%]")
    ax.plot(rpm, lim, color=INK, lw=1.6, label=f"torque limit at {m.c.rated_voltage:.0f} V")
    T = veh.tables0
    ok = T.v <= T.v_top
    ax.plot(T.rpm[ok], T.T[ok], color=CAT[1], lw=1.6, ls="--", label="with the accumulator limits (start SOC)")
    if lr is not None:
        d = lr.pt["motor_torque"] > 1
        ax.scatter(lr.pt["motor_rpm"][d], lr.pt["motor_torque"][d], s=5, color=INK, alpha=0.25, lw=0,
                   label="lap operating points (drive)")
    ax.set(title=title, xlabel="motor speed [rpm]", ylabel="shaft torque [N m]", ylim=(0, m.c.peak_torque * 1.06))
    ax.legend(fontsize=8, loc="upper right")
    _banner(fig, note)
    fig.tight_layout()
    return fig


# =========================================================================== LAP
def lap_trace(lr, title=None, note=None):
    """Speed, motor torque, accumulator power, pack voltage, pack current and SOC along the lap."""
    p, s = lr.pt, lr.s
    fig, ax = plt.subplots(6, 1, figsize=(15, 13.5), sharex=True)
    ax[0].plot(s, 3.6 * lr.v, color=INK)
    ax[0].set(ylabel="speed [km/h]", title=title or f"{lr.track.name}: {lr.time:.2f} s")
    ax[0].set_ylim(0, 3.6 * lr.v.max() * 1.12)
    _limit_band(ax[0], lr)
    ax[1].plot(s, p["motor_torque_max"], color=INK2, lw=1.0, ls=":", label="available")
    ax[1].plot(s, -p["regen_torque_max"], color=INK2, lw=1.0, ls=":")
    ax[1].fill_between(s, 0, np.maximum(p["motor_torque"], 0), color=DRIVE, alpha=0.85, lw=0, label="drive")
    ax[1].fill_between(s, 0, np.minimum(p["motor_torque"], 0), color=REGEN, alpha=0.85, lw=0, label="regen")
    ax[1].set(ylabel="motor torque [N m]")
    ax[1].legend(fontsize=8, ncol=3, loc="lower right", bbox_to_anchor=(1.0, 1.0), borderaxespad=0.1)
    ax[2].fill_between(s, 0, np.maximum(p["P_acc_kW"], 0), color=DRIVE, alpha=0.85, lw=0)
    ax[2].fill_between(s, 0, np.minimum(p["P_acc_kW"], 0), color=REGEN, alpha=0.85, lw=0)
    ax[2].set(ylabel="accumulator power [kW]")
    ax[3].plot(s, p["V_pack"], color=CAT[0])
    ax[3].set(ylabel="pack voltage [V]")
    ax[4].plot(s, p["I_pack"], color=CAT[0])
    ax[4].axhline(0, color=INK2, lw=0.8)
    ax[4].set(ylabel="pack current [A]")
    ax[5].plot(s, 100 * p["soc"], color=CAT[0])
    ax[5].set(ylabel="SOC [%]", xlabel="distance [m]")
    _limit_legend(fig, lr, loc="lower center", ncol=5, bbox_to_anchor=(0.5, -0.005))
    _banner(fig, note)
    fig.tight_layout(rect=(0, 0.035, 1, 1))
    return fig


def track_maps(lr, note=None):
    """Track coloured by what limits the car, by speed and by accumulator power."""
    if lr.track.x is None:
        return None
    x, y = lr.track.x, lr.track.y
    n = min(len(x), len(lr.s))
    pts = np.column_stack([x[:n], y[:n]])[:, None, :]
    seg = np.concatenate([pts[:-1], pts[1:]], axis=1)
    asp = max(np.ptp(y[:n]), 1.0) / max(np.ptp(x[:n]), 1.0)
    if asp < 0.6:
        fig, ax = plt.subplots(3, 1, figsize=(15, 3 * max(15 * asp, 1.6) + 1.5))
    else:
        fig, ax = plt.subplots(1, 3, figsize=(18, 5.4))
    li = {k: i for i, k in enumerate(LIMITS)}
    lc = LineCollection(seg, cmap=ListedColormap([LIMIT_COLORS[k] for k in LIMITS]),
                        norm=BoundaryNorm(np.arange(-0.5, len(LIMITS) + 0.5), len(LIMITS)), linewidths=4)
    lc.set_array(np.array([li.get(c, len(LIMITS) - 1) for c in lr.limit[:n - 1]]))
    ax[0].add_collection(lc)
    ax[0].legend(handles=[Patch(color=LIMIT_COLORS[k], label=k.replace("_", " ")) for k in LIMITS
                          if np.any(lr.limit == k)], fontsize=8, loc="center left", bbox_to_anchor=(1.01, 0.5))
    ax[0].set_title("What limits the car")
    for a, val, lab, cmap in ((ax[1], 3.6 * lr.v, "speed [km/h]", SEQ),
                              (ax[2], np.maximum(lr.pt["P_acc_kW"], 0), "accumulator power [kW]", "Oranges")):
        c = LineCollection(seg, cmap=cmap, linewidths=4)
        c.set_array(val[:n - 1])
        a.add_collection(c)
        fig.colorbar(c, ax=a, label=lab, fraction=0.035, pad=0.02)
        a.set_title(lab.split(" [")[0].capitalize())
    for a in ax:
        a.set_aspect("equal")
        a.autoscale()
        a.grid(False)
        a.set_xticks([]); a.set_yticks([])
        for sp in a.spines.values():
            sp.set_visible(False)
    _banner(fig, note)
    fig.tight_layout()
    return fig


def energy_flow(lr, title=None, note=None):
    """Where the energy taken from the cells goes over one lap."""
    e = energy_breakdown(lr).sort_values()
    tot = e.sum()
    fig, ax = plt.subplots(figsize=(9.5, 4.4))
    ax.barh(e.index, 1e3 * e.values, color=CAT[0], height=0.62)
    for i, v in enumerate(e.values):
        ax.text(1e3 * v, i, f"  {1e3 * v:.0f} Wh  ({100 * v / tot:.0f} %)", va="center", fontsize=9, color=INK)
    s = lr.summary
    ax.set(xlabel="energy per lap [Wh]", xlim=(0, 1e3 * e.max() * 1.28),
           title=title or f"Where the energy goes: {1e3 * s['energy_kWh']:.0f} Wh net from the accumulator per lap "
                          f"({1e3 * s['regen_kWh']:.0f} Wh recovered by regen)")
    ax.grid(axis="y", visible=False)
    _banner(fig, note)
    fig.tight_layout()
    return fig


def accel_plot(lr, note=None):
    fig, ax = plt.subplots(1, 3, figsize=(16, 4.4))
    ax[0].plot(lr.t, 3.6 * lr.v, color=INK)
    ax[0].set(xlabel="time [s]", ylabel="speed [km/h]",
              title=f"Acceleration: {lr.summary.get('fsae_time_s', lr.time):.3f} s, "
                    f"{lr.summary.get('trap_speed_kph', 3.6 * lr.v[-1]):.0f} km/h at the line")
    ax[1].plot(lr.s, lr.ax / G0, color=INK)
    ax[1].set(xlabel="distance [m]", ylabel="longitudinal acceleration [g]", title="Acceleration along the run")
    ax[1].set_ylim(0, max(lr.ax.max() / G0 * 1.15, 0.1))
    _limit_band(ax[1], lr)
    _limit_legend(ax[1], lr, loc="upper right")
    ax[2].plot(lr.s, lr.pt["P_acc_kW"], color=CAT[0], label="accumulator")
    ax[2].plot(lr.s, lr.pt["P_mech_kW"], color=CAT[1], label="motor shaft")
    ax[2].set(xlabel="distance [m]", ylabel="power [kW]", title="Power")
    ax[2].legend(fontsize=8)
    _banner(fig, note)
    fig.tight_layout()
    return fig


# =========================================================================== ENDURANCE
def endurance_summary(df, soc_min=None, t_max=None, note=None):
    """Per-lap endurance: lap time, energy, SOC, minimum pack voltage, cell and motor temperature."""
    fig, ax = plt.subplots(2, 3, figsize=(16, 7.6), sharex=True)
    L = df.index.to_numpy()
    panels = [("lap_time_s", "lap time [s]", "Lap time"), ("energy_kWh", "energy [kWh]", "Net energy per lap"),
              ("soc_end", "SOC [%]", "State of charge at the end of the lap"),
              ("min_pack_V", "voltage [V]", "Lowest pack voltage in the lap"),
              ("cell_temp_end_C", "temperature [degC]", "Cell temperature"),
              ("motor_temp_end_C", "temperature [degC]", "Motor winding temperature")]
    for a, (col, yl, tt) in zip(ax.ravel(), panels):
        y = df[col].to_numpy() * (100 if col == "soc_end" else 1)
        a.plot(L, y, color=CAT[0], marker="o", ms=4)
        a.set(ylabel=yl, title=tt)
    if soc_min is not None:
        ax[0, 2].axhline(100 * soc_min, color=INK2, ls=":", lw=1.2)
        ax[0, 2].annotate("reserve", (L[0], 100 * soc_min), xytext=(0, 4), textcoords="offset points", fontsize=8, color=INK2)
    if t_max is not None:
        ax[1, 1].axhline(t_max, color=INK2, ls=":", lw=1.2)
        ax[1, 1].annotate("cell limit", (L[0], t_max), xytext=(0, -11), textcoords="offset points", fontsize=8, color=INK2)
    for key, lab in (("dnf_lap", "accumulator empty"), ("over_temp_lap", "cells at limit")):
        if key in df.attrs:
            for a in ax.ravel():
                a.axvline(df.attrs[key], color="#b3261e", lw=1.2)
            ax[0, 0].annotate(lab, (df.attrs[key], ax[0, 0].get_ylim()[1]), xytext=(-4, -12), textcoords="offset points",
                              ha="right", fontsize=8, color="#b3261e")
    from matplotlib.ticker import MaxNLocator
    for a in ax[1]:
        a.set_xlabel("lap")
        a.xaxis.set_major_locator(MaxNLocator(integer=True))
    n, done = df.attrs.get("n_laps", len(df)), len(df)
    head = (f"Endurance at {df.attrs.get('p_limit_W', 0) / 1e3:.0f} kW: "
            + (f"{df['lap_time_s'].sum():.0f} s, {df['energy_kWh'].sum():.2f} kWh, {n} laps" if df.attrs.get("finished", True)
               else f"DOES NOT FINISH - stops on lap {done} of {n}"))
    fig.suptitle(head, fontweight="bold")
    _banner(fig, note)
    fig.tight_layout()
    return fig


def endurance_trace(laps, note=None):
    """Accumulator over the whole endurance: power, voltage, current, SOC, temperatures against time."""
    t = np.concatenate([lr.pt["t_endurance"] for lr in laps]) / 60
    cat = lambda k: np.concatenate([lr.pt[k] for lr in laps])
    fig, ax = plt.subplots(5, 1, figsize=(15, 11.5), sharex=True)
    pa = cat("P_acc_kW")
    ax[0].fill_between(t, 0, np.maximum(pa, 0), color=DRIVE, lw=0, label="discharge")
    ax[0].fill_between(t, 0, np.minimum(pa, 0), color=REGEN, lw=0, label="regen")
    ax[0].set(ylabel="accumulator power [kW]", title="Accumulator over the endurance")
    ax[0].legend(fontsize=8, ncol=2, loc="upper right")
    ax[1].plot(t, cat("V_pack"), color=CAT[0], lw=0.8)
    ax[1].set(ylabel="pack voltage [V]")
    ax[2].plot(t, cat("I_pack"), color=CAT[0], lw=0.8)
    ax[2].set(ylabel="pack current [A]")
    ax[3].plot(t, 100 * cat("soc"), color=CAT[0])
    ax[3].set(ylabel="SOC [%]")
    ax[4].plot(t, cat("cell_temp_C"), color=CAT[0], label="cells")
    ax[4].plot(t, cat("motor_temp_C"), color=CAT[1], label="motor winding")
    ax[4].set(ylabel="temperature [degC]", xlabel="time [min]")
    ax[4].legend(fontsize=8, loc="upper left")
    _banner(fig, note)
    fig.tight_layout()
    return fig


def energy_sweep_plot(sw, soc_min=0.05, note=None):
    """Endurance time, energy and final SOC against the accumulator power limit."""
    fig, ax = plt.subplots(1, 3, figsize=(16, 4.6))
    p = sw.index.to_numpy(float)
    fin = sw["finishes"].to_numpy(bool)
    ok = sw["above_reserve"].to_numpy(bool)
    ax[0].plot(p[fin], sw["time_s"][fin], color=CAT[0], marker="o")
    for x in p[~fin]:
        ax[0].axvline(x, color="#b3261e", lw=1.0, ls=":")
    if (~fin).any():
        ax[0].annotate("does not finish", (p[~fin].min(), 0.95), xycoords=("data", "axes fraction"), xytext=(4, 0),
                       textcoords="offset points", fontsize=8, color="#b3261e", va="top")
    ax[0].set(xlabel="accumulator power limit [kW]", ylabel="endurance time [s]", title="Endurance time")
    ax[1].plot(p, sw["energy_kWh"], color=CAT[0], marker="o")
    ax[1].set(xlabel="accumulator power limit [kW]", ylabel="energy [kWh]",
              title="Net energy used (to the finish, or until empty)")
    ax[2].bar(p, sw["final_soc_%"].clip(lower=0), width=0.6 * (np.min(np.abs(np.diff(p))) if len(p) > 1 else 5),
              color=[CAT[0] if o else GRID for o in ok])
    ax[2].axhline(100 * soc_min, color=INK2, ls=":", lw=1.2)
    ax[2].annotate("reserve", (0.02, 100 * soc_min), xycoords=("axes fraction", "data"), xytext=(0, 4),
                   textcoords="offset points", fontsize=8, color=INK2)
    ax[2].set(xlabel="accumulator power limit [kW]", ylabel="SOC at the finish [%]", title="Charge left")
    if ok.any():
        best = sw.index[ok][np.argmin(sw["time_s"][ok])]
        fig.suptitle(f"Fastest power limit that finishes above the reserve: {best:g} kW "
                     f"({sw.loc[best, 'time_s']:.0f} s, {sw.loc[best, 'energy_kWh']:.2f} kWh)", fontweight="bold")
    else:
        fig.suptitle("No power limit in this range finishes above the reserve", fontweight="bold")
    _banner(fig, note)
    fig.tight_layout()
    return fig


def gearing_plot(gs, current=None, note=None):
    cols = [("acceleration_s", "time [s]", "Acceleration (75 m)"), ("autocross_s", "time [s]", "Autocross lap"),
            ("top_speed_kph", "speed [km/h]", "Top speed"), ("autocross_Wh_per_km", "energy [Wh/km]", "Autocross energy")]
    cols = [c for c in cols if c[0] in gs]
    fig, ax = plt.subplots(1, len(cols), figsize=(4.4 * len(cols), 4.2))
    for a, (c, yl, tt) in zip(np.atleast_1d(ax), cols):
        a.plot(gs.index, gs[c], color=CAT[0], marker="o")
        if current is not None:
            a.axvline(current, color=INK2, ls=":", lw=1.2)
        a.set(xlabel="reduction ratio (motor : wheel)", ylabel=yl, title=tt)
    if current is not None:
        np.atleast_1d(ax)[0].annotate("configured", (current, 0.96), xycoords=("data", "axes fraction"), xytext=(4, 0),
                                      textcoords="offset points", fontsize=8, color=INK2, va="top")
    _banner(fig, note)
    fig.tight_layout()
    return fig
