"""Folders, and the import path for the shared packages.

    fsae_lapsim/            LAPSIM_ROOT   fsae_vd (suspension, tires, aero), fsae_pt (differential model)
      ev/                   EV_ROOT       everything about the electric car
        fsae_ev/                          this package: EV powertrain + lap simulation
        fsae_ev_bms/                      accumulator estimation / run analysis (its own project)
"""
from __future__ import annotations

import sys
from pathlib import Path

EV_ROOT = Path(__file__).resolve().parents[1]
# the folder holding fsae_vd / fsae_pt: next to ev/ (flat layout) or in IC/ (IC / ev layout)
LAPSIM_ROOT = next((p for p in (EV_ROOT.parent, EV_ROOT.parent / "IC") if (p / "fsae_vd").is_dir()), EV_ROOT.parent)
BMS_ROOT = EV_ROOT / "fsae_ev_bms"

for _p in (LAPSIM_ROOT, BMS_ROOT):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))
