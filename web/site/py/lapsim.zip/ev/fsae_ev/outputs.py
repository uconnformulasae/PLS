"""Write one simulation run to ev/results/lapsim/<date_time>/.

    summary.txt / summary.json      event times, energy, what limits the car, warnings
    inputs_status.csv               every EV input: value, confirmed or PLACEHOLDER
    events.csv                      time and points per event
    lap_<event>.csv                 every channel along the lap (suspension + powertrain + accumulator)
    endurance_laps.csv              one row per endurance lap
    endurance_accumulator.csv       pack power / current / voltage / SOC / temperatures over the whole endurance
    energy_sweep.csv                endurance time and energy against the accumulator power limit
    gearing_sweep.csv               acceleration / autocross / top speed against the reduction ratio
    figures/*.png
"""
from __future__ import annotations

import datetime as _dt
import json
from pathlib import Path

import numpy as np
import pandas as pd

from ._paths import EV_ROOT
from .config import status_counts
from .lapsim_ev import LIMITS, energy_breakdown

RESULTS = EV_ROOT / "results" / "lapsim"


def placeholder_note(status) -> str | None:
    if status is None:
        return None
    c = status_counts(status)
    n = c["placeholder"] + c["missing"]
    return f"PLACEHOLDER CAR: {n} of {n + c['confirmed']} EV inputs not confirmed" if n else None


def summary_text(res, status=None, sweep=None, gearing=None) -> str:
    veh, evc = res.vehicle, res.vehicle.evc
    ep, pk = veh.ep, veh.ep.pack
    L = []
    note = placeholder_note(status)
    if note:
        L += ["!" * 78, f"  {note}.",
              "  The numbers below show what the simulation produces, NOT the car's performance.",
              "  See inputs_status.csv for the list.", "!" * 78, ""]
    L += [f"{veh.cfg.name}  /  {evc.name}",
          f"  mass with driver {veh.m:.1f} kg, {100 * veh.ff:.0f} % front, CG {1e3 * veh.h:.0f} mm",
          f"  motor {evc.motor.peak_torque:.0f} N m, {evc.motor.max_rpm:.0f} rpm; reduction {ep.G:.3f}:1 "
          f"({evc.drivetrain.type}); top speed {3.6 * res.tables.v_top:.0f} km/h",
          f"  accumulator {pk.ns}s{pk.npar}p, {pk.nominal_energy / 3.6e6:.2f} kWh, "
          f"{float(pk.voc(1.0)):.0f} V full; power limit {ep.power_limit() / 1e3:.0f} kW "
          f"(endurance {ep.power_limit(True) / 1e3:.0f} kW)",
          f"  regen {'on' if evc.regen.enabled else 'off'}"
          + (f": up to {evc.regen.max_torque:.0f} N m / {evc.regen.max_power / 1e3:.0f} kW" if evc.regen.enabled else ""),
          "", "EVENTS"]
    for e, t in res.times.items():
        p = res.points.get(e)
        L.append(f"  {e:<13s} {t:9.3f} s" + (f"   {p:6.1f} pts" if p is not None else "   (not scored: events.tmin_* missing)"))
    if "efficiency" in res.points:
        L.append(f"  {'efficiency':<13s} {'':9s}     {res.points['efficiency']:6.1f} pts")
    for e in ("acceleration", "autocross", "endurance"):
        if e not in res.laps:
            continue
        s = res.laps[e].summary
        L += ["", f"{e.upper()}" + (" (lap 2, flying)" if e == "endurance" else ""),
              f"  energy {1e3 * s['energy_kWh']:.0f} Wh net ({1e3 * s['regen_kWh']:.0f} Wh regen), {s['Wh_per_km']:.0f} Wh/km",
              f"  accumulator peak {s['peak_power_kW']:.1f} kW, {s['peak_current_A']:.0f} A; lowest pack voltage {s['min_pack_V']:.0f} V "
              f"({s['min_cell_V']:.2f} V per cell)",
              f"  motor peak {s['peak_motor_torque_Nm']:.0f} N m, rms {s['rms_motor_torque_Nm']:.0f} N m, {s['max_motor_rpm']:.0f} rpm; "
              f"top speed {s['top_speed_kph']:.0f} km/h",
              "  time limited by: " + ", ".join(f"{c.replace('_', ' ')} {s[f'time_{c}_%']:.0f} %" for c in LIMITS
                                                if s[f"time_{c}_%"] >= 0.5)]
    if res.endurance is not None:
        d = res.endurance
        fin = d.attrs.get("finished", True)
        L += ["", "ENDURANCE TOTAL",
              f"  {len(d)} of {d.attrs.get('n_laps', len(d))} laps, {d['lap_time_s'].sum():.1f} s, {d['energy_kWh'].sum():.2f} kWh net, "
              f"{d['regen_kWh'].sum():.2f} kWh regen",
              f"  SOC at the end {100 * d['soc_end'].iloc[-1]:.1f} %, cells {d['cell_temp_end_C'].max():.1f} degC max, "
              f"motor {d['motor_temp_end_C'].max():.1f} degC max",
              f"  rms motor torque {np.sqrt((d['rms_motor_torque_Nm'] ** 2 * d['lap_time_s']).sum() / d['lap_time_s'].sum()):.0f} N m "
              f"(continuous rating {evc.motor.continuous_torque:.0f} N m)"]
        if not fin:
            L.append(f"  ** DOES NOT FINISH at this power limit: accumulator empty on lap {d.attrs['dnf_lap']} **")
    if sweep is not None:
        L += ["", "ENDURANCE POWER-LIMIT SWEEP",
              sweep[["time_s", "energy_kWh", "final_soc_%", "max_cell_temp_C", "finishes", "above_reserve"]].round(2).to_string()]
        ok = sweep[sweep["above_reserve"]]
        L.append(f"  -> fastest limit that finishes above the SOC reserve: {ok['time_s'].idxmin():g} kW" if len(ok)
                 else "  -> no limit in this range finishes above the SOC reserve")
    if gearing is not None:
        L += ["", "REDUCTION RATIO SWEEP", gearing.round(3).to_string()]
    if res.notes:
        L += ["", "NOTES"] + [f"  - {n}" for n in res.notes]
    return "\n".join(L) + "\n"


def _json(o):
    if isinstance(o, dict):
        return {str(k): _json(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_json(v) for v in o]
    if isinstance(o, (np.floating, float)):
        return None if not np.isfinite(o) else float(o)
    if isinstance(o, (np.integer, np.bool_)):
        return o.item()
    return o


def endurance_accumulator_frame(laps, step=5) -> pd.DataFrame:
    """Predicted accumulator duty cycle over the whole endurance (every `step`-th sample)."""
    keys = ("P_acc_kW", "I_pack", "V_pack", "V_cell", "I_cell", "soc", "cell_temp_C", "motor_temp_C",
            "motor_torque", "motor_rpm")
    fr = []
    for i, lr in enumerate(laps):
        d = {"time_s": lr.pt["t_endurance"], "lap": i + 1, "distance_m": lr.s, "speed_mps": lr.v}
        d.update({k: lr.pt[k] for k in keys})
        fr.append(pd.DataFrame(d).iloc[::step])
    return pd.concat(fr, ignore_index=True)


def make_figures(res, status=None, sweep=None, gearing=None) -> dict:
    from . import plots_ev as pe
    note = placeholder_note(status)
    veh, evc = res.vehicle, res.vehicle.evc
    figs = {"01_powertrain_envelope": pe.powertrain_envelope(veh, res.tggv, note=note)}
    if "acceleration" in res.laps:
        figs["02_acceleration"] = pe.accel_plot(res.laps["acceleration"], note=note)
    for i, e in ((3, "autocross"), (6, "endurance")):
        if e not in res.laps:
            continue
        lr = res.laps[e]
        tag = f"{e} (lap 2, flying)" if e == "endurance" else e
        figs[f"{i:02d}_{e}_trace"] = pe.lap_trace(lr, f"{tag.capitalize()}: {lr.time:.2f} s, "
                                                      f"{1e3 * lr.summary['energy_kWh']:.0f} Wh", note=note)
        tm = pe.track_maps(lr, note=note)
        if tm is not None:
            figs[f"{i + 1:02d}_{e}_track"] = tm
        figs[f"{i + 2:02d}_{e}_energy"] = pe.energy_flow(lr, note=note)
    ref = res.laps.get("endurance", res.laps.get("autocross"))
    figs["09_motor_map"] = pe.motor_map(veh, ref, note=note)
    if res.endurance is not None:
        figs["10_endurance_laps"] = pe.endurance_summary(res.endurance, evc.accumulator.soc_min,
                                                         veh.ep.pack.lim.cell_t_max, note=note)
        figs["11_endurance_accumulator"] = pe.endurance_trace(res.laps["endurance_all"], note=note)
    if sweep is not None:
        figs["12_energy_sweep"] = pe.energy_sweep_plot(sweep, evc.accumulator.soc_min, note=note)
    if gearing is not None:
        figs["13_gearing_sweep"] = pe.gearing_plot(gearing, veh.ep.G, note=note)
    return figs


def write_results(res, status=None, out_dir=None, sweep=None, gearing=None, figures=True) -> Path:
    import matplotlib.pyplot as plt
    out = Path(out_dir) if out_dir else RESULTS / _dt.datetime.now().strftime("%Y-%m-%d_%H%M%S")
    out.mkdir(parents=True, exist_ok=True)
    (out / "summary.txt").write_text(summary_text(res, status, sweep, gearing))
    js = {"car": res.vehicle.cfg.name, "placeholder_note": placeholder_note(status), "times_s": res.times,
          "points": res.points, "notes": res.notes,
          "laps": {e: lr.summary for e, lr in res.laps.items() if hasattr(lr, "summary")},
          "energy_breakdown_kWh": {e: energy_breakdown(lr).to_dict() for e, lr in res.laps.items() if hasattr(lr, "pt")}}
    if res.endurance is not None:
        js["endurance"] = {"laps_completed": len(res.endurance), **res.endurance.attrs,
                           "time_s": float(res.endurance["lap_time_s"].sum()),
                           "energy_kWh": float(res.endurance["energy_kWh"].sum())}
    (out / "summary.json").write_text(json.dumps(_json(js), indent=2))
    res.table().to_csv(out / "events.csv")
    if status is not None:
        status.to_csv(out / "inputs_status.csv", index=False)
    for e, lr in res.laps.items():
        if hasattr(lr, "frame"):
            lr.frame().to_csv(out / f"lap_{e}.csv", index=False, float_format="%.6g")
    if res.endurance is not None:
        res.endurance.to_csv(out / "endurance_laps.csv", float_format="%.6g")
        endurance_accumulator_frame(res.laps["endurance_all"]).to_csv(out / "endurance_accumulator.csv", index=False,
                                                                      float_format="%.6g")
    if sweep is not None:
        sweep.to_csv(out / "energy_sweep.csv", float_format="%.6g")
    if gearing is not None:
        gearing.to_csv(out / "gearing_sweep.csv", float_format="%.6g")
    if figures:
        fd = out / "figures"
        fd.mkdir(exist_ok=True)
        for name, fig in make_figures(res, status, sweep, gearing).items():
            fig.savefig(fd / f"{name}.png", dpi=130, bbox_inches="tight")
            plt.close(fig)
    return out
