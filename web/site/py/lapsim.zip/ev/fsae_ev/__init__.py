"""fsae_ev - electric-vehicle section of the predictive lap simulation (CT-17EV).

Uses the vehicle-dynamics package of the IC car (``fsae_vd``: suspension, tires, aero) and the
accumulator definition of ``fsae_ev_bms``; adds the motor, inverter, reduction, regen and the
energy / state-of-charge / temperature bookkeeping.

    import fsae_ev as ev
    cfg, evc, bcfg, status = ev.load_car()            # ev/configs/ct17ev_*.yaml
    evc.set("drivetrain.rear_sprocket", 40)            # change anything
    res = ev.run_events_ev(cfg, evc, bcfg)             # acceleration, skidpad, autocross, endurance
    res.table(); res.endurance                         # times / per-lap endurance table
    res.laps["autocross"].frame()                      # every channel along the lap
    ev.outputs.write_results(res, status)              # ev/results/lapsim/<date_time>/
"""
from ._paths import EV_ROOT, LAPSIM_ROOT, BMS_ROOT
from .config import (EVConfig, load_ev_config, load_ev_vehicle, load_car, input_status, status_counts,
                     VEHICLE_FILE, POWERTRAIN_FILE, TRACK_SET)
from .powertrain import Motor, Pack, PackState, EVPowertrain, EVTables, CODES
from .vehicle_ev import EVVehicle
from .lapsim_ev import (LapEV, EVEventResults, solve_ev, run_events_ev, endurance, accel_run, make_tracks,
                        energy_sweep, gearing_sweep, energy_breakdown, lap_summary, LIMITS, LIMIT_COLORS,
                        LIMIT_HELP)
from . import plots_ev, outputs

__all__ = ["EV_ROOT", "LAPSIM_ROOT", "BMS_ROOT", "EVConfig", "load_ev_config", "load_ev_vehicle", "load_car",
           "input_status", "status_counts", "VEHICLE_FILE", "POWERTRAIN_FILE", "TRACK_SET", "Motor", "Pack",
           "PackState", "EVPowertrain", "EVTables", "CODES", "EVVehicle", "LapEV", "EVEventResults", "solve_ev",
           "run_events_ev", "endurance", "accel_run", "make_tracks", "energy_sweep", "gearing_sweep",
           "energy_breakdown", "lap_summary", "LIMITS", "LIMIT_COLORS", "LIMIT_HELP", "plots_ev", "outputs"]
