"""EV configuration: the electric powertrain file, the vehicle overlay on the IC car,
and the table that says which inputs are still placeholders.

    cfg, evc, bcfg, status = load_car()          # ev/configs/ct17ev_*.yaml + the accumulator config
    evc.set("drivetrain.rear_sprocket", 40)       # change anything
    cfg.set("mass.mass_no_driver", "245 kg")
"""
from __future__ import annotations

import copy
import dataclasses as dc
from pathlib import Path
from typing import Optional

import pandas as pd
import yaml

from ._paths import EV_ROOT, LAPSIM_ROOT  # noqa: F401  (sets the import path)

import fsae_vd as vd
from fsae_vd.units import parse_quantity
from fsae_pt.config import Differential as DifferentialCfg, Wheels as WheelsCfg

_TEXT = {"name", "type", "model", "config_file", "sag_branches", "torque_curve_file"}
VEHICLE_FILE = EV_ROOT / "configs" / "ct17ev_vehicle.yaml"
POWERTRAIN_FILE = EV_ROOT / "configs" / "ct17ev_powertrain.yaml"
TRACK_SET = EV_ROOT / "configs" / "tracks" / "ev_2026.yaml"


@dc.dataclass
class Motor:
    name: str = "motor"
    peak_torque: float = 230.0               # N m
    continuous_torque: float = 120.0         # N m
    peak_power: float = 100e3                # W mechanical
    max_rpm: float = 6500.0
    corner_rpm: float = 4500.0               # at rated_voltage
    rated_voltage: float = 520.0             # V dc
    kt: float = 0.60                         # N m / A rms
    phase_resistance: float = 0.012          # ohm at 20 degC
    iron_loss_1: float = 1.2                 # W / (rad/s)
    iron_loss_2: float = 0.0035              # W / (rad/s)^2
    rotor_inertia: float = 0.042             # kg m^2
    torque_curve_file: Optional[str] = None
    thermal_mass: float = 6000.0             # J/K
    ua_coolant: float = 60.0                 # W/K
    coolant_temp: float = 40.0               # degC
    start_temp: float = 40.0
    derate_start_temp: float = 110.0
    derate_end_temp: float = 130.0


@dc.dataclass
class Inverter:
    name: str = "inverter"
    max_phase_current: float = 400.0         # A rms
    max_dc_current: float = 250.0            # A
    min_dc_voltage: float = 300.0            # V
    loss_const: float = 150.0                # W
    loss_per_amp: float = 2.2                # W / A rms


@dc.dataclass
class Accumulator:
    config_file: str = "../fsae_ev_bms/configs/ev_accumulator.yaml"
    start_soc: float = 0.98
    soc_min: float = 0.05
    start_temp: float = 25.0
    sag_branches: str = "r0+r1"


@dc.dataclass
class Drivetrain:
    type: str = "chain"
    front_sprocket: Optional[float] = 12
    rear_sprocket: Optional[float] = 42
    ratio: Optional[float] = None
    efficiency: float = 0.96
    inertia: float = 0.03                    # kg m^2 at the axle
    chain_pitch: float = 0.015875            # m (520 chain), for the chain tension channel
    ratio_options: list = dc.field(default_factory=lambda: [3.0, 3.25, 3.5, 3.75, 4.0, 4.25])

    @property
    def overall(self) -> float:
        if self.ratio:
            return float(self.ratio)
        if not (self.front_sprocket and self.rear_sprocket):
            raise ValueError("drivetrain: give ratio, or front_sprocket and rear_sprocket")
        return float(self.rear_sprocket) / float(self.front_sprocket)


@dc.dataclass
class Regen:
    enabled: bool = True
    max_torque: float = 80.0                 # N m
    max_power: float = 30e3                  # W into the accumulator
    min_speed: float = 5 / 3.6               # m/s
    fade_speed: float = 15 / 3.6             # m/s
    rear_brake_share: float = 1.0
    max_soc: float = 0.97


@dc.dataclass
class LV:
    aux_power: float = 350.0                 # W
    dcdc_efficiency: float = 0.90


@dc.dataclass
class Strategy:
    power_limit: Optional[float] = None      # W at the accumulator
    endurance_power_limit: Optional[float] = None
    torque_limit: Optional[float] = None     # N m
    max_speed: Optional[float] = None        # m/s


@dc.dataclass
class Endurance:
    driver_change_s: float = 180.0


@dc.dataclass
class Scoring:
    energy_min_per_lap: Optional[float] = None   # J (give it as "0.25 kWh")
    t_min_lap: Optional[float] = None
    ef_min: float = 0.10
    ef_max: float = 0.85


@dc.dataclass
class EVConfig:
    name: str = "ev_powertrain"
    confirmed: list = dc.field(default_factory=list)
    motor: Motor = dc.field(default_factory=Motor)
    inverter: Inverter = dc.field(default_factory=Inverter)
    accumulator: Accumulator = dc.field(default_factory=Accumulator)
    drivetrain: Drivetrain = dc.field(default_factory=Drivetrain)
    differential: DifferentialCfg = dc.field(default_factory=DifferentialCfg)
    wheels: WheelsCfg = dc.field(default_factory=WheelsCfg)
    regen: Regen = dc.field(default_factory=Regen)
    lv: LV = dc.field(default_factory=LV)
    strategy: Strategy = dc.field(default_factory=Strategy)
    endurance: Endurance = dc.field(default_factory=Endurance)
    scoring: Scoring = dc.field(default_factory=Scoring)
    source: Optional[str] = None
    listed: list = dc.field(default_factory=list)      # keys present in the YAML

    def get(self, path):
        obj = self
        for p in path.split("."):
            obj = getattr(obj, p)
        return obj

    def set(self, path, value):
        """e.g. evc.set('drivetrain.rear_sprocket', 40); evc.set('strategy.power_limit', '60 kW')."""
        *parents, leaf = path.split(".")
        obj = self
        for p in parents:
            obj = getattr(obj, p)
        if not hasattr(obj, leaf):
            raise AttributeError(f"no EV powertrain field '{path}'")
        setattr(obj, leaf, _conv(leaf, value))
        return self

    def copy(self):
        return copy.deepcopy(self)


def _conv(key, v):
    if key in _TEXT:
        return None if v is None else str(v)
    return parse_quantity(v, angle_field=key.endswith("_deg"))


def _fill(obj, data, where, listed):
    names = {f.name for f in dc.fields(obj)}
    for k, v in (data or {}).items():
        if k not in names:
            raise KeyError(f"unknown EV powertrain key '{where}{k}'")
        cur = getattr(obj, k)
        if dc.is_dataclass(cur):
            _fill(cur, v, f"{where}{k}.", listed)
        else:
            setattr(obj, k, _conv(k, v))
            listed.append(f"{where}{k}")


def load_ev_config(path=POWERTRAIN_FILE) -> EVConfig:
    path = Path(path)
    data = yaml.safe_load(path.read_text()) or {}
    evc = EVConfig(name=data.pop("name", path.stem), confirmed=list(data.pop("confirmed", None) or []),
                   source=str(path))
    _fill(evc, data, "", evc.listed)
    for sec, key in (("accumulator", "config_file"), ("motor", "torque_curve_file")):
        f = getattr(getattr(evc, sec), key)
        if f and not Path(f).is_absolute():
            setattr(getattr(evc, sec), key, str((path.parent / f).resolve()))
    _check_confirmed(evc.confirmed, evc.listed, path)
    return evc


def _check_confirmed(confirmed, listed, path):
    bad = [k for k in confirmed if k not in listed]
    if bad:
        raise KeyError(f"{Path(path).name}: `confirmed` names {bad}, which are not values in this file")


# --------------------------------------------------------------------------- vehicle overlay
def _flatten(d, prefix=""):
    for k, v in (d or {}).items():
        if isinstance(v, dict) and prefix.count(".") < 1 and k not in ("components", "settings", "drs", "hardpoints"):
            yield from _flatten(v, f"{prefix}{k}.")
        else:
            yield f"{prefix}{k}", v


def load_ev_vehicle(path=VEHICLE_FILE):
    """The EV's vehicle-dynamics config: the IC car's file (`base`) with this file's values on top.
    Returns (CarConfig, overlay) where overlay = {'listed': [...], 'confirmed': [...], 'base': path}."""
    path = Path(path)
    data = yaml.safe_load(path.read_text()) or {}
    name = data.pop("name", path.stem)
    confirmed = list(data.pop("confirmed", None) or [])
    base = data.pop("base", None)
    if base is None:
        raise KeyError(f"{path.name}: `base` (the vehicle config this file overlays) is missing")
    base = (path.parent / base).resolve()
    cfg = vd.load_config(base)
    cfg.name = name
    listed = []
    for key, val in _flatten(data):
        leaf = key.rsplit(".", 1)[-1]
        if isinstance(val, str) and (leaf.endswith("_file") or leaf.endswith("_track")) and not Path(val).is_absolute():
            val = str((path.parent / val).resolve())
        cfg.set(key, val)
        listed.append(key)
    if "aero.rho" not in listed and any(k.startswith("aero.ambient") for k in listed):
        cfg.aero.rho = cfg.aero.density()
    _check_confirmed(confirmed, listed, path)
    return cfg, {"listed": listed, "confirmed": confirmed, "base": str(base), "source": str(path)}


# --------------------------------------------------------------------------- status of the inputs
def input_status(cfg, overlay, evc: EVConfig, bcfg=None) -> pd.DataFrame:
    """One row per EV input: its value and whether it is confirmed or still a placeholder."""
    rows = []
    for k in overlay["listed"]:
        v = cfg.get(k)
        st = "confirmed" if k in overlay["confirmed"] else ("MISSING" if v is None else
                                                             "setting" if isinstance(v, str) else "PLACEHOLDER")
        rows.append({"file": Path(overlay["source"]).name, "key": k, "value_SI": v, "status": st})
    for k in evc.listed:
        v = evc.get(k)
        optional = v is None or k.split(".")[0] in ("strategy", "scoring") or k.endswith(("name", "type", "_options"))
        st = "confirmed" if k in evc.confirmed else ("setting" if optional else "PLACEHOLDER")
        rows.append({"file": Path(evc.source or "powertrain").name, "key": k, "value_SI": v, "status": st})
    if bcfg is not None:
        for sec in ("pack", "cell", "limits", "thermal"):
            for f in dc.fields(getattr(bcfg, sec)):
                v = getattr(getattr(bcfg, sec), f.name)
                if isinstance(v, (int, float, str)) and not isinstance(v, bool):
                    rows.append({"file": Path(getattr(bcfg, "source", "accumulator") or "accumulator").name,
                                 "key": f"{sec}.{f.name}", "value_SI": v, "status": "ASSUMED (see that file)"})
    return pd.DataFrame(rows)


def status_counts(status: pd.DataFrame) -> dict:
    s = status[~status["status"].str.startswith("ASSUMED")]
    return {"confirmed": int((s["status"] == "confirmed").sum()),
            "placeholder": int((s["status"] == "PLACEHOLDER").sum()),
            "missing": int((s["status"] == "MISSING").sum())}


def load_car(vehicle=VEHICLE_FILE, powertrain=POWERTRAIN_FILE, track_set=TRACK_SET):
    """(cfg, evc, bcfg, status): vehicle config, EV powertrain config, accumulator config, input-status table.
    The track set's autocross / endurance files are applied to cfg.events."""
    import fsae_ev_bms as bms
    from fsae_vd.track_sets import load_track_set
    cfg, overlay = load_ev_vehicle(vehicle)
    evc = load_ev_config(powertrain)
    bcfg = bms.load_battery_config(evc.accumulator.config_file)
    if track_set:
        load_track_set(track_set, root=LAPSIM_ROOT).apply(cfg)
    return cfg, evc, bcfg, input_status(cfg, overlay, evc, bcfg)
