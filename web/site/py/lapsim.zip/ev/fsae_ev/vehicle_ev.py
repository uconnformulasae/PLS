"""The EV as an fsae_vd vehicle.

``EVVehicle`` is the same chassis model as the IC car (load transfer, roll, camber, kinematics from
the hardpoints, tires, aero: fsae_vd.Vehicle) and the same differential model (fsae_pt), with the
motor / inverter / accumulator in place of the engine and gearbox:

* drive force limit = the motor torque the accumulator can supply at each speed (EVTables);
* under braking the differential's coast side is loaded by the regen torque instead of engine braking.

``traction_ggv()`` (tires + differential only) is what the lap solver uses; the powertrain limit is
applied in the solver from the tables of the current SOC and temperatures.
"""
from __future__ import annotations

import numpy as np

from ._paths import LAPSIM_ROOT  # noqa: F401
from fsae_vd.vehicle import Vehicle
from fsae_pt.drivetrain import Differential
from fsae_pt.vehicle_pt import PTVehicle

from .config import EVConfig
from .powertrain import EVPowertrain, EVTables

ASSUMED_CRR = 0.020


class _DriveLimit:
    """Stands in for fsae_vd's Powertrain: the force the motor can put down at each speed."""

    def __init__(self, veh):
        self.veh = veh
        self.unlimited = False

    def available(self):
        return True

    def force(self, v):
        v = np.atleast_1d(np.asarray(v, float))
        if self.unlimited:
            return np.full(v.shape, np.inf)
        T = self.veh.tables0
        return np.interp(v, T.v, T.F) * (self.veh.m / T.meq)


class EVVehicle(PTVehicle):
    def __init__(self, cfg, evc: EVConfig, bcfg):
        cfg = cfg.copy()
        self.assumed = []
        if cfg.tires.rolling_resistance is None:
            cfg.tires.rolling_resistance = ASSUMED_CRR
            self.assumed.append(f"tires.rolling_resistance = {ASSUMED_CRR} (ASSUMED, fit a coast-down)")
        cfg.powertrain.kind = "EV"
        Vehicle.__init__(self, cfg)
        self.evc = self.ptc = evc
        self.bcfg = bcfg
        self.ep = self.dt = EVPowertrain(evc, bcfg, cfg.tires.tire_radius, self.m)
        self.cfg.powertrain.final_drive_ratio = self.ep.G
        self.diff = Differential(evc)
        self._tables0 = None
        self.pt = _DriveLimit(self)
        self.warnings += self.assumed

    # nominal tables (start-of-event SOC and temperatures)
    @property
    def tables0(self) -> EVTables:
        if self._tables0 is None:
            self._tables0 = self.tables()
        return self._tables0

    def tables(self, state=None, p_limit=None) -> EVTables:
        return EVTables(self.ep, getattr(self, "resist_drive", self.resist), state, p_limit)

    # ---------------------------------------------------------------- drive split
    def _wheel_fx(self, v, ax, st=None):
        need = self.m * ax + (self.resist_state(st) if st is not None else self.resist(v))
        drive = np.maximum(need, 0.0)
        brk = np.maximum(-need, 0.0)
        bias = self.bias if self.bias is not None else 0.6
        fo = fi = brk * bias / 2
        rb = brk * (1 - bias) / 2
        if st is None:
            return {"fo": fo, "fi": fi, "ro": drive / 2 + rb, "ri": drive / 2 + rb}, drive, brk
        kap_t = self.tr * np.abs(st["ay"]) / np.maximum(st["v"], 1.0) ** 2
        ci, co = self._rear_caps(st)
        Fi, Fo, ok = self.diff.split(drive, ci, co, st["Fz"]["ri"], st["Fz"]["ro"], kap_t, self.ep.r)
        if np.any(brk > 0) and self.diff.type != "open":
            # coast side of the diff: loaded by the regen torque at the axle (preload alone without regen)
            T = self.tables0
            t_regen = np.interp(st["v"], T.v, T.F_regen) * self.ep.r
            fi_k, fo_k = self.diff.locked_split(-2 * rb, ci, co, st["Fz"]["ri"], st["Fz"]["ro"], kap_t)
            lock_c = self.diff.lock_torque(t_regen, coast=True) / self.ep.r
            dF_c = np.where(brk > 0, np.minimum(np.maximum(fi_k - fo_k, 0.0), lock_c), 0.0)
        else:
            dF_c = np.zeros_like(drive)
        ro = np.where(brk > 0, rb + dF_c / 2, Fo)
        ri = np.where(brk > 0, np.abs(rb - dF_c / 2), Fi)
        self._diff_ok = np.where(brk > 0, True, ok)
        self._mz = np.where(brk > 0, -dF_c, Fo - Fi) * self.tr / 2
        return {"fo": fo, "fi": fi, "ro": ro, "ri": ri}, drive, brk
