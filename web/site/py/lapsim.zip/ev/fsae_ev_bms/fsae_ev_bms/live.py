"""Live battery telemetry: sources, the running estimator, a recorder and a dashboard.

Every source yields events ``(t, kind, index, value)``:
    kind  'current' (A, + discharge) | 'pack_voltage' (V) | 'cell_voltage' (V, index 0-based)
          | 'cell_temp' (degC, index) | 'pack_temp' (degC) | 'rpm'
Sources:
    ReplaySource(data, speed=1.0)       replay a logged run (BatteryData) in real time or faster
    UDPSource(port=5005)                telemetry radio -> laptop; one JSON object or CSV line per datagram
    CANSource(spec, channel, interface) python-can + a small signal map (see configs/ev_accumulator.yaml)
Run it:
    fb.live.run_dashboard(cfg, fb.live.UDPSource(5005), record="data/logs/live_run.csv")
    fb.live.run_console(cfg, source)    # text only (pit laptop / ssh)
The recorder writes every raw event; ``fb.load_battery_log`` reads that file
back, so the post-run smoother (``fb.estimate``) runs on exactly what came in.
"""
from __future__ import annotations

import csv
import json
import queue
import socket
import threading
import time
from collections import deque

import numpy as np

from .estimator import PackEstimator

KINDS = ("current", "pack_voltage", "cell_voltage", "cell_temp", "pack_temp", "inverter_current", "speed")


# --------------------------------------------------------------------------- sources
class ReplaySource:
    """Replay a BatteryData as a live stream (``speed`` x real time; 0 = as fast as possible)."""

    def __init__(self, data, speed=1.0, t_start=None):
        self.d, self.speed, self.t_start = data, speed, t_start

    def events(self):
        d = self.d
        ev = []
        if d.t_i is not None:
            ev += [(t, 0, "current", 0, x) for t, x in zip(d.t_i, d.i)]
        if d.v_cells is not None:
            for k, t in enumerate(d.t_v):
                for j in np.flatnonzero(np.isfinite(d.v_cells[k])):
                    ev.append((t, 1, "cell_voltage", int(j), float(d.v_cells[k, j])))
        elif d.v_pack is not None:
            ev += [(t, 1, "pack_voltage", 0, x) for t, x in zip(d.t_v, d.v_pack)]
        T = d.temp_sensors if d.temp_sensors is not None else d.temp
        if T is not None:
            for k, t in enumerate(d.t_temp):
                for j in range(T.shape[1]):
                    if np.isfinite(T[k, j]):
                        ev.append((t, 2, "cell_temp" if T.shape[1] > 1 else "pack_temp", j, float(T[k, j])))
        for key in ("inverter_current", "speed"):
            if key in d.aux:
                ev += [(t, 3, key, 0, float(x)) for t, x in zip(*d.aux[key]) if np.isfinite(x)]
        ev.sort(key=lambda e: (e[0], e[1]))
        if self.t_start is not None:
            ev = [e for e in ev if e[0] >= self.t_start]
        wall0, t0 = time.monotonic(), ev[0][0] if ev else 0.0
        for t, _, kind, idx, val in ev:
            if self.speed > 0:
                lag = (t - t0) / self.speed - (time.monotonic() - wall0)
                if lag > 0:
                    time.sleep(lag)
            yield t, kind, idx, val


class UDPSource:
    """Datagrams of JSON {"t":..., "current":..., "cells":[...], "temps":[...], "pack_voltage":...}
    or CSV lines 't,kind,index,value'. ``t`` missing -> arrival time."""

    def __init__(self, port=5005, host="0.0.0.0", timeout=0.5):
        self.addr, self.timeout = (host, port), timeout
        self.t0 = time.monotonic()

    def events(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.bind(self.addr)
        s.settimeout(self.timeout)
        try:
            while True:
                try:
                    msg, _ = s.recvfrom(65535)
                except socket.timeout:
                    continue
                yield from self._parse(msg.decode(errors="replace"))
        finally:
            s.close()

    def _parse(self, text):
        text = text.strip()
        if text.startswith("{"):
            o = json.loads(text)
            t = float(o.get("t", time.monotonic() - self.t0))
            if "current" in o:
                yield t, "current", 0, float(o["current"])
            if "pack_voltage" in o:
                yield t, "pack_voltage", 0, float(o["pack_voltage"])
            for j, v in enumerate(o.get("cells", []) or []):
                if v is not None:
                    yield t, "cell_voltage", j, float(v)
            for j, v in enumerate(o.get("temps", []) or []):
                if v is not None:
                    yield t, "cell_temp", j, float(v)
            if "rpm" in o:
                yield t, "rpm", 0, float(o["rpm"])
        else:
            for line in text.splitlines():
                p = line.split(",")
                if len(p) >= 4 and p[1] in KINDS:
                    yield float(p[0]), p[1], int(p[2]), float(p[3])


class CANSource:
    """CAN bus via python-can. ``spec`` is a list of signals:

        - {id: 0x100, start: 0, length: 16, scale: 0.1, offset: 0, signed: true,
           endian: little, kind: current}
        - {id: 0x101, start: 0, length: 16, scale: 0.0001, kind: cell_voltage, index_from: 0,
           count: 4}        # 4 consecutive 16-bit cell voltages per frame, cells index_from..+3
        - {id: 0x101, ..., mux_byte: 7}   # optional multiplexor byte -> index_from += mux * count

    Bit positions are Intel (little-endian) LSB-first or Motorola (big-endian) as
    in the BMS's DBC. Timestamps are the interface's hardware timestamps.
    """

    def __init__(self, spec, channel="can0", interface="socketcan", bitrate=500000):
        try:
            import can  # noqa: F401
        except ImportError as e:
            raise ImportError("CANSource needs 'pip install python-can'") from e
        self.spec, self.channel, self.interface, self.bitrate = spec, channel, interface, bitrate
        self.by_id = {}
        for s in spec:
            self.by_id.setdefault(int(s["id"]), []).append(s)

    @staticmethod
    def _field(data, start, length, signed, endian):
        if endian == "big":
            raw = int.from_bytes(bytes(data), "big")
            nbits = 8 * len(data)
            v = (raw >> (nbits - start - length)) & ((1 << length) - 1)
        else:
            raw = int.from_bytes(bytes(data), "little")
            v = (raw >> start) & ((1 << length) - 1)
        if signed and v >= 1 << (length - 1):
            v -= 1 << length
        return v

    def decode(self, arb_id, data, t):
        for s in self.by_id.get(arb_id, []):
            count = int(s.get("count", 1))
            base = int(s.get("index_from", s.get("index", 0)))
            if "mux_byte" in s:
                base += data[int(s["mux_byte"])] * count
            for k in range(count):
                v = self._field(data, int(s["start"]) + k * int(s["length"]), int(s["length"]),
                                bool(s.get("signed", False)), s.get("endian", "little"))
                yield t, s["kind"], base + k, v * float(s.get("scale", 1.0)) + float(s.get("offset", 0.0))

    def events(self):
        import can
        with can.Bus(channel=self.channel, interface=self.interface, bitrate=self.bitrate) as bus:
            t0 = None
            for msg in bus:
                if msg is None or msg.is_error_frame:
                    continue
                t0 = msg.timestamp if t0 is None else t0
                yield from self.decode(msg.arbitration_id, msg.data, msg.timestamp - t0)


def load_can_spec(path):
    """``can_signals`` list from a battery YAML (see configs/ev_accumulator_example.yaml)."""
    import yaml
    from pathlib import Path
    return (yaml.safe_load(Path(path).read_text()) or {}).get("can_signals", [])


# --------------------------------------------------------------------------- recorder + feed
class Recorder:
    """Writes every raw event to CSV (t,kind,index,value); readable by load_battery_log."""

    def __init__(self, path):
        self.fh = open(path, "w", newline="")
        self.w = csv.writer(self.fh)
        self.w.writerow(["t", "kind", "index", "value"])
        self.n = 0

    def write(self, t, kind, idx, val):
        self.w.writerow([f"{t:.6f}", kind, idx, f"{val:.6g}"])
        self.n += 1
        if self.n % 500 == 0:
            self.fh.flush()

    def close(self):
        self.fh.close()


def feed(est: PackEstimator, t, kind, idx, val, cell_buf=None):
    """Route one event into the estimator. Cell voltages arriving one by one are
    collected per timestamp (a BMS frame) before the update."""
    if kind == "current":
        est.current(t, val)
    elif kind == "pack_voltage":
        est.pack_voltage(t, val)
    elif kind == "cell_voltage":
        a = np.full(est.ns, np.nan)
        if 0 <= idx < est.ns:
            a[idx] = val
            est.cell_voltages(t, a)
    elif kind == "cell_temp":                 # LiveSession maps thermistors to groups; direct use = group index
        est.cell_temperature(t, idx, val)
    elif kind == "pack_temp":
        est.temperatures(t, np.full(est.ns, val))


class _CellFrameBuffer:
    """Merge single-cell voltage events with (nearly) the same timestamp into one update."""

    def __init__(self, est, window=0.02):
        self.est, self.window = est, window
        self.t = None
        self.v = np.full(est.ns, np.nan)

    def add(self, t, idx, val):
        if self.t is not None and t - self.t > self.window:
            self.flush()
        if self.t is None:
            self.t = t
        if 0 <= idx < self.est.ns:
            self.v[idx] = val

    def flush(self):
        if self.t is not None and np.isfinite(self.v).any():
            self.est.cell_voltages(self.t, self.v.copy())
        self.t = None
        self.v[:] = np.nan


class LiveSession:
    """Source thread -> queue -> estimator; keeps a history ring buffer for plotting."""

    def __init__(self, cfg, source, record=None, history_s=120.0, method=None, history_dt=0.1):
        self.cfg = cfg
        self.est = PackEstimator(cfg, method=method)
        self.src = source
        self.q = queue.Queue(maxsize=200000)
        self.rec = Recorder(record) if record else None
        self.cells = _CellFrameBuffer(self.est)
        self.hist = {k: deque() for k in ("t", "i", "i_est", "v", "soc", "soc_std", "soc_min", "soc_max", "p",
                                          "p_avg", "sop")}
        self.history_s = history_s
        self.history_dt = history_dt
        ns = cfg.pack.series
        # thermistors -> groups, plus an online core-to-can gradient per group (first-order lag)
        self.sensor_vals = {}
        self.can_temp = None
        self.core_dt = np.zeros(ns)
        th, npar = cfg.thermal, cfg.pack.parallel
        self._r_cs = th.r_core_surface / npar
        self._tau_c = th.core_fraction * th.cell_mass * th.cell_cp * npar * self._r_cs
        self._t_core = None
        # accumulator power monitor (instantaneous, sustained and moving-average checks)
        self._pw = deque()
        self._e = 0.0
        self._last_p = None
        self._above_since = None
        self.power = {"p": 0.0, "p_avg": 0.0, "events": 0, "events_avg": 0, "p_max": 0.0, "p_avg_max": 0.0}
        self._in_avg = False
        self.sop = None
        self._sop_t = -np.inf
        self.stop = threading.Event()
        self.n_events = 0
        self.thread = threading.Thread(target=self._pump, daemon=True)

    def start(self):
        self.thread.start()
        return self

    def _pump(self):
        try:
            for ev in self.src.events():
                if self.stop.is_set():
                    break
                self.q.put(ev)
        finally:
            self.q.put(None)

    def poll(self, max_events=50000):
        """Process queued events; returns False when the source has ended."""
        alive = True
        for _ in range(max_events):
            try:
                ev = self.q.get_nowait()
            except queue.Empty:
                break
            if ev is None:
                alive = False
                break
            t, kind, idx, val = ev
            self.n_events += 1
            if self.rec:
                self.rec.write(t, kind, idx, val)
            if kind == "cell_voltage":
                self.cells.add(t, idx, val)
            else:
                if self.cells.t is not None and t - self.cells.t > self.cells.window:
                    self.cells.flush()
                if kind == "cell_temp":
                    self._thermistor(t, idx, val)
                    continue
                feed(self.est, t, kind, idx, val)
                if kind == "current":
                    self._power(t, val)
            # history on the estimator's clock (not the screen's), so fast replays keep every point
            if self.est.ready and (not self.hist["t"] or self.est.t - self.hist["t"][-1] >= self.history_dt):
                self._snapshot()
        if not alive:
            self.cells.flush()
            self.est.flush()
        self._snapshot()
        return alive

    # ------------------------------------------------------------------ EV extras
    def _thermistor(self, t, idx, val):
        lo, hi = self.cfg.clean.temp_range
        if not (lo <= val <= hi):
            return                                    # open / shorted thermistor: ignore the sample
        self.sensor_vals[int(idx)] = float(val)
        from .io import sensor_positions, sensors_to_groups
        n = len(self.cfg.thermal.sensor_cells) if self.cfg.thermal.sensor_cells else max(self.sensor_vals) + 1
        pos = sensor_positions(self.cfg, n)
        row = np.array([self.sensor_vals.get(k, np.nan) for k in range(n)])
        if np.isfinite(row).any():
            self.can_temp = sensors_to_groups(row[None, :], pos, self.cfg.pack.series)[0]
            self.est.temperatures(t, self.can_temp + self.core_dt)

    def _update_core(self):
        """Core = can + gradient; the gradient follows q * R_cs with the core time constant."""
        est = self.est
        if not est.ready or est.t is None:
            return
        if self._t_core is None:
            self._t_core = est.t
            return
        dt = est.t - self._t_core
        if dt <= 0:
            return
        self._t_core = est.t
        f = est.B if est.B is not None else est.A
        from .chemistry import arrhenius
        g = f.x[:, f.ig] if f.ig is not None else 1.0
        gp = f.x[:, f.ip] if f.ip is not None else 1.0
        T = est.temp
        ar = arrhenius(T, est.p.ea, est.p.t_ref)
        i = est.u - est.bias_pack()
        from .cell import V1, V2
        v_rc = f.x[:, V1] + f.x[:, V2]
        if est.B is None:
            v_rc = np.repeat(v_rc, est.ns)
        q = i * (i * ar * est.p.r0 * g + v_rc)        # ohmic + polarisation loss from the filter's own states
        a = 1 - np.exp(-dt / self._tau_c)
        self.core_dt = self.core_dt + a * (q * self._r_cs - self.core_dt)
        if self.can_temp is not None:
            est.temp = self.can_temp + self.core_dt

    def _power(self, t, i):
        est = self.est
        v = est.v_pack if np.isfinite(est.v_pack) else (float(np.nansum(est.v_cells))
                                                        if np.isfinite(est.v_cells).any() else np.nan)
        if not np.isfinite(v):
            return
        lim = self.cfg.limits
        p = v * (i - est.bias_pack())
        if self._last_p is not None:
            t0, p0 = self._last_p
            if t > t0:
                self._e += 0.5 * (p + p0) * (t - t0)
        self._last_p = (t, p)
        self._pw.append((t, self._e))
        while len(self._pw) > 2 and self._pw[1][0] <= t - lim.power_avg_window:
            self._pw.popleft()
        tw, ew = self._pw[0]
        p_avg = (self._e - ew) / max(t - tw, 1e-6) if t - tw >= 0.8 * lim.power_avg_window else p
        P = self.power
        P["p"], P["p_avg"] = p, p_avg
        P["p_max"] = max(P["p_max"], p)
        P["p_avg_max"] = max(P["p_avg_max"], p_avg)
        if p > lim.max_power:
            if self._above_since is None:
                self._above_since = t
            elif t - self._above_since >= lim.power_window and not P.get("_counted"):
                P["events"] += 1
                P["_counted"] = True
        else:
            self._above_since = None
            P["_counted"] = False
        if p_avg > lim.max_power and not self._in_avg:
            P["events_avg"] += 1
        self._in_avg = p_avg > lim.max_power

    def _update_sop(self):
        est = self.est
        if not est.ready or est.t - self._sop_t < 1.0:
            return
        self._sop_t = est.t
        from .cell import SOC, V1, V2, H
        from .sop import state_of_power
        f = est.B if est.B is not None else est.A
        rep_ = (lambda a: np.repeat(a, est.ns)) if est.B is None else (lambda a: a)
        x = f.x
        g = x[:, f.ig] if f.ig is not None else np.ones(f.N)
        gp = x[:, f.ip] if f.ip is not None else np.ones(f.N)
        out = {}
        for hz in self.cfg.sop.horizons:
            r = state_of_power(self.cfg, rep_(x[:, SOC]), rep_(np.sqrt(f.P[:, SOC, SOC])), rep_(x[:, V1]),
                               rep_(x[:, V2]), rep_(x[:, H]), rep_(g), est.temp, hz, rpol_mult=rep_(gp), iters=32)
            out[hz] = {k: (v[0] if np.ndim(v) else v) for k, v in r.items() if k in
                       ("p_dis", "p_chg", "i_dis", "i_chg", "limit_cell_dis", "reason_dis", "limit_cell_chg", "reason_chg")}
        self.sop = out

    def _snapshot(self):
        self._update_core()
        self._update_sop()
        s = self.est.snapshot()
        if not s.get("ready"):
            return
        h = self.hist
        if h["t"] and s["t"] <= h["t"][-1]:
            return
        for k, v in (("t", s["t"]), ("i", s["i_meas"]), ("i_est", s["i_est"]), ("v", s["v_pack"]),
                     ("soc", s["soc_pack"]), ("soc_std", s["soc_pack_std"]), ("soc_min", s["soc_min"]),
                     ("soc_max", float(np.max(s["soc"]))), ("p", s["power"]), ("p_avg", self.power["p_avg"]),
                     ("sop", self.sop[self.cfg.sop.horizons[0]]["p_dis"] if self.sop else np.nan)):
            h[k].append(v)
        while h["t"] and h["t"][-1] - h["t"][0] > self.history_s:
            for d in h.values():
                d.popleft()

    def status(self):
        """Estimator snapshot plus power-limit monitor and state of power."""
        s = self.est.snapshot()
        if not s.get("ready"):
            return s
        s["power_monitor"] = dict(self.power)
        s["sop"] = self.sop
        lim = self.cfg.limits
        if self.power["p_avg"] > 0.95 * lim.max_power:
            s["warnings"].append(f"power {self.power['p_avg'] / 1e3:.1f} kW avg near the {lim.max_power / 1e3:.0f} kW limit")
        if self.power["events"] or self.power["events_avg"]:
            s["warnings"].append(f"power limit exceeded {self.power['events']}x (>{1e3 * lim.power_window:.0f} ms), "
                                 f"{self.power['events_avg']}x ({1e3 * lim.power_avg_window:.0f} ms avg)")
        return s

    def close(self):
        self.stop.set()
        if self.rec:
            self.rec.close()


# --------------------------------------------------------------------------- front ends
def run_console(cfg, source, record=None, every=1.0, method=None):
    """Print a status line every ``every`` seconds until the source ends."""
    ses = LiveSession(cfg, source, record=record, method=method).start()
    last = 0.0
    try:
        while True:
            alive = ses.poll()
            now = time.monotonic()
            if now - last >= every or not alive:
                last = now
                print(status_line(ses.status()), flush=True)
            if not alive:
                break
            time.sleep(0.02)
    except KeyboardInterrupt:
        pass
    finally:
        ses.close()
    return ses


def status_line(s):
    if not s.get("ready"):
        return "waiting for current + voltage ..."
    w = ("  !! " + "; ".join(s["warnings"])) if s["warnings"] else ""
    pm = s.get("power_monitor")
    p_txt = f"P {s['power'] / 1e3:6.1f} kW" + (f" (avg {pm['p_avg'] / 1e3:5.1f})" if pm else "")
    sop = s.get("sop")
    sop_txt = ""
    if sop:
        h0 = min(sop)
        sop_txt = f"  avail {sop[h0]['p_dis'] / 1e3:.1f}/{-sop[h0]['p_chg'] / 1e3:.1f} kW ({h0:g}s)"
    return (f"t={s['t']:8.1f}s  SOC {100 * s['soc_pack']:5.1f}% (+/-{100 * s['soc_pack_std']:.1f}, min cell "
            f"{100 * s['soc_min']:.1f}%)  I {s['i_est']:7.1f} A  V {s['v_pack']:7.1f} V  {p_txt}{sop_txt}  "
            f"cells {np.nanmin(s['v_cells']):.3f}-{np.nanmax(s['v_cells']):.3f} V  T max {np.max(s['temp']):.1f} C  "
            f"used {s['ah']:.2f} Ah / {s['wh']:.0f} Wh{w}")


def run_dashboard(cfg, source, record=None, window=60.0, interval_ms=200, method=None, block=True):
    """Matplotlib live dashboard: current, power vs limit and available power, SOC +/- 2 sigma,
    cell voltages, cell temperatures, status line."""
    import matplotlib.pyplot as plt
    from matplotlib.animation import FuncAnimation
    from . import plots as pb

    ses = LiveSession(cfg, source, record=record, history_s=window, method=method).start()
    ns = cfg.pack.series
    fig = plt.figure(figsize=(14, 8.5))
    gs = fig.add_gridspec(4, 3, height_ratios=[1, 1, 1, 0.35], hspace=0.55, wspace=0.28)
    ax_i = fig.add_subplot(gs[0, :2])
    ax_v = fig.add_subplot(gs[1, :2], sharex=ax_i)
    ax_s = fig.add_subplot(gs[2, :2], sharex=ax_i)
    ax_c = fig.add_subplot(gs[0:2, 2])
    ax_t = fig.add_subplot(gs[2, 2])
    ax_txt = fig.add_subplot(gs[3, :])
    ax_txt.axis("off")
    li_m, = ax_i.plot([], [], color=pb.GREY, lw=1.0, label="measured")
    li_e, = ax_i.plot([], [], color=pb.CAT[0], lw=1.6, label="offset-corrected")
    ax_i.set(title="Pack current", ylabel="A")
    ax_i.legend(loc="upper left", ncol=2)
    lv, = ax_v.plot([], [], color=pb.GREY, lw=1.0, label="power")
    lva, = ax_v.plot([], [], color=pb.CAT[1], lw=1.6, label=f"{1e3 * cfg.limits.power_avg_window:.0f} ms avg")
    lvs, = ax_v.plot([], [], color=pb.CAT[3], lw=1.4, ls="--", label=f"available ({cfg.sop.horizons[0]:g} s)")
    ax_v.axhline(cfg.limits.max_power / 1e3, color=pb.CRIT, lw=1, ls=":", label="limit")
    ax_v.set(title="Accumulator power", ylabel="kW")
    ax_v.legend(loc="lower left", ncol=4, fontsize=8)
    band = [None]
    ls, = ax_s.plot([], [], color=pb.CAT[2], lw=1.8, label="pack SOC")
    lmin, = ax_s.plot([], [], color=pb.CAT[2], lw=1.0, ls="--", label="weakest cell")
    ax_s.set(title="State of charge (band = 2 sigma)", ylabel="%", xlabel="time [s]")
    ax_s.legend(loc="upper right", ncol=2)
    idx = np.arange(1, ns + 1)
    bars = ax_c.bar(idx, np.zeros(ns), color=pb.CAT[0], width=0.8)
    p = cfg.params()
    ax_c.axhline(p.v_min, color=pb.CRIT, lw=1, ls=":")
    ax_c.axhline(p.v_max, color=pb.CRIT, lw=1, ls=":")
    ax_c.set(title="Cell voltages", xlabel="cell", ylabel="V")
    tbars = ax_t.bar(idx, np.zeros(ns), color=pb.CAT[3], width=0.8)
    ax_t.axhline(p.t_max, color=pb.CRIT, lw=1, ls=":")
    ax_t.set(title="Cell temperatures", xlabel="cell", ylabel="degC")
    txt = ax_txt.text(0.0, 0.5, "waiting for data ...", fontsize=9, family="monospace", va="center")

    def update(_):
        alive = ses.poll()
        h = ses.hist
        if not h["t"]:
            return []
        t = np.array(h["t"])
        li_m.set_data(t, np.array(h["i"]))
        li_e.set_data(t, np.array(h["i_est"]))
        pk = np.array(h["p"]) / 1e3
        pa = np.array(h["p_avg"]) / 1e3
        sp = np.array(h["sop"], float) / 1e3
        lv.set_data(t, pk)
        lva.set_data(t, pa)
        lvs.set_data(t, sp)
        soc, sd = 100 * np.array(h["soc"]), 100 * np.array(h["soc_std"])
        ls.set_data(t, soc)
        lmin.set_data(t, 100 * np.array(h["soc_min"]))
        if band[0] is not None:
            band[0].remove()
        band[0] = ax_s.fill_between(t, soc - 2 * sd, soc + 2 * sd, color=pb.CAT[2], alpha=0.18, lw=0)
        for ax, ys in ((ax_i, np.r_[h["i"], h["i_est"]]), (ax_v, np.r_[pk, pa, sp[np.isfinite(sp)], cfg.limits.max_power / 1e3]), (ax_s, np.r_[soc - 2 * sd, soc + 2 * sd, 100 * np.array(h["soc_min"])])):
            lo, hi = np.nanmin(ys), np.nanmax(ys)
            pad = 0.08 * max(hi - lo, 1e-3)
            ax.set_ylim(lo - pad, hi + pad)
        ax_i.set_xlim(max(t[-1] - window, t[0]), t[-1] + 1e-3)
        s = ses.status()
        vc = s["v_cells"]
        for b, v in zip(bars, vc):
            b.set_height(v if np.isfinite(v) else 0)
        fin = vc[np.isfinite(vc)]
        if fin.size:
            ax_c.set_ylim(min(fin.min(), p.v_min) - 0.05, max(fin.max(), p.v_max) + 0.05)
        for b, v in zip(tbars, s["temp"]):
            b.set_height(v)
        ax_t.set_ylim(min(s["temp"].min(), 15) - 2, max(s["temp"].max(), p.t_max) + 3)
        import textwrap
        txt.set_text("\n".join(textwrap.wrap(status_line(s) + ("" if alive else "   [source ended]"), 150)))
        return []

    anim = FuncAnimation(fig, update, interval=interval_ms, cache_frame_data=False)
    fig._anim = anim
    if block:
        try:
            plt.show()
        finally:
            ses.close()
    return ses, fig
