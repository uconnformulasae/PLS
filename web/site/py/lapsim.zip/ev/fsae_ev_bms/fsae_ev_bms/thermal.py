"""Cell temperature estimation: core and can temperature of every group, including
the groups without a thermistor.

Model (per series group j, Np physical cells in parallel):
    Cc dTc_j/dt = q_j - Gcs (Tc_j - Ts_j)
    Cs dTs_j/dt = Gcs (Tc_j - Ts_j) - Gsa (Ts_j - Ta) - Gnb sum_k (Ts_j - Ts_k)   (k = neighbours j-1, j+1)
    dTa/dt      = w                    (air / coolant temperature, estimated)
Heat q_j = i * (OCV_j(SOC_j, T) - v_j): the cell's own measured loss (ohmic + polarisation +
hysteresis), optionally plus the reversible heat -i T dOCV/dT.

Linear and time-invariant, so it is discretised exactly (matrix exponential, zero-order hold
on the heat over each step), filtered with a Kalman filter on the thermistor readings and
smoothed with RTS. The thermistors measure can temperature; the electrical model needs core
temperature, which is what this returns per group with its 1-sigma.
"""
from __future__ import annotations

import dataclasses as dc

import numpy as np
from scipy.linalg import expm


@dc.dataclass
class ThermalResult:
    t: np.ndarray            # thermal grid [s]
    core: np.ndarray         # (K, Ns) degC, smoothed
    core_std: np.ndarray
    surface: np.ndarray      # (K, Ns)
    surface_std: np.ndarray
    ambient: np.ndarray      # (K,)
    heat: np.ndarray         # (K, Ns) W per group
    sensor_resid: np.ndarray  # (K, n_sensors) measured - predicted (filter), K
    sensor_cells: np.ndarray
    params: dict

    def at(self, t):
        """Core temperature (Ns,) interpolated to times t -> (len(t), Ns)."""
        return np.column_stack([np.interp(t, self.t, self.core[:, j]) for j in range(self.core.shape[1])])


def _matrices(cfg, ns, dt):
    th, npar = cfg.thermal, cfg.pack.parallel
    mcp = th.cell_mass * th.cell_cp * npar
    Cc, Cs = th.core_fraction * mcp, (1 - th.core_fraction) * mcp
    Gcs, Gsa, Gnb = npar / th.r_core_surface, npar / th.r_surface_ambient, th.neighbour_conductance
    n = 2 * ns + 1                                   # [Tc_0..Tc_N-1, Ts_0..Ts_N-1, Ta]
    A = np.zeros((n, n))
    c, s, a = np.arange(ns), ns + np.arange(ns), 2 * ns
    A[c, c] = -Gcs / Cc
    A[c, s] = Gcs / Cc
    A[s, c] = Gcs / Cs
    A[s, s] = -(Gcs + Gsa) / Cs
    A[s, a] = Gsa / Cs
    for j in range(ns - 1):                          # neighbouring groups exchange heat through the can
        A[s[j], s[j]] -= Gnb / Cs
        A[s[j + 1], s[j + 1]] -= Gnb / Cs
        A[s[j], s[j + 1]] += Gnb / Cs
        A[s[j + 1], s[j]] += Gnb / Cs
    B = np.zeros((n, ns))
    B[c, c] = 1.0 / Cc
    M = np.zeros((n + ns, n + ns))
    M[:n, :n], M[:n, n:] = A, B
    E = expm(M * dt)                                 # exact ZOH discretisation
    Phi, Gam = E[:n, :n], E[:n, n:]
    # process noise: model error on every node (Van Loan) + ambient random walk
    Qc = np.zeros((n, n))
    Qc[np.arange(2 * ns), np.arange(2 * ns)] = th.model_walk ** 2
    Qc[a, a] = (0.2 * th.model_walk) ** 2
    V = np.zeros((2 * n, 2 * n))
    V[:n, :n], V[:n, n:], V[n:, n:] = -A, Qc, A.T
    W = expm(V * dt)
    Q = Phi @ W[:n, n:]
    Q = 0.5 * (Q + Q.T)
    return Phi, Gam, Q, {"Cc": Cc, "Cs": Cs, "Gcs": Gcs, "Gsa": Gsa, "Gnb": Gnb}


def simulate(cfg, t, heat, t_amb=None, x0=None):
    """Truth simulator (for synthetic data): heat (len(t), Ns) W per group on a uniform grid t."""
    ns = cfg.pack.series
    dt = float(t[1] - t[0])
    Phi, Gam, _, _ = _matrices(cfg, ns, dt)
    ta = cfg.thermal.ambient if t_amb is None else t_amb
    x = np.full(2 * ns + 1, float(ta)) if x0 is None else np.asarray(x0, float).copy()
    out = np.empty((len(t), 2 * ns + 1))
    out[0] = x
    for k in range(1, len(t)):
        x = Phi @ x + Gam @ heat[k - 1]
        out[k] = x
    return out[:, :ns], out[:, ns:2 * ns], out[:, 2 * ns]


def heat_from_result(res, t_grid):
    """Average heat per group over each thermal step from the electrical estimate:
    q = i * (OCV(SOC, T) - v_cell) at every voltage sample, bin-averaged (energy-conserving)."""
    p = res.cfg.params()
    soc = res.soc
    T = res.temp
    ocv = p.ocv(soc, T)
    v = np.where(np.isfinite(res.v_meas), res.v_meas, res.v_model)
    q = res.i_est[:, None] * (ocv - v)
    if res.cfg.thermal.entropic_heat and p.ocv.docv_dt:
        q = q - res.i_est[:, None] * (T + 273.15) * p.ocv.docv_dt
    edges = np.r_[t_grid - 0.5 * (t_grid[1] - t_grid[0]), t_grid[-1] + 0.5 * (t_grid[1] - t_grid[0])]
    b = np.clip(np.searchsorted(edges, res.t, side="right") - 1, 0, len(t_grid) - 1)
    out = np.zeros((len(t_grid), q.shape[1]))
    cnt = np.bincount(b, minlength=len(t_grid)).astype(float)
    for j in range(q.shape[1]):
        out[:, j] = np.bincount(b, weights=np.nan_to_num(q[:, j]), minlength=len(t_grid))
    with np.errstate(invalid="ignore"):
        out = out / cnt[:, None]
    # fill empty bins by interpolation
    good = cnt > 0
    for j in range(out.shape[1]):
        out[~good, j] = np.interp(t_grid[~good], t_grid[good], out[good, j])
    return out


def estimate_temperatures(cfg, t_sensor, T_sensor, sensor_cells, t_grid, heat, heat_sigma=None):
    """Kalman filter + RTS smoother of the thermal model on the thermistor readings."""
    ns = cfg.pack.series
    dt = float(t_grid[1] - t_grid[0])
    Phi, Gam, Q0, prm = _matrices(cfg, ns, dt)
    n = 2 * ns + 1
    th = cfg.thermal
    pos = np.asarray(sensor_cells, int)
    nsens = T_sensor.shape[1]
    # thermistor readings averaged into the grid bins
    edges = np.r_[t_grid - 0.5 * dt, t_grid[-1] + 0.5 * dt]
    b = np.searchsorted(edges, t_sensor, side="right") - 1
    inside = (b >= 0) & (b < len(t_grid))
    Y = np.full((len(t_grid), nsens), np.nan)
    Ny = np.zeros((len(t_grid), nsens))
    for j in range(nsens):
        ok = inside & np.isfinite(T_sensor[:, j])
        cnt = np.bincount(b[ok], minlength=len(t_grid))
        sm = np.bincount(b[ok], weights=T_sensor[ok, j], minlength=len(t_grid))
        with np.errstate(invalid="ignore", divide="ignore"):
            Y[:, j] = np.where(cnt > 0, sm / cnt, np.nan)
        Ny[:, j] = cnt
    r_meas = th.sensor_noise ** 2
    quant = (0.1 ** 2) / 12
    # initial state from the first readings
    first = np.array([Y[np.flatnonzero(np.isfinite(Y[:, j]))[0], j] if np.isfinite(Y[:, j]).any() else np.nan
                      for j in range(nsens)])
    okf = np.isfinite(first)
    T0 = np.interp(np.arange(ns), pos[okf], first[okf]) if okf.any() else np.full(ns, th.ambient)
    x = np.r_[T0, T0, th.ambient if not okf.any() else float(np.min(first[okf]))]
    dist = np.min(np.abs(np.arange(ns)[:, None] - pos[okf][None, :]), axis=1) if okf.any() else np.full(ns, ns)
    s0 = 0.5 + 0.2 * np.minimum(dist, 10)            # less certain far from a thermistor
    P = np.diag(np.r_[s0 ** 2, s0 ** 2, 5.0 ** 2])
    # heat uncertainty: one level per group for the whole run, so the model is time-invariant and the
    # covariance converges; then only the steps where it still changes are stored (memory ~ MB, not GB)
    if heat_sigma is None:
        heat_sigma = 0.1 * np.sqrt(np.mean(heat ** 2, axis=0)) + 0.05
    heat_sigma = np.broadcast_to(np.asarray(heat_sigma, float), (ns,))
    Q = Q0 + (Gam * heat_sigma ** 2) @ Gam.T
    Q = 0.5 * (Q + Q.T)
    K_ = len(t_grid)
    xs_p, xs_f = np.empty((K_, n)), np.empty((K_, n))
    store_p, store_f = [], []                        # distinct covariances
    ip = np.empty(K_, int)                           # index of P_pred / P_filt used at each step
    resid = np.full((K_, nsens), np.nan)
    surf = ns + pos
    prev_mask, steady, Pf_prev = None, False, None
    Kss = None
    for k in range(K_):
        ok = np.isfinite(Y[k])
        mask = ok.tobytes()
        if k:
            x = Phi @ x + Gam @ heat[k - 1]
        xs_p[k] = x
        if steady and mask == prev_mask:
            # converged covariance, same sensors: reuse it (and the gain)
            ip[k] = ip[k - 1]
            if ok.any():
                idx = surf[ok]
                e = Y[k, ok] - x[idx]
                resid[k, ok] = e
                x = x + Kss @ e
            xs_f[k] = x
            continue
        if k:
            P = Phi @ P @ Phi.T + Q
        Pp = P
        Kg = None
        if ok.any():
            idx = surf[ok]
            e = Y[k, ok] - x[idx]
            resid[k, ok] = e
            S = P[np.ix_(idx, idx)] + np.diag(r_meas / np.maximum(Ny[k, ok], 1) + quant)
            Kg = np.linalg.solve(S, P[:, idx].T).T
            x = x + Kg @ e
            P = P - Kg @ S @ Kg.T
            P = 0.5 * (P + P.T)
        xs_f[k] = x
        store_p.append(Pp)
        store_f.append(P)
        ip[k] = len(store_f) - 1
        if Pf_prev is not None and mask == prev_mask:
            steady = np.max(np.abs(P - Pf_prev)) < 1e-10 * max(np.max(np.abs(P)), 1e-12)
            Kss = Kg
        else:
            steady = False
        Pf_prev, prev_mask = P, mask
    # RTS smoother: only the current smoothed covariance is kept; gains cached per covariance pair
    xs = xs_f.copy()
    sd = np.empty((K_, n))
    Ps = store_f[ip[-1]]
    sd[-1] = np.sqrt(np.maximum(np.diag(Ps), 0))
    gains = {}
    for k in range(K_ - 2, -1, -1):
        key = (ip[k], ip[k + 1])
        if key not in gains:
            gains[key] = np.linalg.solve(store_p[ip[k + 1]], Phi @ store_f[ip[k]]).T
        G = gains[key]
        xs[k] = xs_f[k] + G @ (xs[k + 1] - xs_p[k + 1])
        Pk = store_f[ip[k]] + G @ (Ps - store_p[ip[k + 1]]) @ G.T
        Ps = 0.5 * (Pk + Pk.T)
        sd[k] = np.sqrt(np.maximum(np.diag(Ps), 0))
    # the core-to-can gradient is heat x r_core_surface; thermistors on the can cannot observe that
    # resistance, so its uncertainty is added to the core +/- (consider-parameter treatment)
    grad = xs[:, :ns] - xs[:, ns:2 * ns]
    core_sd = np.sqrt(sd[:, :ns] ** 2 + (th.gradient_uncertainty * grad) ** 2)
    return ThermalResult(t=t_grid, core=xs[:, :ns], core_std=core_sd, surface=xs[:, ns:2 * ns],
                         surface_std=sd[:, ns:2 * ns], ambient=xs[:, -1], heat=heat, sensor_resid=resid,
                         sensor_cells=pos, params=prm)
