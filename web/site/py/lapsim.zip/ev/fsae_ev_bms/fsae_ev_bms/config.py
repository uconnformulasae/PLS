"""EV accumulator configuration: topology, cell model, sensors, filter tuning,
data cleaning, thermal model, rule limits, state of power, balancing, channels.

Loaded from ``configs/ev_accumulator.yaml``; change anything with
``cfg.set("cell.r0", 0.014)``. Values may be SI numbers or strings with units
("14 mOhm", "4.2 Ah", "2 mV", "80 kW", "6 MJ"). Temperatures are degC.

Terminology: a *cell* here is one series element as the BMS sees it, i.e. a
parallel group of ``pack.parallel`` physical cells. Cell parameters in the file
are for ONE physical cell; the group values (capacity x Np, resistance / Np)
are formed internally.
"""
from __future__ import annotations

import copy
import dataclasses as dc
from pathlib import Path
from typing import Optional

import numpy as np
import yaml

from .units import parse_quantity

from .chemistry import OCV, PRESETS


@dc.dataclass
class Pack:
    series: int = 140                    # cells (parallel groups) in series
    parallel: int = 4                    # physical cells per group
    segments: int = 7                    # accumulator segments (rules limit voltage and energy per segment)
    interconnect_resistance: float = 0.0  # ohm, busbars + fuses + contactors + MSD between terminals and cells
    name: str = "accumulator"

    def segment_of(self, group):
        """0-based segment of a 0-based group (groups split evenly, in series order)."""
        per = -(-self.series // self.segments)
        return np.asarray(group) // per


@dc.dataclass
class Cell:
    chemistry: str = "nmc"
    capacity_ah: Optional[float] = None
    r0: Optional[float] = None           # ohm at t_ref, ohmic
    r1: Optional[float] = None           # ohm, fast RC (charge transfer)
    tau1: Optional[float] = None         # s
    r2: Optional[float] = None           # ohm, slow RC (diffusion); 0 -> 1-RC model
    tau2: Optional[float] = None         # s
    hyst_m: Optional[float] = None       # V, dynamic hysteresis amplitude
    hyst_m0: Optional[float] = None      # V, instantaneous hysteresis on current sign change
    hyst_gamma: Optional[float] = None   # -, hysteresis rate (1/gamma ~ SOC swing to settle)
    eta_charge: Optional[float] = None   # coulombic efficiency on charge
    ea_r: Optional[float] = None         # J/mol, Arrhenius activation energy for R0/R1/R2
    t_ref: float = 25.0                  # degC at which r0/r1/r2 are given
    v_min: Optional[float] = None
    v_max: Optional[float] = None
    docv_dt: Optional[float] = None      # V/K entropic OCV coefficient
    ocv_soc: Optional[list] = None       # override the preset OCV table
    ocv_v: Optional[list] = None
    r0_soc: Optional[list] = None        # optional R0 multiplier vs SOC (rises at low SOC)
    r0_soc_factor: Optional[list] = None
    capacity_scale: Optional[list] = None  # per-cell capacity multipliers (cell-to-cell spread), len = series
    r0_scale: Optional[list] = None        # per-cell R0 multipliers
    t_max: float = 60.0                  # degC warning limit

    def resolved(self):
        """Preset values with every explicit entry in this section overriding them."""
        if self.chemistry not in PRESETS:
            raise ValueError(f"unknown chemistry '{self.chemistry}' (choose from {list(PRESETS)})")
        out = dict(PRESETS[self.chemistry])
        for f in dc.fields(self):
            v = getattr(self, f.name)
            if v is not None:
                out[f.name] = v
        return out


@dc.dataclass
class Sensors:
    cell_voltage_noise: float = 2e-3     # V, 1-sigma per cell-voltage sample (BMS ADC)
    pack_voltage_noise: float = 20e-3    # V, 1-sigma pack voltage sample
    current_noise: float = 0.1           # A, 1-sigma white noise per current sample
    current_offset: float = 0.0          # A, known offset (e.g. from io.offset_from_window at key-off); prior mean
    current_bias_std: float = 0.2        # A, 1-sigma of the offset around that value
    current_bias_walk: float = 1e-3      # A/sqrt(s), drift of the offset
    current_gain_error: float = 0.0      # fraction, known gain correction applied to current (I *= 1+g)
    voltage_delay: float = 0.0           # s, voltage samples lag the current samples by this much
    current_sign: float = 1.0            # set -1 if the logged current is positive on charge


@dc.dataclass
class Filter:
    method: str = "iekf"                 # 'ekf' | 'iekf' (iterated) | 'ukf'
    iekf_iterations: int = 3
    initial_soc: Optional[float] = None  # None -> from the first rest voltage via OCV^-1
    initial_soc_std: Optional[float] = None  # None -> from voltage noise / OCV slope + hysteresis
    estimate_bias: bool = True           # current-sensor offset as a state
    estimate_r0: bool = True             # per-cell R0 multiplier as a state (ageing / temperature error)
    soc_walk: float = 1e-6               # 1/sqrt(s), unmodelled SOC drift (self-discharge, gain error)
    v_rc_walk: float = 2e-4              # V/sqrt(s), RC-voltage model error
    hyst_walk: float = 5e-3              # 1/sqrt(s)
    r0_walk: float = 2e-3                # 1/sqrt(s) on the R0 multiplier
    r0_mult_std: float = 0.15            # initial 1-sigma of the R0 multiplier
    estimate_capacity: Optional[object] = None  # capacity multiplier: True (estimated), 'consider' (uncertainty
                                         # carried, never adjusted - Schmidt filter), False; None = chemistry default
                                         # (True for NMC; 'consider' for LFP, whose flat OCV cannot separate it from SOC)
    capacity_std: float = 0.05           # prior 1-sigma of the capacity (5 % of nominal)
    model_error: Optional[float] = None  # V, slowly varying voltage-model error (Gauss-Markov state); None = chemistry
    model_error_tau: Optional[float] = None  # s, its correlation time
    capacity_walk: float = 1e-6          # 1/sqrt(s)
    init_hypotheses: int = 15            # post-run: initial-SOC grid points (x3 hysteresis states) scored by
                                         # likelihood before the final pass; 0 = off. Fixes flat-OCV (LFP) starts
    gate_probability: float = 0.9999     # innovation chi-square gate (outlier rejection)
    max_rejections: int = 5              # consecutive rejections before the gate reopens (re-convergence)
    thermal_coupling: bool = True        # post-run: re-run with estimated core temperatures (two-way coupling)
    adaptive_r: bool = False             # innovation-based measurement-noise adaptation
    adaptive_forgetting: float = 0.995
    smoother_iterations: int = 2         # post-run: iterated extended RTS smoother passes
    ukf_alpha: float = 1e-1
    ukf_beta: float = 2.0
    ukf_kappa: float = 0.0


@dc.dataclass
class Channels:
    """Raw logger channel names. Strings are exact names; 're:' prefix means a regex
    whose first group is the 1-based cell / sensor index."""
    pack_voltage: Optional[str] = "re:^(?:pack[ _]?v(?:olt(?:age)?)?|ivt[ _]?u1|hv[ _]?voltage)$"
    pack_current: Optional[str] = "re:^(?:pack[ _]?(?:i|current)|ivt[ _]?i|hv[ _]?current)$"
    cell_voltage: Optional[str] = "re:^cell[ _]?v(?:olt(?:age)?)?[ _]?(\\d+)$"
    cell_temp: Optional[str] = "re:^(?:cell[ _]?)?t(?:emp)?[ _]?(\\d+)$"
    pack_temp: Optional[str] = None
    inverter_current: Optional[str] = None   # inverter DC-link current: cross-check of the pack current sensor
    speed: Optional[str] = None               # vehicle speed [m/s or km/h], for energy per km
    lap_marker: Optional[str] = None          # beacon / lap counter channel
    units: dict = dc.field(default_factory=dict)   # raw name -> unit, overrides the logger's unit


@dc.dataclass
class Thermal:
    """Two-node (core, surface) thermal model per group, coupled to neighbours and to the coolant/air."""
    ambient: float = 25.0                # degC, air / coolant temperature
    cell_mass: float = 0.068             # kg per physical cell (21700)
    cell_cp: float = 1000.0              # J/(kg K)
    core_fraction: float = 0.5           # share of the heat capacity in the core node
    r_core_surface: float = 2.0          # K/W per physical cell, core -> can (radial conduction)
    r_surface_ambient: float = 15.0      # K/W per physical cell, can -> air / cold plate
    neighbour_conductance: float = 0.05  # W/K between adjacent groups (busbars, potting)
    sensor_cells: Optional[list] = None  # 1-based group each temperature sensor sits on; None = spread evenly
    sensor_noise: float = 0.5            # K, 1-sigma per thermistor sample
    model_walk: float = 0.1              # K/sqrt(s), thermal-model error (covers ~20 % parameter error)
    entropic_heat: bool = False          # add reversible heat i*T*dOCV/dT
    dt: float = 1.0                      # s, thermal step (cores move several K within a few seconds)
    gradient_uncertainty: float = 0.25   # relative 1-sigma of the core-to-can gradient: can-mounted thermistors
                                         # cannot observe it, so the r_core_surface uncertainty goes into core +/-


@dc.dataclass
class Limits:
    """Rule and cell limits. Defaults follow the FSAE EV rules as commonly applied and a
    high-power 21700 datasheet - CHECK THE CURRENT RULEBOOK AND YOUR CELL DATASHEET."""
    max_power: float = 80e3              # W at the accumulator
    power_window: float = 0.1            # s, continuous time above max_power that counts as a violation
    power_avg_window: float = 0.5        # s, moving-average window also checked against max_power
    max_pack_voltage: float = 600.0      # V
    max_segment_voltage: float = 120.0   # V
    max_segment_energy: float = 6e6      # J
    cell_t_max: float = 60.0             # degC, rule / shutdown limit
    cell_t_derate: float = 50.0          # degC, start of linear current derating (to zero at cell_t_max)
    cell_t_min_charge: float = 0.0       # degC, no charging (regen) below this
    min_temp_monitor_fraction: float = 0.2  # share of cells with a temperature sensor
    i_dis_cont: float = 30.0             # A per physical cell, continuous discharge
    i_dis_peak: float = 45.0             # A per physical cell, peak (<= sop horizon)
    i_chg_peak: float = 8.4              # A per physical cell, regen / charge
    soc_min: float = 0.0                 # SOC floor for state of power
    soc_max: float = 1.0


@dc.dataclass
class Clean:
    """Data conditioning applied before estimation (see clean.py)."""
    enabled: bool = True
    cell_v_range: list = dc.field(default_factory=lambda: [1.5, 4.6])   # V, outside = invalid / open wire
    temp_range: list = dc.field(default_factory=lambda: [-30.0, 110.0])  # degC, outside = sensor fault
    current_range: list = dc.field(default_factory=lambda: [-1000.0, 1000.0])  # A
    hampel_window: int = 11              # samples, robust spike filter (median / MAD)
    hampel_sigma: float = 6.0            # reject |x - median| > this * 1.4826 MAD (and > hampel_floor)
    hampel_floor_v: float = 0.02         # V, never flag deviations smaller than this
    stuck_window: float = 20.0           # s, constant while the pack current moves -> stuck channel
    max_gap: float = 1.0                 # s, report gaps longer than this
    align_delay: bool = True             # estimate the voltage-vs-current delay from the data
    max_delay: float = 0.3               # s, search range for that delay


@dc.dataclass
class SOP:
    """State of power: largest current the pack can deliver / accept for a horizon."""
    horizons: list = dc.field(default_factory=lambda: [2.0, 10.0, 30.0])   # s
    soc_sigma_margin: float = 2.0        # use SOC -/+ this many sigma (conservative)
    voltage_margin: float = 0.02         # V per cell kept away from v_min / v_max


@dc.dataclass
class Balance:
    balance_current: float = 0.15        # A per group (bleed resistor)
    min_delta_soc: float = 0.002         # do not bleed below this SOC difference


@dc.dataclass
class Report:
    lap_times: Optional[list] = None     # [(t_start, t_end), ...] if no lap channel is logged
    track_length: Optional[float] = None  # m per lap, for energy per km when speed is not logged


@dc.dataclass
class BatteryConfig:
    name: str = "battery"
    pack: Pack = dc.field(default_factory=Pack)
    cell: Cell = dc.field(default_factory=Cell)
    sensors: Sensors = dc.field(default_factory=Sensors)
    filter: Filter = dc.field(default_factory=Filter)
    channels: Channels = dc.field(default_factory=Channels)
    thermal: Thermal = dc.field(default_factory=Thermal)
    limits: Limits = dc.field(default_factory=Limits)
    clean: Clean = dc.field(default_factory=Clean)
    sop: SOP = dc.field(default_factory=SOP)
    balance: Balance = dc.field(default_factory=Balance)
    report: Report = dc.field(default_factory=Report)
    source: str = ""

    def set(self, path: str, value):
        sec, _, key = path.partition(".")
        obj = getattr(self, sec)
        if not hasattr(obj, key):
            raise KeyError(path)
        setattr(obj, key, _parse(key, value))
        return self

    def copy(self):
        return copy.deepcopy(self)

    def params(self) -> "CellParams":
        return CellParams.from_config(self)


_NO_PARSE = {"chemistry", "name", "method", "pack_voltage", "pack_current", "cell_voltage", "cell_temp",
             "pack_temp", "inverter_current", "speed", "lap_marker", "units", "sensor_cells", "lap_times"}
SECTIONS = ("pack", "cell", "sensors", "filter", "channels", "thermal", "limits", "clean", "sop", "balance", "report")


def _parse(key, v):
    if key in _NO_PARSE:
        return v
    if key == "capacity_ah" and isinstance(v, str):
        return parse_quantity(v) / 3600.0
    return parse_quantity(v)


def load_battery_config(path: str | Path) -> BatteryConfig:
    path = Path(path)
    raw = yaml.safe_load(path.read_text()) or {}
    unknown = set(raw) - set(SECTIONS) - {"name", "can_signals"}
    if unknown:
        raise KeyError(f"{path.name}: unknown section(s) {sorted(unknown)}")
    cfg = BatteryConfig(name=raw.get("name", path.stem), source=str(path))
    for sec in SECTIONS:
        obj = getattr(cfg, sec)
        names = {f.name for f in dc.fields(obj)}
        for k, v in (raw.get(sec) or {}).items():
            if k not in names:
                raise KeyError(f"{path.name}: unknown key '{sec}.{k}'")
            setattr(obj, k, _parse(k, v))
    return cfg


def save_battery_config(cfg: BatteryConfig, path: str | Path):
    d = {"name": cfg.name}
    for sec in SECTIONS:
        d[sec] = dc.asdict(getattr(cfg, sec))
    Path(path).write_text(yaml.safe_dump(d, sort_keys=False))


# --------------------------------------------------------------------------- per-group parameters
@dc.dataclass
class CellParams:
    """Resolved per-series-element (parallel group) parameters, arrays of length N."""
    n: int
    q: np.ndarray            # As, group capacity
    r0: np.ndarray           # ohm at t_ref
    r1: np.ndarray
    tau1: float
    r2: np.ndarray
    tau2: float
    m: float
    m0: float
    gamma: float
    eta_c: float
    ea: float
    t_ref: float
    v_min: float
    v_max: float
    t_max: float
    ocv: OCV
    r0_soc: Optional[np.ndarray] = None
    r0_soc_f: Optional[np.ndarray] = None
    r_ic: float = 0.0
    model_error: float = 0.0
    model_error_tau: float = 120.0
    estimate_capacity: object = False

    @classmethod
    def from_config(cls, cfg: BatteryConfig):
        c = cfg.cell.resolved()
        ns, npar = int(cfg.pack.series), int(cfg.pack.parallel)
        cap = np.full(ns, c["capacity_ah"] * 3600.0 * npar)
        if c.get("capacity_scale") is not None:
            cap = cap * np.asarray(c["capacity_scale"], float)
        r0 = np.full(ns, c["r0"] / npar)
        if c.get("r0_scale") is not None:
            r0 = r0 * np.asarray(c["r0_scale"], float)
        return cls(n=ns, q=cap, r0=r0, r1=np.full(ns, c["r1"] / npar), tau1=float(c["tau1"]),
                   r2=np.full(ns, c["r2"] / npar), tau2=float(c["tau2"]), m=float(c["hyst_m"]),
                   m0=float(c["hyst_m0"]), gamma=float(c["hyst_gamma"]), eta_c=float(c["eta_charge"]),
                   ea=float(c["ea_r"]), t_ref=float(c["t_ref"]), v_min=float(c["v_min"]), v_max=float(c["v_max"]),
                   t_max=float(c.get("t_max", 60.0)),
                   ocv=OCV(c["ocv_soc"], c["ocv_v"], c.get("docv_dt", 0.0) or 0.0, float(c["t_ref"])),
                   r0_soc=None if c.get("r0_soc") is None else np.asarray(c["r0_soc"], float),
                   r0_soc_f=None if c.get("r0_soc_factor") is None else np.asarray(c["r0_soc_factor"], float),
                   r_ic=float(cfg.pack.interconnect_resistance),
                   model_error=float(c.get("model_error", 0.0) or 0.0),
                   model_error_tau=float(c.get("model_error_tau", 120.0) or 120.0),
                   estimate_capacity=c.get("estimate_capacity", False))


def validate_config(cfg: BatteryConfig) -> list:
    """Static checks of the configuration (topology vs rule limits, parameter sanity).
    Returns a list of (level, message); level is 'error' or 'warning'."""
    out = []
    p = cfg.params()
    pk, lim = cfg.pack, cfg.limits
    v_pack_max = pk.series * p.v_max
    per_seg = -(-pk.series // pk.segments)
    v_seg = per_seg * p.v_max
    e_seg = per_seg * float(np.mean(p.q)) * float(np.mean(p.ocv(np.linspace(0, 1, 201))))
    if v_pack_max > lim.max_pack_voltage:
        out.append(("error", f"max pack voltage {v_pack_max:.0f} V > limit {lim.max_pack_voltage:.0f} V"))
    if v_seg > lim.max_segment_voltage:
        out.append(("error", f"segment voltage {v_seg:.1f} V ({per_seg} groups) > limit {lim.max_segment_voltage:.0f} V"))
    if e_seg > lim.max_segment_energy:
        out.append(("error", f"segment energy {e_seg / 1e6:.2f} MJ > limit {lim.max_segment_energy / 1e6:.1f} MJ"))
    n_sens = len(cfg.thermal.sensor_cells) if cfg.thermal.sensor_cells else None
    if n_sens is not None:
        frac = n_sens / pk.series
        if frac < lim.min_temp_monitor_fraction:
            out.append(("warning", f"temperature sensors on {100 * frac:.0f} % of groups < "
                                   f"{100 * lim.min_temp_monitor_fraction:.0f} %"))
        bad = [s for s in cfg.thermal.sensor_cells if not 1 <= int(s) <= pk.series]
        if bad:
            out.append(("error", f"thermal.sensor_cells out of range 1..{pk.series}: {bad}"))
    for k in ("r0", "r1", "r2"):
        v = getattr(p, k)
        if np.any(v <= 0) and k != "r2":
            out.append(("error", f"cell.{k} must be > 0"))
    if not (0 < p.tau1 < p.tau2 or p.tau2 == 0):
        out.append(("warning", "expected tau1 < tau2 (fast then slow RC branch)"))
    if p.v_min >= p.v_max:
        out.append(("error", "cell v_min >= v_max"))
    if cfg.sensors.cell_voltage_noise <= 0 or cfg.sensors.current_noise <= 0:
        out.append(("error", "sensor noise values must be > 0"))
    return out
