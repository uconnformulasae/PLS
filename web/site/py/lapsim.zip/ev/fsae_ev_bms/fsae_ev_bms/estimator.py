"""Pack state estimation, live (causal filter) and post-run (filter + iterated smoother).

Two stages (the 'bar-delta' idea used in production BMSs, made exact-enough
and cheap):

  A. pack-level filter on the MEAN cell: SOC, RC voltages, hysteresis, R0
     multiplier and the current-sensor OFFSET. The offset is common to every
     cell, so it is estimated once from the best-conditioned signal (mean of N
     cell voltages has sqrt(N) less noise; with only a pack voltage this is the
     only stage).
  B. per-cell bank (cells mode): every cell's SOC, RC, hysteresis and its own
     R0 multiplier, driven by the offset-corrected current. The offset's
     uncertainty is added to the current noise, so cell covariances stay honest.

Post-run (``estimate``) runs A forward, smooths it (RTS, re-linearised and
re-run ``smoother_iterations`` times = iterated extended RTS / Gauss-Newton
smoother), then runs B forward with the SMOOTHED offset (it uses the future
data too) and smooths B. Smoothing removes the convergence transient at the
start and the lag of the causal filter, and is the most accurate estimate the
data supports.
"""
from __future__ import annotations

import dataclasses as dc
import warnings

import numpy as np
import pandas as pd

from .cell import SOC, V1, V2, H, rc_weights
from .filters import CellBankFilter, mean_params, rts_smooth, subset_params


# --------------------------------------------------------------------------- initial state
def initial_soc(p, v_cell, i_cell, temp, sigma_v, fcfg):
    """SOC and its 1-sigma from a voltage sample: v + R0 i ~ OCV +/- hysteresis +/- RC."""
    from .cell import resistances
    r0, r1, r2 = resistances(p, temp)
    v_oc = np.asarray(v_cell, float) + r0 * i_cell
    soc = np.clip(p.ocv.inverse(v_oc, temp), 0.0, 1.0)
    if fcfg.initial_soc is not None:
        soc = np.full_like(soc, fcfg.initial_soc)
    slope = np.maximum(p.ocv.slope(soc), 1e-3)
    var_v = sigma_v ** 2 + (p.m + p.m0) ** 2 + ((r1 + r2) * np.abs(i_cell)) ** 2 + (0.3 * r0 * i_cell) ** 2
    std = np.clip(np.sqrt(var_v) / slope, 0.01, 0.35)
    if fcfg.initial_soc_std is not None:
        std = np.full_like(std, fcfg.initial_soc_std)
    return soc, std


def _stage_a(cfg, p, mode, v0, u0_group, temp0, method=None):
    s, f = cfg.sensors, cfg.filter
    pa = mean_params(p)
    ns, npar = p.n, cfg.pack.parallel
    if mode == "cells":
        sig_y = s.cell_voltage_noise / np.sqrt(ns)
        r_extra = 0.0
    else:
        sig_y = s.pack_voltage_noise / ns
        r_extra = p.r_ic / ns               # pack-terminal drop, per series element
    soc0, std0 = initial_soc(pa, v0 - r_extra * u0_group, u0_group, temp0, sig_y, f)
    return CellBankFilter(pa, f, soc0=soc0, soc0_std=std0, sigma_y=sig_y, sigma_u=s.current_noise,
                          bias_walk=s.current_bias_walk, bias0=s.current_offset, bias0_std=s.current_bias_std,
                          estimate_bias=f.estimate_bias, r_extra=r_extra, method=method)


def _stage_b(cfg, p, v0_cells, u0, temp0, sigma_u, idx=None, method=None):
    """Per-cell bank driven by the offset-corrected current (u0 already corrected)."""
    s, f = cfg.sensors, cfg.filter
    pb = p if idx is None else subset_params(p, idx)
    soc0, std0 = initial_soc(pb, v0_cells, u0, temp0, s.cell_voltage_noise, f)
    return CellBankFilter(pb, f, soc0=soc0, soc0_std=std0, sigma_y=s.cell_voltage_noise, sigma_u=sigma_u,
                          estimate_bias=False, method=method)


# --------------------------------------------------------------------------- live
class PackEstimator:
    """Causal estimator for live telemetry. Feed samples in time order:

        est = PackEstimator(cfg)
        est.current(t, amps)                    # every current sample
        est.cell_voltages(t, v)                 # (Ns,) array, NaN for cells not in this message
        est.pack_voltage(t, volts)              # if there are no cell taps
        est.temperatures(t, temps)              # (Ns,) or scalar
        snap = est.snapshot()

    Samples may arrive out of order by up to ``latency`` seconds (CAN/radio
    jitter); they are buffered, sorted and processed ``latency`` behind the
    newest timestamp. Call ``flush()`` at the end.
    """

    def __init__(self, cfg, mode=None, latency=0.05, method=None):
        self.cfg, self.p = cfg, cfg.params()
        self.mode = mode
        self.latency = latency
        self.method = method
        self.A = self.B = None
        self.t = None
        self.u = None
        self.ns, self.npar = self.p.n, cfg.pack.parallel
        self.temp = np.full(self.ns, cfg.thermal.ambient)
        self.temp_measured = False
        self.v_cells = np.full(self.ns, np.nan)
        self.v_pack = np.nan
        self.last_out = None
        self.q = []
        self._seq = 0
        self.t_newest = -np.inf
        self.ah = 0.0
        self.wh = 0.0
        self.peak = {"i_dis": 0.0, "i_chg": 0.0, "p_dis": 0.0, "v_cell_min": np.inf, "v_cell_max": -np.inf}

    # ------------- input
    def _push(self, t, kind, val):
        import heapq
        self._seq += 1
        heapq.heappush(self.q, (float(t), self._seq, kind, val))
        self.t_newest = max(self.t_newest, float(t))
        self._drain(self.t_newest - self.latency)

    def current(self, t, amps):
        self._push(t, "i", float(self.cfg.sensors.current_sign * amps * (1 + self.cfg.sensors.current_gain_error)))

    def cell_voltages(self, t, v):
        self._push(t, "vc", np.asarray(v, float))

    def cell_voltage(self, t, index, v):
        a = np.full(self.ns, np.nan)
        a[index] = v
        self._push(t, "vc", a)

    def pack_voltage(self, t, v):
        self._push(t, "vp", float(v))

    def cell_temperature(self, t, index, value):
        self._push(t, "Ti", (int(index), float(value)))

    def temperatures(self, t, temps):
        self._push(t, "T", np.broadcast_to(np.asarray(temps, float), (self.ns,)).copy())

    def flush(self):
        self._drain(np.inf)

    # ------------- processing
    def _drain(self, t_until):
        import heapq
        while self.q and self.q[0][0] <= t_until:
            t, _, kind, val = heapq.heappop(self.q)
            self._process(t, kind, val)

    def _advance(self, t, u_new):
        if self.A is None or self.t is None or t <= self.t:
            self.u = u_new if u_new is not None else self.u
            return
        dt = t - self.t
        u0 = self.u
        u1 = u_new if u_new is not None else self.u
        g0, g1 = u0, u1                       # every series group carries the pack current
        if not self.temp_measured:
            self._thermal(dt, g0)
        self.A.predict(g0, g1, dt, float(np.mean(self.temp)))
        if self.B is not None:
            b = self.A.x[0, self.A.ib] if self.A.ib is not None else 0.0
            pb = self.A.P[0, self.A.ib, self.A.ib] if self.A.ib is not None else 0.0
            su = np.sqrt(self.cfg.sensors.current_noise ** 2 + pb)
            self.B.predict(g0 - b, g1 - b, dt, self.temp, sigma_u=su)
        v = self.v_pack if np.isfinite(self.v_pack) else np.nansum(self.v_cells) if np.isfinite(self.v_cells).any() else 0.0
        ie = u1 - self.bias_pack()
        self.ah += 0.5 * (u0 + u1) * dt / 3600
        self.wh += v * 0.5 * (u0 + u1) * dt / 3600
        self.peak["i_dis"] = max(self.peak["i_dis"], ie)
        self.peak["i_chg"] = min(self.peak["i_chg"], ie)
        self.peak["p_dis"] = max(self.peak["p_dis"], v * ie)
        self.t, self.u = t, u1

    def _thermal(self, dt, i_group):
        th = self.cfg.thermal
        r0 = self.p.r0 * self.npar
        i_cell = i_group / self.npar
        m_cp = th.cell_mass * th.cell_cp
        self.temp = self.temp + dt * (i_cell ** 2 * r0 - th.h_area * (self.temp - th.ambient)) / m_cp

    def _process(self, t, kind, val):
        if kind == "i":
            if self.t is None:
                self.u = val
                self._t_u = t
                return
            self._advance(t, val)
            self._t_u = t
            return
        if kind == "T":
            self.temp = np.where(np.isfinite(val), val, self.temp)
            self.temp_measured = True
            return
        if kind == "Ti":
            if 0 <= val[0] < self.ns:
                self.temp[val[0]] = val[1]
            self.temp_measured = True
            return
        if self.u is None:
            return                                   # no current yet: cannot initialise
        if kind == "vc":
            self.v_cells = np.where(np.isfinite(val), val, self.v_cells)
            mode = "cells"
        else:
            self.v_pack = val
            mode = "pack"
        if self.mode is None:
            self.mode = mode
        if mode != self.mode:
            return                                   # pack voltage alongside cell taps: display only
        u_t = self._current_at(t)
        if self.A is None:
            if mode == "cells" and not np.isfinite(self.v_cells).all():
                return                               # wait until every cell has reported once
            self.u = u_t
            self._init(t)
            return
        self._advance(t, u_t)
        g = self.u
        if mode == "cells":
            # pack stage: mean of the latest value of every cell (a partial BMS frame would bias the mean)
            ya = float(np.mean(self.v_cells))
            self.A.sigma_y[:] = self.cfg.sensors.cell_voltage_noise / np.sqrt(self.ns)
            outA = self.A.update(ya, g, float(np.mean(self.temp)), t=t)
            b = self.A.x[0, self.A.ib] if self.A.ib is not None else 0.0
            outB = self.B.update(val, g - b, self.temp, t=t)
            self.last_out = outB
        else:
            outA = self.A.update(val / self.ns, g, float(np.mean(self.temp)), t=t)
            self.last_out = outA
        vc = val if mode == "cells" else np.full(self.ns, val / self.ns)
        if np.isfinite(vc).any():
            self.peak["v_cell_min"] = min(self.peak["v_cell_min"], float(np.nanmin(vc)))
            self.peak["v_cell_max"] = max(self.peak["v_cell_max"], float(np.nanmax(vc)))

    def _current_at(self, t):
        """Current at a voltage timestamp: linear between the last processed current sample and
        the next one still in the latency buffer (same first-order hold as post-run)."""
        if self.t is None or not hasattr(self, "_t_u"):
            return self.u
        nxt = min(((e[0], e[3]) for e in self.q if e[2] == "i" and e[0] >= t), default=None)
        if nxt is None or nxt[0] <= self._t_u:
            return self.u
        w = (t - self._t_u) / (nxt[0] - self._t_u)
        return self.u + w * (nxt[1] - self.u)

    def _init(self, t):
        g = self.u
        if self.mode == "cells":
            self.A = _stage_a(self.cfg, self.p, "cells", float(np.mean(self.v_cells)), g, float(np.mean(self.temp)),
                              self.method)
            su = np.sqrt(self.cfg.sensors.current_noise ** 2 + self.cfg.sensors.current_bias_std ** 2)
            self.B = _stage_b(self.cfg, self.p, self.v_cells, g - self.cfg.sensors.current_offset, self.temp, su,
                              method=self.method)
        else:
            self.A = _stage_a(self.cfg, self.p, "pack", self.v_pack / self.ns, g, float(np.mean(self.temp)), self.method)
        self.t = t

    # ------------- output
    @property
    def ready(self):
        return self.A is not None

    def bias_pack(self):
        if self.A is None or self.A.ib is None:
            return 0.0
        return float(self.A.x[0, self.A.ib])

    def snapshot(self) -> dict:
        if self.A is None:
            return {"ready": False}
        f = self.B if self.B is not None else self.A
        soc = f.x[:, SOC] if self.B is not None else np.repeat(self.A.x[:, SOC], self.ns)
        sstd = np.sqrt(f.P[:, SOC, SOC]) if self.B is not None else np.repeat(np.sqrt(self.A.P[:, SOC, SOC]), self.ns)
        g = f.x[:, f.ig] if f.ig is not None else np.ones(f.N)
        i_est = self.u - self.bias_pack()
        vc = self.v_cells if self.mode == "cells" else np.full(self.ns, self.v_pack / self.ns)
        v_pack = self.v_pack if np.isfinite(self.v_pack) else float(np.nansum(vc))
        warn = []
        p = self.p
        if np.nanmin(vc) < p.v_min:
            warn.append(f"cell {int(np.nanargmin(vc)) + 1} under-voltage {np.nanmin(vc):.3f} V")
        if np.nanmax(vc) > p.v_max:
            warn.append(f"cell {int(np.nanargmax(vc)) + 1} over-voltage {np.nanmax(vc):.3f} V")
        if np.max(self.temp) > p.t_max:
            warn.append(f"cell {int(np.argmax(self.temp)) + 1} over-temperature {np.max(self.temp):.1f} C")
        if self.mode == "cells" and np.nanmax(vc) - np.nanmin(vc) > 0.05:
            warn.append(f"imbalance {1e3 * (np.nanmax(vc) - np.nanmin(vc)):.0f} mV")
        return {"ready": True, "t": self.t, "soc": soc.copy(), "soc_std": sstd, "soc_pack": float(np.mean(soc)),
                "soc_min": float(np.min(soc)), "soc_pack_std": float(np.sqrt(self.A.P[0, SOC, SOC])),
                "i_meas": self.u, "i_est": i_est, "bias": self.bias_pack(), "v_pack": v_pack, "v_cells": vc.copy(),
                "power": v_pack * i_est, "temp": self.temp.copy(), "r0_mult": g.copy(),
                "ah": self.ah, "wh": self.wh, "peak": dict(self.peak), "warnings": warn,
                "nis": None if self.last_out is None else self.last_out["nis"].copy()}


# --------------------------------------------------------------------------- offline
@dc.dataclass
class Timeline:
    t: np.ndarray          # merged times
    u: np.ndarray          # pack current at t (FOH interpolation of the samples)
    su: np.ndarray         # current 1-sigma at t
    temp: np.ndarray       # (K, Ns)
    row: np.ndarray        # voltage row at t, -1 if no voltage sample at t


def build_timeline(d, cfg, t_range=None):
    s = cfg.sensors
    tv = d.t_v - s.voltage_delay
    t0 = max(d.t_i[0], tv[0])
    t1 = min(d.t_i[-1], tv[-1])
    if t_range is not None:
        t0, t1 = max(t0, t_range[0]), min(t1, t_range[1])
    vin = np.flatnonzero((tv >= t0) & (tv <= t1))
    if len(vin) < 2:
        raise ValueError("current and voltage records do not overlap")
    t0 = tv[vin[0]]
    ti = d.t_i[(d.t_i > t0) & (d.t_i <= t1)]
    tt = np.unique(np.round(np.concatenate([ti, tv[vin]]), 9))
    row = np.full(len(tt), -1)
    row[np.searchsorted(tt, np.round(tv[vin], 9))] = vin
    u = np.interp(tt, d.t_i, d.i)
    su = (np.interp(tt, d.t_i, d.i_sigma) if d.i_sigma is not None else np.full(len(tt), s.current_noise))
    ns = cfg.pack.series
    if d.temp is not None:
        temp = np.column_stack([np.interp(tt, d.t_temp, d.temp[:, j]) for j in range(d.temp.shape[1])])
        temp = np.repeat(temp, ns, axis=1) if temp.shape[1] == 1 else temp
    else:
        from .cell import lumped_temperature
        npar = cfg.pack.parallel
        r0_phys = float(np.mean(cfg.params().r0)) * npar
        temp = np.repeat(lumped_temperature(tt, u / npar, r0_phys, cfg.thermal)[:, None], ns, axis=1)
    return Timeline(tt, u, su, temp, row)


def _forward(flt, tl, Y, u_scale, bias=None, bias_var=None, x_lin=None, sigma_u_floor=0.0, pack_mode=False,
             stage_a=None):
    """Run one filter over the timeline sample by sample (reference path), recording at every voltage sample."""
    flt.start_recording(tl.t[0])
    rec = 1
    mean_T = (flt.N == 1) if stage_a is None else stage_a
    for k in range(1, len(tl.t)):
        dt = tl.t[k] - tl.t[k - 1]
        u0, u1 = tl.u[k - 1] * u_scale, tl.u[k] * u_scale
        T = tl.temp[k].mean() if mean_T else tl.temp[k]
        su = tl.su[k] * u_scale
        if bias is not None:
            u0, u1 = u0 - bias[k - 1], u1 - bias[k]
            su = np.sqrt(su ** 2 + bias_var[k])
        flt.predict(u0, u1, dt, T, sigma_u=np.maximum(su, sigma_u_floor))
        r = tl.row[k]
        if r >= 0:
            y = Y[r]
            if mean_T:
                ok = np.isfinite(y)
                if not ok.any():
                    y = np.nan
                elif pack_mode:
                    y = float(y)
                else:
                    flt.sigma_y[:] = flt._sig_base / np.sqrt(ok.sum())
                    y = float(np.mean(y[ok]))
            xl = None if x_lin is None else x_lin[rec]
            flt.update(y, u1, T, x_lin=xl, t=tl.t[k])
            rec += 1
    return flt.stacked()


def interval_coeffs(tl, p, u_scale=1.0, bias=None, bias_var=None):
    """Per-interval sums that make one composite step between voltage samples exact.

    Every current sample between two voltage samples is kept: charge by the
    trapezoid rule, each RC branch by its exponentially weighted FOH input, the
    hysteresis by compounding each sub-step, and the input-noise covariance by
    summing each sample's sensitivity to the interval-end state.
    """
    t = tl.t
    u = tl.u * u_scale
    su2 = (tl.su * u_scale) ** 2
    if bias is not None:
        u = u - bias
        su2 = su2 + bias_var
    rec = tl.row >= 0
    rec[0] = True
    r_idx = np.flatnonzero(rec)                       # timeline index of every record
    n_int = len(r_idx) - 1
    s = np.arange(1, r_idx[-1] + 1)                   # steps s: t[s-1] -> t[s]
    iv = np.searchsorted(r_idx, s, side="left") - 1   # interval of each step
    t_end = t[r_idx[iv + 1]]
    dt = t[s] - t[s - 1]
    ub = 0.5 * (u[s - 1] + u[s])
    eta = np.where(ub < 0, p.eta_c, 1.0)
    bc = lambda w: np.bincount(iv, weights=w, minlength=n_int)
    c = {"dt": np.diff(t[r_idx]), "soc_a": bc(eta * dt * ub), "soc_b": bc(eta * dt)}
    L = np.zeros((len(s), 3))                         # sensitivity of interval-end state to u[s-1]
    R = np.zeros((len(s), 3))                         # ... to u[s]
    L[:, 0] = R[:, 0] = -eta * dt / 2
    for j, tau in ((1, p.tau1), (2, p.tau2)):
        key = f"rc{j}"
        if tau <= 0:
            c[f"a{j}"] = np.zeros(n_int)
            c[key] = c[key + "_b"] = np.zeros(n_int)
            continue
        _, w0, w1 = rc_weights(dt, tau)
        cw = np.exp(-(t_end - t[s]) / tau)
        c[f"a{j}"] = np.exp(-c["dt"] / tau)
        c[key] = bc(cw * (w0 * u[s - 1] + w1 * u[s]))
        c[key + "_b"] = bc(cw * (w0 + w1))
        L[:, j], R[:, j] = cw * w0, cw * w1
    # hysteresis, per cell (depends on each cell's capacity)
    z = np.abs(eta * ub)[:, None] * p.gamma * dt[:, None] / p.q[None, :]          # (steps, N)
    Zc = np.cumsum(z, axis=0)
    last = np.r_[np.flatnonzero(np.diff(iv)), len(s) - 1]                        # last step of each interval
    Z_after = Zc[last][iv] - Zc                                                    # sum of z after step s
    contrib = np.exp(-Z_after) * (-(-np.expm1(-z))) * np.sign(ub)[:, None]
    c["hk"] = np.exp(-np.vstack([Zc[last[0]], np.diff(Zc[last], axis=0)]))
    c["hin"] = np.zeros((n_int, p.n))
    np.add.at(c["hin"], iv, contrib)
    # input noise: each sample's total sensitivity (R of its step + L of the next step if same interval)
    same = np.r_[iv[1:] == iv[:-1], False]
    comb = R + np.where(same[:, None], np.vstack([L[1:], np.zeros((1, 3))]), 0.0)
    first = np.r_[0, last[:-1] + 1]                                               # first step of each interval
    qin = np.zeros((n_int, 3, 3))
    np.add.at(qin, iv, su2[s][:, None, None] * comb[:, :, None] * comb[:, None, :])
    Lf = L[first]
    qin += su2[s[first] - 1][:, None, None] * Lf[:, :, None] * Lf[:, None, :]
    c["qin"] = qin
    c["g1"] = R[last]
    c["u_last"] = u[s[last]]
    c["su2_last"] = su2[s[last]]
    c["rec_idx"] = r_idx
    return c


def _forward_fast(flt, tl, Y, c, x_lin=None, pack_mode=False, stage_a=None, record=True):
    if record:
        flt.start_recording(tl.t[0])
    r_idx = c["rec_idx"]
    mean_T = (flt.N == 1) if stage_a is None else stage_a
    last = None
    if mean_T and not pack_mode:                   # latest value of every cell, forward-filled
        first = Y[tl.row[r_idx[0]]]
        last = np.where(np.isfinite(first), first, np.nanmean(first))
    for m in range(len(r_idx) - 1):
        k = r_idx[m + 1]
        T = tl.temp[k].mean() if mean_T else tl.temp[k]
        flt.predict_composite(c, m, T, x_lin=None if x_lin is None else x_lin[m])
        y = Y[tl.row[k]]
        if last is not None:
            ok = np.isfinite(y)
            if ok.any():
                last = np.where(ok, y, last)
                flt.sigma_y[:] = flt._sig_base / np.sqrt(len(last))
                y = float(np.mean(last))
            else:
                y = np.nan
        flt.update(y, c["u_last"][m], T, x_lin=None if x_lin is None else x_lin[m + 1], t=tl.t[k])
    return flt.stacked() if record else None


def _choose_start(base, tl, Y, K, stage_a, pack_mode=False, bias=None, bias_var=None, min_std=0.02, flat_slope=0.15):
    """Multiple-hypothesis initialisation.

    A single EKF started on a flat part of the OCV curve converges to the nearest
    local optimum and then believes it. Instead, run (in one batch) a grid of K
    initial SOCs spanning +/-2.5 sigma of the voltage-based prior, each with the
    hysteresis state at -1, 0 and +1, score each by its innovation log-likelihood
    over the whole record, and return the best start per cell. Skipped for cells
    whose prior is already tight (steep OCV).
    """
    from .filters import tile
    soc0, std0 = base.x[:, SOC].copy(), np.sqrt(base.P[:, SOC, SOC])
    # multimodality comes from a flat OCV: only search where the curve is flat around the prior
    grid = np.clip(soc0[:, None] + std0[:, None] * np.linspace(-2, 2, 9)[None, :], 0, 1)
    flat = np.median(base.p.ocv.slope(grid), axis=1) < flat_slope
    if K < 2 or not np.any((std0 >= min_std) & flat):
        return None
    hs = np.array([-1.0, 0.0, 1.0])
    off = np.linspace(-2.5, 2.5, K)
    socg = np.clip(soc0[:, None] + std0[:, None] * off[None, :], 0.0, 1.0)            # (N, K)
    S_ = np.repeat(socg, 3, axis=1)                                                  # (N, 3K)
    Hh = np.tile(hs, K)[None, :].repeat(base.N, axis=0)
    KK = 3 * K
    g = tile(base, KK)
    spacing = np.maximum(std0 * 5.0 / (K - 1), 0.005)
    g.x[:, SOC] = S_.ravel()
    g.x[:, H] = Hh.ravel()
    g.P[:, SOC, :] = g.P[:, :, SOC] = 0.0
    g.P[:, H, :] = g.P[:, :, H] = 0.0
    g.P[:, SOC, SOC] = np.repeat(spacing, KK) ** 2
    g.P[:, H, H] = 0.3 ** 2
    if hasattr(base, "_sig_base"):
        g._sig_base = base._sig_base
    if stage_a:
        tl_r, Y_r = tl, Y
    else:
        tl_r = dc.replace(tl, temp=np.repeat(tl.temp, KK, axis=1))
        Y_r = np.repeat(Y, KK, axis=1)
    c = interval_coeffs(tl_r, g.p, 1.0, bias, bias_var)
    _forward_fast(g, tl_r, Y_r, c, pack_mode=pack_mode, stage_a=stage_a, record=False)
    ll = g.loglik.reshape(base.N, KK)
    best = np.argmax(ll, axis=1)
    pick = lambda A: A[np.arange(base.N), best]
    use = (std0 >= min_std) & flat
    return {"soc": np.where(use, pick(S_), soc0), "std": np.where(use, 1.5 * spacing, std0),
            "h": np.where(use, pick(Hh), base.x[:, H]), "use": use, "loglik": ll}


def _apply_choice(flt, ch):
    if ch is None:
        return
    flt.x[:, SOC] = ch["soc"]
    flt.P[:, SOC, :] = flt.P[:, :, SOC] = 0.0
    flt.P[:, SOC, SOC] = ch["std"] ** 2
    flt.x[:, H] = ch["h"]
    flt.P[:, H, :] = flt.P[:, :, H] = 0.0
    flt.P[:, H, H] = np.where(ch["use"], 0.3, 0.5) ** 2


def _run_smoothed(make, tl, Y, u_scale, iters, method, fast=True, bias=None, bias_var=None, pack_mode=False,
                  stage_a=False):
    flt = make()
    if fast:
        c = interval_coeffs(tl, flt.p, u_scale, bias, bias_var)
        fwd = lambda f, xl: _forward_fast(f, tl, Y, c, x_lin=xl, pack_mode=pack_mode, stage_a=stage_a)
    else:
        fwd = lambda f, xl: _forward(f, tl, Y, u_scale, bias=bias, bias_var=bias_var, x_lin=xl, pack_mode=pack_mode,
                                     stage_a=stage_a)
    rec = fwd(flt, None)
    xs, Ps = rts_smooth(rec)
    n_it = max(iters, 1) if method in ("ekf", "iekf") else 1
    for _ in range(n_it - 1):
        flt = make()
        rec = fwd(flt, xs)
        xs, Ps = rts_smooth(rec)
    return rec, xs, Ps, flt


@dc.dataclass
class BatteryResult:
    cfg: object
    data: object
    mode: str
    t: np.ndarray                 # record times (voltage samples)
    soc: np.ndarray               # (K, Ns) smoothed cell SOC
    soc_std: np.ndarray
    soc_f: np.ndarray             # causal filter SOC (what the live estimator showed)
    soc_f_std: np.ndarray
    soc_pack: np.ndarray          # smoothed pack-level (mean-cell) SOC
    soc_pack_std: np.ndarray
    soc_pack_f: np.ndarray
    bias: np.ndarray              # smoothed current-sensor offset, pack amps
    bias_std: np.ndarray
    r0_mult: np.ndarray           # (K, Ns) smoothed R0 multiplier
    i_meas: np.ndarray            # pack current at t
    i_est: np.ndarray             # i_meas - offset
    v_meas: np.ndarray            # (K, Ns) cell voltages (pack mode: pack/Ns)
    v_model: np.ndarray           # (K, Ns) model voltage on the smoothed states
    v_pack: np.ndarray
    temp: np.ndarray
    innov: np.ndarray             # (K, Ns) forward-filter innovations
    S: np.ndarray
    nis: np.ndarray
    accepted: np.ndarray
    states_pack: np.ndarray       # (K, n) smoothed stage-A states
    metrics: dict = dc.field(default_factory=dict)
    psi: object = None            # (Ns,) smoothed Q_nominal / Q at the end (capacity passes)
    psi_std: object = None
    capacity: dict = dc.field(default_factory=dict)
    rpol_mult: object = None      # (K, Ns) smoothed multiplier on R1, R2
    x0_pack: object = None
    P0_pack: object = None
    x0_cells: object = None
    P0_cells: object = None
    cfg_used: object = None
    x_cells: object = None        # (K, Ns, 4) smoothed [soc, v1, v2, h] per cell (for state of power)

    def frame(self) -> pd.DataFrame:
        d = {"t": self.t, "i_meas": self.i_meas, "i_est": self.i_est, "v_pack": self.v_pack,
             "soc_pack": self.soc_pack, "soc_pack_std": self.soc_pack_std, "soc_pack_filter": self.soc_pack_f,
             "soc_min": self.soc.min(1), "soc_max": self.soc.max(1), "bias": self.bias,
             "power": self.v_pack * self.i_est}
        if self.mode == "cells":
            for j in range(self.soc.shape[1]):
                d[f"soc_{j + 1:03d}"] = self.soc[:, j]
                d[f"v_{j + 1:03d}"] = self.v_meas[:, j]
                d[f"r0x_{j + 1:03d}"] = self.r0_mult[:, j]
        return pd.DataFrame(d)


def estimate(d, cfg, method=None, t_range=None, max_cells_per_chunk=None, fast=True):
    """Post-run estimation: forward filter + iterated RTS smoother, pack stage then cell stage.

    Returns SOC per cell with 1-sigma, the current-sensor offset, R0 and (NMC)
    capacity per cell, model voltages, innovations and summary metrics.
    """
    run_cfg = cfg
    res = _estimate_once(d, run_cfg, method=method, t_range=t_range, max_cells_per_chunk=max_cells_per_chunk,
                         fast=fast)
    res.cfg = cfg
    p = cfg.params()
    if res.psi is not None:
        res.capacity = {"ah": p.q / res.psi / 3600.0, "std_ah": p.q / res.psi ** 2 * res.psi_std / 3600.0,
                        "vs_nominal": 1.0 / res.psi, "observable": res.psi_std < 0.5 * cfg.filter.capacity_std}
        res.metrics["capacity_ah"] = [float(x) for x in res.capacity["ah"]]
        res.metrics["capacity_std_ah"] = [float(x) for x in res.capacity["std_ah"]]
    return res


def _apply_init(flt, init, idx=None):
    """Overwrite the base states (soc, v1, v2, h) and their variances (correlations dropped)."""
    if init is None:
        return
    x0, P0 = init
    x0, P0 = np.atleast_2d(x0), np.atleast_2d(P0)
    if idx is not None:
        x0, P0 = x0[idx], P0[idx]
    for j in range(4):
        flt.x[:, j] = x0[:, j]
        flt.P[:, j, :] = 0.0
        flt.P[:, :, j] = 0.0
        flt.P[:, j, j] = np.maximum(P0[:, j], 1e-12)


def _estimate_once(d, cfg, method=None, t_range=None, max_cells_per_chunk=None, fast=True, init=None) -> BatteryResult:
    """One pass: forward filter + iterated RTS smoother, pack stage then cell stage."""
    p = cfg.params()
    f = cfg.filter
    method = (method or f.method).lower()
    tl = build_timeline(d, cfg, t_range)
    ns, npar = p.n, cfg.pack.parallel
    g_scale = 1.0                           # every series group carries the full pack current
    mode = d.mode
    r0_row = tl.row[0]
    T0 = tl.temp[0]
    u0g = tl.u[0] * g_scale

    if mode == "cells":
        Yc = d.v_cells
        # first row where every cell has a value, for initialisation
        v_init = np.array([Yc[np.flatnonzero(np.isfinite(Yc[:, j]) & (np.arange(len(Yc)) >= r0_row))[0], j]
                           for j in range(ns)])
        YA = Yc
        v0A = float(np.mean(v_init))
    else:
        YA = d.v_pack / ns
        v0A = float(YA[r0_row])
    kw_a = dict(pack_mode=(mode == "pack"), fast=fast, stage_a=True)

    def make_a():
        fa = _stage_a(cfg, p, mode, v0A, u0g, float(np.mean(T0)), method)
        fa._sig_base = cfg.sensors.cell_voltage_noise if mode == "cells" else fa.sigma_y[0]
        _apply_init(fa, None if init is None else init["A"])
        _apply_choice(fa, choice_a)
        return fa

    choice_a = None
    if f.init_hypotheses and fast:
        choice_a = _choose_start(make_a(), tl, YA, f.init_hypotheses, stage_a=True, pack_mode=(mode == "pack"))

    recA, xsA, PsA, fa = _run_smoothed(make_a, tl, YA, g_scale, f.smoother_iterations, method, **kw_a)
    tr = recA["t"]
    ib = fa.ib
    bias_g = xsA[:, 0, ib] if ib is not None else np.zeros(len(tr))
    bias_v = PsA[:, 0, ib, ib] if ib is not None else np.zeros(len(tr))
    rowsA = np.r_[tl.row[0], tl.row[1:][tl.row[1:] >= 0]]          # voltage row of every record
    temp_tr = np.column_stack([np.interp(tr, tl.t, tl.temp[:, j]) for j in range(tl.temp.shape[1])])

    if mode == "cells":
        # smoothed offset (and its variance) on the timeline
        bt = np.interp(tl.t, tr, bias_g)
        bvt = np.interp(tl.t, tr, bias_v)
        su0 = np.sqrt(cfg.sensors.current_noise ** 2 + bvt[0])
        n_state = 10
        if max_cells_per_chunk is None:
            budget = 3e8                                   # bytes for one chunk's covariance histories
            per_cell = len(tr) * n_state * n_state * 8 * 6     # P_pred, P, F, smoothed P, list + stacked copies
            max_cells_per_chunk = int(max(1, min(ns, budget // max(per_cell, 1))))
        parts = []
        for a in range(0, ns, max_cells_per_chunk):
            idx = np.arange(a, min(ns, a + max_cells_per_chunk))
            tl_c = dc.replace(tl, temp=tl.temp[:, idx])

            def make_b(idx=idx, choice=None):
                fb_ = _stage_b(cfg, p, v_init[idx], u0g - bt[0], T0[idx], su0, idx=idx, method=method)
                _apply_init(fb_, None if init is None else init["B"], idx)
                _apply_choice(fb_, choice)
                return fb_
            ch_b = None
            if f.init_hypotheses and fast:
                ch_b = _choose_start(make_b(), tl_c, Yc[:, idx], f.init_hypotheses, stage_a=False, bias=bt,
                                     bias_var=bvt)
            make_b = (lambda idx=idx, ch=ch_b, mk=make_b: mk(idx, ch))
            recB, xsB, PsB, fb = _run_smoothed(make_b, tl_c, Yc[:, idx], g_scale, f.smoother_iterations, method,
                                               bias=bt, bias_var=bvt, fast=fast)
            # keep only per-cell summaries; the covariance histories (the bulk of the memory) go now
            ones = np.ones(xsB.shape[:2])
            parts.append({
                "soc": xsB[:, :, SOC].copy(), "soc_var": PsB[:, :, SOC, SOC].copy(),
                "soc_f": recB["x"][:, :, SOC].copy(), "soc_f_var": recB["P"][:, :, SOC, SOC].copy(),
                "r0m": xsB[:, :, fb.ig].copy() if fb.ig is not None else ones,
                "rpm": xsB[:, :, fb.ip].copy() if fb.ip is not None else ones,
                "innov": recB["innov"], "S": recB["S"], "nis": recB["nis"], "acc": recB["accepted"],
                "vm": _model_voltage(fb, xsB, tl, tr, g_scale, bt, temp_tr[:, idx]),
                "x4": xsB[:, :, :4].copy(), "x0": xsB[0][:, :4].copy(),
                "P0": np.diagonal(PsB[0], axis1=1, axis2=2)[:, :4].copy(),
                "psi": xsB[-1][:, fb.ic].copy() if fb.ic is not None else None,
                "psi_std": np.sqrt(PsB[-1][:, fb.ic, fb.ic]) if fb.ic is not None else None})
            del recB, xsB, PsB, fb
        cat = lambda key, arrs=None: np.concatenate([pt[key] for pt in parts], axis=1)
        soc = cat("soc")
        # common-mode part: SOC uncertainty that the shared current offset explains (pack stage),
        # which the cell stage sees only as white current noise
        if ib is not None:
            cm_s = (PsA[:, 0, SOC, ib] ** 2 / np.maximum(PsA[:, 0, ib, ib], 1e-30))[:, None]
            cm_f = (recA["P"][:, 0, SOC, ib] ** 2 / np.maximum(recA["P"][:, 0, ib, ib], 1e-30))[:, None]
        else:
            cm_s = cm_f = 0.0
        soc_std = np.sqrt(cat("soc_var") + cm_s)
        soc_f = cat("soc_f")
        soc_f_std = np.sqrt(cat("soc_f_var") + cm_f)
        r0m, rpm = cat("r0m"), cat("rpm")
        innov, S, nis, acc = cat("innov"), cat("S"), cat("nis"), cat("acc")
        v_meas = Yc[rowsA]
        v_model = cat("vm")                          # model voltage on the smoothed states
    else:
        soc = np.repeat(xsA[:, :, SOC], ns, axis=1)
        soc_std = np.repeat(np.sqrt(PsA[:, :, SOC, SOC]), ns, axis=1)
        soc_f = np.repeat(recA["x"][:, :, SOC], ns, axis=1)
        soc_f_std = np.repeat(np.sqrt(recA["P"][:, :, SOC, SOC]), ns, axis=1)
        r0m = np.repeat(xsA[:, :, fa.ig] if fa.ig is not None else np.ones((len(tr), 1)), ns, axis=1)
        rpm = np.repeat(xsA[:, :, fa.ip] if fa.ip is not None else np.ones((len(tr), 1)), ns, axis=1)
        innov, S, nis, acc = recA["innov"], recA["S"], recA["nis"], recA["accepted"]
        v_meas = np.repeat(YA[rowsA][:, None], ns, axis=1)
        v_model = np.repeat(_model_voltage(fa, xsA, tl, tr, g_scale, None, temp_tr.mean(1, keepdims=True)), ns, axis=1)

    i_meas = np.interp(tr, tl.t, tl.u)
    i_est = i_meas - bias_g
    if d.v_pack is not None:
        v_pack = d.v_pack[rowsA]
    else:
        v_pack = np.nansum(v_meas, axis=1)
    temp = temp_tr
    res = BatteryResult(cfg=cfg, data=d, mode=mode, t=tr, soc=soc, soc_std=soc_std, soc_f=soc_f, soc_f_std=soc_f_std,
                        soc_pack=xsA[:, 0, SOC], soc_pack_std=np.sqrt(PsA[:, 0, SOC, SOC]),
                        soc_pack_f=recA["x"][:, 0, SOC], bias=bias_g, bias_std=np.sqrt(bias_v),
                        r0_mult=r0m, i_meas=i_meas, i_est=i_est, v_meas=v_meas, v_model=v_model, v_pack=v_pack,
                        temp=temp, innov=innov, S=S, nis=nis, accepted=acc, states_pack=xsA[:, 0])
    res.rpol_mult = rpm
    if mode == "cells":
        res.x_cells = cat("x4")
    else:
        res.x_cells = np.repeat(xsA[:, :, :4], ns, axis=1)
    res.x0_pack = xsA[0, 0, :4].copy()
    res.P0_pack = np.diagonal(PsA[0, 0])[:4].copy()
    if mode == "cells":
        res.x0_cells = np.concatenate([pt["x0"] for pt in parts])
        res.P0_cells = np.concatenate([pt["P0"] for pt in parts])
        if parts[0]["psi"] is not None:
            res.psi = np.concatenate([pt["psi"] for pt in parts])
            res.psi_std = np.concatenate([pt["psi_std"] for pt in parts])
    else:
        res.x0_cells = np.repeat(res.x0_pack[None], ns, axis=0)
        res.P0_cells = np.repeat(res.P0_pack[None], ns, axis=0)
        if fa.ic is not None:
            res.psi = np.full(ns, xsA[-1, 0, fa.ic])
            res.psi_std = np.full(ns, np.sqrt(PsA[-1, 0, fa.ic, fa.ic]))
    res.metrics = metrics(res, tl)
    res.cfg_used = cfg
    return res


def _model_voltage(flt, xs, tl, tr, u_scale, bias, temp_tr):
    """Terminal voltage on the smoothed states (for residual plots)."""
    u = np.interp(tr, tl.t, tl.u) * u_scale
    if bias is not None:
        u = u - np.interp(tr, tl.t, bias)
    out = np.empty((len(tr), flt.N))
    s = np.ones(flt.N)
    for k in range(len(tr)):
        T = np.broadcast_to(temp_tr[k] if temp_tr.shape[1] == flt.N else temp_tr[k].mean(), (flt.N,))
        b = xs[k, :, flt.ib] if flt.ib is not None else 0.0
        s = np.where(u[k] - b > flt.i_eps, 1.0, np.where(u[k] - b < -flt.i_eps, -1.0, s))
        flt.s = s
        uk = np.broadcast_to(u[k], (flt.N,))
        out[k] = flt._h(xs[k][:, None], uk, np.broadcast_to(T, (flt.N,)))[:, 0]
    return out


def metrics(res, tl) -> dict:
    """Headline numbers for the run."""
    t, ie = tl.t, tl.u - np.interp(tl.t, res.t, res.bias)
    vp = np.interp(t, res.t, res.v_pack)
    dt = np.diff(t)
    p = vp * ie
    e_wh = float(np.sum(0.5 * (p[1:] + p[:-1]) * dt) / 3600)
    ah = float(np.sum(0.5 * (ie[1:] + ie[:-1]) * dt) / 3600)
    ah_abs = float(np.sum(0.5 * np.abs(ie[1:] + ie[:-1]) * dt) / 3600)
    nis = res.nis[np.isfinite(res.nis) & res.accepted]
    resid = (res.v_meas - res.v_model)
    resid = resid[np.isfinite(resid)]
    # cell voltages without the samples the filter rejected as glitches
    vc = res.v_meas.copy()
    if res.mode == "cells":
        vc[np.isfinite(res.nis) & ~res.accepted] = np.nan
    j_min = np.unravel_index(np.nanargmin(vc), vc.shape)
    m = {
        "duration_s": float(t[-1] - t[0]),
        "current_source": res.data.current_source,
        "mode": res.mode,
        "soc_start": float(res.soc_pack[0]), "soc_end": float(res.soc_pack[-1]),
        "soc_start_std": float(res.soc_pack_std[0]), "soc_end_std": float(res.soc_pack_std[-1]),
        "soc_used": float(res.soc_pack[0] - res.soc_pack[-1]),
        "soc_min_cell_end": float(res.soc[-1].min()),
        "weakest_cell": int(np.argmin(res.soc[-1])) + 1,
        "energy_wh": e_wh, "charge_ah": ah, "throughput_ah": ah_abs,
        "i_peak_discharge": float(ie.max()), "i_peak_charge": float(ie.min()), "p_peak_kw": float(p.max() / 1e3),
        "i_rms": float(np.sqrt(np.sum(0.5 * (ie[1:] ** 2 + ie[:-1] ** 2) * dt) / (t[-1] - t[0]))),
        "v_cell_min": float(vc[j_min]), "v_cell_min_cell": int(j_min[1]) + 1, "v_cell_min_t": float(res.t[j_min[0]]),
        "v_cell_max": float(np.nanmax(vc)),
        "imbalance_mv_max": float(1e3 * np.nanmax(np.nanmax(vc, 1) - np.nanmin(vc, 1))) if res.mode == "cells" else float("nan"),
        "soc_spread_end": float(res.soc[-1].max() - res.soc[-1].min()),
        "current_offset_a": float(np.median(res.bias)), "current_offset_std_a": float(np.median(res.bias_std)),
        "r0_mult_end": [float(x) for x in res.r0_mult[-1]],
        "voltage_residual_rms_mv": float(1e3 * np.sqrt(np.mean(resid ** 2))) if resid.size else float("nan"),
        "nis_mean": float(np.mean(nis)) if nis.size else float("nan"),
        "rejected_samples": int(np.sum(np.isfinite(res.nis) & ~res.accepted)),
        "temp_max": float(np.max(res.temp)),
    }
    # consistency check: mean NIS ~ 1 for a well-tuned filter (95 % band for this sample count)
    if nis.size:
        lo, hi = 1 - 2.8 / np.sqrt(nis.size), 1 + 2.8 / np.sqrt(nis.size)
        m["filter_consistent"] = bool(0.5 < m["nis_mean"] < 2.0)
        m["nis_band"] = (float(lo), float(hi))
    return m


def summary(res) -> str:
    m = res.metrics
    lines = [
        f"{res.cfg.name}: {res.cfg.pack.series}s{res.cfg.pack.parallel}p, {m['duration_s']:.0f} s, "
        f"current from {m['current_source']}, voltages per {'cell' if res.mode == 'cells' else 'pack'}",
        f"SOC {100 * m['soc_start']:.1f} % (+/-{100 * m['soc_start_std']:.1f}) -> {100 * m['soc_end']:.1f} % "
        f"(+/-{100 * m['soc_end_std']:.1f});  used {100 * m['soc_used']:.2f} %",
        f"energy {m['energy_wh']:.1f} Wh   charge {m['charge_ah']:.3f} Ah   throughput {m['throughput_ah']:.3f} Ah",
        f"current peak {m['i_peak_discharge']:.1f} A discharge / {m['i_peak_charge']:.1f} A charge, "
        f"rms {m['i_rms']:.1f} A;  peak power {m['p_peak_kw']:.2f} kW",
        f"min cell {m['v_cell_min']:.3f} V (cell {m['v_cell_min_cell']} at t={m['v_cell_min_t']:.1f} s), "
        f"max {m['v_cell_max']:.3f} V",
    ]
    if res.mode == "cells":
        lines.append(f"imbalance max {m['imbalance_mv_max']:.0f} mV; SOC spread at end {100 * m['soc_spread_end']:.2f} %;"
                     f" weakest cell {m['weakest_cell']}")
    lines.append(f"current-sensor offset {m['current_offset_a']:+.3f} A (+/-{m['current_offset_std_a']:.3f})")
    lines.append(f"voltage residual {m['voltage_residual_rms_mv']:.2f} mV rms; NIS mean {m['nis_mean']:.2f} "
                 f"(~1 = consistent); {m['rejected_samples']} outlier samples rejected")
    if res.cfg.params().model_error >= 0.002 and res.cfg.filter.initial_soc is None:
        lines.append("NOTE: flat-OCV chemistry (LiFePO4): voltage alone pins SOC only to a few % on the plateau and "
                     "the reported +/- is optimistic there. Anchor the start at a known SOC "
                     "(filter.initial_soc = 1.0 after the charger finishes) for ~1-2 %.")
    if not m.get("filter_consistent", True):
        lines.append(f"WARNING: innovations are not consistent (NIS {m['nis_mean']:.1f}, ideal ~1): the cell model or "
                     "the current does not fit this data - treat SOC as indicative and check the diagnostics figure.")
    return "\n".join(lines)
