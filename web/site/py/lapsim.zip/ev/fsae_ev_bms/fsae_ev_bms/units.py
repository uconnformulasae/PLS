"""Units for configuration values.

A value may be a plain number (already in the field's SI unit) or a string
with a unit: "14 mOhm", "4.2 Ah", "2 mV", "80 kW", "6 MJ", "500 ms", "60 degC".
Internally: V, A, ohm, F, s, W, J, kg, m, and A*s for charge. Temperatures are
degC (they are offsets, not scaled). Capacities given as "4.2 Ah" are converted
by the config loader to Ah fields.
"""
from __future__ import annotations

import re

_FACTORS = {
    "V": 1.0, "mV": 1e-3, "kV": 1e3, "uV": 1e-6,
    "A": 1.0, "mA": 1e-3, "kA": 1e3,
    "Ah": 3600.0, "mAh": 3.6, "As": 1.0, "C": 1.0,
    "ohm": 1.0, "Ohm": 1.0, "mohm": 1e-3, "mOhm": 1e-3, "uohm": 1e-6, "uOhm": 1e-6,
    "F": 1.0, "kF": 1e3,
    "s": 1.0, "ms": 1e-3, "min": 60.0, "h": 3600.0,
    "W": 1.0, "kW": 1e3, "MW": 1e6,
    "J": 1.0, "kJ": 1e3, "MJ": 1e6, "Wh": 3600.0, "kWh": 3.6e6,
    "kg": 1.0, "g": 1e-3,
    "m": 1.0, "mm": 1e-3, "cm": 1e-2,
    "K": 1.0, "degC": 1.0, "C_temp": 1.0,
    "%": 0.01, "": 1.0,
}


def _unit_factor(expr: str) -> float:
    expr = expr.strip()
    num, _, den = expr.partition("/")

    def prod(part):
        f = 1.0
        for tok in re.split(r"[*·]", part):
            tok = tok.strip()
            if not tok:
                continue
            m = re.fullmatch(r"([A-Za-z%]+)\^?(-?\d+)?", tok)
            if not m or m.group(1) not in _FACTORS:
                raise ValueError(f"unknown unit '{tok}' in '{expr}'")
            f *= _FACTORS[m.group(1)] ** (int(m.group(2)) if m.group(2) else 1)
        return f

    f = prod(num)
    for d in den.split("/") if den else []:
        f /= prod(d)
    return f


def parse_quantity(value):
    """Number or 'number unit' -> SI number. Lists convert element-wise; other strings pass through."""
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, (list, tuple)):
        return [parse_quantity(v) for v in value]
    if not isinstance(value, str):
        return value
    m = re.fullmatch(r"\s*([-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?)\s*(.*?)\s*", value)
    if not m:
        return value
    number, unit = float(m.group(1)), m.group(2)
    if unit in ("degC", "C_temp", "°C"):
        return number
    return number * _unit_factor(unit) if unit else number
