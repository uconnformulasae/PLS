"""Cell-model identification from test or drive data.

The estimator is only as accurate as the cell model, so fit it to the team's
own cells before trusting SOC to a fraction of a percent:

  1. ``ocv_from_low_rate``  - OCV(SOC) and hysteresis from a C/20 (or slower)
     discharge followed by a charge (or a GITT/pulse-rest test).
  2. ``fit_ecm``            - R0, R1/tau1, R2/tau2, hysteresis from a pulse test
     (HPPC) or a drive cycle, by nonlinear least squares on the exact model.
  3. ``r0_from_steps``      - R0 directly from current steps in ANY log (works
     on car data: every throttle tip-in is a step).

Every fit returns its 1-sigma uncertainty from the Jacobian.
"""
from __future__ import annotations

import dataclasses as dc

import numpy as np

from .cell import simulate

_LOG = {"r0", "r1", "tau1", "r2", "tau2", "m", "gamma"}


def ocv_from_low_rate(t, i, v, capacity_ah, soc_start=1.0, n=21, r0=0.0):
    """OCV table from a slow discharge then charge.

    Each branch is corrected for the ohmic drop (r0 * i, small at C/20), the two
    branches are averaged for the OCV, and half their difference is the
    hysteresis amplitude M. Returns dict(soc, ocv, m, discharge, charge).
    """
    t, i, v = map(lambda a: np.asarray(a, float), (t, i, v))
    q = np.r_[0.0, np.cumsum(0.5 * (i[1:] + i[:-1]) * np.diff(t))] / 3600.0
    soc = soc_start - q / capacity_ah
    vo = v + r0 * i
    grid = np.linspace(0, 1, n)
    out = {}
    for name, m in (("discharge", i > 0), ("charge", i < 0)):
        if m.sum() < 10:
            raise ValueError(f"no {name} branch in the data")
        s, vv = soc[m], vo[m]
        o = np.argsort(s)
        out[name] = np.interp(grid, s[o], vv[o], left=np.nan, right=np.nan)
    ocv = 0.5 * (out["discharge"] + out["charge"])
    good = np.isfinite(ocv)
    m_h = float(np.nanmedian(0.5 * (out["charge"] - out["discharge"])))
    ocv_g = np.maximum.accumulate(np.where(good, ocv, -np.inf))[good]   # enforce monotone
    ocv_g = ocv_g + 1e-6 * np.arange(len(ocv_g))
    return {"soc": grid[good], "ocv": ocv_g, "m": m_h, **out}


def r0_from_steps(t, i, v, min_step=None, max_dt=0.05):
    """Ohmic resistance from current steps: R0 = -dV/dI across one sample.

    Uses only steps with |dI| > ``min_step`` (default: 20 % of the current
    range) between samples less than ``max_dt`` apart, where the RC branches
    cannot move. Returns (t_step, r0, median, robust 1-sigma).
    """
    t, i, v = map(lambda a: np.asarray(a, float), (t, i, v))
    di, dv, dt = np.diff(i), np.diff(v), np.diff(t)
    if min_step is None:
        min_step = 0.2 * (np.nanpercentile(i, 99) - np.nanpercentile(i, 1))
    m = (np.abs(di) > min_step) & (dt < max_dt) & np.isfinite(dv)
    r = -dv[m] / di[m]
    r = r[(r > 0) & (r < 1.0)]
    if not r.size:
        return np.array([]), np.array([]), float("nan"), float("nan")
    med = float(np.median(r))
    mad = float(1.4826 * np.median(np.abs(r - med)))
    return t[1:][m][: r.size], r, med, mad / np.sqrt(r.size)


def fit_ecm(cfg, t, i, v, temp=25.0, soc0=None, fit=("r0", "r1", "tau1", "r2", "tau2"), h0=0.0,
            weights=None, verbose=0):
    """Least-squares fit of ECM parameters to one cell's (group's) voltage.

    ``cfg`` supplies the OCV, capacity and starting values; ``i`` is the cell
    (group) current, + = discharge. ``soc0`` None = from the first voltage via
    OCV^-1 (start the test from rest). Parameters are fitted in log space
    (always positive). Returns dict(values, std, rms_mv, residual, cfg) where
    ``cfg`` is a copy with the fitted values written in (per physical cell).
    """
    from scipy.optimize import least_squares
    t, i, v = map(lambda a: np.asarray(a, float), (t, i, v))
    one = cfg.copy()
    one.pack.series = 1
    npar = cfg.pack.parallel
    p = one.params()
    if soc0 is None:
        soc0 = float(p.ocv.inverse(v[0] + p.r0[0] * i[0]))
    names = list(fit)
    group_scale = {"r0": 1 / npar, "r1": 1 / npar, "r2": 1 / npar}
    attr = {"r0": "r0", "r1": "r1", "r2": "r2", "tau1": "tau1", "tau2": "tau2", "m": "m", "gamma": "gamma",
            "m0": "m0"}
    x0 = np.array([np.log(max(float(np.atleast_1d(getattr(p, attr[n]))[0]), 1e-9)) for n in names])
    w = np.ones_like(v) if weights is None else np.asarray(weights, float)

    def model(x):
        q = p
        for n, val in zip(names, np.exp(x)):
            cur = getattr(q, attr[n])
            q = dc.replace(q, **{attr[n]: np.full_like(cur, val) if isinstance(cur, np.ndarray) else float(val)})
        return simulate(q, t, i, temp=temp, soc0=soc0, h0=h0, substeps=1)["v"][:, 0]

    def resid(x):
        return w * (model(x) - v)

    sol = least_squares(resid, x0, x_scale=1.0, diff_step=1e-4, verbose=verbose)
    r = sol.fun / w
    dof = max(len(v) - len(names), 1)
    s2 = float(np.sum(sol.fun ** 2) / dof)
    try:
        cov = np.linalg.inv(sol.jac.T @ sol.jac) * s2
        std_log = np.sqrt(np.diag(cov))
    except np.linalg.LinAlgError:
        std_log = np.full(len(names), np.nan)
    vals = np.exp(sol.x)
    out_cfg = cfg.copy()
    values, std = {}, {}
    for n, val, sl in zip(names, vals, std_log):
        phys = val / group_scale.get(n, 1.0)          # back to one physical cell
        values[n], std[n] = float(phys), float(phys * sl)
        key = {"m": "hyst_m", "gamma": "hyst_gamma", "m0": "hyst_m0"}.get(n, n)
        setattr(out_cfg.cell, key, float(phys))
    return {"values": values, "std": std, "rms_mv": float(1e3 * np.sqrt(np.mean(r ** 2))), "residual": r,
            "soc0": soc0, "cfg": out_cfg, "success": bool(sol.success)}


def hppc_profile(capacity_ah, c_rate=2.0, pulse=10.0, rest=40.0, n_pulses=9, soc_step=0.1, fs=10.0):
    """A standard HPPC test current (discharge pulse, rest, charge pulse, rest, then a
    discharge to the next SOC step), for planning bench tests and for checking
    ``fit_ecm``. Returns (t, i) for one cell."""
    I = c_rate * capacity_ah
    seg = []
    for _ in range(n_pulses):
        seg += [(pulse, I), (rest, 0.0), (pulse, -0.75 * I), (rest, 0.0)]
        seg += [(soc_step * capacity_ah * 3600 / (0.5 * capacity_ah), 0.5 * capacity_ah), (300.0, 0.0)]
    t = [0.0]
    i = [0.0]
    for d, a in seg:
        tt = np.arange(1, int(d * fs) + 1) / fs + t[-1]
        t += list(tt)
        i += [a] * len(tt)
    return np.array(t), np.array(i)
