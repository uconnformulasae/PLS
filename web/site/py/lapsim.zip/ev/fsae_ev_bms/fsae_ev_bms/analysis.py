"""Whole-run analysis of an EV accumulator log: one call from raw data to results.

    res = analyze(data, cfg)
    print(res.summary())
    res.write("results/run_01")        # CSVs, JSON, figures, report.html

Pipeline
  1. clean            data conditioning + quality report (clean.py)
  2. align            voltage-vs-current delay estimated and corrected
  3. electrical       forward filter + iterated smoother, every cell (estimator.py)
  4. thermal          heat from each cell's measured loss -> core / can temperature of every
                      group (thermal.py), then the electrical pass is repeated with those core
                      temperatures (resistance depends on them)
  5. state of power   per horizon, limiting cell and reason (sop.py)
  6. compliance       configured FSAE limits (rules.py)
  7. balancing        Ah to bleed per cell, outlier cells (capacity, resistance)
  8. laps / energy    per-lap energy, regen, SOC, temperatures; remaining energy and laps
"""
from __future__ import annotations

import dataclasses as dc
import json
from pathlib import Path

import numpy as np
import pandas as pd

from . import clean as clean_mod
from . import rules as rules_mod
from . import sop as sop_mod
from . import thermal as thermal_mod
from .estimator import estimate, summary as elec_summary

_trapz = getattr(np, "trapezoid", None) or np.trapz


@dc.dataclass
class EVResult:
    cfg: object
    data: object               # cleaned data
    quality: object            # CleanReport
    elec: object               # BatteryResult (final pass)
    thermal: object            # ThermalResult or None
    sop: dict
    rules: list
    power: dict
    balance: pd.DataFrame
    cells: pd.DataFrame
    laps: pd.DataFrame
    energy: dict
    issues: list

    # ------------------------------------------------------------------ text
    def summary(self):
        e, m = self.energy, self.elec.metrics
        lines = [elec_summary(self.elec), ""]
        if self.thermal is not None:
            th = self.thermal
            k, j = np.unravel_index(np.argmax(th.core), th.core.shape)
            lines.append(f"hottest cell (estimated core) {th.core[k, j]:.1f} +/- {th.core_std[k, j]:.1f} C, cell {j + 1} "
                         f"at t={th.t[k]:.0f} s; coolant/air estimate {th.ambient[-1]:.1f} C at the end")
        hz = self.cfg.sop.horizons
        s_end = ", ".join(f"{h:g} s: {self.sop[h]['p_dis'][-1] / 1e3:.1f} kW out / {-self.sop[h]['p_chg'][-1] / 1e3:.1f} "
                          f"kW regen" for h in hz)
        lines.append(f"state of power at the end  {s_end}")
        h0 = hz[0]
        lines.append(f"  limited by cell {int(self.sop[h0]['limit_cell_dis'][-1]) + 1} "
                     f"({self.sop[h0]['reason_dis'][-1]}) on discharge, cell "
                     f"{int(self.sop[h0]['limit_cell_chg'][-1]) + 1} ({self.sop[h0]['reason_chg'][-1]}) on regen")
        lines.append(f"remaining usable energy {e['remaining_wh']:.0f} Wh (weakest cell sets it; "
                     f"imbalance costs {e['imbalance_wh']:.0f} Wh)"
                     + (f"; about {e['laps_remaining']:.1f} more laps at {e['wh_per_lap']:.0f} Wh/lap"
                        if e.get("laps_remaining") is not None else ""))
        if len(self.laps):
            lines.append(f"laps: {len(self.laps)}, energy per lap {self.laps['energy_wh'].mean():.0f} Wh "
                         f"(regen recovers {self.laps['regen_wh'].mean():.0f} Wh/lap)")
        need = self.balance[self.balance["bleed_ah"] > 0]
        if len(need):
            lines.append(f"balancing: {len(need)} cells above the lowest; longest bleed "
                         f"{need['bleed_h'].max():.1f} h at {self.cfg.balance.balance_current:.2f} A (cell "
                         f"{int(need.loc[need['bleed_h'].idxmax(), 'cell'])})")
        odd = self.cells[self.cells["flag"] != ""]
        for _, r in odd.iterrows():
            lines.append(f"  cell {int(r['cell'])}: {r['flag']}")
        lines.append("")
        lines.append(rules_mod.table(self.rules))
        lines.append("")
        lines.append(self.quality.text())
        return "\n".join(lines)

    # ------------------------------------------------------------------ files
    def write(self, out, figures=True, html=True):
        out = Path(out)
        out.mkdir(parents=True, exist_ok=True)
        self.elec.frame().to_csv(out / "estimate.csv", index=False)
        self.cells.to_csv(out / "cells.csv", index=False)
        self.balance.to_csv(out / "balance.csv", index=False)
        self.laps.to_csv(out / "laps.csv", index=False)
        pd.DataFrame(self.rules).to_csv(out / "compliance.csv", index=False)
        sop_rows = {"t": self.sop["t"]}
        for h in self.cfg.sop.horizons:
            s = self.sop[h]
            sop_rows.update({f"p_dis_{h:g}s_kw": s["p_dis"] / 1e3, f"p_chg_{h:g}s_kw": s["p_chg"] / 1e3,
                             f"i_dis_{h:g}s": s["i_dis"], f"i_chg_{h:g}s": s["i_chg"],
                             f"limit_cell_dis_{h:g}s": s["limit_cell_dis"] + 1, f"reason_dis_{h:g}s": s["reason_dis"]})
        pd.DataFrame(sop_rows).to_csv(out / "state_of_power.csv", index=False)
        if self.thermal is not None:
            th = self.thermal
            pd.DataFrame({"t": th.t, "ambient": th.ambient, "core_max": th.core.max(1),
                          "core_max_cell": th.core.argmax(1) + 1, "surface_max": th.surface.max(1)}).to_csv(
                out / "thermal.csv", index=False)
        metrics = {"electrical": self.elec.metrics, "energy": self.energy,
                   "quality": {"issues": self.quality.issues, "streams": self.quality.streams,
                               "delay": {k: v for k, v in self.quality.delay.items() if k != "curve"},
                               "inverter": self.quality.inverter, "pack_vs_cells": self.quality.pack_vs_cells},
                   "issues": self.issues}
        (out / "metrics.json").write_text(json.dumps(metrics, indent=2, default=_json))
        (out / "summary.txt").write_text(self.summary())
        figs = {}
        if figures:
            import matplotlib
            matplotlib.use("Agg", force=False)
            import matplotlib.pyplot as plt
            from . import plots
            figs = {"overview": plots.overview(self.elec), "power": plots.power(self),
                    "cells": plots.cells(self.elec), "diagnostics": plots.diagnostics(self.elec)}
            if self.thermal is not None:
                figs["thermal"] = plots.thermal(self)
            if self.quality.delay.get("curve") is not None:
                figs["alignment"] = plots.alignment(self.quality)
            for k, f in figs.items():
                f.savefig(out / f"{k}.png", bbox_inches="tight")
                plt.close(f)
        if html:
            from .report import html_report
            (out / "report.html").write_text(html_report(self, out if figures else None))
        return out


def _json(o):
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, (np.floating, np.integer)):
        return o.item()
    if isinstance(o, np.bool_):
        return bool(o)
    return str(o)


# --------------------------------------------------------------------------- pipeline
def analyze(d, cfg, method=None, thermal=True, sop=True, progress=None):
    say = progress or (lambda *_: None)
    issues = []
    say("cleaning data")
    dc_, rep = clean_mod.clean(d, cfg)
    cfg_run = cfg.copy()
    if rep.delay.get("applied"):
        cfg_run.sensors.voltage_delay = rep.delay["delay_s"]
    if dc_.v_cells is not None:
        dead = np.flatnonzero(~np.isfinite(dc_.v_cells).any(0))
        if dead.size:
            issues.append(("error", f"no valid voltage at all for cell(s) {', '.join(str(j + 1) for j in dead)}"))
            # an unmeasured cell is reported but cannot be estimated: fill from the pack mean so the run completes
            dc_.v_cells = dc_.v_cells.copy()
            dc_.v_cells[:, dead] = np.nanmean(dc_.v_cells, axis=1, keepdims=True)
    say("electrical estimate")
    res = estimate(dc_, cfg_run, method=method)
    th = None
    if thermal and dc_.temp_sensors is not None and np.isfinite(dc_.temp_sensors).any():
        say("thermal estimate")
        ns = cfg.pack.series
        n = 2 * ns + 1
        dur = res.t[-1] - res.t[0]
        dt = cfg.thermal.dt                       # ~1 s: cores swing several K within a few seconds
        tg = np.arange(res.t[0], res.t[-1] + 0.5 * dt, dt)
        heat = thermal_mod.heat_from_result(res, tg)
        good = [j for j in range(dc_.temp_sensors.shape[1]) if np.isfinite(dc_.temp_sensors[:, j]).sum() > 0.5 * len(dc_.t_temp)]
        th = thermal_mod.estimate_temperatures(cfg_run, dc_.t_temp, dc_.temp_sensors[:, good],
                                               np.asarray(dc_.sensor_cells)[good], tg, heat)
        if cfg.filter.thermal_coupling:
            say("electrical estimate with estimated core temperatures")
            d2 = dc.replace(dc_, t_temp=tg, temp=th.core, temp_sensors=None)
            res = estimate(d2, cfg_run, method=method)
            heat = thermal_mod.heat_from_result(res, tg)
            th = thermal_mod.estimate_temperatures(cfg_run, dc_.t_temp, dc_.temp_sensors[:, good],
                                                   np.asarray(dc_.sensor_cells)[good], tg, heat)
            th.sensor_cells_all = np.asarray(dc_.sensor_cells)
    if th is not None:
        th.sensor_index = np.asarray(good) + 1           # original thermistor numbers (dead ones dropped)
        th.sensor_cells_all = np.asarray(dc_.sensor_cells)
    res.cfg = cfg_run
    say("state of power")
    sp = sop_mod.from_result(res) if sop else {}
    say("compliance, balancing, laps")
    rows, power = rules_mod.check(dc_, res, th, cfg_run)
    bal, cells = balance(res, th, cfg_run)
    laps = lap_table(dc_, res, th, cfg_run, power)
    energy = remaining_energy(res, cfg_run, laps)
    return EVResult(cfg=cfg_run, data=dc_, quality=rep, elec=res, thermal=th, sop=sp, rules=rows, power=power,
                    balance=bal, cells=cells, laps=laps, energy=energy, issues=issues + rep.issues)


# --------------------------------------------------------------------------- balancing / cell table
def _robust_z(x):
    med = np.median(x)
    mad = 1.4826 * np.median(np.abs(x - med))
    return (x - med) / max(mad, 1e-12 * max(abs(med), 1.0)) if mad > 0 else np.zeros_like(x)


def balance(res, th, cfg):
    p = cfg.params()
    ns = p.n
    cap = res.capacity["ah"] if res.capacity else p.q / 3600.0
    cap_std = res.capacity["std_ah"] if res.capacity else np.full(ns, np.nan)
    soc = res.soc[-1]
    sd = res.soc_std[-1]
    lowest = float(np.min(soc))
    bleed = np.where(soc - lowest > cfg.balance.min_delta_soc, (soc - lowest) * cap, 0.0)
    bal = pd.DataFrame({"cell": np.arange(1, ns + 1), "soc_end": soc, "soc_std": sd, "capacity_ah": cap,
                        "bleed_ah": bleed, "bleed_h": bleed / max(cfg.balance.balance_current, 1e-9)})
    r0 = p.r0 * res.r0_mult[-1]
    z_c = _robust_z(cap) if res.capacity else np.zeros(ns)
    z_r = _robust_z(r0)
    flags = []
    for j in range(ns):
        f = []
        if z_c[j] < -3.5:
            f.append(f"low capacity ({cap[j]:.2f} Ah, z={z_c[j]:.1f})")
        if z_r[j] > 3.5:
            f.append(f"high resistance ({1e3 * r0[j]:.2f} mOhm, z={z_r[j]:.1f})")
        flags.append("; ".join(f))
    cells = pd.DataFrame({"cell": np.arange(1, ns + 1), "segment": cfg.pack.segment_of(np.arange(ns)) + 1,
                          "soc_start": res.soc[0], "soc_end": soc, "soc_end_std": sd,
                          "capacity_ah": cap, "capacity_std_ah": cap_std, "r0_mohm_25c": 1e3 * r0,
                          "v_min": np.nanmin(res.v_meas, 0), "v_max": np.nanmax(res.v_meas, 0),
                          "flag": flags})
    if th is not None:
        cells["core_max_c"] = th.core.max(0)
        cells["core_max_std"] = th.core_std[np.argmax(th.core, 0), np.arange(ns)]
        cells["thermistor"] = np.isin(np.arange(ns), getattr(th, "sensor_cells_all", th.sensor_cells))
    return bal, cells


# --------------------------------------------------------------------------- laps / energy
def lap_starts(d, cfg):
    if cfg.report.lap_times:
        return np.array([a for a, _ in cfg.report.lap_times], float), np.array([b for _, b in cfg.report.lap_times], float)
    if "lap" in d.aux:
        t, x = d.aux["lap"]
        if len(t) == 0:
            return None, None
        ch = np.r_[True, np.diff(x) != 0] if len(t) > len(np.unique(x)) else np.ones(len(t), bool)
        st = t[ch]
        return st, np.r_[st[1:], d.t_i[-1]]
    return None, None


def lap_table(d, res, th, cfg, power):
    a, b = lap_starts(d, cfg)
    if a is None:
        return pd.DataFrame(columns=["lap", "t_start", "duration_s", "energy_wh", "regen_wh", "charge_ah",
                                     "soc_used", "peak_kw", "min_cell_v", "max_core_c"])
    t, pw = power["t"], power["power"]
    e = np.r_[0.0, np.cumsum(0.5 * (pw[1:] + pw[:-1]) * np.diff(t))]
    pn = np.minimum(pw, 0)
    er = np.r_[0.0, np.cumsum(0.5 * (pn[1:] + pn[:-1]) * np.diff(t))]
    i = d.i - np.interp(t, res.t, res.bias)
    q = np.r_[0.0, np.cumsum(0.5 * (i[1:] + i[:-1]) * np.diff(t))]
    rows = []
    for k, (t0, t1) in enumerate(zip(a, b)):
        if t1 <= t[0] or t0 >= t[-1] or t1 - t0 < 5:
            continue
        E = lambda arr, tt: np.interp(tt, t, arr)
        m = (res.t >= t0) & (res.t <= t1)
        mp = (t >= t0) & (t <= t1)
        row = {"lap": k + 1, "t_start": t0, "duration_s": t1 - t0,
               "energy_wh": (E(e, t1) - E(e, t0)) / 3600, "regen_wh": -(E(er, t1) - E(er, t0)) / 3600,
               "charge_ah": (E(q, t1) - E(q, t0)) / 3600,
               "soc_used": float(np.interp(t0, res.t, res.soc_pack) - np.interp(t1, res.t, res.soc_pack)),
               "peak_kw": float(pw[mp].max() / 1e3) if mp.any() else np.nan,
               "min_cell_v": float(np.nanmin(res.v_meas[m])) if m.any() else np.nan,
               "max_core_c": float(th.core[(th.t >= t0) & (th.t <= t1)].max()) if th is not None and
               ((th.t >= t0) & (th.t <= t1)).any() else np.nan}
        if "speed" in d.aux:
            ts, vs = d.aux["speed"]
            ms = (ts >= t0) & (ts <= t1)
            if ms.sum() > 2:
                row["distance_m"] = float(_trapz(vs[ms], ts[ms]))
                row["wh_per_km"] = row["energy_wh"] / max(row["distance_m"] / 1e3, 1e-9)
        elif cfg.report.track_length:
            row["distance_m"] = cfg.report.track_length
            row["wh_per_km"] = row["energy_wh"] / (cfg.report.track_length / 1e3)
        rows.append(row)
    return pd.DataFrame(rows)


def remaining_energy(res, cfg, laps):
    """Energy the pack can still deliver down to limits.soc_min, set by the weakest cell.

    Discharges every cell by the same charge (series string) until the first reaches
    soc_min, integrating the sum of OCVs minus the resistive drop at the run's mean
    discharge current."""
    p = cfg.params()
    cap = (res.capacity["ah"] * 3600.0) if res.capacity else p.q
    soc = res.soc[-1]
    T = res.temp[-1]
    q_usable = float(np.min((soc - cfg.limits.soc_min) * cap))
    q_mean = float(np.mean((soc - cfg.limits.soc_min) * cap))
    i_dis = res.i_est[res.i_est > 1]
    i_avg = float(np.mean(i_dis)) if i_dis.size else 0.0
    r_pack = float(np.sum(p.r0 * res.r0_mult[-1]) + np.sum(p.r1) + np.sum(p.r2) + p.r_ic)

    def energy(qmax):
        if qmax <= 0:
            return 0.0
        qs = np.linspace(0, qmax, 201)
        v = np.array([np.sum(p.ocv(soc - qq / cap, T)) for qq in qs]) - i_avg * r_pack
        return float(_trapz(v, qs) / 3600)

    e_now = energy(q_usable)
    e_bal = energy(q_mean)
    out = {"remaining_wh": e_now, "remaining_ah": q_usable / 3600, "imbalance_wh": max(e_bal - e_now, 0.0),
           "mean_discharge_current_a": i_avg, "pack_resistance_mohm": 1e3 * r_pack,
           "used_wh": res.metrics["energy_wh"]}
    if len(laps):
        wpl = float(laps["energy_wh"].median())
        out.update({"wh_per_lap": wpl, "laps_remaining": e_now / wpl if wpl > 0 else None})
    return out
