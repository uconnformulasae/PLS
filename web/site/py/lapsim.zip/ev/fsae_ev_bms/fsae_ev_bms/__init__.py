"""fsae_ev_bms - FSAE electric-vehicle accumulator state estimation and run analysis.

Standalone (no dependency on the CT17 IC-car packages).

After a run:
    import fsae_ev_bms as ev
    cfg = ev.load_battery_config("configs/ev_accumulator.yaml")
    data = ev.load_battery_log("data/logs/run.csv", cfg)
    res = ev.analyze(data, cfg)              # clean -> estimate -> thermal -> SOP -> rules -> laps
    print(res.summary()); res.write("results/run")

Live, during a run:
    ev.live.run_dashboard(cfg, ev.live.CANSource(ev.live.load_can_spec("configs/ev_accumulator.yaml")))

Command line: python tools/ev_bms.py analyze|live|validate|check-config  (see README).
"""
from .config import BatteryConfig, CellParams, load_battery_config, save_battery_config, validate_config
from .chemistry import OCV, PRESETS, arrhenius
from .cell import simulate
from .filters import CellBankFilter, rts_smooth
from .io import BatteryData, load_battery_log, read_raw, from_raw, offset_from_window
from .estimator import PackEstimator, BatteryResult, estimate, summary
from .analysis import EVResult, analyze
from . import clean, thermal, sop, rules, synthetic, identify, live, plots, report

__all__ = ["BatteryConfig", "CellParams", "load_battery_config", "save_battery_config", "validate_config", "OCV",
           "PRESETS", "arrhenius", "simulate", "CellBankFilter", "rts_smooth", "BatteryData", "load_battery_log",
           "read_raw", "from_raw", "offset_from_window", "PackEstimator", "BatteryResult", "estimate", "summary",
           "EVResult", "analyze", "clean", "thermal", "sop", "rules", "synthetic", "identify", "live", "plots",
           "report"]
