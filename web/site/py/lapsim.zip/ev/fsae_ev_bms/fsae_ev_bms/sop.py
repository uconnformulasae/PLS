"""State of power: the largest constant current (and power) the accumulator can deliver
or accept for a horizon, from the estimated state of every cell.

For a constant current i held for dt, each cell's model voltage at the end is
    v(dt) = OCV(soc - eta i dt / Q, T) + M h(dt) + M0 sgn(i)
            - [a1 v1 + R1 (1-a1) i] - [a2 v2 + R2 (1-a2) i] - R0 g i
(exact for the equivalent circuit; for constant discharge it is the minimum over the horizon,
for constant charge the maximum). The limit current solves v(dt) = v_min + margin (discharge)
or v_max - margin (charge) by bisection, vectorised over cells and times, and is then capped by
  * SOC staying inside [soc_min, soc_max], using SOC -/+ k sigma (conservative),
  * the cell current limits times Np,
  * linear temperature derating between cell_t_derate and cell_t_max, no charge below
    cell_t_min_charge.
The pack limit is the weakest cell's; power = I * (sum of cell voltages - I R_ic).
"""
from __future__ import annotations

import numpy as np

from .cell import rc_weights
from .chemistry import arrhenius

REASONS = np.array(["voltage", "soc", "current", "temperature"])


def _v_end(p, soc, v1, v2, h, g, T, i, dt, q, gp=1.0):
    eta = np.where(i < 0, p.eta_c, 1.0)
    f = arrhenius(T, p.ea, p.t_ref)
    r0, r1, r2 = p.r0 * f * g, p.r1 * f * gp, p.r2 * f * gp
    a1, _, _ = rc_weights(dt, p.tau1)
    a2 = rc_weights(dt, p.tau2)[0] if p.tau2 > 0 else 0.0
    soc_e = soc - eta * i * dt / q
    k = np.exp(-np.abs(eta * i * p.gamma * dt / q))
    h_e = k * h - (1 - k) * np.sign(i)
    return (p.ocv(soc_e, T) + p.m * h_e + p.m0 * np.sign(i)
            - (a1 * v1 + r1 * (1 - a1) * i) - (a2 * v2 + r2 * (1 - a2) * i) - r0 * i)


def state_of_power(cfg, soc, soc_std, v1, v2, h, r0_mult, temp, horizon, q=None, iters=48, rpol_mult=None):
    """Per-cell current limits for one horizon.

    Arrays are (K, Ns) (or (Ns,)). Returns dict with i_dis, i_chg (A, pack current; i_chg <= 0),
    each (K, Ns) per cell plus the pack limit (K,) and limiting cell / reason.
    """
    p = cfg.params()
    lim, sp = cfg.limits, cfg.sop
    npar = cfg.pack.parallel
    q = p.q if q is None else q
    soc, soc_std, v1, v2, h, g, T = (np.atleast_2d(np.asarray(a, float)) for a in
                                     (soc, soc_std, v1, v2, h, r0_mult, temp))
    gp = np.ones_like(g) if rpol_mult is None else np.atleast_2d(np.asarray(rpol_mult, float))
    k = sp.soc_sigma_margin
    s_dis = soc - k * soc_std
    s_chg = soc + k * soc_std
    vmin, vmax = p.v_min + sp.voltage_margin, p.v_max - sp.voltage_margin
    # temperature derating (both directions), no charge when cold
    der = np.clip((lim.cell_t_max - T) / max(lim.cell_t_max - lim.cell_t_derate, 1e-6), 0.0, 1.0)
    i_cap_d = lim.i_dis_peak * npar * der
    i_cap_c = lim.i_chg_peak * npar * der * (T >= lim.cell_t_min_charge)
    # SOC caps: soc_end stays within bounds
    i_soc_d = np.maximum(s_dis - lim.soc_min, 0) * q / horizon
    i_soc_c = np.maximum(lim.soc_max - s_chg, 0) * q / horizon / p.eta_c

    def solve(sign, s, cap):
        lo = np.zeros_like(s)
        hi = cap.copy()
        target = vmin if sign > 0 else vmax
        for _ in range(iters):
            mid = 0.5 * (lo + hi)
            v = _v_end(p, s, v1, v2, h, g, T, sign * mid, horizon, q, gp)
            ok = v >= target if sign > 0 else v <= target
            lo = np.where(ok, mid, lo)
            hi = np.where(ok, hi, mid)
        # the zero-current voltage itself may already violate the limit
        v0 = _v_end(p, s, v1, v2, h, g, T, sign * 1e-9, horizon, q, gp)
        bad0 = v0 < target if sign > 0 else v0 > target
        return np.where(bad0, 0.0, lo)

    # voltage limit searched on its own up to 3x the peak rating, so the binding reason is reported correctly
    i_v_d = solve(+1, s_dis, np.full_like(s_dis, 3 * lim.i_dis_peak * npar))
    i_v_c = solve(-1, s_chg, np.full_like(s_chg, 3 * lim.i_chg_peak * npar))
    cand_d = np.stack([i_v_d, i_soc_d, np.full_like(i_v_d, lim.i_dis_peak * npar), i_cap_d])
    cand_c = np.stack([i_v_c, i_soc_c, np.full_like(i_v_c, lim.i_chg_peak * npar), i_cap_c])
    i_dis = cand_d.min(0)
    i_chg = cand_c.min(0)
    why_d = np.argmin(cand_d, axis=0)
    why_c = np.argmin(cand_c, axis=0)
    # limiting cell; ties (e.g. several cells derated to zero) go to the hottest / most extreme cell
    span = max(lim.cell_t_max, 1.0) * 10
    jd = np.argmin(i_dis - 1e-6 * T / span + 1e-9 * s_dis, axis=1)
    jc = np.argmin(i_chg - 1e-6 * T / span - 1e-9 * s_chg, axis=1)
    rows = np.arange(i_dis.shape[0])
    I_d, I_c = i_dis[rows, jd], i_chg[rows, jc]
    # pack power at the limit current: sum of cell end voltages minus interconnect drop
    V_d = _v_end(p, s_dis, v1, v2, h, g, T, I_d[:, None], horizon, q, gp).sum(1) - I_d * p.r_ic
    V_c = _v_end(p, s_chg, v1, v2, h, g, T, -I_c[:, None], horizon, q, gp).sum(1) + I_c * p.r_ic
    return {"horizon": horizon, "i_dis_cell": i_dis, "i_chg_cell": -i_chg,
            "i_dis": I_d, "i_chg": -I_c, "p_dis": I_d * V_d, "p_chg": -I_c * V_c,
            "v_at_dis": V_d, "v_at_chg": V_c,
            "limit_cell_dis": jd, "limit_cell_chg": jc,
            "reason_dis": REASONS[why_d[rows, jd]], "reason_chg": REASONS[why_c[rows, jc]]}


def from_result(res, max_points=2000):
    """SOP for every configured horizon along a post-run estimate (decimated to max_points)."""
    cfg = res.cfg
    K = len(res.t)
    idx = np.unique(np.linspace(0, K - 1, min(K, max_points)).round().astype(int))
    xc = res.x_cells[idx]
    q = res.cfg.params().q
    if res.capacity:
        q = res.capacity["ah"] * 3600.0
    out = {"t": res.t[idx]}
    for hz in cfg.sop.horizons:
        out[hz] = state_of_power(cfg, xc[..., 0], res.soc_std[idx], xc[..., 1], xc[..., 2], xc[..., 3],
                                 res.r0_mult[idx], res.temp[idx], hz, q=q,
                                 rpol_mult=None if res.rpol_mult is None else res.rpol_mult[idx])
    return out
