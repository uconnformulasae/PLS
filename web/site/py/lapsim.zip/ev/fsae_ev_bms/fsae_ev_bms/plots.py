"""Accumulator figures. Every function returns a matplotlib Figure.

Categorical slots in fixed order,
a one-hue ramp for magnitudes, red/blue diverging with a grey midpoint for
signed deviations, one y-scale per axes (two measures = two panels).
"""
from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm

CAT = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
INK, INK2, GRID = "#0b0b0b", "#52514e", "#d9d8d3"
plt.rcParams.update({"figure.dpi": 110, "axes.grid": True, "grid.alpha": 0.35, "grid.color": GRID,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": INK2,
                     "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2, "lines.linewidth": 2.0,
                     "legend.frameon": False, "axes.titleweight": "bold", "axes.titlesize": 11})

GREY = "#8a8985"
CRIT = "#e34948"


def _band(ax, t, y, s, color, k=2.0, label=None):
    ax.fill_between(t, y - k * s, y + k * s, color=color, alpha=0.18, lw=0, label=label)


def overview(res, title=None):
    """Current, pack voltage, SOC (+/- 2 sigma, weakest/strongest cell), power."""
    t = res.t
    fig, ax = plt.subplots(4, 1, figsize=(14, 11), sharex=True, gridspec_kw={"hspace": 0.32})
    ax[0].plot(t, res.i_meas, color=GREY, lw=0.8, label="logged" if res.data.current_source == "sensor" else "model")
    ax[0].plot(t, res.i_est, color=CAT[0], lw=1.3, label=f"offset-corrected ({res.metrics['current_offset_a']:+.2f} A)")
    ax[0].axhline(0, color=INK2, lw=0.6)
    ax[0].set(title="Pack current (+ = discharge)", ylabel="A")
    ax[0].legend(loc="upper right", ncol=2)
    ns = res.cfg.pack.series
    ax[1].plot(t, res.v_pack, color=GREY, lw=0.8, label="measured")
    vm = np.nansum(res.v_model, axis=1) if res.mode == "cells" else res.v_model[:, 0] * ns
    if res.mode == "pack":
        vm = vm - res.i_est * res.cfg.pack.interconnect_resistance
    ax[1].plot(t, vm, color=CAT[1], lw=1.2, label="model on the estimated state")
    ax[1].set(title="Pack voltage", ylabel="V")
    ax[1].legend(loc="upper right", ncol=2)
    soc, sd = 100 * res.soc_pack, 100 * res.soc_pack_std
    _band(ax[2], t, soc, sd, CAT[2], label="2 sigma")
    ax[2].plot(t, soc, color=CAT[2], lw=1.8, label="pack (smoothed)")
    ax[2].plot(t, 100 * res.soc_pack_f, color=CAT[2], lw=1.0, ls="--", label="live filter")
    if res.mode == "cells":
        ax[2].plot(t, 100 * res.soc.min(1), color=CAT[4], lw=1.0, label="weakest cell")
        ax[2].plot(t, 100 * res.soc.max(1), color=CAT[5], lw=1.0, label="strongest cell")
    ax[2].set(title="State of charge", ylabel="%")
    ax[2].legend(loc="upper right", ncol=5)
    p_kw = res.v_pack * res.i_est / 1e3
    ax[3].plot(t, p_kw, color=CAT[3], lw=1.0)
    ax[3].axhline(0, color=INK2, lw=0.6)
    ax[3].set(title=f"Pack power  (energy {res.metrics['energy_wh']:.1f} Wh, peak {res.metrics['p_peak_kw']:.2f} kW)",
              ylabel="kW", xlabel="time [s]")
    fig.suptitle(title or f"{res.cfg.name} - SOC {100 * res.metrics['soc_start']:.1f} -> "
                          f"{100 * res.metrics['soc_end']:.1f} %", fontweight="bold")
    return fig


def cells(res):
    """Per-cell picture: voltage deviation map, final SOC, R0 and capacity per cell."""
    if res.mode != "cells":
        raise ValueError("per-cell figure needs cell-voltage channels")
    t, V = res.t, res.v_meas.copy()
    V[np.isfinite(res.nis) & ~res.accepted] = np.nan          # samples the filter rejected as glitches
    dev = 1e3 * (V - np.nanmean(V, axis=1, keepdims=True))
    ns = V.shape[1]
    idx = np.arange(1, ns + 1)
    fig = plt.figure(figsize=(14, 10))
    gs = fig.add_gridspec(3, 2, height_ratios=[1.3, 1, 1], hspace=0.45, wspace=0.22)
    a0 = fig.add_subplot(gs[0, :])
    lim = max(float(np.nanpercentile(np.abs(dev), 99.5)), 1.0)
    im = a0.imshow(dev.T, aspect="auto", origin="lower", cmap="RdBu_r", norm=TwoSlopeNorm(0, -lim, lim),
                   extent=[t[0], t[-1], 0.5, ns + 0.5], interpolation="nearest")
    fig.colorbar(im, ax=a0, label="mV from pack mean", pad=0.01)
    a0.set(title="Cell voltage minus pack mean", xlabel="time [s]", ylabel="cell")
    a0.grid(False)
    a1 = fig.add_subplot(gs[1, 0])
    a1.bar(idx, 100 * res.soc[-1], yerr=200 * res.soc_std[-1], color=CAT[2], capsize=2, ecolor=INK2)
    lo = 100 * (res.soc[-1] - 2 * res.soc_std[-1]).min()
    a1.set(title="SOC at the end (+/- 2 sigma)", xlabel="cell", ylabel="%", ylim=(max(lo - 2, 0), None))
    a2 = fig.add_subplot(gs[1, 1])
    a2.plot(t, 1e3 * (np.nanmax(V, 1) - np.nanmin(V, 1)), color=CAT[1], lw=1.0)
    a2.set(title="Imbalance (max - min cell)", xlabel="time [s]", ylabel="mV")
    a3 = fig.add_subplot(gs[2, 0])
    r0 = res.cfg.params().r0 * res.r0_mult[-1] * 1e3
    a3.bar(idx, r0, color=CAT[0])
    a3.axhline(float(np.median(r0)), color=INK2, lw=1, ls="--")
    a3.set(title="R0 per group at 25 degC (estimated)", xlabel="cell", ylabel="mOhm")
    a4 = fig.add_subplot(gs[2, 1])
    cap = res.capacity if res.capacity else None
    if cap:
        a4.bar(idx, cap["ah"], yerr=2 * cap["std_ah"], color=CAT[6], capsize=2, ecolor=INK2)
        a4.set(title="Capacity per group (+/- 2 sigma)", xlabel="cell", ylabel="Ah")
        a4.set_ylim(0.9 * np.min(cap["ah"]), None)
    else:
        a4.text(0.5, 0.5, "capacity not estimated for this chemistry\n(filter.estimate_capacity)", ha="center",
                va="center", transform=a4.transAxes, color=INK2)
        a4.set(title="Capacity per group")
    return fig


def diagnostics(res):
    """Is the filter consistent? Normalised innovations (should be white, unit variance)."""
    z = res.innov / np.sqrt(res.S)
    acc = res.accepted
    fig, ax = plt.subplots(2, 2, figsize=(14, 8), gridspec_kw={"hspace": 0.4, "wspace": 0.22})
    zz = np.where(acc, z, np.nan)
    ax[0, 0].plot(res.t, zz, ".", ms=1.5, color=CAT[0], alpha=0.4)
    rej = np.isfinite(z) & ~acc
    if rej.any():
        r, c = np.nonzero(rej)
        ax[0, 0].plot(res.t[r], np.clip(z[r, c], -8, 8), "x", color=CRIT, ms=6, label=f"rejected ({rej.sum()})")
        ax[0, 0].legend(loc="upper right")
    for k in (-3, 3):
        ax[0, 0].axhline(k, color=INK2, lw=0.8, ls="--")
    ax[0, 0].set(title="Normalised innovation e / sqrt(S)", xlabel="time [s]", ylim=(-8, 8))
    v = zz[np.isfinite(zz)]
    x = np.linspace(-5, 5, 200)
    ax[0, 1].hist(np.clip(v, -5, 5), bins=80, density=True, color=CAT[0], alpha=0.6)
    ax[0, 1].plot(x, np.exp(-x ** 2 / 2) / np.sqrt(2 * np.pi), color=INK, lw=1.5, label="N(0, 1)")
    ax[0, 1].set(title=f"Distribution (mean NIS {res.metrics['nis_mean']:.2f}, ideal 1)", xlabel="e / sqrt(S)")
    ax[0, 1].legend()
    ok = np.isfinite(zz).any(axis=1)
    col = np.nanmean(zz[ok], axis=1)
    col = col - np.mean(col)
    lags = np.arange(0, min(200, len(col) // 4))
    ac = np.array([np.sum(col[: len(col) - L] * col[L:]) for L in lags]) / np.sum(col * col)
    ax[1, 0].bar(lags, ac, color=CAT[1], width=1.0)
    ax[1, 0].axhspan(-2 / np.sqrt(len(col)), 2 / np.sqrt(len(col)), color=GRID, alpha=0.6)
    ax[1, 0].set(title="Autocorrelation (white = inside the grey band)", xlabel="lag [samples]")
    _band(ax[1, 1], res.t, res.bias, res.bias_std, CAT[3])
    ax[1, 1].plot(res.t, res.bias, color=CAT[3], lw=1.5)
    ax[1, 1].set(title="Current-sensor offset (smoothed, 2 sigma band)", xlabel="time [s]", ylabel="A")
    return fig


def ocv(cfg, res=None):
    """OCV curve with the hysteresis band and its slope (how much SOC information a mV carries)."""
    p = cfg.params()
    s = np.linspace(0, 1, 501)
    v = p.ocv(s)
    fig, ax = plt.subplots(1, 2, figsize=(14, 4.6))
    ax[0].fill_between(100 * s, v - p.m, v + p.m, color=CAT[0], alpha=0.2, lw=0, label="+/- hysteresis M")
    ax[0].plot(100 * s, v, color=CAT[0], label="OCV (mean of charge/discharge)")
    ax[0].plot(100 * p.ocv.soc_tab, p.ocv.v_tab, "o", color=INK2, ms=4, label="table points")
    if res is not None:
        ax[0].axvspan(100 * res.soc_pack.min(), 100 * res.soc_pack.max(), color=CAT[3], alpha=0.12, label="this run")
    ax[0].set(title=f"Open-circuit voltage ({cfg.cell.chemistry.upper()})", xlabel="SOC [%]", ylabel="V per cell")
    ax[0].legend(loc="lower right")
    ax[1].plot(100 * s, 1e3 * p.ocv.slope(s) / 100, color=CAT[1])
    ax[1].set(title="OCV slope", xlabel="SOC [%]", ylabel="mV per % SOC", yscale="log")
    return fig


def accuracy(res, truth):
    """Synthetic-data check: estimated minus true SOC with the estimator's own 2-sigma band."""
    st = np.column_stack([np.interp(res.t, truth.t, truth.soc[:, j]) for j in range(truth.soc.shape[1])])
    e = 100 * (res.soc - st)
    ef = 100 * (res.soc_f - st)
    fig, ax = plt.subplots(1, 2, figsize=(14, 4.6))
    j = int(np.argmax(np.abs(e).max(0)))
    _band(ax[0], res.t, 0 * res.t, 100 * res.soc_std[:, j], CAT[2], label="2 sigma (smoothed)")
    ax[0].plot(res.t, ef[:, j], color=CAT[0], lw=1.0, label="live filter")
    ax[0].plot(res.t, e[:, j], color=CAT[2], lw=1.6, label="smoothed")
    ax[0].axhline(0, color=INK2, lw=0.6)
    settled = res.t > res.t[0] + 30
    lim = 1.3 * max(np.abs(e[:, j]).max(), np.abs(ef[settled, j]).max(), 2 * 100 * res.soc_std[:, j].max())
    ax[0].set(title=f"SOC error, worst cell ({j + 1})  (first 30 s of the live filter may be off-scale)",
              xlabel="time [s]", ylabel="% SOC", ylim=(-lim, lim))
    ax[0].legend(loc="lower right")
    rms_s = np.sqrt(np.mean(e ** 2, axis=0))
    late = res.t > res.t[0] + 60
    rms_f = np.sqrt(np.mean(ef[late] ** 2, axis=0))
    idx = np.arange(1, len(rms_s) + 1)
    ax[1].bar(idx - 0.2, rms_f, width=0.4, color=CAT[0], label="live filter (after 60 s)")
    ax[1].bar(idx + 0.2, rms_s, width=0.4, color=CAT[2], label="smoothed")
    ax[1].set(title="RMS SOC error per cell", xlabel="cell", ylabel="% SOC")
    ax[1].legend()
    return fig


# =========================================================================== EV pipeline figures
def power(evr):
    """Accumulator power against the limit, and state of power along the run."""
    cfg, pw = evr.cfg, evr.power
    lim = cfg.limits.max_power / 1e3
    fig, ax = plt.subplots(3, 1, figsize=(14, 10), sharex=True, gridspec_kw={"hspace": 0.32})
    ax[0].plot(pw["t"], pw["power"] / 1e3, color=GREY, lw=0.7, label="instantaneous")
    ax[0].plot(pw["t"], pw["power_avg"] / 1e3, color=CAT[0], lw=1.4,
               label=f"{1e3 * cfg.limits.power_avg_window:.0f} ms average")
    ax[0].axhline(lim, color=CRIT, lw=1.2, ls="--", label=f"limit {lim:.0f} kW")
    for ev in pw["events"] + pw["events_avg"]:
        ax[0].axvspan(ev["t0"], ev["t0"] + max(ev["duration_s"], 0.2), color=CRIT, alpha=0.2, lw=0)
    ax[0].set(title="Accumulator power", ylabel="kW")
    ax[0].legend(loc="upper right", ncol=3)
    sp = evr.sop
    for k, h in enumerate(cfg.sop.horizons):
        ax[1].plot(sp["t"], sp[h]["p_dis"] / 1e3, color=CAT[k], lw=1.4, label=f"{h:g} s")
        ax[2].plot(sp["t"], -sp[h]["p_chg"] / 1e3, color=CAT[k], lw=1.4, label=f"{h:g} s")
    ax[1].axhline(lim, color=CRIT, lw=1.0, ls="--")
    ax[1].set(title="Available discharge power (state of power, conservative SOC)", ylabel="kW")
    ax[1].legend(loc="upper right", ncol=len(cfg.sop.horizons))
    ax[2].set(title="Available regen power", ylabel="kW", xlabel="time [s]")
    ax[2].legend(loc="upper right", ncol=len(cfg.sop.horizons))
    return fig


def thermal(evr):
    """Estimated core temperature of every group, thermistor fit, hottest cell."""
    th, cfg = evr.thermal, evr.cfg
    fig = plt.figure(figsize=(14, 9))
    gs = fig.add_gridspec(2, 2, height_ratios=[1.2, 1], hspace=0.4, wspace=0.2)
    a0 = fig.add_subplot(gs[0, :])
    im = a0.imshow(th.core.T, aspect="auto", origin="lower", cmap="inferno",
                   extent=[th.t[0], th.t[-1], 0.5, th.core.shape[1] + 0.5], interpolation="nearest")
    fig.colorbar(im, ax=a0, label="degC", pad=0.01)
    sc = getattr(th, "sensor_cells_all", th.sensor_cells)
    a0.plot(np.full(len(sc), th.t[0]), np.asarray(sc) + 1, ">", color=CAT[2], ms=5, clip_on=False,
            label="thermistor positions")
    a0.legend(loc="upper right")
    a0.set(title="Estimated core temperature, every group", xlabel="time [s]", ylabel="cell")
    a0.grid(False)
    a1 = fig.add_subplot(gs[1, 0])
    j = int(np.argmax(th.core.max(0)))
    _band(a1, th.t, th.core[:, j], th.core_std[:, j], CAT[1], label="2 sigma")
    a1.plot(th.t, th.core[:, j], color=CAT[1], lw=1.6, label=f"core, cell {j + 1}")
    a1.plot(th.t, th.surface[:, j], color=CAT[3], lw=1.2, label="can")
    a1.plot(th.t, th.ambient, color=GREY, lw=1.0, label="air / coolant (estimated)")
    a1.axhline(cfg.limits.cell_t_max, color=CRIT, lw=1, ls="--")
    a1.set(title="Hottest cell", xlabel="time [s]", ylabel="degC")
    a1.legend(loc="upper left", ncol=2)
    a2 = fig.add_subplot(gs[1, 1])
    r = th.sensor_resid
    idx = getattr(th, "sensor_index", np.arange(1, r.shape[1] + 1))
    a2.bar(idx, np.sqrt(np.nanmean(r ** 2, axis=0)), color=CAT[0])
    a2.set(title="Thermistor vs model, rms residual (live filter)", xlabel="thermistor", ylabel="K")
    return fig


def alignment(quality):
    taus, r = quality.delay["curve"]
    fig, ax = plt.subplots(figsize=(7, 3.6))
    ax.plot(1e3 * taus, r, color=CAT[0])
    ax.axvline(1e3 * quality.delay["delay_s"], color=CAT[1], ls="--",
               label=f"{1e3 * quality.delay['delay_s']:+.1f} ms")
    ax.set(title="Voltage vs current alignment", xlabel="voltage delay [ms]", ylabel="step correlation")
    ax.legend()
    return fig
