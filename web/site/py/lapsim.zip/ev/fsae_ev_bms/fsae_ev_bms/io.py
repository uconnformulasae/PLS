"""Accumulator data: loading from CSV exports, AiM .xrk/.xrz and live recordings.

Every channel keeps its native time base (current at 100 Hz and cell voltages
at 10 Hz from a BMS are normal); the estimator merges them exactly.

Conventions after loading: current [A] positive = DISCHARGE, voltages [V],
temperatures [degC], time [s].
"""
from __future__ import annotations

import csv
import dataclasses as dc
import re
from pathlib import Path
from typing import Optional

import numpy as np

_UNIT = {"v": 1.0, "mv": 1e-3, "kv": 1e3, "a": 1.0, "ma": 1e-3, "ka": 1e3,
         "c": 1.0, "degc": 1.0, "°c": 1.0, "k": 1.0, "rpm": 1.0, "": 1.0,
         "m/s": 1.0, "km/h": 1 / 3.6, "kph": 1 / 3.6, "mph": 0.44704, "#": 1.0}


@dc.dataclass
class BatteryData:
    t_i: Optional[np.ndarray] = None       # current time base
    i: Optional[np.ndarray] = None         # pack current, + = discharge
    i_sigma: Optional[np.ndarray] = None   # per-sample 1-sigma of i (model current); None -> sensor spec
    current_source: str = "sensor"         # 'sensor' | 'model'
    t_v: Optional[np.ndarray] = None       # voltage time base
    v_cells: Optional[np.ndarray] = None   # (K, Ns) cell (group) voltages, NaN where missing
    v_pack: Optional[np.ndarray] = None    # (K,) pack voltage on t_v
    t_temp: Optional[np.ndarray] = None
    temp: Optional[np.ndarray] = None      # (K, Ns) per-group temperature used by the estimator, degC
    temp_sensors: Optional[np.ndarray] = None  # (K, n_sensors) raw thermistor readings on t_temp
    sensor_cells: Optional[np.ndarray] = None  # 0-based group each thermistor sits on
    aux: dict = dc.field(default_factory=dict)  # 'inverter_current' | 'speed' | 'lap' -> (t, x)
    meta: dict = dc.field(default_factory=dict)
    source: str = ""

    @property
    def mode(self):
        return "cells" if self.v_cells is not None else "pack"

    def window(self, t0, t1):
        """Copy restricted to t0 <= t <= t1."""
        d = dc.replace(self)
        def cut(t, *arrs):
            if t is None:
                return (None,) * (1 + len(arrs))
            m = (t >= t0) & (t <= t1)
            return (t[m],) + tuple(None if a is None else a[m] for a in arrs)
        d.t_i, d.i, d.i_sigma = cut(self.t_i, self.i, self.i_sigma)
        d.t_v, d.v_cells, d.v_pack = cut(self.t_v, self.v_cells, self.v_pack)
        d.t_temp, d.temp, d.temp_sensors = cut(self.t_temp, self.temp, self.temp_sensors)
        d.aux = {k: cut(t, x) for k, (t, x) in self.aux.items()}
        return d


# --------------------------------------------------------------------------- raw readers
def read_raw(path) -> dict:
    """All channels of a log as {raw_name: (t, x, unit)}."""
    path = Path(path)
    ext = path.suffix.lower()
    if ext in (".xrk", ".xrz"):
        return _raw_xrk(path)
    if ext == ".csv":
        with open(path, newline="", encoding="utf-8-sig", errors="replace") as fh:
            head = fh.readline().strip().lower().replace(" ", "")
        if head.startswith("t,kind,index,value"):
            return _raw_events(path)
        return _raw_csv(path)
    raise ValueError(f"unsupported file type {ext}")


def _raw_xrk(path):
    import warnings
    from libxrk import aim_xrk, ChannelMetadata
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        log = aim_xrk(str(path))
    out = {}
    for raw, table in log.channels.items():
        cols = [c for c in table.column_names if c != "timecodes"]
        t = np.asarray(table.column("timecodes").to_numpy(), float) / 1000.0
        x = np.asarray(table.column(cols[0]).to_numpy(zero_copy_only=False), float)
        try:
            unit = ChannelMetadata.from_channel_table(table).units or ""
        except Exception:
            unit = ""
        out[raw] = (t, x, unit)
    return out


def _num(s):
    try:
        return float(s)
    except ValueError:
        return np.nan


def _raw_csv(path):
    """RaceStudio CSV export or plain CSV with a time column (first column)."""
    with open(path, newline="", encoding="utf-8-sig", errors="replace") as fh:
        rows = list(csv.reader(fh))
    hdr = next((i for i, r in enumerate(rows) if r and r[0].strip().lower() in
                ("time", "time (s)", "time [s]", "t", "time_s", "timestamp")
                and sum(1 for c in r[1:] if c.strip()) >= 1), None)
    if hdr is None:
        raise ValueError(f"{path.name}: no time column")
    header = [h.strip() for h in rows[hdr]]
    units = [""] * len(header)
    start = hdr + 1
    if start < len(rows) and rows[start] and not np.isfinite(_num(rows[start][0] or "x")):
        units = ([u.strip() for u in rows[start]] + [""] * len(header))[:len(header)]
        start += 1
    data = np.array([[_num(v) for v in (r + [""] * len(header))[:len(header)]]
                     for r in rows[start:] if r and np.isfinite(_num(r[0]))], float)
    t = data[:, 0] / (1000.0 if units[0].lower() == "ms" else 1.0)
    out = {}
    for j, name in enumerate(header[1:], start=1):
        m = np.isfinite(data[:, j])
        out[name] = (t[m], data[m, j], units[j])
    return out


def _raw_events(path):
    """Live-recorder event log: t,kind,index,value (see live.Recorder)."""
    acc = {}
    with open(path, newline="") as fh:
        rd = csv.reader(fh)
        next(rd)
        for r in rd:
            if len(r) < 4:
                continue
            t, kind, idx, val = float(r[0]), r[1], r[2], float(r[3])
            name = {"current": "pack_current", "pack_voltage": "pack_voltage", "speed": "speed",
                    "pack_temp": "pack_temp", "inverter_current": "inverter_current",
                    "lap": "lap"}.get(kind) or f"{kind}_{int(idx) + 1}"
            acc.setdefault(name, ([], []))
            acc[name][0].append(t)
            acc[name][1].append(val)
    units = {"pack_current": "A", "pack_voltage": "V"}
    return {k: (np.array(a), np.array(b), units.get(k, "V" if k.startswith("cell_v") else ""))
            for k, (a, b) in acc.items()}


# --------------------------------------------------------------------------- mapping
def _conv(x, unit, override=None):
    u = (override or unit or "").strip().lower()
    if u == "k":
        return x - 273.15
    f = _UNIT.get(u)
    if f is None:
        raise ValueError(f"unrecognised unit '{unit}'")
    return x * f


def _find(raw, spec):
    """Exact name, or 're:<pattern>' -> {index: name} (index 0-based)."""
    if spec is None:
        return None
    if spec.startswith("re:"):
        pat = re.compile(spec[3:], re.I)
        if pat.groups == 0:                       # single channel by pattern
            return next((name for name in raw if pat.match(name.strip())), None)
        hits = {}
        for name in raw:
            m = pat.match(name.strip())
            if m:
                hits[int(m.group(1)) - 1] = name
        return hits or None
    return spec if spec in raw else None


def _matrix(raw, hits, n, units_override):
    """Put indexed channels on one time base (union of their timestamps, NaN where a cell has no sample)."""
    ts = np.unique(np.concatenate([raw[nm][0] for nm in hits.values()]))
    M = np.full((len(ts), n), np.nan)
    for k, nm in hits.items():
        if k >= n:
            continue
        t, x, u = raw[nm]
        j = np.searchsorted(ts, t)
        M[j, k] = _conv(x, u, units_override.get(nm))
    return ts, M


def sensor_positions(cfg, n_sensors):
    """0-based group of every thermistor: from thermal.sensor_cells, else spread evenly."""
    sc = cfg.thermal.sensor_cells
    if sc:
        pos = np.asarray(sc, int) - 1
        if len(pos) < n_sensors:
            raise ValueError(f"thermal.sensor_cells lists {len(pos)} sensors but the log has {n_sensors}")
        return pos[:n_sensors]
    ns = cfg.pack.series
    return np.round((np.arange(n_sensors) + 0.5) * ns / n_sensors - 0.5).astype(int)


def sensors_to_groups(temp_sensors, sensor_cells, ns):
    """First estimate of every group's temperature: linear in group index between the
    sensors (nearest sensor beyond the ends; averaged where two sensors share a group).
    The thermal estimator replaces this with modelled core temperatures."""
    T = np.asarray(temp_sensors, float)
    pos = np.asarray(sensor_cells, float)
    out = np.empty((T.shape[0], ns))
    g = np.arange(ns)
    u, inv = np.unique(pos, return_inverse=True)
    for k in range(T.shape[0]):
        row = T[k]
        ok = np.isfinite(row)
        if not ok.any():
            out[k] = np.nan
            continue
        vals = np.bincount(inv[ok], weights=row[ok], minlength=len(u)) / np.maximum(
            np.bincount(inv[ok], minlength=len(u)), 1)
        have = np.bincount(inv[ok], minlength=len(u)) > 0
        out[k] = np.interp(g, u[have], vals[have])
    return out


def from_raw(raw: dict, cfg) -> BatteryData:
    """Map raw channels to a BatteryData using ``cfg.channels``."""
    ch, ns = cfg.channels, int(cfg.pack.series)
    uo = ch.units or {}
    d = BatteryData()
    cells = _find(raw, ch.cell_voltage)
    pv = _find(raw, ch.pack_voltage)
    pc = _find(raw, ch.pack_current)
    pv = pv if not isinstance(pv, dict) else next(iter(pv.values()))
    pc = pc if not isinstance(pc, dict) else next(iter(pc.values()))
    if cells:
        d.t_v, d.v_cells = _matrix(raw, cells, ns, uo)
        if len(cells) < ns:
            d.meta["warning_cells"] = f"only {len(cells)} of {ns} cell-voltage channels found"
        if pv:
            t, x, u = raw[pv]
            d.v_pack = np.interp(d.t_v, t, _conv(x, u, uo.get(pv)))
    elif pv:
        t, x, u = raw[pv]
        d.t_v, d.v_pack = t, _conv(x, u, uo.get(pv))
    else:
        raise ValueError("no accumulator voltage channel found: set channels.cell_voltage or channels.pack_voltage")
    temps = _find(raw, ch.cell_temp)
    if temps:
        n_sens = max(temps) + 1
        d.t_temp, d.temp_sensors = _matrix(raw, temps, n_sens, uo)
        d.temp_sensors = _fill_cols(d.temp_sensors)
        d.sensor_cells = sensor_positions(cfg, n_sens)
        d.temp = sensors_to_groups(d.temp_sensors, d.sensor_cells, ns)
    else:
        pt = _find(raw, ch.pack_temp)
        if pt:
            t, x, u = raw[pt]
            d.t_temp, d.temp_sensors = t, _conv(x, u, uo.get(pt))[:, None]
            d.sensor_cells = np.array([ns // 2])
            d.temp = np.repeat(d.temp_sensors, ns, axis=1)
    if not pc:
        raise ValueError("no pack current channel found (channels.pack_current); the estimator needs the current")
    t, x, u = raw[pc]
    d.t_i, d.i = t, cfg.sensors.current_sign * _conv(x, u, uo.get(pc)) * (1 + cfg.sensors.current_gain_error)
    d.current_source = "sensor"
    for key, spec in (("inverter_current", ch.inverter_current), ("speed", ch.speed), ("lap", ch.lap_marker)):
        nm = _find(raw, spec)
        nm = nm if not isinstance(nm, dict) else next(iter(nm.values()))
        if nm:
            t, x, u = raw[nm]
            x = _conv(x, u, uo.get(nm))
            if key == "inverter_current":
                x = cfg.sensors.current_sign * x
            d.aux[key] = (t, x)
    return d


def _fill_cols(M):
    """Forward/backward fill NaNs column-wise (temperatures are slow)."""
    M = M.copy()
    for j in range(M.shape[1]):
        c = M[:, j]
        ok = np.isfinite(c)
        if ok.any():
            M[:, j] = np.interp(np.arange(len(c)), np.flatnonzero(ok), c[ok])
    return M


def load_battery_log(path, cfg) -> BatteryData:
    d = from_raw(read_raw(path), cfg)
    d.source = str(path)
    return d


def offset_from_window(d: BatteryData, t0, t1):
    """Current-sensor offset from a window where the true current is known to be zero
    (tractive system / master switch off, sensor powered). Returns (offset, 1-sigma).
    Put the result in cfg.sensors.current_offset / current_bias_std."""
    m = (d.t_i >= t0) & (d.t_i <= t1)
    if m.sum() < 10:
        raise ValueError("fewer than 10 current samples in the zero-current window")
    x = d.i[m]
    # samples are correlated (filtering in the sensor): use an effective count of n/10
    return float(np.mean(x)), float(max(np.std(x) / np.sqrt(max(m.sum() / 10, 1)), 0.01))


def _runs(mask):
    idx = np.flatnonzero(np.diff(np.r_[0, mask.astype(int), 0]))
    return list(zip(idx[::2], idx[1::2] - 1))
