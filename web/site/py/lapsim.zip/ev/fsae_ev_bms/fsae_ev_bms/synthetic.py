"""Synthetic FSAE EV accumulator data with known truth, for verifying the whole pipeline.

The 'true' pack differs from the configuration the way a real one does (cell-to-cell
capacity and resistance spread, unequal starting SOC, thermal parameters off by 20 %),
and the logged data carries the faults real logs carry, each switchable:
current-sensor offset, ADC noise and quantisation, timestamp jitter, lost CAN frames,
glitches, voltage lagging the current, an open-wire cell tap, a frozen BMS channel,
a current gap, duplicated / out-of-order timestamps, a dead thermistor, and an
inverter DC current with its own gain/offset error.
"""
from __future__ import annotations

import dataclasses as dc

import numpy as np

from .cell import simulate
from .io import BatteryData, sensor_positions


def endurance_current(duration=600.0, fs=100.0, i_peak=150.0, i_regen=-60.0, lap=55.0, seed=0, rest=(None, None)):
    """FSAE-endurance-like pack current: launches, part throttle, regen braking, coasting.
    Returns (t, i, lap_start_times). ``rest=(t0, t1)`` inserts a driver change (zero current)."""
    rng = np.random.default_rng(seed)
    t = np.arange(0.0, duration, 1.0 / fs)
    i = np.zeros_like(t)
    segs = [(0.10, 0.95), (0.06, -0.8), (0.08, 0.45), (0.05, 0.0), (0.12, 0.7), (0.07, -1.0), (0.10, 0.35),
            (0.08, 0.85), (0.05, -0.6), (0.14, 0.5), (0.05, 0.05), (0.10, 0.6)]
    tt, laps = 0.0, []
    while tt < duration:
        laps.append(tt)
        L = lap * rng.uniform(0.95, 1.05)
        for frac, lvl in segs:
            d = frac * L
            m = (t >= tt) & (t < tt + d)
            i[m] = lvl * (i_peak if lvl >= 0 else -i_regen) * rng.uniform(0.8, 1.1)
            tt += d
    from scipy.signal import lfilter
    a = np.exp(-1 / (0.15 * fs))                     # driver / torque ramp, not a square wave
    i = lfilter([1 - a], [1, -a], i)
    i += rng.normal(0, 0.02 * i_peak, len(t)) * (np.abs(i) > 1)
    if rest[0] is not None:
        i[(t >= rest[0]) & (t < rest[1])] = 0.0
    return t, i, np.array(laps)


@dc.dataclass
class Truth:
    t: np.ndarray
    i: np.ndarray
    soc: np.ndarray        # (T, N)
    v: np.ndarray
    h: np.ndarray
    v1: np.ndarray
    v2: np.ndarray
    core: np.ndarray       # (T, N) core temperature
    surface: np.ndarray
    bias: float
    delay: float
    params: object
    laps: np.ndarray


def make_synthetic(cfg, t, i_true, *, laps=None, soc0=0.9, soc0_spread=0.02, cap_spread=0.03, r0_spread=0.10,
                   bias=0.3, fs_v=10.0, fs_temp=1.0, n_thermistors=None, temp_noise=0.3, t_amb=28.0,
                   thermal_error=0.2, v_noise=None, i_noise=None, adc_lsb=1e-3, i_lsb=0.05, jitter=0.002,
                   dropout=0.01, spikes=5, delay=0.0, open_wire=None, stuck=None, current_gap=None,
                   dup_frac=0.0, disorder_frac=0.0, dead_thermistor=None, inverter=True, seed=1, mode="cells"):
    """Return (BatteryData as the logger would record it, Truth).

    open_wire=(cell, t0, t1): that tap reads 0 V; stuck=(cell, t0, t1): frozen value;
    current_gap=(t0, t1): current samples lost; dead_thermistor=k: sensor k reads -40 C.
    """
    from . import thermal
    rng = np.random.default_rng(seed)
    p_nom = cfg.params()
    n = p_nom.n
    p_true = dc.replace(p_nom, q=p_nom.q * (1 + cap_spread * rng.standard_normal(n)),
                        r0=p_nom.r0 * (1 + r0_spread * rng.standard_normal(n)))
    s0 = np.clip(soc0 + soc0_spread * rng.standard_normal(n), 0.02, 1.0)
    # thermal truth with parameters off from the config (the estimator does not know them)
    cfg_t = cfg.copy()
    th = cfg_t.thermal
    th.ambient = t_amb
    th.r_surface_ambient *= 1 + thermal_error * rng.uniform(-1, 1)
    th.r_core_surface *= 1 + thermal_error * rng.uniform(-1, 1)
    th.cell_cp *= 1 + 0.5 * thermal_error * rng.uniform(-1, 1)
    tg = np.arange(t[0], t[-1] + 1.0, 1.0)
    T_core = np.full((len(t), n), t_amb)
    for _ in range(3):                               # electro-thermal fixed point
        sim = simulate(p_true, t, i_true, temp=T_core, soc0=s0, h0=-1.0, substeps=2)
        q = i_true[:, None] * (p_true.ocv(sim["soc"], T_core) - sim["v"])
        qg = np.column_stack([np.interp(tg, t, q[:, j]) for j in range(n)])
        core_g, surf_g, _ = thermal.simulate(cfg_t, tg, qg, t_amb=t_amb)
        T_core = np.column_stack([np.interp(t, tg, core_g[:, j]) for j in range(n)])
    # final electrical pass with exactly the temperatures that are recorded as truth
    sim = simulate(p_true, t, i_true, temp=T_core, soc0=s0, h0=-1.0, substeps=2)
    surf = np.column_stack([np.interp(t, tg, surf_g[:, j]) for j in range(n)])
    s = cfg.sensors
    v_noise = s.cell_voltage_noise if v_noise is None else v_noise
    i_noise = s.current_noise if i_noise is None else i_noise
    # current sensor
    i_log = np.round((i_true + bias + rng.normal(0, i_noise, len(t))) / i_lsb) * i_lsb
    t_i = np.sort(t + rng.uniform(-jitter, jitter, len(t)))
    if current_gap:
        keep = ~((t_i >= current_gap[0]) & (t_i < current_gap[1]))
        t_i, i_log = t_i[keep], i_log[keep]
    # BMS cell voltages, sampled at tv_true; with a delay the logger stamps each sample 'delay' late
    tv_true = np.arange(t[0] + 0.05, t[-1] - 0.05 - max(delay, 0), 1.0 / fs_v)
    tv_true = tv_true + rng.uniform(-jitter, jitter, len(tv_true))
    V = np.column_stack([np.interp(tv_true, t, sim["v"][:, j]) for j in range(n)])
    V = np.round((V + rng.normal(0, v_noise, V.shape)) / adc_lsb) * adc_lsb
    V[rng.random(V.shape) < dropout] = np.nan
    for _ in range(spikes):
        V[rng.integers(len(tv_true)), rng.integers(n)] += rng.choice([-1, 1]) * rng.uniform(0.2, 0.6)
    tv = tv_true + delay
    if open_wire:
        j, a, b = open_wire
        V[(tv >= a) & (tv < b), j] = 0.0
    if stuck:
        j, a, b = stuck
        m = (tv >= a) & (tv < b)
        V[m, j] = V[np.flatnonzero(m)[0], j]
    v_pack = np.sum(np.column_stack([np.interp(tv_true, t, sim["v"][:, j]) for j in range(n)]), 1) \
        - np.interp(tv_true, t, i_true) * p_nom.r_ic
    v_pack = np.round((v_pack + rng.normal(0, s.pack_voltage_noise, len(tv))) / 0.01) * 0.01
    d = BatteryData(t_i=t_i, i=i_log, t_v=tv, current_source="sensor", source="synthetic")
    if mode == "cells":
        d.v_cells = V
    d.v_pack = v_pack
    # thermistors on a subset of groups, measuring can temperature
    n_th = n_thermistors or max(1, int(np.ceil(0.3 * n)))
    pos = sensor_positions(cfg, n_th)
    tT = np.arange(t[0], t[-1], 1.0 / fs_temp)
    TT = np.column_stack([np.interp(tT, t, surf[:, j]) for j in pos])
    TT = np.round((TT + rng.normal(0, temp_noise, TT.shape)) * 10) / 10
    if dead_thermistor is not None:
        TT[:, dead_thermistor] = -40.0
    from .io import sensors_to_groups
    d.t_temp, d.temp_sensors, d.sensor_cells = tT, TT, pos
    d.temp = sensors_to_groups(TT, pos, n)
    # timestamp faults
    if dup_frac:
        k = rng.choice(len(d.t_i), int(dup_frac * len(d.t_i)), replace=False)
        d.t_i = np.r_[d.t_i, d.t_i[k]]
        d.i = np.r_[d.i, d.i[k]]
    if disorder_frac:
        k = rng.choice(len(d.t_i) - 1, int(disorder_frac * len(d.t_i)), replace=False)
        d.t_i[k], d.t_i[k + 1] = d.t_i[k + 1].copy(), d.t_i[k].copy()
        d.i[k], d.i[k + 1] = d.i[k + 1].copy(), d.i[k].copy()
    if inverter:                                      # inverter DC current: 2 % gain error, +1.5 A offset
        ti = t[::5]
        d.aux["inverter_current"] = (ti, 0.98 * np.interp(ti, t, i_true) + 1.5 + rng.normal(0, 1.0, len(ti)))
    if laps is not None:
        d.aux["lap"] = (np.asarray(laps, float), np.arange(1, len(laps) + 1, dtype=float))
    truth = Truth(t=t, i=i_true, soc=sim["soc"], v=sim["v"], h=sim["h"], v1=sim["v1"], v2=sim["v2"],
                  core=T_core, surface=surf, bias=bias, delay=delay, params=p_true,
                  laps=np.asarray(laps if laps is not None else [], float))
    return d, truth
