"""Batched Kalman filters for a bank of cells + the Rauch-Tung-Striebel smoother.

One filter instance estimates N independent cells at once (arrays (N, n) and
(N, n, n)), so a 140-cell accumulator costs the same Python overhead as one cell.

State per cell:  [soc, v1, v2, h, (b), (g), (c), (d)]
    b  current-sensor offset [A]  (measured = true + b); random walk
    g  multiplier on the ohmic resistance R0 (ageing, contact, temperature error); random walk
    gp multiplier on the polarisation resistances R1, R2 (temperature error scales these too:
       without it a 2 K core-temperature error became a 4 A offset error); random walk
    c  Q_nominal / Q_true, inverse-capacity multiplier (state of health); random walk
    d  voltage-model error [V], first-order Gauss-Markov (sigma_d, tau_d). Without it
       a filter that sees thousands of samples treats sub-mV model error as signal
       and becomes over-confident, worst on the flat LiFePO4 plateau (1 % SOC ~ 1 mV)

Methods
    ekf   extended KF, Joseph-form covariance update
    iekf  iterated EKF (Gauss-Newton measurement update) - removes the linearisation
          error at the knees of the OCV curve
    ukf   scaled unscented KF (sigma points through the exact nonlinear model)

Accuracy details that matter for SOC:
  * exact first-order-hold discretisation (see ``cell``), so dt jitter costs nothing
  * the noise on the current sample enters BOTH the state prediction and the
    voltage measurement (through R0); the cross-covariance C = cov(w, v) is
    carried into S, K and the Joseph update instead of being ignored
  * the current-sensor offset is estimated (it is the dominant coulomb-count error)
  * chi-square innovation gating rejects ADC glitches / CAN errors; the gate reopens
    after ``max_rejections`` consecutive rejections so a real step is not locked out
  * optional innovation-based measurement-noise adaptation
  * process noise built from the actual input-noise propagation (correlated), not
    a hand-tuned diagonal
"""
from __future__ import annotations

import dataclasses as dc

import numpy as np
from scipy.stats import chi2

from .cell import SOC, V1, V2, H, N_BASE, rc_weights, hyst_sign
from .chemistry import arrhenius


def mean_params(p):
    """Parameters of one 'average' cell (for the pack-level / pack-voltage filter)."""
    one = lambda a: np.array([float(np.mean(a))])
    return dc.replace(p, n=1, q=one(p.q), r0=one(p.r0), r1=one(p.r1), r2=one(p.r2))


def subset_params(p, idx):
    idx = np.asarray(idx)
    return dc.replace(p, n=len(idx), q=p.q[idx], r0=p.r0[idx], r1=p.r1[idx], r2=p.r2[idx])


class CellBankFilter:
    def __init__(self, p, fcfg, *, soc0, soc0_std, sigma_y, sigma_u, bias_walk=0.0, bias0=0.0, bias0_std=0.0,
                 estimate_bias=None, estimate_r0=None, estimate_capacity=None, r_extra=0.0, method=None,
                 h0=0.0, h0_std=0.5):
        self.p, self.c = p, fcfg
        self.N = p.n
        self.method = (method or fcfg.method).lower()
        if self.method not in ("ekf", "iekf", "ukf"):
            raise ValueError(f"unknown filter method '{self.method}'")
        eb = fcfg.estimate_bias if estimate_bias is None else estimate_bias
        er = fcfg.estimate_r0 if estimate_r0 is None else estimate_r0
        n = N_BASE
        self.ib = n if eb else None
        n += bool(eb)
        self.ig = n if er else None
        n += bool(er)
        self.ip = n if er and getattr(fcfg, "estimate_rpol", True) else None
        n += self.ip is not None
        ec = fcfg.estimate_capacity if estimate_capacity is None else estimate_capacity
        if ec is None:
            ec = p.estimate_capacity
        self.ic = n if ec else None
        n += bool(ec)
        self.consider = [self.ic] if (ec == "consider") else []
        self.sd = p.model_error if fcfg.model_error is None else fcfg.model_error
        self.td = p.model_error_tau if fcfg.model_error_tau is None else fcfg.model_error_tau
        self.idm = n if self.sd and self.sd > 0 else None
        n += self.idm is not None
        self.n = n
        self.sigma_y = np.broadcast_to(np.asarray(sigma_y, float), (self.N,)).copy()
        self.sigma_u = sigma_u
        self.bias_walk = bias_walk
        self.r_extra = r_extra
        N = self.N
        self.x = np.zeros((N, n))
        self.x[:, SOC] = soc0
        self.x[:, H] = h0
        P0 = np.zeros(n)
        P0[SOC] = np.broadcast_to(soc0_std, (N,)).max() ** 2
        P0[V1] = P0[V2] = (5e-3) ** 2
        P0[H] = h0_std ** 2
        if self.ib is not None:
            self.x[:, self.ib] = bias0
            P0[self.ib] = max(bias0_std, 1e-6) ** 2
        if self.ig is not None:
            self.x[:, self.ig] = 1.0
            P0[self.ig] = fcfg.r0_mult_std ** 2
        if self.ip is not None:
            self.x[:, self.ip] = 1.0
            P0[self.ip] = fcfg.r0_mult_std ** 2
        if self.ic is not None:
            self.x[:, self.ic] = 1.0
            P0[self.ic] = fcfg.capacity_std ** 2
        if self.idm is not None:
            P0[self.idm] = self.sd ** 2
        self.P = np.repeat(np.diag(P0)[None], N, axis=0)
        self.P[:, SOC, SOC] = np.broadcast_to(np.asarray(soc0_std, float) ** 2, (N,))
        self.s = np.ones(N)                       # instantaneous-hysteresis sign
        self.i_eps = 0.01 * p.q / 3600            # C/100: below this the cell is 'at rest'
        self.G1 = np.zeros((N, n))                # d x / d u1 of the last prediction step
        self.su_last = 0.0
        self.Fc = np.repeat(np.eye(n)[None], N, axis=0)
        self.rej = np.zeros(N, int)
        self.loglik = np.zeros(N)                 # sum of log N(e; 0, S): scores competing hypotheses
        self.r2scale = np.ones(N)
        self.gate = chi2.ppf(fcfg.gate_probability, 1)
        self.records = None
        self.t = None
        # unscented weights
        a, b, k = fcfg.ukf_alpha, fcfg.ukf_beta, fcfg.ukf_kappa
        lam = a * a * (n + k) - n
        self.ukf_c = n + lam
        self.Wm = np.full(2 * n + 1, 0.5 / (n + lam))
        self.Wc = self.Wm.copy()
        self.Wm[0] = lam / (n + lam)
        self.Wc[0] = lam / (n + lam) + (1 - a * a + b)

    # ------------------------------------------------------------------ model
    def _r(self, temp):
        f = arrhenius(temp, self.p.ea, self.p.t_ref)
        return self.p.r0 * f, self.p.r1 * f, self.p.r2 * f

    def _socf(self, soc):
        p = self.p
        return np.interp(soc, p.r0_soc, p.r0_soc_f) if p.r0_soc is not None else 1.0

    def _f(self, x, u0, u1, dt, temp):
        """Nonlinear propagation; x is (N, K, n), u/temp are (N,)."""
        p = self.p
        _, r1, r2 = self._r(temp)
        b = x[..., self.ib] if self.ib is not None else 0.0
        i0 = u0[:, None] - b
        i1 = u1[:, None] - b
        ib = 0.5 * (i0 + i1)
        q = p.q[:, None]
        eta = np.where(ib < 0, p.eta_c, 1.0)
        psi = x[..., self.ic] if self.ic is not None else 1.0
        gm = x[..., self.ip] if self.ip is not None else 1.0
        out = x.copy()
        out[..., SOC] = x[..., SOC] - psi * eta * dt * ib / q
        a1, w01, w11 = rc_weights(dt, p.tau1)
        out[..., V1] = a1 * x[..., V1] + gm * r1[:, None] * (w01 * i0 + w11 * i1)
        if p.tau2 > 0:
            a2, w02, w12 = rc_weights(dt, p.tau2)
            out[..., V2] = a2 * x[..., V2] + gm * r2[:, None] * (w02 * i0 + w12 * i1)
        else:
            out[..., V2] = 0.0
        k = np.exp(-np.abs(eta * ib * p.gamma * dt / q))
        out[..., H] = k * x[..., H] - (1 - k) * np.sign(ib)
        if self.idm is not None:
            out[..., self.idm] = np.exp(-dt / self.td) * x[..., self.idm]
        return out

    def _jac_f(self, x, u0, u1, dt, temp):
        """F = df/dx, G0 = df/du0, G1 = df/du1 at the mean x (N, n)."""
        p, N, n = self.p, self.N, self.n
        _, r1, r2 = self._r(temp)
        b = x[:, self.ib] if self.ib is not None else 0.0
        ib = 0.5 * (u0 + u1) - b
        eta = np.where(ib < 0, p.eta_c, 1.0)
        c = eta * p.gamma * dt / p.q
        k = np.exp(-np.abs(c * ib))
        dk_di = -k * c * np.sign(ib)                    # d kappa / d i_bar
        dh_di = (x[:, H] + np.sign(ib)) * dk_di         # d h' / d i_bar
        a1, w01, w11 = rc_weights(dt, p.tau1)
        a2, w02, w12 = rc_weights(dt, p.tau2) if p.tau2 > 0 else (0.0, 0.0, 0.0)
        F = np.repeat(np.eye(n)[None], N, axis=0)
        F[:, V1, V1] = a1
        F[:, V2, V2] = a2 if p.tau2 > 0 else 0.0
        F[:, H, H] = k
        G0 = np.zeros((N, n))
        G1 = np.zeros((N, n))
        psi = x[:, self.ic] if self.ic is not None else 1.0
        G0[:, SOC] = G1[:, SOC] = -psi * eta * dt / (2 * p.q)
        if self.ic is not None:
            F[:, SOC, self.ic] = -eta * dt * ib / p.q
        gm = x[:, self.ip] if self.ip is not None else 1.0
        G0[:, V1], G1[:, V1] = gm * r1 * w01, gm * r1 * w11
        if p.tau2 > 0:
            G0[:, V2], G1[:, V2] = gm * r2 * w02, gm * r2 * w12
        if self.ip is not None:
            i0, i1 = u0 - b, u1 - b
            F[:, V1, self.ip] = r1 * (w01 * i0 + w11 * i1)
            if p.tau2 > 0:
                F[:, V2, self.ip] = r2 * (w02 * i0 + w12 * i1)
        G0[:, H] = G1[:, H] = 0.5 * dh_di
        if self.ib is not None:                          # true current = u - b
            F[:, :, self.ib] -= G0 + G1
            F[:, self.ib, self.ib] = 1.0
        if self.idm is not None:
            F[:, self.idm, self.idm] = np.exp(-dt / self.td)
        return F, G0, G1

    def _h(self, x, u1, temp):
        """Predicted terminal voltage; x is (N, K, n)."""
        p = self.p
        r0, _, _ = self._r(temp)
        soc = x[..., SOC]
        b = x[..., self.ib] if self.ib is not None else 0.0
        g = x[..., self.ig] if self.ig is not None else 1.0
        i = u1[:, None] - b
        r0e = r0[:, None] * self._socf(soc) * g + self.r_extra
        dm = x[..., self.idm] if self.idm is not None else 0.0
        return (p.ocv(soc, temp[:, None]) + p.m * x[..., H] + p.m0 * self.s[:, None]
                - x[..., V1] - x[..., V2] - r0e * i + dm)

    def _jac_h(self, x, u1, temp):
        p = self.p
        r0, _, _ = self._r(temp)
        soc = x[:, SOC]
        b = x[:, self.ib] if self.ib is not None else 0.0
        g = x[:, self.ig] if self.ig is not None else 1.0
        sf = self._socf(soc)
        i = u1 - b
        Hm = np.zeros((self.N, self.n))
        Hm[:, SOC] = p.ocv.slope(soc)
        if p.r0_soc is not None:
            dsf = np.interp(soc, p.r0_soc[1:], np.diff(p.r0_soc_f) / np.diff(p.r0_soc))
            Hm[:, SOC] -= r0 * dsf * g * i
        Hm[:, V1] = -1.0
        Hm[:, V2] = -1.0 if p.tau2 > 0 else 0.0
        Hm[:, H] = p.m
        r0e = r0 * sf * g + self.r_extra
        if self.ib is not None:
            Hm[:, self.ib] = r0e
        if self.ig is not None:
            Hm[:, self.ig] = -r0 * sf * i
        if self.idm is not None:
            Hm[:, self.idm] = 1.0
        return Hm, r0e

    def _Q(self, G0, G1, dt, su):
        c = self.c
        su2 = np.broadcast_to(np.asarray(su, float) ** 2, (self.N,))[:, None, None]
        Q = su2 * (G0[:, :, None] * G0[:, None, :] + G1[:, :, None] * G1[:, None, :])
        d = np.zeros(self.n)
        d[SOC] = c.soc_walk ** 2
        d[V1] = d[V2] = c.v_rc_walk ** 2
        d[H] = c.hyst_walk ** 2
        if self.ib is not None:
            d[self.ib] = self.bias_walk ** 2
        if self.ig is not None:
            d[self.ig] = c.r0_walk ** 2
        if self.ip is not None:
            d[self.ip] = c.r0_walk ** 2
        if self.ic is not None:
            d[self.ic] = c.capacity_walk ** 2
        d = d * dt
        if self.idm is not None:
            d[self.idm] = self.sd ** 2 * -np.expm1(-2 * dt / self.td)
        return Q + np.diag(d)[None]

    # ------------------------------------------------------------------ sigma points
    def _sigma(self, x, P):
        L = _chol(self.ukf_c * P)                        # (N, n, n), columns are offsets
        d = np.swapaxes(L, 1, 2)
        return np.concatenate([x[:, None], x[:, None] + d, x[:, None] - d], axis=1)

    # ------------------------------------------------------------------ predict
    def predict(self, u0, u1, dt, temp, sigma_u=None):
        if dt <= 0:
            return
        u0 = np.broadcast_to(np.asarray(u0, float), (self.N,))
        u1 = np.broadcast_to(np.asarray(u1, float), (self.N,))
        temp = np.broadcast_to(np.asarray(temp, float), (self.N,))
        su = self.sigma_u if sigma_u is None else sigma_u
        F, G0, G1 = self._jac_f(self.x, u0, u1, dt, temp)
        Q = self._Q(G0, G1, dt, su)
        if self.method == "ukf":
            X = self._sigma(self.x, self.P)
            Y = self._f(X, u0, u1, dt, temp)
            xm = np.einsum("k,nki->ni", self.Wm, Y)
            dX, dY = X - self.x[:, None], Y - xm[:, None]
            P = np.einsum("k,nki,nkj->nij", self.Wc, dY, dY) + Q
            D = np.einsum("k,nki,nkj->nij", self.Wc, dX, dY)          # cov(x_k, x_k+1)
            F = np.swapaxes(np.linalg.solve(self.P, D), 1, 2)        # statistical linearisation
            self.x = xm
        else:
            self.x = self._f(self.x[:, None], u0, u1, dt, temp)[:, 0]
            P = F @ self.P @ np.swapaxes(F, 1, 2) + Q
        self.P = 0.5 * (P + np.swapaxes(P, 1, 2))
        self.Fc = F @ self.Fc
        self.G1 = G1
        self.su_last = np.broadcast_to(np.asarray(su, float), (self.N,))
        # instantaneous hysteresis sign follows the (bias-corrected) current
        b = self.x[:, self.ib] if self.ib is not None else 0.0
        self.s = hyst_sign(u1 - b, self.s, self.i_eps)

    def predict_composite(self, c, k, temp, x_lin=None):
        """Exact propagation over one whole interval between voltage samples (offline fast path).

        ``c`` holds per-interval sums from ``interval_coeffs`` (index k). For a
        given current the dynamics are linear in the state, so the composite
        step equals running every current sample one by one (the bias's effect
        on the hysteresis rate is the only term dropped).
        """
        p, N, n = self.p, self.N, self.n
        temp = np.broadcast_to(np.asarray(temp, float), (N,))
        _, r1, r2 = self._r(temp)
        q = p.q
        F = np.repeat(np.eye(n)[None], N, axis=0)
        x = self.x.copy()
        b = x[:, self.ib] if self.ib is not None else 0.0
        psi = x[:, self.ic] if self.ic is not None else 1.0
        # linearisation point: the filter mean, or (iterated smoother) the previous smoothed state.
        # Only the SOC row is nonlinear (capacity x charge, capacity x offset).
        xl = self.x if x_lin is None else x_lin
        bl = xl[:, self.ib] if self.ib is not None else 0.0
        pl = xl[:, self.ic] if self.ic is not None else 1.0
        A_, B_ = c["soc_a"][k], c["soc_b"][k]
        x[:, SOC] = self.x[:, SOC] - (psi * (A_ - bl * B_) - pl * B_ * (b - bl)) / q
        if self.ic is not None:
            F[:, SOC, self.ic] = -(A_ - bl * B_) / q
        # RC rows are bilinear in (resistance multiplier g, offset b): linearised at (gl, bl)
        gm = x[:, self.ip] if self.ip is not None else 1.0
        gl = xl[:, self.ip] if self.ip is not None else 1.0
        u1c, u2c = c["rc1"][k] - bl * c["rc1_b"][k], c["rc2"][k] - bl * c["rc2_b"][k]
        x[:, V1] = c["a1"][k] * self.x[:, V1] + r1 * (gm * u1c - gl * c["rc1_b"][k] * (b - bl))
        F[:, V1, V1] = c["a1"][k]
        if self.ip is not None:
            F[:, V1, self.ip] = r1 * u1c
            if p.tau2 > 0:
                F[:, V2, self.ip] = r2 * u2c
        if p.tau2 > 0:
            x[:, V2] = c["a2"][k] * self.x[:, V2] + r2 * (gm * u2c - gl * c["rc2_b"][k] * (b - bl))
            F[:, V2, V2] = c["a2"][k]
        else:
            x[:, V2] = 0.0
            F[:, V2, V2] = 0.0
        x[:, H] = c["hk"][k] * self.x[:, H] + c["hin"][k]
        F[:, H, H] = c["hk"][k]
        if self.idm is not None:
            ad = np.exp(-c["dt"][k] / self.td)
            x[:, self.idm] = ad * self.x[:, self.idm]
            F[:, self.idm, self.idm] = ad
        if self.ib is not None:
            F[:, SOC, self.ib] = pl * B_ / q
            F[:, V1, self.ib] = -r1 * gl * c["rc1_b"][k]
            F[:, V2, self.ib] = -r2 * gl * c["rc2_b"][k] if p.tau2 > 0 else 0.0
        # input-noise covariance (soc, v1, v2 block) + random walks
        g = np.stack([pl / q * np.ones(N), r1 * gl, r2 * gl], axis=1)  # (N, 3) scale of each row
        Qi = c["qin"][k] * g[:, :, None] * g[:, None, :]              # (N, 3, 3)
        dt = c["dt"][k]
        Q = np.zeros((N, n, n))
        Q[:, :3, :3] = Qi
        d = np.zeros(n)
        d[SOC] = self.c.soc_walk ** 2
        d[V1] = d[V2] = self.c.v_rc_walk ** 2
        d[H] = self.c.hyst_walk ** 2
        if self.ib is not None:
            d[self.ib] = self.bias_walk ** 2
        if self.ig is not None:
            d[self.ig] = self.c.r0_walk ** 2
        if self.ip is not None:
            d[self.ip] = self.c.r0_walk ** 2
        if self.ic is not None:
            d[self.ic] = self.c.capacity_walk ** 2
        d = d * dt
        if self.idm is not None:
            d[self.idm] = self.sd ** 2 * -np.expm1(-2 * dt / self.td)
        Q += np.diag(d)[None]
        if p.tau2 <= 0:
            Q[:, V2, :] = Q[:, :, V2] = 0.0
        self.x = x
        P = F @ self.P @ np.swapaxes(F, 1, 2) + Q
        self.P = 0.5 * (P + np.swapaxes(P, 1, 2))
        self.Fc = F @ self.Fc
        G1 = np.zeros((N, n))
        G1[:, SOC] = pl * c["g1"][k, 0] / q
        G1[:, V1] = r1 * gl * c["g1"][k, 1]
        G1[:, V2] = r2 * gl * c["g1"][k, 2] if p.tau2 > 0 else 0.0
        self.G1 = G1
        self.su_last = np.broadcast_to(np.sqrt(c["su2_last"][k]), (N,))
        self.s = hyst_sign(c["u_last"][k] - b, self.s, self.i_eps)

    # ------------------------------------------------------------------ update
    def update(self, y, u1, temp, x_lin=None, t=None):
        """Measurement update with cell (or mean-cell) voltages y (N,); NaN = no sample."""
        N, n = self.N, self.n
        y = np.broadcast_to(np.asarray(y, float), (N,))
        u1 = np.broadcast_to(np.asarray(u1, float), (N,))
        temp = np.broadcast_to(np.asarray(temp, float), (N,))
        valid = np.isfinite(y)
        x_pred, P_pred = self.x.copy(), self.P.copy()
        Hm, r0e = self._jac_h(self.x, u1, temp)
        su2 = np.asarray(self.su_last, float) ** 2
        C = -self.G1 * (r0e * su2)[:, None]                         # cov(w, v): shared current noise
        Rm = self.sigma_y ** 2 * self.r2scale + r0e ** 2 * su2
        yv = np.where(valid, y, 0.0)

        if self.method == "ukf":
            X = self._sigma(self.x, self.P)
            Yp = self._h(X, u1, temp)
            yhat = Yp @ self.Wm
            dX, dY = X - self.x[:, None], Yp - yhat[:, None]
            Pyy = np.einsum("k,nk,nk->n", self.Wc, dY, dY)
            Pxy = np.einsum("k,nki,nk->ni", self.Wc, dX, dY)
            Hl = np.linalg.solve(self.P, Pxy[..., None])[..., 0]     # statistical linearisation
            S = Pyy + Rm + 2 * np.einsum("ni,ni->n", Hl, C)
            e = yv - yhat
            K = (Pxy + C) / S[:, None]
            Hm = Hl
            hph = Pyy
            if self.consider:
                K[:, self.consider] = 0.0
                IKH = np.eye(n)[None] - K[:, :, None] * Hm[:, None, :]
                KCt = K[:, :, None] * C[:, None, :]
                Pn = (IKH @ self.P @ np.swapaxes(IKH, 1, 2) + Rm[:, None, None] * K[:, :, None] * K[:, None, :]
                      - IKH @ np.swapaxes(KCt, 1, 2) - KCt @ np.swapaxes(IKH, 1, 2))
            else:
                Pn = self.P - S[:, None, None] * K[:, :, None] * K[:, None, :]
            xn = self.x + K * e[:, None]
        else:
            iters = self.c.iekf_iterations if self.method == "iekf" else 1
            xi = self.x.copy() if x_lin is None else np.array(x_lin, float)
            e0 = None
            for _ in range(max(iters, 1)):
                Hm, r0e_i = self._jac_h(xi, u1, temp)
                yhat = self._h(xi[:, None], u1, temp)[:, 0] + np.einsum("ni,ni->n", Hm, self.x - xi)
                PHt = np.einsum("nij,nj->ni", self.P, Hm)
                hph = np.einsum("ni,ni->n", Hm, PHt)
                S = hph + Rm + 2 * np.einsum("ni,ni->n", Hm, C)
                K = (PHt + C) / S[:, None]
                if self.consider:
                    K[:, self.consider] = 0.0          # Schmidt: carried in P, never adjusted
                e = yv - yhat
                if e0 is None:
                    e0, S0 = e.copy(), S.copy()
                xn = self.x + K * e[:, None]
                xi = np.where(valid[:, None], xn, self.x)
            e, S = (e0, S0) if x_lin is None else (e, S)
            IKH = np.eye(n)[None] - K[:, :, None] * Hm[:, None, :]
            KCt = K[:, :, None] * C[:, None, :]
            Pn = (IKH @ self.P @ np.swapaxes(IKH, 1, 2) + Rm[:, None, None] * K[:, :, None] * K[:, None, :]
                  - IKH @ np.swapaxes(KCt, 1, 2) - KCt @ np.swapaxes(IKH, 1, 2))

        nis = np.where(valid, e ** 2 / S, np.nan)
        # outlier-robust (truncated) log-likelihood, counted for every valid sample so a wrong
        # hypothesis cannot escape its penalty through the gate
        self.loglik += np.where(valid, -0.5 * (np.log(2 * np.pi * np.abs(S)) + np.minimum(np.nan_to_num(nis), 4 * self.gate)), 0.0)
        accept = valid & ((nis <= self.gate) | (self.rej >= self.c.max_rejections))
        self.rej = np.where(valid & ~accept, self.rej + 1, np.where(accept, 0, self.rej))
        self.x = np.where(accept[:, None], xn, self.x)
        Pn = 0.5 * (Pn + np.swapaxes(Pn, 1, 2))
        self.P = np.where(accept[:, None, None], Pn, self.P)
        if self.c.adaptive_r:
            lam = self.c.adaptive_forgetting
            est = (e ** 2 - hph - r0e ** 2 * su2) / self.sigma_y ** 2
            self.r2scale = np.where(accept, lam * self.r2scale + (1 - lam) * np.clip(est, 0.1, 100.0), self.r2scale)
        self.G1 = np.zeros_like(self.G1)                   # the next update has no shared current sample
        out = {"innov": np.where(valid, e, np.nan), "S": S, "nis": nis, "accepted": accept,
               "yhat": np.where(valid, y - e, np.nan)}
        if self.records is not None:
            self.records.append((t, x_pred, P_pred, self.x.copy(), self.P.copy(), self.Fc.copy(), out))
        self.Fc = np.repeat(np.eye(n)[None], N, axis=0)
        return out

    # ------------------------------------------------------------------ recording / smoothing
    def start_recording(self, t0):
        self.records = [(t0, self.x.copy(), self.P.copy(), self.x.copy(), self.P.copy(),
                         np.repeat(np.eye(self.n)[None], self.N, axis=0),
                         {"innov": np.full(self.N, np.nan), "S": np.full(self.N, np.nan),
                          "nis": np.full(self.N, np.nan), "accepted": np.zeros(self.N, bool),
                          "yhat": np.full(self.N, np.nan)})]
        self.Fc = np.repeat(np.eye(self.n)[None], self.N, axis=0)

    def stacked(self):
        r = self.records
        out = {"t": np.array([a[0] for a in r], float),
               "x_pred": np.stack([a[1] for a in r]), "P_pred": np.stack([a[2] for a in r]),
               "x": np.stack([a[3] for a in r]), "P": np.stack([a[4] for a in r]),
               "F": np.stack([a[5] for a in r])}
        for k in r[0][6]:
            out[k] = np.stack([a[6][k] for a in r])
        return out


def tile(flt, K):
    """Copy of a filter with every cell repeated K times (rows j*K .. j*K+K-1 belong to cell j)."""
    import copy
    g = copy.copy(flt)
    rep = np.repeat(np.arange(flt.N), K)
    g.p = subset_params(flt.p, rep)
    g.N = flt.N * K
    for a in ("x", "P", "s", "G1", "Fc", "rej", "r2scale", "sigma_y", "loglik", "i_eps"):
        v = getattr(flt, a)
        setattr(g, a, np.repeat(v, K, axis=0) if np.ndim(v) else v)
    if np.ndim(flt.su_last):
        g.su_last = np.repeat(flt.su_last, K, axis=0)
    g.records = None
    return g


def _chol(A):
    try:
        return np.linalg.cholesky(A)
    except np.linalg.LinAlgError:
        w, V = np.linalg.eigh(0.5 * (A + np.swapaxes(A, -1, -2)))
        w = np.maximum(w, 1e-18)
        return np.linalg.cholesky(V @ (w[..., None] * np.swapaxes(V, -1, -2)) + 1e-18 * np.eye(A.shape[-1]))


def rts_smooth(rec):
    """Rauch-Tung-Striebel smoother over recorded filter steps (batched over cells).

    The cell dynamics are linear in the state for a given current (only OCV in the
    measurement is nonlinear), so the backward pass with the composite transition
    F between records is the exact linear-Gaussian smoother around the forward
    linearisation. Returns (x_s, P_s) with shapes (K, N, n), (K, N, n, n).
    """
    xf, Pf, xp, Pp, F = rec["x"], rec["P"], rec["x_pred"], rec["P_pred"], rec["F"]
    K = len(xf)
    xs, Ps = xf.copy(), Pf.copy()
    for k in range(K - 2, -1, -1):
        A = F[k + 1] @ Pf[k]                                   # cov(x_k+1|k, x_k)
        G = np.swapaxes(np.linalg.solve(Pp[k + 1], A), 1, 2)  # P_f F^T P_p^-1
        xs[k] = xf[k] + np.einsum("nij,nj->ni", G, xs[k + 1] - xp[k + 1])
        Pk = Pf[k] + G @ (Ps[k + 1] - Pp[k + 1]) @ np.swapaxes(G, 1, 2)
        Ps[k] = 0.5 * (Pk + np.swapaxes(Pk, 1, 2))
    return xs, Ps
