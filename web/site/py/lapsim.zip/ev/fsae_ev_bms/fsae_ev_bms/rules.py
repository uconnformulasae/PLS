"""Compliance checks against the configured FSAE EV limits (``limits`` section).

The limits are configuration, not hard-coded rule text: check them against the current
FSAE rulebook before relying on a PASS. Each check returns a row
(check, limit, observed, margin, status, detail) with status PASS / WARN / FAIL.
"""
from __future__ import annotations

import numpy as np

from .config import validate_config


def _runs(mask):
    idx = np.flatnonzero(np.diff(np.r_[0, mask.astype(int), 0]))
    return list(zip(idx[::2], idx[1::2]))


def power_trace(d, res):
    """Accumulator power on the current time base: measured pack voltage x offset-corrected current."""
    t = d.t_i
    i = d.i - np.interp(t, res.t, res.bias)
    if d.v_pack is not None and np.isfinite(d.v_pack).any():
        ok = np.isfinite(d.v_pack)
        v = np.interp(t, d.t_v[ok], d.v_pack[ok])
    else:
        v = np.interp(t, res.t, res.v_pack)
    return t, v * i, v, i


def power_violations(t, p, limit, min_duration, avg_window):
    """Continuous excursions above the limit longer than min_duration, and moving-average excursions."""
    above = p > limit
    events = []
    for a, b in _runs(above):
        dur = t[min(b, len(t) - 1)] - t[a]
        if dur >= min_duration:
            events.append({"t0": float(t[a]), "duration_s": float(dur), "peak_kw": float(p[a:b].max() / 1e3)})
    # moving average over avg_window, exact for irregular sampling (trapezoid cumulative energy)
    e = np.r_[0.0, np.cumsum(0.5 * (p[1:] + p[:-1]) * np.diff(t))]
    t_back = t - avg_window
    e_back = np.interp(t_back, t, e)
    valid = t_back >= t[0]
    p_avg = np.where(valid, (e - e_back) / avg_window, np.nan)
    avg_events = []
    for a, b in _runs(np.nan_to_num(p_avg) > limit):
        avg_events.append({"t0": float(t[a]), "duration_s": float(t[min(b, len(t) - 1)] - t[a]),
                           "peak_kw": float(np.nanmax(p_avg[a:b]) / 1e3)})
    return events, avg_events, p_avg


def check(d, res, thermal=None, cfg=None):
    """All checks; returns (rows, extras) where extras holds the power-limit traces."""
    cfg = cfg or res.cfg
    lim = cfg.limits
    p = cfg.params()
    rows = []

    def row(name, limit, observed, margin, status, detail=""):
        rows.append({"check": name, "limit": limit, "observed": observed, "margin": margin,
                     "status": status, "detail": detail})

    # static configuration
    for lvl, msg in validate_config(cfg):
        row("configuration", "-", "-", "-", "FAIL" if lvl == "error" else "WARN", msg)
    # accumulator power
    t, pw, v, i = power_trace(d, res)
    ev, ev_avg, p_avg = power_violations(t, pw, lim.max_power, lim.power_window, lim.power_avg_window)
    pmax = float(np.max(pw))
    pavg_max = float(np.nanmax(p_avg)) if np.isfinite(p_avg).any() else float("nan")
    st = "FAIL" if (ev or ev_avg) else ("WARN" if pmax > 0.95 * lim.max_power else "PASS")
    det = ""
    if ev or ev_avg:
        first = (ev or ev_avg)[0]
        det = (f"{len(ev)} excursion(s) > {1e3 * lim.power_window:.0f} ms, {len(ev_avg)} over the "
               f"{1e3 * lim.power_avg_window:.0f} ms average; first at t={first['t0']:.2f} s")
    row("accumulator power", f"{lim.max_power / 1e3:.0f} kW", f"{pmax / 1e3:.1f} kW peak, "
        f"{pavg_max / 1e3:.1f} kW {1e3 * lim.power_avg_window:.0f} ms avg",
        f"{(lim.max_power - pavg_max) / 1e3:+.1f} kW", st, det)
    # pack voltage
    vmax = float(np.nanmax(d.v_pack)) if d.v_pack is not None else float(np.nanmax(res.v_pack))
    row("pack voltage", f"{lim.max_pack_voltage:.0f} V", f"{vmax:.1f} V", f"{lim.max_pack_voltage - vmax:+.1f} V",
        "FAIL" if vmax > lim.max_pack_voltage else "PASS")
    # cell voltage window (measured, glitches already removed)
    vc = res.v_meas
    lo, hi = float(np.nanmin(vc)), float(np.nanmax(vc))
    under = np.nanmin(vc, axis=1) < p.v_min
    over = np.nanmax(vc, axis=1) > p.v_max
    dur_u = float(np.sum(np.diff(res.t, prepend=res.t[0])[under]))
    dur_o = float(np.sum(np.diff(res.t, prepend=res.t[0])[over]))
    row("cell voltage (min)", f"{p.v_min:.2f} V", f"{lo:.3f} V", f"{lo - p.v_min:+.3f} V",
        "FAIL" if dur_u > 0.5 else ("WARN" if under.any() else "PASS"),
        f"{dur_u:.1f} s below" if under.any() else "")
    row("cell voltage (max)", f"{p.v_max:.2f} V", f"{hi:.3f} V", f"{p.v_max - hi:+.3f} V",
        "FAIL" if dur_o > 0.5 else ("WARN" if over.any() else "PASS"), f"{dur_o:.1f} s above" if over.any() else "")
    # temperatures: measured thermistors and estimated cores (unmonitored cells too)
    if d.temp_sensors is not None and np.isfinite(d.temp_sensors).any():
        tm = float(np.nanmax(d.temp_sensors))
        row("cell temperature (thermistors)", f"{lim.cell_t_max:.0f} C", f"{tm:.1f} C", f"{lim.cell_t_max - tm:+.1f} K",
            "FAIL" if tm > lim.cell_t_max else ("WARN" if tm > lim.cell_t_derate else "PASS"))
    if thermal is not None:
        k, j = np.unravel_index(np.argmax(thermal.core), thermal.core.shape)
        tc, sd = float(thermal.core[k, j]), float(thermal.core_std[k, j])
        hi2 = tc + 2 * sd
        row("cell temperature (estimated core)", f"{lim.cell_t_max:.0f} C", f"{tc:.1f} +/- {sd:.1f} C (cell {j + 1})",
            f"{lim.cell_t_max - tc:+.1f} K", "FAIL" if tc > lim.cell_t_max else
            ("WARN" if hi2 > lim.cell_t_max or tc > lim.cell_t_derate else "PASS"),
            f"t={thermal.t[k]:.0f} s; " + ("monitored" if j in set(thermal.sensor_cells.tolist()) else "no thermistor on this cell"))
    # charging (regen) below the minimum charge temperature
    if thermal is not None:
        Tmin = np.interp(t, thermal.t, thermal.core.min(1))
        cold_chg = (i < -1.0) & (Tmin < lim.cell_t_min_charge)
        if cold_chg.any():
            row("regen below min charge temperature", f"{lim.cell_t_min_charge:.0f} C", "regen seen", "-", "FAIL",
                f"{int(cold_chg.sum())} samples")
    # cell current vs rating (per physical cell)
    npar = cfg.pack.parallel
    i_cell_max, i_cell_min = float(np.max(i) / npar), float(np.min(i) / npar)
    row("cell discharge current", f"{lim.i_dis_peak:.0f} A peak", f"{i_cell_max:.1f} A", f"{lim.i_dis_peak - i_cell_max:+.1f} A",
        "FAIL" if i_cell_max > lim.i_dis_peak else ("WARN" if i_cell_max > lim.i_dis_cont else "PASS"))
    row("cell charge current", f"{lim.i_chg_peak:.1f} A peak", f"{-i_cell_min:.1f} A", f"{lim.i_chg_peak + i_cell_min:+.1f} A",
        "FAIL" if -i_cell_min > lim.i_chg_peak else "PASS")
    extras = {"t": t, "power": pw, "power_avg": p_avg, "events": ev, "events_avg": ev_avg}
    return rows, extras


def table(rows):
    w = max(len(r["check"]) for r in rows)
    out = [f"{'check':<{w}}  {'status':<6} {'limit':<12} observed"]
    for r in rows:
        out.append(f"{r['check']:<{w}}  {r['status']:<6} {str(r['limit']):<12} {r['observed']}"
                   + (f"   [{r['detail']}]" if r["detail"] else ""))
    return "\n".join(out)
