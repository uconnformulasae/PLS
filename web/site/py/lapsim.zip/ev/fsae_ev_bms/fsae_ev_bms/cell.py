"""Equivalent-circuit cell model: OCV(SOC,T) + hysteresis - R0 - (R1||C1) - (R2||C2).

    v = OCV(soc, T) + M h + M0 s - v1 - v2 - R0(T, soc) i          (i > 0 = discharge)
    d soc/dt = -eta i / Q
    d v_j/dt = -v_j / tau_j + i / C_j                                    (R_j C_j = tau_j)
    d h/dt   = -|eta i gamma / Q| (h + sign(i))

Discretisation is exact for a current that varies linearly between samples
(first-order hold), not the usual zero-order hold. With the 10-100 Hz current
of a race car ZOH alone puts a lag of half a sample into every RC state and a
trapezoid-vs-rectangle error into the charge count; FOH removes both:

    soc'  = soc - eta dt (i0 + i1) / (2 Q)                   (trapezoid = exact for linear i)
    v_j'  = a v_j + R_j [w0 i0 + w1 i1],   a = exp(-dt/tau)
            w1 = 1 - (1 - a) tau/dt,  w0 = (1 - a) tau/dt - a
"""
from __future__ import annotations

import numpy as np

from .chemistry import arrhenius

# state indices (filters may append bias / R0-multiplier states after these)
SOC, V1, V2, H = 0, 1, 2, 3
N_BASE = 4


def rc_weights(dt, tau):
    """FOH weights (a, w0, w1) for one RC branch; stable as dt/tau -> 0."""
    x = np.asarray(dt, float) / tau
    a = np.exp(-x)
    with np.errstate(invalid="ignore", divide="ignore"):
        g = np.where(x > 1e-6, -np.expm1(-x) / np.maximum(x, 1e-300), 1.0 - x / 2 + x * x / 6)   # (1-a) tau/dt
    return a, g - a, 1.0 - g


def resistances(p, temp, soc=None):
    """R0, R1, R2 [ohm] per cell at temperature ``temp`` [degC] (and SOC, if an R0-SOC table is set)."""
    f = arrhenius(temp, p.ea, p.t_ref)
    r0 = p.r0 * f
    if p.r0_soc is not None and soc is not None:
        r0 = r0 * np.interp(soc, p.r0_soc, p.r0_soc_f)
    return r0, p.r1 * f, p.r2 * f


def hyst_sign(i, prev, i_eps):
    """Instantaneous-hysteresis sign: follows the current, holds through rest."""
    return np.where(i > i_eps, 1.0, np.where(i < -i_eps, -1.0, prev))


def step(p, x, i0, i1, dt, temp):
    """Exact FOH propagation of base states x[..., :4] for true currents i0 -> i1 (per cell)."""
    _, r1, r2 = resistances(p, temp)
    ib = 0.5 * (i0 + i1)
    eta = np.where(ib < 0, p.eta_c, 1.0)
    out = np.array(x, float, copy=True)
    out[..., SOC] = x[..., SOC] - eta * dt * ib / p.q
    a1, w01, w11 = rc_weights(dt, p.tau1)
    out[..., V1] = a1 * x[..., V1] + r1 * (w01 * i0 + w11 * i1)
    if p.tau2 > 0:
        a2, w02, w12 = rc_weights(dt, p.tau2)
        out[..., V2] = a2 * x[..., V2] + r2 * (w02 * i0 + w12 * i1)
    k = np.exp(-np.abs(eta * ib * p.gamma * dt / p.q))
    out[..., H] = k * x[..., H] - (1 - k) * np.sign(ib)
    return out


def terminal_voltage(p, x, i, temp, s, r0_mult=1.0):
    r0, _, _ = resistances(p, temp, x[..., SOC])
    return (p.ocv(x[..., SOC], temp) + p.m * x[..., H] + p.m0 * s - x[..., V1] - x[..., V2]
            - r0 * r0_mult * i)


def bcast(a, nt, n):
    """Scalar, (T,) or (T, N) -> (T, N) float array."""
    a = np.asarray(a, float)
    if a.ndim == 0:
        return np.full((nt, n), float(a))
    if a.ndim == 1:
        return np.repeat(a[:, None], n, axis=1)
    return np.broadcast_to(a, (nt, n)).copy()


def simulate(p, t, i, temp=25.0, soc0=1.0, h0=0.0, substeps=10):
    """Simulate cell (group) voltages for a current trace.

    ``i`` is (T,) for the same current in every cell or (T, N); ``temp`` scalar,
    (T,) or (T, N). Each sample interval is split into ``substeps`` FOH steps (the
    result is already exact for piecewise-linear current; substeps only matter for
    the hysteresis, which is nonlinear). Returns dict of (T, N) arrays.
    """
    t = np.asarray(t, float)
    n = p.n
    I = bcast(i, len(t), n)
    TT = bcast(temp, len(t), n)
    x = np.zeros((n, N_BASE))
    x[:, SOC] = soc0
    x[:, H] = h0
    i_eps = 0.01 * p.q / 3600
    s = np.where(np.asarray(h0) < 0, -1.0, 1.0) * np.ones(n)
    X = np.empty((len(t), n, N_BASE))
    V = np.empty((len(t), n))
    for k in range(len(t)):
        if k:
            dt = (t[k] - t[k - 1]) / substeps
            for j in range(substeps):
                ia = I[k - 1] + (I[k] - I[k - 1]) * j / substeps
                ib = I[k - 1] + (I[k] - I[k - 1]) * (j + 1) / substeps
                x = step(p, x, ia, ib, dt, TT[k])
        s = hyst_sign(I[k], s, i_eps)
        X[k] = x
        V[k] = terminal_voltage(p, x, I[k], TT[k], s)
    return {"t": t, "v": V, "soc": X[..., SOC], "v1": X[..., V1], "v2": X[..., V2], "h": X[..., H], "i": I}


def lumped_temperature(t, i_cell, r0_cell, cfg_th, t0=None):
    """Cell temperature from I^2 R heating and convection to ambient (used when no sensor is logged)."""
    m_cp = cfg_th.cell_mass * cfg_th.cell_cp
    T = np.empty(len(t))
    T[0] = cfg_th.ambient if t0 is None else t0
    for k in range(1, len(t)):
        dt = t[k] - t[k - 1]
        h_area = getattr(cfg_th, "h_area", None) or 1.0 / (cfg_th.r_core_surface + cfg_th.r_surface_ambient)
        q = i_cell[k - 1] ** 2 * r0_cell - h_area * (T[k - 1] - cfg_th.ambient)
        T[k] = T[k - 1] + dt * q / m_cp
    return T
