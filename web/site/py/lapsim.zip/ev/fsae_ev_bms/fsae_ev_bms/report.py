"""Self-contained HTML report (figures embedded) for one analysed run."""
from __future__ import annotations

import base64
import html
from pathlib import Path

import numpy as np

_CSS = """
:root{--bg:#fbfbf9;--fg:#0b0b0b;--mut:#52514e;--line:#d9d8d3;--card:#fff;--pass:#1baf7a;--warn:#eda100;--fail:#e34948}
@media (prefers-color-scheme:dark){:root{--bg:#141413;--fg:#ecebe6;--mut:#a6a59f;--line:#3a3935;--card:#1d1d1b}}
body{background:var(--bg);color:var(--fg);font:14px/1.45 -apple-system,Segoe UI,Roboto,sans-serif;margin:0 auto;max-width:1180px;padding:24px 16px}
h1{font-size:22px;margin:0 0 4px}h2{font-size:17px;margin:28px 0 8px;border-bottom:1px solid var(--line);padding-bottom:4px}
.sub{color:var(--mut)}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;margin-top:14px}
.card{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:10px 12px}
.card b{display:block;font-size:20px}.card span{color:var(--mut);font-size:12px}
table{border-collapse:collapse;width:100%;font-size:13px;background:var(--card)}
th,td{border-bottom:1px solid var(--line);padding:5px 8px;text-align:left;vertical-align:top}th{color:var(--mut);font-weight:600}
.PASS{color:var(--pass);font-weight:700}.WARN{color:var(--warn);font-weight:700}.FAIL{color:var(--fail);font-weight:700}
img{max-width:100%;border:1px solid var(--line);border-radius:6px;background:#fff;margin:6px 0}
pre{background:var(--card);border:1px solid var(--line);border-radius:6px;padding:10px;overflow-x:auto;font-size:12px}
.scroll{max-height:420px;overflow:auto}
"""


def _img(path):
    if path is None or not Path(path).exists():
        return ""
    b = base64.b64encode(Path(path).read_bytes()).decode()
    return f'<img alt="{html.escape(Path(path).stem)}" src="data:image/png;base64,{b}">'


def _table(df, fmt=None, max_rows=None):
    fmt = fmt or {}
    cols = list(df.columns)
    rows = df.itertuples(index=False)
    head = "".join(f"<th>{html.escape(str(c))}</th>" for c in cols)
    body = []
    for k, r in enumerate(rows):
        if max_rows and k >= max_rows:
            break
        cells = []
        for c, v in zip(cols, r):
            if c in fmt and isinstance(v, (int, float, np.floating, np.integer)) and np.isfinite(v):
                s = fmt[c].format(v)
            else:
                s = "" if (isinstance(v, float) and not np.isfinite(v)) else str(v)
            cls = f' class="{s}"' if s in ("PASS", "WARN", "FAIL") else ""
            cells.append(f"<td{cls}>{html.escape(s)}</td>")
        body.append("<tr>" + "".join(cells) + "</tr>")
    return f"<table><thead><tr>{head}</tr></thead><tbody>{''.join(body)}</tbody></table>"


def html_report(evr, fig_dir=None):
    import pandas as pd
    m, e, cfg = evr.elec.metrics, evr.energy, evr.cfg
    fd = Path(fig_dir) if fig_dir else None
    f = (lambda k: _img(fd / f"{k}.png")) if fd else (lambda k: "")
    n_fail = sum(r["status"] == "FAIL" for r in evr.rules)
    n_warn = sum(r["status"] == "WARN" for r in evr.rules)
    h0 = cfg.sop.horizons[0]
    cards = [
        ("SOC", f"{100 * m['soc_start']:.1f} → {100 * m['soc_end']:.1f} %", f"±{100 * m['soc_end_std']:.1f} % (1σ) at the end"),
        ("Energy used", f"{m['energy_wh']:.0f} Wh", f"{m['charge_ah']:.2f} Ah net"),
        ("Peak power", f"{m['p_peak_kw']:.1f} kW", f"limit {cfg.limits.max_power / 1e3:.0f} kW"),
        ("Remaining", f"{e['remaining_wh']:.0f} Wh", (f"≈ {e['laps_remaining']:.1f} laps" if e.get("laps_remaining")
                                                       else "to the weakest cell's floor")),
        (f"Power now ({h0:g} s)", f"{evr.sop[h0]['p_dis'][-1] / 1e3:.1f} kW",
         f"regen {-evr.sop[h0]['p_chg'][-1] / 1e3:.1f} kW") if evr.sop else ("", "", ""),
        ("Compliance", "FAIL" if n_fail else ("WARN" if n_warn else "PASS"), f"{n_fail} fail, {n_warn} warn"),
    ]
    if evr.thermal is not None:
        th = evr.thermal
        k, j = np.unravel_index(np.argmax(th.core), th.core.shape)
        cards.append(("Hottest cell", f"{th.core[k, j]:.1f} °C", f"cell {j + 1}, ±{th.core_std[k, j]:.1f} K (core est.)"))
    cards.append(("Filter check", f"NIS {m['nis_mean']:.2f}", "≈ 1 means the model fits the data"))
    card_html = "".join(f'<div class="card"><span>{html.escape(a)}</span><b class="{html.escape(b)}">{html.escape(b)}</b>'
                        f"<span>{html.escape(c)}</span></div>" for a, b, c in cards if a)
    rules = pd.DataFrame(evr.rules)[["check", "status", "limit", "observed", "margin", "detail"]]
    cells = evr.cells.copy()
    cells_fmt = {"soc_start": "{:.3f}", "soc_end": "{:.3f}", "soc_end_std": "{:.4f}", "capacity_ah": "{:.3f}",
                 "capacity_std_ah": "{:.3f}", "r0_mohm_25c": "{:.3f}", "v_min": "{:.3f}", "v_max": "{:.3f}",
                 "core_max_c": "{:.1f}", "core_max_std": "{:.1f}"}
    lap_fmt = {c: "{:.2f}" for c in evr.laps.columns if c not in ("lap",)}
    issues = "".join(f"<li><b class=\"{'FAIL' if l == 'error' else 'WARN'}\">{html.escape(l)}</b> {html.escape(msg)}</li>"
                     for l, msg in evr.issues if l in ("error", "warning")) or "<li>none</li>"
    bal = evr.balance[evr.balance["bleed_ah"] > 0].sort_values("bleed_ah", ascending=False)
    parts = [
        f"<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
        f"<title>Accumulator Run Report</title><style>{_CSS}</style></head><body>",
        f"<h1>Accumulator run report — {html.escape(cfg.name)}</h1>",
        f"<div class='sub'>{html.escape(str(evr.data.source))} · {cfg.pack.series}s{cfg.pack.parallel}p "
        f"{html.escape(cfg.cell.chemistry.upper())} · {m['duration_s']:.0f} s · voltages per "
        f"{'cell' if evr.elec.mode == 'cells' else 'pack'}</div>",
        f"<div class='cards'>{card_html}</div>",
        "<h2>Compliance (configured limits — check against the current rulebook)</h2>", _table(rules),
        "<h2>Issues found in the data</h2>", f"<ul>{issues}</ul>",
        "<h2>Run overview</h2>", f("overview"),
        "<h2>Power and state of power</h2>", f("power"),
    ]
    if evr.thermal is not None:
        parts += ["<h2>Temperatures</h2>", f("thermal")]
    parts += ["<h2>Cells</h2>", f("cells"), "<div class='scroll'>", _table(cells, cells_fmt), "</div>"]
    if len(evr.laps):
        parts += ["<h2>Laps</h2>", _table(evr.laps, lap_fmt)]
    parts += ["<h2>Balancing plan</h2>",
              f"<p>Bleed each cell down to the lowest SOC at {cfg.balance.balance_current:.2f} A per group.</p>",
              _table(bal, {"soc_end": "{:.4f}", "soc_std": "{:.4f}", "capacity_ah": "{:.3f}", "bleed_ah": "{:.4f}",
                           "bleed_h": "{:.2f}"}, max_rows=40) if len(bal) else "<p>Cells are balanced within the threshold.</p>",
              "<h2>Estimator health</h2>", f("diagnostics"), f("alignment"),
              "<h2>Data quality</h2>", f"<pre>{html.escape(evr.quality.text())}</pre>",
              "<h2>Full text summary</h2>", f"<pre>{html.escape(evr.summary())}</pre>",
              "</body></html>"]
    return "\n".join(parts)
