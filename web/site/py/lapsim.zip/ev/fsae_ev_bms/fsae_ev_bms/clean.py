"""Data conditioning for accumulator logs, with a report of everything it changed.

Run before estimation (``analysis.analyze`` does). Nothing is silently invented:
bad samples become NaN (the filter skips them), current gaps are bridged by
interpolation but carry an inflated per-sample uncertainty, and every action is
counted in the CleanReport.

Steps
  1. timestamps   non-finite / out-of-order / duplicate times; sample rate, jitter, gaps
  2. ranges       cell voltage outside [v_lo, v_hi] (open wire / ADC fault), thermistor
                  outside its range (open / short), current outside the sensor range
  3. spikes       Hampel test on each cell's deviation from the cross-cell median: a real
                  current-driven dip moves every cell, a glitch moves one; thermistors on
                  their own signal with a 2 K floor
  4. stuck        a channel frozen at one value while the pack current is moving
  5. current      gaps bridged linearly with sigma growing with the gap; saturation
  6. alignment    voltage-vs-current delay estimated from ohmic steps (sub-sample)
  7. cross-checks inverter DC current vs pack current (offset, gain); pack voltage vs
                  sum of cells (interconnect resistance, missing taps)
"""
from __future__ import annotations

import dataclasses as dc

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

from .io import BatteryData


@dc.dataclass
class CleanReport:
    streams: dict = dc.field(default_factory=dict)        # name -> rate, jitter, gaps, fixes
    cell_flags: dict = dc.field(default_factory=dict)     # reason -> (Ns,) counts
    sensor_flags: dict = dc.field(default_factory=dict)   # reason -> (n_sensors,) counts
    current: dict = dc.field(default_factory=dict)
    delay: dict = dc.field(default_factory=dict)
    inverter: dict = dc.field(default_factory=dict)
    pack_vs_cells: dict = dc.field(default_factory=dict)
    issues: list = dc.field(default_factory=list)         # (level, message)

    def add(self, level, msg):
        self.issues.append((level, msg))

    def text(self):
        rows = ["DATA QUALITY"]
        for k, v in self.streams.items():
            rows.append(f"  {k:<12} {v['n']:>8d} samples  {v['rate_hz']:7.1f} Hz  jitter {1e3 * v['jitter_s']:.1f} ms  "
                        f"gaps>{v['gap_limit_s']:.1f}s: {v['n_gaps']} ({v['gap_total_s']:.1f} s)  "
                        f"reordered {v['reordered']}, duplicates {v['duplicates']}")
        for k, v in self.cell_flags.items():
            if np.sum(v):
                worst = np.argsort(v)[::-1][:5]
                rows.append(f"  cells   {k:<10} {int(np.sum(v)):6d} samples removed; worst cells "
                            + ", ".join(f"{j + 1}({int(v[j])})" for j in worst if v[j]))
        for k, v in self.sensor_flags.items():
            if np.sum(v):
                rows.append(f"  temps   {k:<10} {int(np.sum(v)):6d} samples removed")
        if self.delay:
            rows.append(f"  voltage-current delay {1e3 * self.delay['delay_s']:+.1f} ms "
                        f"(fit r {self.delay['r']:.3f}; applied: {self.delay['applied']})")
        if self.inverter:
            rows.append(f"  inverter vs pack current: offset {self.inverter['offset_a']:+.2f} A, gain "
                        f"{self.inverter['gain']:.4f}, rms difference {self.inverter['rms_a']:.2f} A")
        if self.pack_vs_cells:
            rows.append(f"  pack voltage vs sum of cells: interconnect {1e3 * self.pack_vs_cells['r_ic_ohm']:.1f} mOhm, "
                        f"offset {self.pack_vs_cells['offset_v']:+.2f} V, residual {self.pack_vs_cells['rms_v']:.2f} V rms")
        for lvl, m in self.issues:
            rows.append(f"  {lvl.upper()}: {m}")
        return "\n".join(rows)


# --------------------------------------------------------------------------- helpers
def _timebase(name, t, arrays, rep, gap_limit):
    """Sort, drop non-finite and duplicate times. Returns (t, arrays) and logs stats."""
    t = np.asarray(t, float)
    ok = np.isfinite(t)
    reordered = int(np.sum(np.diff(t[ok]) < 0)) if ok.sum() > 1 else 0
    o = np.argsort(t[ok], kind="stable")
    t2 = t[ok][o]
    arrs = [None if a is None else np.asarray(a, float)[ok][o] for a in arrays]
    keep = np.r_[True, np.diff(t2) > 0]
    dups = int(np.sum(~keep))
    if dups:
        # merge duplicate stamps: keep the last finite value of each (BMS frames repeat a stamp)
        idx = np.cumsum(keep) - 1
        merged = []
        for a in arrs:
            if a is None:
                merged.append(None)
                continue
            b = np.full((int(idx[-1]) + 1,) + a.shape[1:], np.nan)
            for k in range(len(a)):
                row = a[k]
                fin = np.isfinite(row)
                if np.ndim(row) == 0:
                    if fin:
                        b[idx[k]] = row
                else:
                    b[idx[k]][fin] = row[fin]
            merged.append(b)
        arrs, t2 = merged, t2[keep]
    dt = np.diff(t2)
    med = float(np.median(dt)) if dt.size else float("nan")
    gaps = dt > max(gap_limit, 5 * med) if dt.size else np.array([], bool)
    rep.streams[name] = {"n": int(t2.size), "rate_hz": 1 / med if med > 0 else float("nan"),
                         "jitter_s": float(1.4826 * np.median(np.abs(dt - med))) if dt.size else 0.0,
                         "n_gaps": int(gaps.sum()), "gap_total_s": float(dt[gaps].sum()) if gaps.any() else 0.0,
                         "gap_limit_s": float(gap_limit), "reordered": reordered, "duplicates": dups,
                         "dropped_bad_time": int((~ok).sum()), "t0": float(t2[0]) if t2.size else float("nan"),
                         "t1": float(t2[-1]) if t2.size else float("nan")}
    if reordered:
        rep.add("warning", f"{name}: {reordered} timestamps out of order (sorted)")
    if gaps.any():
        rep.add("warning", f"{name}: {int(gaps.sum())} gap(s) longer than {gap_limit:.1f} s, "
                           f"{float(dt[gaps].sum()):.1f} s in total, longest {float(dt.max()):.1f} s")
    return t2, arrs


def _hampel_mask(x, window, k, floor):
    """True where x[i] is an isolated outlier (NaN-aware rolling median / MAD), per column."""
    x = np.asarray(x, float)
    one = x.ndim == 1
    X = x[:, None] if one else x
    w = int(window) | 1
    h = w // 2
    if X.shape[0] < w:
        return np.zeros_like(x, bool)
    pad = np.pad(X, ((h, h), (0, 0)), mode="edge")
    win = sliding_window_view(pad, w, axis=0)                 # (K, N, w)
    with np.errstate(all="ignore"):
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            med = np.nanmedian(win, axis=2)
            mad = 1.4826 * np.nanmedian(np.abs(win - med[..., None]), axis=2)
    thr = np.maximum(k * mad, floor)
    m = np.abs(X - med) > thr
    m &= np.isfinite(X)
    return m[:, 0] if one else m


def _runs(mask):
    idx = np.flatnonzero(np.diff(np.r_[0, mask.astype(int), 0]))
    return list(zip(idx[::2], idx[1::2]))          # [start, end) pairs


# --------------------------------------------------------------------------- main
def clean(d: BatteryData, cfg, report: CleanReport | None = None):
    """Return (cleaned BatteryData, CleanReport). The input is not modified."""
    c = cfg.clean
    rep = report or CleanReport()
    d = dc.replace(d)
    if not c.enabled:
        return d, rep
    ns = cfg.pack.series
    gap = c.max_gap

    # 1. timestamps -------------------------------------------------------------
    d.t_i, (d.i, d.i_sigma) = _timebase("current", d.t_i, [d.i, d.i_sigma], rep, gap)
    d.t_v, (d.v_cells, d.v_pack) = _timebase("voltage", d.t_v, [d.v_cells, d.v_pack], rep, gap)
    if d.t_temp is not None:
        d.t_temp, (d.temp, d.temp_sensors) = _timebase("temperature", d.t_temp, [d.temp, d.temp_sensors], rep,
                                                       max(gap, 5.0))
    for k, (t, x) in list(d.aux.items()):
        t2, (x2,) = _timebase(k, t, [x], rep, max(gap, 2.0))
        d.aux[k] = (t2, x2)

    # 2-4. cell voltages --------------------------------------------------------
    if d.v_cells is not None:
        V = d.v_cells.copy()
        lo, hi = c.cell_v_range
        bad_rng = np.isfinite(V) & ((V < lo) | (V > hi))
        V[bad_rng] = np.nan
        rep.cell_flags["range"] = bad_rng.sum(0)
        runs_bad = [j for j in range(ns) if bad_rng[:, j].sum() > 0.5 * np.isfinite(d.v_cells[:, j]).sum()]
        if runs_bad:
            rep.add("error", f"cell tap(s) {', '.join(str(j + 1) for j in runs_bad)} out of range most of the run "
                             "(open wire or wrong channel) - those cells are not estimated")
        # spikes: deviation from the cross-cell median removes the common (current-driven) motion
        with np.errstate(all="ignore"):
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", RuntimeWarning)
                common = np.nanmedian(V, axis=1, keepdims=True)
        dev = V - common
        spikes = _hampel_mask(dev, c.hampel_window, c.hampel_sigma, c.hampel_floor_v)
        V[spikes] = np.nan
        rep.cell_flags["spike"] = spikes.sum(0)
        # stuck: identical value for >= stuck_window while the current moves
        stuck = np.zeros_like(V, bool)
        if d.t_i is not None and len(d.t_v) > 3:
            I_v = np.interp(d.t_v, d.t_i, np.nan_to_num(d.i))
            for j in range(ns):
                col = d.v_cells[:, j]
                same = np.r_[False, np.diff(col) == 0] & np.isfinite(col)
                for a, b in _runs(same):
                    a = max(a - 1, 0)
                    if d.t_v[b - 1] - d.t_v[a] >= c.stuck_window and np.std(I_v[a:b]) > 5.0:
                        stuck[a:b, j] = True
        V[stuck] = np.nan
        rep.cell_flags["stuck"] = stuck.sum(0)
        if stuck.any():
            js = np.flatnonzero(stuck.any(0))
            rep.add("warning", f"cell channel(s) {', '.join(str(j + 1) for j in js)} frozen while current was flowing "
                               "(stale BMS data) - samples removed")
        missing = ~np.isfinite(d.v_cells)
        rep.cell_flags["missing"] = missing.sum(0)
        d.v_cells = V

    # temperatures -----------------------------------------------------------------
    if d.temp_sensors is not None:
        T = d.temp_sensors.copy()
        lo, hi = c.temp_range
        bad = np.isfinite(T) & ((T < lo) | (T > hi))
        T[bad] = np.nan
        sp = _hampel_mask(T, max(c.hampel_window, 7), c.hampel_sigma, 2.0)
        T[sp] = np.nan
        rep.sensor_flags = {"range": bad.sum(0), "spike": sp.sum(0)}
        dead = [j for j in range(T.shape[1]) if np.isfinite(T[:, j]).sum() < 0.5 * T.shape[0]]
        if dead:
            rep.add("warning", f"thermistor(s) {', '.join(str(j + 1) for j in dead)} invalid most of the run "
                               "(open / shorted) - their cells rely on the thermal model")
        from .io import _fill_cols, sensors_to_groups
        d.temp_sensors = T
        if d.sensor_cells is not None:
            good = [j for j in range(T.shape[1]) if j not in dead]
            if good:
                d.temp = sensors_to_groups(_fill_cols(T[:, good]), d.sensor_cells[good], ns)

    # 5. current -------------------------------------------------------------------
    # gaps in the current's time base (lost frames) become explicit missing samples, so they are
    # bridged below with an honest uncertainty instead of being interpolated silently by the estimator
    dt_i = np.diff(d.t_i)
    med = float(np.median(dt_i)) if dt_i.size else 0.0
    holes = np.flatnonzero(dt_i > 5 * med) if med > 0 else np.array([], int)
    if holes.size:
        new_t = [np.arange(d.t_i[k] + med, d.t_i[k + 1] - 0.5 * med, med) for k in holes]
        add = np.concatenate(new_t) if new_t else np.array([])
        if add.size:
            t_all = np.r_[d.t_i, add]
            o = np.argsort(t_all, kind="stable")
            d.t_i = t_all[o]
            d.i = np.r_[d.i, np.full(add.size, np.nan)][o]
            if d.i_sigma is not None:
                d.i_sigma = np.r_[d.i_sigma, np.full(add.size, np.nan)][o]
    I = d.i.copy()
    lo, hi = c.current_range
    bad = np.isfinite(I) & ((I < lo) | (I > hi))
    I[bad] = np.nan
    sat = 0
    fin = np.isfinite(I)
    if fin.sum() > 10:
        top, bot = np.nanmax(I), np.nanmin(I)
        for v in (top, bot):
            run_mask = np.isclose(I, v) & fin
            longest = max((b - a for a, b in _runs(run_mask)), default=0)
            if longest >= 10 and abs(v) > 50:
                sat += longest
                rep.add("warning", f"current pinned at {v:.1f} A for {longest} samples - possible sensor saturation")
    sig = np.full(len(I), cfg.sensors.current_noise) if d.i_sigma is None else \
        np.where(np.isfinite(d.i_sigma), d.i_sigma, cfg.sensors.current_noise)
    miss = ~np.isfinite(I)
    filled_s = 0.0
    if miss.any():
        good = ~miss
        I[miss] = np.interp(d.t_i[miss], d.t_i[good], I[good])
        for a, b in _runs(miss):
            ta = d.t_i[max(a - 1, 0)]
            tb = d.t_i[min(b, len(I) - 1)]
            span = tb - ta
            filled_s += span
            # uncertainty of a bridged gap: the swing seen around it, growing with the gap length
            ctx = I[max(a - 50, 0):min(b + 50, len(I))]
            swing = float(np.nanstd(ctx)) if ctx.size else 0.0
            sig[a:b] = np.hypot(sig[a:b], swing * min(1.0, span / 0.5) + 0.05 * abs(float(np.nanmean(ctx))))
        rep.add("warning" if filled_s > 1 else "info",
                f"current: {int(miss.sum())} samples bridged ({filled_s:.2f} s); their uncertainty is inflated")
    d.i, d.i_sigma = I, sig
    rep.current = {"out_of_range": int(bad.sum()), "bridged": int(miss.sum()), "bridged_s": float(filled_s),
                   "saturated_samples": int(sat)}
    rest = _runs(np.abs(I) < 0.5)
    rest = [(d.t_i[a], d.t_i[b - 1]) for a, b in rest if d.t_i[b - 1] - d.t_i[a] > 3.0]
    rep.current["rest_windows"] = rest[:10]

    # 6. voltage-current alignment --------------------------------------------------
    if c.align_delay and d.t_i is not None:
        est = estimate_delay(d, cfg)
        if est:
            dt_i = 1.0 / rep.streams["current"]["rate_hz"]
            apply = abs(est["delay_s"] - cfg.sensors.voltage_delay) > 0.5 * dt_i and est["r"] > 0.3
            est["applied"] = bool(apply)
            rep.delay = est
            if apply:
                rep.add("info", f"voltage samples lag the current by {1e3 * est['delay_s']:.1f} ms - "
                                "corrected (sensors.voltage_delay)")

    # 7. cross-checks --------------------------------------------------------------
    if "inverter_current" in d.aux:
        ti, xi = d.aux["inverter_current"]
        ok = np.isfinite(xi) & (ti >= d.t_i[0]) & (ti <= d.t_i[-1])
        if ok.sum() > 20:
            ip = np.interp(ti[ok], d.t_i, d.i)
            A = np.column_stack([np.ones(ok.sum()), ip])
            (off, gain), *_ = np.linalg.lstsq(A, xi[ok], rcond=None)
            rms = float(np.sqrt(np.mean((xi[ok] - ip) ** 2)))
            rep.inverter = {"offset_a": float(off), "gain": float(gain), "rms_a": rms}
            if abs(gain - 1) > 0.03 or abs(off) > 2:
                rep.add("warning", f"inverter DC current disagrees with the pack sensor: gain {gain:.3f}, "
                                   f"offset {off:+.2f} A (losses in DC-DC/LV and calibration both show up here)")
    if d.v_cells is not None and d.v_pack is not None:
        full = np.isfinite(d.v_cells).all(1) & np.isfinite(d.v_pack)
        if full.sum() > 20:
            s = d.v_cells[full].sum(1)
            ii = np.interp(d.t_v[full], d.t_i, d.i)
            A = np.column_stack([np.ones(full.sum()), -ii])
            (off, ric), *_ = np.linalg.lstsq(A, d.v_pack[full] - s, rcond=None)
            res = d.v_pack[full] - s - off + ric * ii
            rep.pack_vs_cells = {"r_ic_ohm": float(ric), "offset_v": float(off), "rms_v": float(np.std(res))}
            if abs(off) > 0.01 * np.median(s):
                rep.add("warning", f"pack voltage differs from the sum of cells by {off:+.1f} V "
                                   "(missing cell tap, wrong scaling or a different measurement point)")
    return d, rep


def estimate_delay(d: BatteryData, cfg, n_grid=121):
    """Delay of the voltage samples relative to the current samples, from ohmic steps.

    Between consecutive voltage samples the mean cell voltage changes by about
    -R0 * (change of current); only R0 acts that fast. For each candidate delay
    tau the current is read at (t_v - tau) - exactly, by interpolating the 100 Hz
    current, not the 10 Hz voltage - and the correlation of the two differences
    is computed; the peak is refined by a parabola through its neighbours.
    Returns dict(delay_s, r, r0_group_ohm) or None if the data has no steps.
    """
    c = cfg.clean
    if d.v_cells is not None:
        with np.errstate(all="ignore"):
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", RuntimeWarning)
                v = np.nanmean(d.v_cells, axis=1)
    else:
        v = d.v_pack / cfg.pack.series
    t = d.t_v
    ok = np.isfinite(v)
    t, v = t[ok], v[ok]
    if len(t) < 50:
        return None
    dv = np.diff(v)
    taus = np.linspace(-c.max_delay, c.max_delay, n_grid)
    r = np.empty(len(taus))
    for k, tau in enumerate(taus):
        ii = np.interp(t - tau, d.t_i, d.i)
        di = np.diff(ii)
        if np.std(di) < 1e-9:
            r[k] = 0.0
            continue
        r[k] = -np.corrcoef(dv, di)[0, 1]
    k = int(np.argmax(r))
    tau = taus[k]
    if 0 < k < len(taus) - 1:
        y0, y1, y2 = r[k - 1], r[k], r[k + 1]
        den = y0 - 2 * y1 + y2
        if den < 0:
            tau = tau + 0.5 * (y0 - y2) / den * (taus[1] - taus[0])
    ii = np.interp(t - tau, d.t_i, d.i)
    di = np.diff(ii)
    slope = float(np.dot(dv, di) / np.dot(di, di))
    return {"delay_s": float(tau), "r": float(r[k]), "r0_group_ohm": -slope, "applied": False,
            "curve": (taus, r)}
