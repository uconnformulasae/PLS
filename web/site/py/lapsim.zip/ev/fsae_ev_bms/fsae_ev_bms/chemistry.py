"""Cell chemistry presets: open-circuit voltage curves and default ECM parameters.

Each preset is a starting point. Every value is tagged ASSUMED (generic
literature/datasheet shape) until it is replaced by a fit from the team's own
cells (``fsae_ev_bms.identify``). The OCV curve matters most: SOC accuracy is
limited by how well OCV(SOC) is known, especially for LiFePO4 whose plateau is
only ~60 mV tall from 20 % to 90 % SOC.

OCV tables are the average of the charge and discharge rest curves; the
hysteresis band (+/- M) sits around them.
"""
from __future__ import annotations

import numpy as np

# --------------------------------------------------------------------------- OCV
# LiFePO4 / graphite (A123 26650 / motorsport starter battery class).  ASSUMED
_LFP_SOC = [0.00, 0.02, 0.05, 0.10, 0.15, 0.20, 0.30, 0.40, 0.50, 0.60, 0.65, 0.70, 0.80, 0.90, 0.95, 0.98, 1.00]
_LFP_OCV = [2.500, 2.900, 3.100, 3.195, 3.225, 3.248, 3.272, 3.287, 3.297, 3.305, 3.315, 3.326, 3.332, 3.338, 3.355, 3.400, 3.550]

# NMC / graphite high-power 21700 (Molicel P42A / Samsung 40T class, typical FSAE EV accumulator).  ASSUMED
_NMC_SOC = [0.00, 0.02, 0.05, 0.10, 0.15, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 0.95, 1.00]
_NMC_OCV = [2.750, 3.080, 3.300, 3.440, 3.510, 3.560, 3.625, 3.672, 3.725, 3.802, 3.893, 3.985, 4.075, 4.120, 4.180]

PRESETS = {
    "lfp": dict(
        ocv_soc=_LFP_SOC, ocv_v=_LFP_OCV,
        capacity_ah=2.5, r0=8.0e-3, r1=3.0e-3, tau1=8.0, r2=4.0e-3, tau2=120.0,
        hyst_m=0.015, hyst_m0=0.002, hyst_gamma=50.0, eta_charge=0.995,
        ea_r=25e3, v_min=2.5, v_max=3.65, docv_dt=-0.0001,
        model_error=0.003, model_error_tau=120.0, estimate_capacity="consider",   # flat OCV: see README
    ),
    "nmc": dict(
        ocv_soc=_NMC_SOC, ocv_v=_NMC_OCV,
        capacity_ah=4.2, r0=14.0e-3, r1=6.0e-3, tau1=5.0, r2=8.0e-3, tau2=80.0,
        hyst_m=0.006, hyst_m0=0.001, hyst_gamma=40.0, eta_charge=0.998,
        ea_r=28e3, v_min=2.5, v_max=4.2, docv_dt=0.0,
        model_error=0.001, model_error_tau=120.0, estimate_capacity=True,
    ),
}

R_GAS = 8.314462618  # J/(mol K)


class OCV:
    """Open-circuit voltage OCV(SOC, T) with an exact-derivative lookup.

    Built once from the table with a monotone cubic (PCHIP: no overshoot, so the
    curve stays invertible) sampled on a 0.05 % SOC grid; evaluation is then a
    vectorised ``np.interp``. Outside [0, 1] the end slopes are extended linearly
    so the filter's Jacobian never goes to zero there.
    """

    def __init__(self, soc, v, docv_dt=0.0, t_ref=25.0, n=2001):
        from scipy.interpolate import PchipInterpolator
        soc = np.asarray(soc, float)
        v = np.asarray(v, float)
        if np.any(np.diff(soc) <= 0) or np.any(np.diff(v) <= 0):
            raise ValueError("OCV table must be strictly increasing in both SOC and voltage")
        p = PchipInterpolator(soc, v)
        self.grid = np.linspace(soc[0], soc[-1], n)
        self.v_grid = p(self.grid)
        self.dv_grid = p.derivative()(self.grid)
        self.s0, self.s1 = soc[0], soc[-1]
        self.k0, self.k1 = float(self.dv_grid[0]), float(self.dv_grid[-1])
        self.docv_dt = docv_dt
        self.t_ref = t_ref
        self.soc_tab, self.v_tab = soc, v

    def __call__(self, soc, temp=None):
        soc = np.asarray(soc, float)
        v = np.interp(soc, self.grid, self.v_grid)
        v = np.where(soc < self.s0, self.v_grid[0] + self.k0 * (soc - self.s0), v)
        v = np.where(soc > self.s1, self.v_grid[-1] + self.k1 * (soc - self.s1), v)
        if temp is not None and self.docv_dt:
            v = v + self.docv_dt * (np.asarray(temp, float) - self.t_ref)
        return v

    def slope(self, soc):
        soc = np.asarray(soc, float)
        d = np.interp(soc, self.grid, self.dv_grid)
        d = np.where(soc < self.s0, self.k0, d)
        return np.where(soc > self.s1, self.k1, d)

    def inverse(self, v, temp=None):
        """SOC at which OCV equals v (rest voltage -> SOC)."""
        v = np.asarray(v, float)
        if temp is not None and self.docv_dt:
            v = v - self.docv_dt * (np.asarray(temp, float) - self.t_ref)
        s = np.interp(v, self.v_grid, self.grid)
        s = np.where(v < self.v_grid[0], self.s0 + (v - self.v_grid[0]) / self.k0, s)
        return np.where(v > self.v_grid[-1], self.s1 + (v - self.v_grid[-1]) / self.k1, s)


def arrhenius(temp_c, ea, t_ref_c=25.0):
    """Resistance multiplier exp(Ea/R (1/T - 1/Tref)); > 1 when colder than Tref."""
    t = np.asarray(temp_c, float) + 273.15
    return np.exp(ea / R_GAS * (1.0 / t - 1.0 / (t_ref_c + 273.15)))
