"""Spring, damper, anti-roll-bar, rod and rocker calculations for one axle,
and the axle/vehicle stiffness quantities the vehicle model needs."""
from __future__ import annotations

import dataclasses as dc
import warnings

import numpy as np

from .config import Axle, CarConfig, MissingDataError
from .units import G0


def mr_damper_per_wheel(ax: Axle) -> float:
    """Motion ratio as damper travel / wheel travel, whatever convention was entered."""
    if ax.motion_ratio is None:
        raise MissingDataError("motion_ratio not set")
    if ax.motion_ratio_convention == "wheel/damper":
        return 1.0 / ax.motion_ratio
    if ax.motion_ratio_convention == "damper/wheel":
        return ax.motion_ratio
    raise ValueError("motion_ratio_convention must be 'wheel/damper' or 'damper/wheel'")


def wheel_rate(ax: Axle) -> float:
    """Spring rate referred to the wheel centre: k * MR_d^2 [N/m]."""
    if ax.spring_rate is None:
        raise MissingDataError("spring_rate not set")
    return ax.spring_rate * mr_damper_per_wheel(ax) ** 2


def tire_rate(cfg: CarConfig, pressure: float | None, load: float) -> float:
    """Tire vertical stiffness [N/m], bilinear in the manufacturer table (clamped)."""
    t = cfg.tires
    if not t.kt_rates:
        raise MissingDataError("tires.kt_* stiffness table not set")
    P, Lo, K = np.array(t.kt_pressures), np.array(t.kt_loads), np.array(t.kt_rates)
    p = np.clip(pressure if pressure is not None else P.mean(), P.min(), P.max())
    l = np.clip(load, Lo.min(), Lo.max())
    row = np.array([np.interp(l, Lo, K[i]) for i in range(len(P))])
    return float(np.interp(p, P, row))


def series(k1, k2):
    return k1 * k2 / (k1 + k2)


def arb_tip_stiffness(ax: Axle):
    """Blade-tip stiffness k = G J / (L_torsion L_blade^2) [N/m] (reproduces B43-45)."""
    if None in (ax.arb_blade_length, ax.arb_torsion_length, ax.arb_od, ax.arb_id):
        return None
    J = np.pi * (ax.arb_od ** 4 - ax.arb_id ** 4) / 32
    return ax.arb_G * J / (ax.arb_torsion_length * ax.arb_blade_length ** 2)


def arb_roll_stiffness(ax: Axle, track: float):
    """ARB roll stiffness at the wheels [N*m/rad].

    Opposite wheel travel z gives opposite tip travel d = MR_arb*z at each blade;
    the bar twists 2d/L_blade, so each wheel sees 2*k_tip*MR_arb^2 and the roll
    stiffness is k_tip*MR_arb^2*t^2."""
    if ax.arb_roll_stiffness is not None:
        return np.degrees(1) * ax.arb_roll_stiffness   # given in N*m/deg
    k = arb_tip_stiffness(ax)
    if k is None or ax.arb_motion_ratio is None:
        return None
    return k * ax.arb_motion_ratio ** 2 * track ** 2


@dc.dataclass
class AxleRates:
    wheel_rate: float          # N/m, springs only
    tire_rate: float           # N/m
    ride_rate: float           # N/m, spring in series with tire
    roll_stiffness: float      # N*m/rad incl. ARB and tires
    roll_stiffness_springs: float
    roll_stiffness_arb: float
    sprung_corner_mass: float  # kg
    ride_frequency: float      # Hz
    damping_bump: float | None     # N*s/m at the damper
    damping_rebound: float | None
    notes: list


def axle_rates(cfg: CarConfig, which: str, mr_d: float | None = None, k_arb_override=None) -> AxleRates:
    ax = cfg.front if which == "front" else cfg.rear
    track = cfg.geometry.track_front if which == "front" else cfg.geometry.track_rear
    m = cfg.mass
    frac = m.front_weight_fraction if which == "front" else 1 - m.front_weight_fraction
    notes = []
    corner_mass = m.total * frac / 2
    mu = m.unsprung_mass_front if which == "front" else m.unsprung_mass_rear
    if mu is None:
        notes.append(f"{which}: unsprung mass not recorded - whole corner mass treated as sprung")
        mu = 0.0
    msc = corner_mass - mu
    mrd = mr_d if mr_d is not None else mr_damper_per_wheel(ax)
    if ax.spring_rate is None:
        raise MissingDataError(f"{which}.spring_rate not set")
    kw = ax.spring_rate * mrd ** 2
    pressure = cfg.tires.pressure_front if which == "front" else cfg.tires.pressure_rear
    kt = tire_rate(cfg, pressure, corner_mass * G0)
    kr = series(kw, kt)
    k_springs = kw * track ** 2 / 2
    k_arb = k_arb_override if k_arb_override is not None else arb_roll_stiffness(ax, track)
    if k_arb is None:
        notes.append(f"{which}: ARB roll stiffness unknown (needs arb_blade_length and arb_motion_ratio, "
                     "or arb_roll_stiffness) - ARB omitted")
        k_arb = 0.0
    k_tire_roll = kt * track ** 2 / 2
    k_roll = series(k_springs + k_arb, k_tire_roll)
    f = np.sqrt(kr / msc) / (2 * np.pi)
    c_crit_w = 2 * np.sqrt(kr * msc)
    cb = ax.damping_ratio_bump * c_crit_w / mrd ** 2 if ax.damping_ratio_bump is not None else None
    cr = ax.damping_ratio_rebound * c_crit_w / mrd ** 2 if ax.damping_ratio_rebound is not None else None
    return AxleRates(kw, kt, kr, k_roll, k_springs, k_arb, msc, f, cb, cr, notes)


# --------------------------------------------------------------- rod / rocker
def rod_force(ax: Axle, wheel_vertical_load: float):
    """Axial rod force for a vertical load at the wheel (B62 formula F_v/cos(theta)).
    Positive = tension (pull rod), negative = compression (push rod)."""
    if ax.rod_angle_deg is None:
        raise MissingDataError("rod_angle_deg not set")
    f = wheel_vertical_load / np.cos(np.radians(ax.rod_angle_deg))
    return f if ax.rod_type == "pull" else -f


def rocker_ratio(ax: Axle):
    if ax.rocker_force_ratio is not None:
        return ax.rocker_force_ratio
    if None in (ax.rocker_lp, ax.rocker_ld, ax.rocker_alpha_deg, ax.rocker_beta_deg):
        raise MissingDataError("rocker geometry (lp, ld, alpha, beta) or rocker_force_ratio needed")
    return (ax.rocker_lp * np.sin(np.radians(ax.rocker_beta_deg))) / (
        ax.rocker_ld * np.sin(np.radians(ax.rocker_alpha_deg)))


def damper_force_from_rod(ax: Axle, f_rod: float):
    return abs(f_rod) * rocker_ratio(ax)


def static_residual(ax: Axle, damper_force: float, reference_length: float = 8 * 0.0254):
    """B62: k*(8 in - L_static) - F_damper  (spring force minus required damper force)."""
    return ax.spring_rate * (reference_length - ax.damper_static_length) - damper_force


def push_rod_buckling(ax: Axle):
    """Euler buckling load [N] (pinned-pinned) for a push rod, or None if dims missing."""
    if None in (ax.rod_length, ax.rod_od, ax.rod_id):
        return None
    I = np.pi * (ax.rod_od ** 4 - ax.rod_id ** 4) / 64
    return np.pi ** 2 * ax.rod_E * I / ax.rod_length ** 2


def rod_check(ax: Axle, max_wheel_load: float):
    out = {"rod_type": ax.rod_type}
    f = rod_force(ax, max_wheel_load)
    out["rod_force_N"] = f
    out["amplification"] = 1 / np.cos(np.radians(ax.rod_angle_deg))
    try:
        out["damper_force_N"] = damper_force_from_rod(ax, f)
    except MissingDataError:
        pass
    if ax.rod_type == "push":
        pcr = push_rod_buckling(ax)
        out["buckling_load_N"] = pcr
        out["buckling_safety_factor"] = (pcr / abs(f)) if pcr else None
    return out
