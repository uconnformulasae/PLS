"""Pacejka Magic Formula 6.1 tire model (steady state), with .tir file I/O.

Implements, vectorised over numpy arrays:
  * pure longitudinal force  Fx0(kappa, Fz, gamma, p)
  * pure lateral force       Fy0(alpha, Fz, gamma, p)
  * combined slip            Fx(kappa, alpha, ...), Fy(kappa, alpha, ...)   (weighting functions G)
  * aligning moment          Mz(kappa, alpha, ...) (pneumatic trail + residual moment + s*Fx)
  * overturning moment       Mx (main terms)
  * rolling resistance       My
including load sensitivity (dfz), inflation-pressure terms (dpi, the MF 6.1 extension), camber
and all user scaling factors (LMUX, LMUY, LKY, ...). Turn slip is not modelled (zeta = 1).

Conventions follow Pacejka, "Tire and Vehicle Dynamics" (3rd ed.), MF 6.1 / TNO .tir files:
  kappa  longitudinal slip ratio (+ = driving)         alpha  slip angle [rad]
  gamma  inclination angle [rad]                        Fz     normal load [N] (>0)
  p      inflation pressure [Pa]
For the vehicle model the wrapper ``MF61Tire`` converts the package's turn-relative camber
(negative = leaning into the turn) to the tire's own sign automatically.
"""
from __future__ import annotations

import functools
import re
from pathlib import Path

import numpy as np

EPS = 1e-6

# every coefficient used, with the neutral default (0 or 1 for scaling factors)
DEFAULTS = {
    # dimensions / operating conditions
    "FNOMIN": 1000.0, "UNLOADED_RADIUS": 0.2032, "WIDTH": 0.1905, "RIM_RADIUS": 0.127,
    "NOMPRES": 82737.0, "LONGVL": 11.176, "VERTICAL_STIFFNESS": 0.0, "VERTICAL_DAMPING": 0.0,
    # scaling
    **{k: 1.0 for k in ("LFZO", "LCX", "LMUX", "LEX", "LKX", "LHX", "LVX", "LCY", "LMUY", "LEY", "LKY", "LKYC",
                        "LKZC", "LHY", "LVY", "LTR", "LRES", "LXAL", "LYKA", "LVYKA", "LS", "LMX", "LVMX", "LMY",
                        "LMP")},
    # longitudinal
    **{k: 0.0 for k in ("PCX1", "PDX1", "PDX2", "PDX3", "PEX1", "PEX2", "PEX3", "PEX4", "PKX1", "PKX2", "PKX3",
                        "PHX1", "PHX2", "PVX1", "PVX2", "PPX1", "PPX2", "PPX3", "PPX4",
                        "RBX1", "RBX2", "RBX3", "RCX1", "REX1", "REX2", "RHX1")},
    # lateral
    **{k: 0.0 for k in ("PCY1", "PDY1", "PDY2", "PDY3", "PEY1", "PEY2", "PEY3", "PEY4", "PEY5", "PKY1", "PKY2",
                        "PKY3", "PKY4", "PKY5", "PKY6", "PKY7", "PHY1", "PHY2", "PVY1", "PVY2", "PVY3", "PVY4",
                        "PPY1", "PPY2", "PPY3", "PPY4", "PPY5", "RBY1", "RBY2", "RBY3", "RBY4", "RCY1", "REY1",
                        "REY2", "RHY1", "RHY2", "RVY1", "RVY2", "RVY3", "RVY4", "RVY5", "RVY6")},
    # aligning
    **{k: 0.0 for k in ("QBZ1", "QBZ2", "QBZ3", "QBZ4", "QBZ5", "QBZ6", "QBZ9", "QBZ10", "QCZ1", "QDZ1", "QDZ2",
                        "QDZ3", "QDZ4", "QDZ6", "QDZ7", "QDZ8", "QDZ9", "QDZ10", "QDZ11", "QEZ1", "QEZ2", "QEZ3",
                        "QEZ4", "QEZ5", "QHZ1", "QHZ2", "QHZ3", "QHZ4", "PPZ1", "PPZ2", "SSZ1", "SSZ2", "SSZ3",
                        "SSZ4")},
    # overturning / rolling resistance
    **{k: 0.0 for k in ("QSX1", "QSX2", "QSX3", "PPMX1", "QSY1", "QSY2", "QSY3", "QSY4", "QSY5", "QSY6", "QSY7",
                        "QSY8")},
    # relaxation lengths (kept for transient use; not used by the steady-state lap sim)
    **{k: 0.0 for k in ("PTX1", "PTX2", "PTX3", "PTY1", "PTY2")},
}

TIR_SECTIONS = {
    "DIMENSION": ["UNLOADED_RADIUS", "WIDTH", "RIM_RADIUS"],
    "OPERATING_CONDITIONS": ["NOMPRES"],
    "VERTICAL": ["FNOMIN", "VERTICAL_STIFFNESS", "VERTICAL_DAMPING"],
    "MODEL": ["LONGVL"],
    "SCALING_COEFFICIENTS": [k for k in DEFAULTS if k.startswith("L") and k != "LONGVL"],
    "LONGITUDINAL_COEFFICIENTS": [k for k in DEFAULTS if re.match(r"^(P[CDEKHVP]X|R[BCEH]X)", k)],
    "OVERTURNING_COEFFICIENTS": ["QSX1", "QSX2", "QSX3", "PPMX1"],
    "LATERAL_COEFFICIENTS": [k for k in DEFAULTS if re.match(r"^(P[CDEKHVP]Y|R[BCEHV]Y)", k)],
    "ROLLING_COEFFICIENTS": [k for k in DEFAULTS if k.startswith("QSY")],
    "ALIGNING_COEFFICIENTS": [k for k in DEFAULTS if re.match(r"^(Q[BCDEH]Z|PPZ|SSZ)", k)],
    "RELAXATION": ["PTX1", "PTX2", "PTX3", "PTY1", "PTY2"],
}


# ------------------------------------------------------------------ .tir I/O
def read_tir(path) -> dict:
    """Read a TNO/MF-Tyre style .tir property file. Unknown keys are kept; units in [UNITS]
    must be SI (the standard). Returns a coefficient dict merged over DEFAULTS."""
    c = dict(DEFAULTS)
    meta = {}
    for line in Path(path).read_text(errors="replace").splitlines():
        line = line.split("$")[0].strip()
        if not line or line.startswith(("[", "!", "{")):
            continue
        if "=" in line:
            k, v = (s.strip() for s in line.split("=", 1))
            v = v.strip("'\" ")
            try:
                c[k.upper()] = float(v)
            except ValueError:
                meta[k.upper()] = v
    c["_meta"] = meta
    return c


def write_tir(coef: dict, path, comment="", fitted_from=""):
    lines = ["[MDI_HEADER]", "FILE_TYPE = 'tir'", "FILE_VERSION = 3.0", "FILE_FORMAT = 'ASCII'",
             f"! {comment}", f"! fitted from: {fitted_from}", "[UNITS]", "LENGTH = 'meter'", "FORCE = 'newton'",
             "ANGLE = 'radians'", "MASS = 'kg'", "TIME = 'second'", "[MODEL]", "FITTYP = 61",
             "PROPERTY_FILE_FORMAT = 'MF61'"]
    for sec, keys in TIR_SECTIONS.items():
        if sec != "MODEL":
            lines.append(f"[{sec}]")
        for k in keys:
            lines.append(f"{k:<22}= {coef.get(k, DEFAULTS.get(k, 0.0)):.10g}")
    Path(path).write_text("\n".join(lines) + "\n")


# ------------------------------------------------------------------ equations
class MF61:
    def __init__(self, coef: dict):
        self.c = {**DEFAULTS, **{k: v for k, v in coef.items() if not k.startswith("_")}}

    # common terms
    def _base(self, fz, gamma, p):
        c = self.c
        fz = np.maximum(np.asarray(fz, float), 1.0)
        fz0 = c["FNOMIN"] * c["LFZO"]
        dfz = (fz - fz0) / fz0
        p = c["NOMPRES"] if p is None else p
        dpi = (np.asarray(p, float) - c["NOMPRES"]) / c["NOMPRES"]
        g = np.asarray(gamma, float)
        return c, fz, fz0, dfz, dpi, g

    # ---- pure longitudinal
    def fx0(self, kappa, fz, gamma=0.0, p=None, _parts=False):
        c, fz, fz0, dfz, dpi, g = self._base(fz, gamma, p)
        k = np.asarray(kappa, float)
        SHx = (c["PHX1"] + c["PHX2"] * dfz) * c["LHX"]
        SVx = fz * (c["PVX1"] + c["PVX2"] * dfz) * c["LVX"] * c["LMUX"]
        kx = k + SHx
        Cx = c["PCX1"] * c["LCX"]
        mux = (c["PDX1"] + c["PDX2"] * dfz) * (1 + c["PPX3"] * dpi + c["PPX4"] * dpi ** 2) * \
            (1 - c["PDX3"] * g ** 2) * c["LMUX"]
        Dx = mux * fz
        Ex = np.minimum((c["PEX1"] + c["PEX2"] * dfz + c["PEX3"] * dfz ** 2) * (1 - c["PEX4"] * np.sign(kx)) * c["LEX"], 1.0)
        Kxk = fz * (c["PKX1"] + c["PKX2"] * dfz) * np.exp(c["PKX3"] * dfz) * (1 + c["PPX1"] * dpi + c["PPX2"] * dpi ** 2) * c["LKX"]
        Bx = Kxk / (Cx * Dx + EPS)
        F = Dx * np.sin(Cx * np.arctan(Bx * kx - Ex * (Bx * kx - np.arctan(Bx * kx)))) + SVx
        if _parts:
            return F, {"Kxk": Kxk, "Dx": Dx, "mux": mux}
        return F

    # ---- pure lateral
    def fy0(self, alpha, fz, gamma=0.0, p=None, _parts=False):
        c, fz, fz0, dfz, dpi, g = self._base(fz, gamma, p)
        a = np.asarray(alpha, float)
        Kya = c["PKY1"] * fz0 * (1 + c["PPY1"] * dpi) * (1 - c["PKY3"] * np.abs(g)) * \
            np.sin(c["PKY4"] * np.arctan(fz / ((c["PKY2"] + c["PKY5"] * g ** 2) * (1 + c["PPY2"] * dpi) * fz0 + EPS))) * c["LKY"]
        Kyg0 = fz * (c["PKY6"] + c["PKY7"] * dfz) * (1 + c["PPY5"] * dpi) * c["LKYC"]
        SVyg = fz * (c["PVY3"] + c["PVY4"] * dfz) * g * c["LKYC"] * c["LMUY"]
        SVy = fz * (c["PVY1"] + c["PVY2"] * dfz) * c["LVY"] * c["LMUY"] + SVyg
        SHy = (c["PHY1"] + c["PHY2"] * dfz) * c["LHY"] + (Kyg0 * g - SVyg) / (Kya + np.sign(Kya + EPS) * EPS)
        ay = a + SHy
        Cy = c["PCY1"] * c["LCY"]
        muy = (c["PDY1"] + c["PDY2"] * dfz) * (1 + c["PPY3"] * dpi + c["PPY4"] * dpi ** 2) * \
            (1 - c["PDY3"] * g ** 2) * c["LMUY"]
        Dy = muy * fz
        Ey = np.minimum((c["PEY1"] + c["PEY2"] * dfz) * (1 + c["PEY5"] * g ** 2 - (c["PEY3"] + c["PEY4"] * g) * np.sign(ay)) * c["LEY"], 1.0)
        By = Kya / (Cy * Dy + EPS)
        F = Dy * np.sin(Cy * np.arctan(By * ay - Ey * (By * ay - np.arctan(By * ay)))) + SVy
        if _parts:
            return F, {"Kya": Kya, "By": By, "Cy": Cy, "Dy": Dy, "muy": muy, "SHy": SHy, "SVy": SVy}
        return F

    # ---- combined slip
    def fx(self, kappa, alpha, fz, gamma=0.0, p=None):
        c, fz_, fz0, dfz, dpi, g = self._base(fz, gamma, p)
        F0 = self.fx0(kappa, fz, gamma, p)
        if c["RBX1"] == 0:
            return F0
        k, a = np.asarray(kappa, float), np.asarray(alpha, float)
        SHxa = c["RHX1"]
        Bxa = (c["RBX1"] + c["RBX3"] * g ** 2) * np.cos(np.arctan(c["RBX2"] * k)) * c["LXAL"]
        Cxa, Exa = c["RCX1"], np.minimum(c["REX1"] + c["REX2"] * dfz, 1.0)
        a_s = a + SHxa
        G = np.cos(Cxa * np.arctan(Bxa * a_s - Exa * (Bxa * a_s - np.arctan(Bxa * a_s)))) / \
            np.cos(Cxa * np.arctan(Bxa * SHxa - Exa * (Bxa * SHxa - np.arctan(Bxa * SHxa))))
        return np.maximum(G, 0.0) * F0

    def fy(self, kappa, alpha, fz, gamma=0.0, p=None):
        c, fz_, fz0, dfz, dpi, g = self._base(fz, gamma, p)
        F0, parts = self.fy0(alpha, fz, gamma, p, _parts=True)
        if c["RBY1"] == 0:
            return F0
        k, a = np.asarray(kappa, float), np.asarray(alpha, float)
        SHyk = c["RHY1"] + c["RHY2"] * dfz
        Byk = (c["RBY1"] + c["RBY4"] * g ** 2) * np.cos(np.arctan(c["RBY2"] * (a - c["RBY3"]))) * c["LYKA"]
        Cyk, Eyk = c["RCY1"], np.minimum(c["REY1"] + c["REY2"] * dfz, 1.0)
        ks = k + SHyk
        G = np.cos(Cyk * np.arctan(Byk * ks - Eyk * (Byk * ks - np.arctan(Byk * ks)))) / \
            np.cos(Cyk * np.arctan(Byk * SHyk - Eyk * (Byk * SHyk - np.arctan(Byk * SHyk))))
        DVyk = parts["muy"] * fz_ * (c["RVY1"] + c["RVY2"] * dfz + c["RVY3"] * g) * np.cos(np.arctan(c["RVY4"] * a))
        SVyk = DVyk * np.sin(c["RVY5"] * np.arctan(c["RVY6"] * k)) * c["LVYKA"]
        return np.maximum(G, 0.0) * F0 + SVyk

    # ---- aligning moment (pure and combined)
    def mz(self, kappa, alpha, fz, gamma=0.0, p=None):
        c, fz_, fz0, dfz, dpi, g = self._base(fz, gamma, p)
        k, a = np.asarray(kappa, float), np.asarray(alpha, float)
        R0 = c["UNLOADED_RADIUS"]
        Fy0, py = self.fy0(alpha, fz, gamma, p, _parts=True)
        _, px = self.fx0(kappa, fz, gamma, p, _parts=True)
        SHt = c["QHZ1"] + c["QHZ2"] * dfz + (c["QHZ3"] + c["QHZ4"] * dfz) * g
        at = a + SHt
        lmuy = c["LMUY"] if c["LMUY"] else 1.0
        Bt = (c["QBZ1"] + c["QBZ2"] * dfz + c["QBZ3"] * dfz ** 2) * (1 + c["QBZ5"] * np.abs(g) + c["QBZ6"] * g ** 2) * c["LKY"] / lmuy
        Ct = c["QCZ1"]
        Dt = fz_ * (R0 / fz0) * (c["QDZ1"] + c["QDZ2"] * dfz) * (1 - c["PPZ1"] * dpi) * c["LTR"] * \
            (1 + c["QDZ3"] * np.abs(g) + c["QDZ4"] * g ** 2)
        Et = np.minimum((c["QEZ1"] + c["QEZ2"] * dfz + c["QEZ3"] * dfz ** 2) *
                        (1 + (c["QEZ4"] + c["QEZ5"] * g) * (2 / np.pi) * np.arctan(Bt * Ct * at)), 1.0)
        SHf = py["SHy"] + py["SVy"] / (py["Kya"] + EPS)
        ar = a + SHf
        Br = c["QBZ9"] * c["LKY"] / lmuy + c["QBZ10"] * py["By"] * py["Cy"]
        Dr = fz_ * R0 * ((c["QDZ6"] + c["QDZ7"] * dfz) * c["LRES"] +
                         ((c["QDZ8"] + c["QDZ9"] * dfz) * (1 + c["PPZ2"] * dpi) + (c["QDZ10"] + c["QDZ11"] * dfz) * np.abs(g))
                         * g * c["LKZC"]) * lmuy * np.cos(a)
        # combined: equivalent slip angles
        ratio = px["Kxk"] / (py["Kya"] + EPS)
        at_eq = np.sqrt(at ** 2 + (ratio * k) ** 2) * np.sign(at)
        ar_eq = np.sqrt(ar ** 2 + (ratio * k) ** 2) * np.sign(ar)
        t = Dt * np.cos(Ct * np.arctan(Bt * at_eq - Et * (Bt * at_eq - np.arctan(Bt * at_eq)))) * np.cos(a)
        Mzr = Dr * np.cos(np.arctan(Br * ar_eq))
        Fx = self.fx(kappa, alpha, fz, gamma, p)
        Fy = self.fy(kappa, alpha, fz, gamma, p)
        s = R0 * (c["SSZ1"] + c["SSZ2"] * Fy / fz0 + (c["SSZ3"] + c["SSZ4"] * dfz) * g) * c["LS"]
        return -t * Fy + Mzr + s * Fx

    def mx(self, fy, fz, gamma=0.0, p=None):
        c, fz_, fz0, dfz, dpi, g = self._base(fz, gamma, p)
        return c["UNLOADED_RADIUS"] * fz_ * c["LMX"] * (c["QSX1"] * c["LVMX"] - c["QSX2"] * g * (1 + c["PPMX1"] * dpi)
                                                         + c["QSX3"] * np.asarray(fy) / fz0)

    def my(self, fx, fz, v, gamma=0.0, p=None):
        c, fz_, fz0, dfz, dpi, g = self._base(fz, gamma, p)
        vr = np.abs(np.asarray(v, float)) / c["LONGVL"]
        pr = (c["NOMPRES"] if p is None else p) / c["NOMPRES"]
        return fz_ * c["UNLOADED_RADIUS"] * c["LMY"] * (
            c["QSY1"] + c["QSY2"] * np.asarray(fx) / fz0 + c["QSY3"] * vr + c["QSY4"] * vr ** 4 +
            (c["QSY5"] + c["QSY6"] * fz_ / fz0) * g ** 2) * (fz_ / fz0) ** c["QSY7"] * pr ** c["QSY8"]

    def cornering_stiffness(self, fz, gamma=0.0, p=None):
        return self.fy0(0.0, fz, gamma, p, _parts=True)[1]["Kya"]

    def slip_stiffness(self, fz, gamma=0.0, p=None):
        return self.fx0(0.0, fz, gamma, p, _parts=True)[1]["Kxk"]


# ------------------------------------------------------------------ vehicle-facing wrapper
class MF61Tire:
    """MF 6.1 tire with the interface the vehicle model uses.

    Peak lateral / longitudinal forces and the combined-slip envelope are pre-computed on a
    (load, camber) grid for each inflation pressure, so the lap simulation stays fast.
    ``lambda_mu`` (track/rig scaling, calibrated from logs) multiplies LMUX and LMUY."""
    FZ = np.linspace(50, 3500, 36)
    GAM = np.radians(np.linspace(-6, 6, 25))
    ALPHA = np.radians(np.linspace(0, 20, 161))
    KAPPA = np.linspace(0, 0.4, 161)

    def __init__(self, coef: dict, lambda_mu=1.0, combined="mf", mux_over_muy=1.0):
        coef = dict(coef)
        coef["LMUX"] = coef.get("LMUX", 1.0) * lambda_mu
        coef["LMUY"] = coef.get("LMUY", 1.0) * lambda_mu
        self.m = MF61(coef)
        self.combined = combined if (coef.get("RBX1", 0) and coef.get("RBY1", 0)) else "ellipse"
        # a .tir fitted to free-rolling (cornering-only) data has no longitudinal curve: use
        # mux_over_muy x the lateral peak and a friction ellipse for braking / drive
        self.no_longitudinal = not coef.get("PDX1", 0)
        self.mux_over_muy = mux_over_muy
        self._tables = {}
        fn = self.m.c["FNOMIN"]
        # sign conventions of this coefficient set: slope of Fy vs alpha, and camber-thrust direction
        self.sK = 1.0 if self.m.cornering_stiffness(fn) >= 0 else -1.0
        thrust = self.m.fy0(0.0, fn, 0.05) - self.m.fy0(0.0, fn, 0.0)
        self.thrust_sign = 1.0 if thrust >= 0 else -1.0

    def _gamma_mf(self, gamma_turn_deg, d):
        """Turn-relative camber [deg] (- = top leaning toward the turn centre, the helpful side) ->
        tire inclination [rad] when the lateral force points in direction d (+1/-1)."""
        return -d * self.thrust_sign * np.radians(np.asarray(gamma_turn_deg, float))

    def _table(self, p):
        key = round(float(p if p is not None else self.m.c["NOMPRES"]), 0)
        if key in self._tables:
            return self._tables[key]
        GT = np.degrees(self.GAM)                                   # turn-relative camber grid [deg]
        FZ, G = np.meshgrid(self.FZ, GT, indexing="ij")
        A = np.radians(np.linspace(-20, 20, 241))[None, None, :]
        fy_pos = self.m.fy0(A, FZ[..., None], self._gamma_mf(G, +1)[..., None], key).max(-1)
        fy_neg = (-self.m.fy0(A, FZ[..., None], self._gamma_mf(G, -1)[..., None], key)).max(-1)
        fy_pk = 0.5 * (fy_pos + fy_neg)
        K = np.linspace(-0.4, 0.4, 161)[None, None, :]
        GR = np.radians(np.abs(G))[..., None]
        fx_all = self.m.fx0(K, FZ[..., None], GR, key)
        fx_drv, fx_brk = fx_all.max(-1), (-fx_all).max(-1)
        u = np.linspace(0, 1, 21)
        loads = np.linspace(200, 3000, 5)
        j0 = int(np.argmin(np.abs(GT)))
        if self.combined == "mf":
            env = np.zeros((loads.size, u.size))
            a = np.radians(np.linspace(-20, 20, 121))[:, None]
            k = np.linspace(-0.4, 0.4, 161)[None, :]
            for i, L in enumerate(loads):
                fx = self.m.fx(k, a, L, 0.0, key)
                fy = self.m.fy(k, a, L, 0.0, key)
                fxp = np.where(fx >= 0, np.interp(L, self.FZ, fx_drv[:, j0]), np.interp(L, self.FZ, fx_brk[:, j0]))
                ux = np.abs(fx) / np.maximum(fxp, EPS)
                uy = np.abs(fy) / max(np.interp(L, self.FZ, fy_pk[:, j0]), EPS)
                for j, uu in enumerate(u):
                    sel = ux >= uu - 0.025
                    env[i, j] = uy[sel].max() if sel.any() else 0.0
                env[i] = np.minimum.accumulate(np.clip(env[i], 0, None) / max(env[i, 0], EPS))
            env[:, -1] = np.minimum(env[:, -1], 0.05)
        else:
            env = np.sqrt(1 - u ** 2)[None, :].repeat(loads.size, 0)
        from scipy.interpolate import RegularGridInterpolator as RGI
        t = {"fy": RGI((self.FZ, GT), fy_pk, bounds_error=False, fill_value=None),
             "fxd": RGI((self.FZ, GT), fx_drv, bounds_error=False, fill_value=None),
             "fxb": RGI((self.FZ, GT), fx_brk, bounds_error=False, fill_value=None),
             "env": RGI((loads, u), env, bounds_error=False, fill_value=None), "env_raw": env, "u": u, "loads": loads}
        self._tables[key] = t
        return t

    @staticmethod
    def _q(rgi, a, b):
        a, b = np.broadcast_arrays(np.asarray(a, float), np.asarray(b, float))
        return rgi(np.column_stack([a.ravel(), b.ravel()])).reshape(a.shape)

    def _clip(self, fz, g):
        return np.clip(fz, self.FZ[0], self.FZ[-1]), np.clip(g, -6, 6)

    # ---- interface used by vehicle.py
    def peak_fy(self, fz, gamma_turn_deg=0.0, p=None):
        fz_, g = self._clip(np.asarray(fz, float), np.asarray(gamma_turn_deg, float))
        return np.maximum(self._q(self._table(p)["fy"], fz_, g), 0.0)

    def mu(self, fz, gamma_turn_deg=0.0, p=None):
        return self.peak_fy(fz, gamma_turn_deg, p) / np.maximum(np.asarray(fz, float), 1.0)

    def peak_fx(self, fz, gamma_turn_deg=0.0, p=None, drive=True):
        if self.no_longitudinal:
            return np.maximum(self.mux_over_muy * self.peak_fy(fz, gamma_turn_deg, p), 1.0)
        fz_, g = self._clip(np.asarray(fz, float), np.asarray(gamma_turn_deg, float))
        return np.maximum(self._q(self._table(p)["fxd" if drive else "fxb"], fz_, g), 1.0)

    def lateral_capacity(self, fz, gamma_turn_deg, fx, p=None):
        """Max lateral force with longitudinal force fx applied (MF combined slip, or ellipse).
        Returns (fy_available, over), over = |fx| beyond the longitudinal peak."""
        fz, fx = np.broadcast_arrays(np.asarray(fz, float), np.asarray(fx, float))
        fxp = np.where(fx >= 0, self.peak_fx(fz, gamma_turn_deg, p, True), self.peak_fx(fz, gamma_turn_deg, p, False))
        u = np.clip(np.abs(fx) / fxp, 0, 1)
        g = self._q(self._table(p)["env"], np.clip(fz, 200, 3000), u)
        return np.where(u < 1, self.peak_fy(fz, gamma_turn_deg, p) * np.clip(g, 0, 1), 0.0), u >= 1

    def fy(self, alpha_rad, fz, gamma_turn_deg=0.0, p=None):
        """Lateral force, positive for positive slip angle, camber on the turn-relative convention."""
        return self.sK * self.m.fy0(self.sK * 0 + np.asarray(alpha_rad, float), fz,
                                    self._gamma_mf(gamma_turn_deg, self.sK), p)

    def cornering_stiffness(self, fz, gamma_turn_deg=0.0, p=None):
        return np.abs(self.m.cornering_stiffness(fz, self._gamma_mf(gamma_turn_deg, self.sK), p))

    def mz(self, alpha_rad, fz, gamma_turn_deg=0.0, p=None, kappa=0.0):
        """Aligning moment magnitude acting to reduce the slip angle (+ = self-aligning)."""
        return -self.sK * self.m.mz(kappa, alpha_rad, fz, self._gamma_mf(gamma_turn_deg, self.sK), p)

    def rolling_resistance(self, fz, v, p=None):
        c = self.m.c
        if c["QSY1"] == 0 and c["QSY3"] == 0:
            return None
        return self.m.my(0.0, fz, v, 0.0, p) / (np.maximum(fz, 1) * c["UNLOADED_RADIUS"])


@functools.lru_cache(maxsize=8)
def _cached_read(path):
    return read_tir(path)


def load_tir(path):
    return dict(_cached_read(str(path)))
