"""Shared notebook plumbing: one results folder per notebook run, and everything in data/.

    run = start_run("vehicle_dynamics")      # results/vehicle_dynamics/2026-11-05_21-40-12/
    run.fig(fig, "ggv")                       #   .../ggv.png
    run.fig(fig, "overview", sub="brakes")    #   .../brakes/overview.png
    run.table(df, "event_summary")            #   .../event_summary.csv
    run.finish()                              #   .../manifest.csv; results/vehicle_dynamics/latest -> this run

    ts = load_track_set("ic_2026")            # configs/tracks/ic_2026.yaml: which track file per event
    tracks = track_catalog(0.5, ts)           # every track of the set as Track objects
    ev = event_tracks(0.5, ts)                # the event tracks used by the lap simulations
    inventory = data_inventory()              # every data file and what uses it
"""
from __future__ import annotations

import datetime as _dt
import os
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"

# --------------------------------------------------------------------------- run folders


class Run:
    """A results folder for one execution of a notebook. Every figure / table goes in here."""

    def __init__(self, notebook: str, root: Path | None = None, stamp: str | None = None):
        self.notebook = notebook
        self.root = Path(root or ROOT)
        self.stamp = stamp or _dt.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        self.base = self.root / "results" / notebook
        self.dir = self.base / self.stamp
        self.dir.mkdir(parents=True, exist_ok=True)
        self.saved = []
        self._link_latest()

    def _link_latest(self):
        link = self.base / "latest"
        try:
            if link.is_symlink() or link.exists():
                link.unlink()
            os.symlink(self.stamp, link, target_is_directory=True)
        except OSError:                       # no symlinks (e.g. some Windows setups): write a pointer file
            (self.base / "latest.txt").write_text(self.stamp + "\n")

    def path(self, name: str, sub: str | None = None) -> Path:
        d = self.dir / sub if sub else self.dir
        d.mkdir(parents=True, exist_ok=True)
        return d / name

    def fig(self, fig, name: str, sub: str | None = None, dpi: int = 140):
        """Save a matplotlib figure as <name>.png (returns the figure so it still displays)."""
        if fig is None:
            return None
        p = self.path(f"{name}.png", sub)
        fig.savefig(p, dpi=dpi, bbox_inches="tight")
        self.saved.append(("figure", p))
        return fig

    def table(self, df, name: str, sub: str | None = None, index: bool = True):
        """Save a DataFrame / Series as <name>.csv (returns it)."""
        if df is None:
            return None
        p = self.path(f"{name}.csv", sub)
        df.to_csv(p, index=index)
        self.saved.append(("table", p))
        return df

    def file(self, name: str, sub: str | None = None) -> Path:
        """Path for any other output (yaml, .tir, ...); recorded in the manifest."""
        p = self.path(name, sub)
        self.saved.append(("file", p))
        return p

    def finish(self):
        """Write manifest.csv (every file of this run) and print where the results are."""
        files = sorted(p for p in self.dir.rglob("*") if p.is_file() and p.name != "manifest.csv")
        kind = {str(p): k for k, p in self.saved}
        man = pd.DataFrame({"file": [str(p.relative_to(self.dir)) for p in files],
                            "kind": [kind.get(str(p), p.suffix.lstrip(".")) for p in files],
                            "bytes": [p.stat().st_size for p in files]})
        man.to_csv(self.dir / "manifest.csv", index=False)
        n_fig = int((man["file"].str.endswith(".png")).sum())
        print(f"{n_fig} figures, {len(man) - n_fig} other files in {self.dir}")
        return man

    def __repr__(self):
        return f"Run({self.notebook!r}, {self.dir})"


def start_run(notebook: str, root: Path | None = None) -> Run:
    run = Run(notebook, root)
    print(f"results of this run: {run.dir}")
    return run


# --------------------------------------------------------------------------- tracks
# Which tracks are simulated is set by a TRACK SET (configs/tracks/<name>.yaml, see track_sets.py and
# configs/tracks/README.md). Every notebook has  TRACK_SET = "ic_2026"  at the top.
from .track_sets import TrackSet, load_track_set, list_track_sets, DEFAULT_TRACK_SET  # noqa: E402


def _track_from_df(d: pd.DataFrame, name: str, ds: float):
    from .track import from_xy
    x, y = d["x_m"].to_numpy(float), d["y_m"].to_numpy(float)
    return from_xy(x, y, ds=ds, name=name)


def _ts(track_set) -> TrackSet:
    return track_set if isinstance(track_set, TrackSet) else load_track_set(track_set)


def track_catalog(ds: float = 0.5, track_set=None) -> dict:
    """Every track of a track set as Track objects (its folder's .csv files, the event files, `extra`).
    A .csv with an `event` column is split per event (course segments), one with a `lap` column per lap
    (skidpad right / left); a logged run (.xrk) becomes the reconstructed course."""
    from .track import from_csv, load_track
    out = {}
    for p in _ts(track_set).lap_files():
        p = Path(p)
        if p.suffix.lower() != ".csv":
            out[p.stem] = load_track(p, ds)
            continue
        head = pd.read_csv(p, nrows=2)
        if "event" in head:
            d = pd.read_csv(p)
            for ev, g in d.groupby("event"):
                g = g[g["segment"] == "course"] if "segment" in g else g
                if len(g) > 3:
                    out[f"{p.stem}_{ev}"] = _track_from_df(g, f"{p.stem}_{ev}", ds)
        elif "lap" in head:
            d = pd.read_csv(p)
            for lap, g in d.groupby("lap", sort=False):
                out[f"{p.stem}_{lap}"] = _track_from_df(g, f"{p.stem}_{lap}", ds)
        elif "x_m" in head or "curvature_1pm" in head or "s_m" in head:
            out[p.stem] = from_csv(p, ds, name=p.stem)
        else:
            out[p.stem] = load_track(p, ds)
    return out


def event_tracks(ds: float = 0.5, track_set=None) -> dict:
    """{'acceleration', 'autocross', 'endurance', 'brake_test'} Track objects of a track set (those it has;
    the skidpad is simulated on the rules circle, its file is in track_catalog for plots)."""
    ts = _ts(track_set)
    out = {e: ts.load(e, ds) for e in ts.events if e != "skidpad"}
    return {e: t for e, t in out.items() if t is not None}


def track_table(tracks: dict, track_set=None) -> pd.DataFrame:
    notes = _ts(track_set).notes if track_set is not None else {}
    rows = []
    for n, t in tracks.items():
        k = np.abs(np.asarray(t.kappa, float))
        rows.append({"track": n, "length_m": float(t.length), "closed": bool(getattr(t, "closed", False)),
                     "min_radius_m": float(1 / k.max()) if k.max() > 1e-6 else np.inf,
                     "share_straight_pct": 100 * float((k < 1 / 200).mean()),
                     "note": notes.get(n, notes.get(n.rsplit("_", 1)[0], ""))})
    return pd.DataFrame(rows).set_index("track")


def plot_tracks(tracks: dict, ncols: int = 4):
    import matplotlib.pyplot as plt
    n = len(tracks)
    nr = int(np.ceil(n / ncols))
    fig, axs = plt.subplots(nr, ncols, figsize=(4.2 * ncols, 3.9 * nr), squeeze=False, constrained_layout=True)
    for ax, (name, t) in zip(axs.ravel(), tracks.items()):
        if t.x is not None:
            sc = ax.scatter(t.x, t.y, c=np.abs(t.kappa), s=2, cmap="Blues", vmin=0, vmax=0.12)
            ax.plot(t.x[0], t.y[0], "o", color="#eb6834", ms=6)
            ax.set_aspect("equal", adjustable="datalim")
            span = max(np.ptp(t.x), np.ptp(t.y), 1.0)
            if np.ptp(t.y) < 0.1 * span:          # a straight: show it with some height
                yc = 0.5 * (np.max(t.y) + np.min(t.y))
                ax.set_ylim(yc - 0.15 * span, yc + 0.15 * span)
        ax.set_title(f"{name}\n{t.length:.0f} m", fontsize=9, loc="left")
        ax.tick_params(labelsize=7)
        for s in ("top", "right"):
            ax.spines[s].set_visible(False)
    for ax in axs.ravel()[n:]:
        ax.axis("off")
    fig.colorbar(sc, ax=axs, shrink=0.6, label="|curvature| [1/m]  (orange dot = start)")
    return fig


def track_images(track_set=None) -> list:
    """Layout images of a track set (its `images` folders / files, else its track folder)."""
    ts = _ts(track_set)
    out = []
    for p in (ts.images or [ts.folder]):
        p = Path(p)
        out += sorted(x for x in p.rglob("*") if x.suffix.lower() in (".png", ".jpg", ".jpeg")
                      and ".ipynb_checkpoints" not in x.parts) if p.is_dir() else ([p] if p.exists() else [])
    return out


def show_images(paths, ncols: int = 3, width: float = 5.5):
    import matplotlib.pyplot as plt
    import matplotlib.image as mpimg
    paths = list(paths)
    nr = int(np.ceil(len(paths) / ncols))
    fig, axs = plt.subplots(nr, ncols, figsize=(width * ncols, width * 0.75 * nr), squeeze=False,
                            constrained_layout=True)
    for ax, p in zip(axs.ravel(), paths):
        ax.imshow(mpimg.imread(p))
        ax.set_title(p.name, fontsize=9, loc="left")
        ax.axis("off")
    for ax in axs.ravel()[len(paths):]:
        ax.axis("off")
    return fig


# --------------------------------------------------------------------------- TTC (Round 8, 10-inch)
TTC_DIR = DATA / "ttc" / "RawData_Cornering_ASCII_USCS_10inch_Round8"
# FSAE TTC Round 8 run guide (data/ttc/RunGuide_Round8.pdf), free-rolling cornering, 10-inch:
# tire, rim width [in] -> transient run, slip-angle-sweep runs (12/10/14 psi, 8 psi + final 12 psi + speed)
TTC_RUNS = {
    ("43075 16x7.5-10 R25B", 7): (1, [2, 4]),
    ("43075 16x7.5-10 R25B", 8): (5, [6, 7]),
    ("43070 16x6.0-10 R25B", 6): (8, [9, 10]),
    ("43070 16x6.0-10 R25B", 7): (11, [12, 13]),
    ("43075 16x7.5-10 LC0", 8): (14, [15, 16]),
    ("43075 16x7.5-10 LC0", 7): (17, [18, 19]),
    ("43070 16x6.0-10 LC0", 6): (20, [21, 22]),
    ("43070 16x6.0-10 LC0", 7): (23, [24, 25]),
}
CT17_TIRE = ("43075 16x7.5-10 LC0", 7)       # 16.0 in OD x 7.5 in (B10, B22), LC0 compound


def ttc_files(tire=CT17_TIRE, sweeps: bool = True, root: Path | None = None) -> list:
    """Raw .dat files of one tire/rim from the Round 8 cornering data (sweeps, or the transient run)."""
    d = Path(root or ROOT) / "data" / "ttc" / "RawData_Cornering_ASCII_USCS_10inch_Round8"
    tr, sw = TTC_RUNS[tire]
    runs = sw if sweeps else [tr]
    return [d / f"A1965raw{r}.dat" for r in runs if (d / f"A1965raw{r}.dat").exists()]


def ttc_table(root: Path | None = None) -> pd.DataFrame:
    rows = []
    for (tire, rim), (tr, sw) in TTC_RUNS.items():
        files = ttc_files((tire, rim), root=root)
        rows.append({"tire": tire, "rim_in": rim, "transient_run": tr, "sweep_runs": sw,
                     "files_present": len(files), "used_for_CT17": (tire, rim) == CT17_TIRE})
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------- inventory
_ROLE = [
    ("data/tracks/**/*.csv", "track", "lap simulations (all notebooks; which ones: configs/tracks/<TRACK_SET>.yaml)"),
    ("configs/tracks/*.yaml", "track set", "which track file each event uses (TRACK_SET in every notebook)"),
    ("data/tracks/**/*.png", "image", "track / site layouts (shown in the notebooks)"),
    ("data/logs/*.xrk", "log", "fusion, identification, brake analysis (vehicle_dynamics, powertrain, aerodynamics, tire_dynamics)"),
    ("*.xrk", "log", "extra log in the project root (tire_dynamics brake analysis)"),
    ("data/hardpoints/*.csv", "hardpoints", "suspension kinematics (vehicle_dynamics, via the config)"),
    ("data/dyno/*.csv", "dyno", "engine torque curve (powertrain, vehicle_dynamics)"),
    ("data/ttc/RawData_Cornering_ASCII_USCS_10inch_Round8/*.dat", "TTC", "tire fit (vehicle_dynamics)"),
    ("data/ttc/*.pdf", "doc", "TTC run guide (run -> tire mapping)"),
    ("data/synthetic/*", "synthetic", "pipeline check only (DEMO mode)"),
    ("data/dampers/*", "dampers", "damper force-velocity (optional)"),
    ("data/**/*.zip", "archive", "original downloads (contents already extracted)"),
]


def data_inventory(root: Path | None = None) -> pd.DataFrame:
    root = Path(root or ROOT)
    rows, seen = [], set()
    for pat, kind, use in _ROLE:
        for p in sorted(root.glob(pat)):
            if p.is_file() and p not in seen and ".ipynb_checkpoints" not in p.parts:
                seen.add(p)
                rows.append({"file": str(p.relative_to(root)), "kind": kind, "MB": round(p.stat().st_size / 1e6, 2),
                             "used for": use})
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------- laps on every track
def laps_on_tracks(veh, ggv, tracks: dict, solver: str = "vd", tables=None, skip=()) -> dict:
    """Simulate one lap of every track. Closed tracks: flying lap; open tracks: standing start.
    solver 'vd' = fsae_vd quasi-steady (veh: Vehicle, ggv: GGV); 'pt' = fsae_pt gear by gear
    (veh: PTVehicle, ggv: the tire-limited GGV it uses, tables: PTTables)."""
    out = {}
    for name, tr in tracks.items():
        if name in skip:
            continue
        closed = bool(getattr(tr, "closed", False))
        if solver == "pt":
            from fsae_pt.lapsim_pt import solve_pt
            out[name] = solve_pt(tr, veh, ggv, tables, v0=None if closed else 0.0, flying=closed)
        else:
            from .lapsim import solve
            out[name] = solve(tr, veh, ggv, v0=None if closed else 0.0, flying=closed)
    return out


def lap_table(laps: dict) -> pd.DataFrame:
    from .units import G0
    rows = []
    for n, lr in laps.items():
        v, ax, ay = np.asarray(lr.v, float), np.asarray(lr.ax, float), np.asarray(lr.ay, float)
        rows.append({"track": n, "length_m": float(lr.s[-1] - lr.s[0]), "time_s": float(lr.time),
                     "mean_kph": 3.6 * float((lr.s[-1] - lr.s[0]) / max(lr.time, 1e-6)),
                     "max_kph": 3.6 * float(v.max()), "min_kph": 3.6 * float(v.min()),
                     "max_lat_g": float(np.abs(ay).max() / G0), "max_decel_g": float(-ax.min() / G0),
                     "pct_braking": 100 * float((ax < -0.5).mean())})
    return pd.DataFrame(rows).set_index("track")


def plot_lap_speeds(laps: dict, ncols: int = 3):
    import matplotlib.pyplot as plt
    n = len(laps)
    nr = int(np.ceil(n / ncols))
    fig, axs = plt.subplots(nr, ncols, figsize=(5.4 * ncols, 2.8 * nr), squeeze=False, constrained_layout=True)
    for ax, (name, lr) in zip(axs.ravel(), laps.items()):
        ax.plot(lr.s - lr.s[0], 3.6 * np.asarray(lr.v), color="#2a78d6", lw=1.3)
        ax.set_title(f"{name}: {lr.time:.2f} s", fontsize=9, loc="left")
        ax.set_xlabel("distance [m]", fontsize=8)
        ax.set_ylabel("km/h", fontsize=8)
        ax.tick_params(labelsize=7)
        ax.grid(True, color="#e4e3df", lw=0.6)
        for s in ("top", "right"):
            ax.spines[s].set_visible(False)
    for ax in axs.ravel()[n:]:
        ax.axis("off")
    return fig


def xrk_logs(root: Path | None = None) -> dict:
    """Every AiM log the project has, by role: {'accel': [...], 'skidpad': [...], 'autocross': [...],
    'endurance': [...], 'brake_test': [...], 'other': [...]} (data/logs and the project root)."""
    root = Path(root or ROOT)
    files = sorted((root / "data" / "logs").glob("*.xrk")) + sorted(root.glob("*.xrk")) + sorted(DATA.glob("*.xrk"))
    roles = {"accel": [], "skidpad": [], "autocross": [], "endurance": [], "brake_test": [], "other": []}
    for p in dict.fromkeys(files):
        n = p.name.lower()
        key = ("brake_test" if "brake" in n else "accel" if "accel" in n else "skidpad" if "skid" in n
               else "autocross" if "autox" in n or "autocross" in n else "endurance" if "endur" in n else "other")
        roles[key].append(p)
    return roles
