"""One interface for an axle's kinematics, built either from the CT17 hardpoint
files (3-D linkage solution) or, if no file is given, from the summary values in
the config (roll-centre height + FVSA, linear camber gain)."""
from __future__ import annotations

import functools

import numpy as np
from scipy import optimize

from . import hardpoints as hp
from .config import CarConfig, MissingDataError


@functools.lru_cache(maxsize=16)
def _load(path):
    return hp.load_optimumk_csv(path)


@functools.lru_cache(maxsize=256)
def _analyse(path, front, d_rod, d_tie, h, L, bias):
    c = hp.Corner(_load(path), front)
    travel = np.linspace(-0.045, 0.045, 31)
    k = hp.analyse_corner(c, travel, h, L, bias, d_rod=d_rod, d_tie=d_tie)
    base = hp.analyse_corner(c, np.array([0.0]), None, None, None) if (d_rod or d_tie) else k
    return c, k, base.static["damper_length_static"]


class AxleModel:
    def __init__(self, cfg: CarConfig, which: str):
        self.which = which
        self.front = which == "front"
        ax = cfg.front if self.front else cfg.rear
        self.ax = ax
        self.track = cfg.geometry.track_front if self.front else cfg.geometry.track_rear
        adj = cfg.adjust
        self.shim = adj.camber_shim_front if self.front else adj.camber_shim_rear
        self.notes = []
        self.source = "hardpoints" if ax.hardpoint_file else "config"
        if ax.hardpoint_file:
            d_rod = round(adj.pull_rod_front if self.front else adj.pull_rod_rear, 7)
            d_tie = round(adj.tie_rod_front if self.front else adj.tie_rod_rear, 7)
            c, k, L0 = _analyse(str(ax.hardpoint_file), self.front, d_rod, d_tie, cfg.mass.cg_height,
                                cfg.geometry.wheelbase, cfg.brakes.front_bias or 0.6)
            self.corner, self.k = c, k
            # static wheel position: same spring length (load) as the baseline pull rod
            if d_rod:
                f = lambda z: np.interp(z, k.travel, k.damper_len) - L0
                self.z_static = float(optimize.brentq(f, k.travel[0], k.travel[-1]))
            else:
                self.z_static = 0.0
            self.body_rise = -self.z_static          # body rises when the wheel sits in droop
            s = k.static
            self.kpi_deg, self.caster_deg = s["kpi_deg"], s["caster_deg"]
            self.scrub, self.trail = s["scrub_radius"], s["mech_trail"]
            dl = np.gradient(k.damper_len, k.travel)
            self.mr_d = float(-np.interp(self.z_static, k.travel, dl))       # damper shortening per wheel bump
            self.rod_angle_deg = s["pull_rod_angle_from_vertical_deg"]
            self.fvsa = s["fvsa"]
            self.blade_rate = (float(np.interp(self.z_static, k.travel, np.gradient(k.blade, k.travel)))
                               if k.blade is not None else None)
            self.blade_len_file = s.get("blade_length_in_file")
            self.anti = {kk: s[kk] for kk in ("anti_dive", "anti_lift", "anti_squat") if kk in s}
            self.toe_static = float(np.interp(self.z_static, k.travel, k.toe))
            if not ax.use_hardpoint_rc and ax.roll_center_height is not None:
                off = ax.roll_center_height - float(np.interp(0.0, k.travel, k.rc_height))
                self._rc = lambda z: np.interp(z, k.travel, k.rc_height) + off
                self.notes.append(f"{which}: roll-centre curve shifted to the configured static height")
            else:
                self._rc = lambda z: np.interp(z, k.travel, k.rc_height)
        else:
            if ax.roll_center_height is None or ax.fvsa_length is None:
                raise MissingDataError(f"{which}: give hardpoint_file, or roll_center_height and fvsa_length")
            self.corner = self.k = None
            self.z_static = self.body_rise = 0.0
            self.kpi_deg, self.caster_deg = ax.kpi_deg or 0.0, ax.caster_deg or 0.0
            self.scrub, self.trail = ax.scrub_radius, ax.mechanical_trail
            self.mr_d = None
            self.rod_angle_deg = ax.rod_angle_deg
            self.fvsa = ax.fvsa_length
            self.blade_rate = None
            self.blade_len_file = None
            self.anti = {}
            self.toe_static = ax.static_toe_deg
            rc0 = ax.roll_center_height
            self._rc = lambda z: np.full(np.shape(z), rc0, float) if np.ndim(z) else rc0

    # -------------------------------------------------------------- curves
    def rc(self, heave):
        return self._rc(self.z_static + np.asarray(heave, float))

    def dcamber(self, z):
        """Camber change relative to the body [deg] (+ top outboard) at wheel travel z (+ bump)."""
        if self.k is None:
            return np.degrees(-np.asarray(z, float) / self.fvsa)
        return np.interp(self.z_static + np.asarray(z, float), self.k.travel, self.k.camber) - \
            np.interp(self.z_static, self.k.travel, self.k.camber)

    def static_camber(self):
        c0 = self.ax.static_camber_deg or 0.0
        sh = hp.camber_per_shim(self.corner, self.shim) if self.corner is not None and self.shim else \
            (np.degrees(np.arctan2(self.shim, 0.2034)) if self.shim else 0.0)
        ride = (np.interp(self.z_static, self.k.travel, self.k.camber) if self.k is not None else 0.0)
        return c0 + sh + ride

    def toe(self, z=0.0):
        if self.k is None:
            return self.toe_static
        return np.interp(self.z_static + np.asarray(z, float), self.k.travel, self.k.toe)

    # -------------------------------------------------------------- ARB
    def arb_roll_stiffness(self):
        """ARB roll stiffness [N*m/rad] from the hardpoint drop-link geometry and the
        torsion bar: K = (G J / L_t) * k^2 * t^2, with k = blade rotation per wheel travel
        scaled by (blade length in the file / selected blade length)."""
        ax = self.ax
        if ax.arb_roll_stiffness is not None:
            return np.degrees(1) * ax.arb_roll_stiffness
        if self.blade_rate is None or None in (ax.arb_torsion_length, ax.arb_od, ax.arb_id):
            return None
        Lb = ax.arb_blade_length
        if Lb is None:
            Lb = self.blade_len_file
            self.notes.append(f"{self.which}: ARB blade length not set - using the {Lb / 0.0254:.2f} in "
                              "blade implied by the hardpoint file")
        if Lb == 0:
            return 0.0     # disconnected
        J = np.pi * (ax.arb_od ** 4 - ax.arb_id ** 4) / 32
        k = self.blade_rate * self.blade_len_file / Lb
        return ax.arb_G * J / ax.arb_torsion_length * k ** 2 * self.track ** 2

    def summary(self):
        d = {"source": self.source, "kpi_deg": self.kpi_deg, "caster_deg": self.caster_deg,
             "scrub_radius_mm": (self.scrub or np.nan) * 1000, "mech_trail_mm": (self.trail or np.nan) * 1000,
             "rc_static_in": float(self.rc(0.0)) / 0.0254, "fvsa_in": self.fvsa / 0.0254,
             "static_camber_deg": self.static_camber(), "static_toe_deg": float(self.toe(0.0)),
             "body_rise_mm": self.body_rise * 1000}
        if self.mr_d:
            d["motion_ratio_wheel_per_damper"] = 1 / self.mr_d
        if self.rod_angle_deg is not None:
            d["rod_angle_deg"] = self.rod_angle_deg
        d.update({k: v for k, v in self.anti.items()})
        return d
