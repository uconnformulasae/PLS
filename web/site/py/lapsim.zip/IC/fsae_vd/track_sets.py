"""Track sets: which track files a simulation runs on (one competition year, one test day, ...).

A track set is a small YAML file in configs/tracks/ (see configs/tracks/README.md):

    name: ic_2026
    folder: data/tracks/ic_tracks2026          # relative to the project root
    events:                                     # file per event, relative to `folder`
      acceleration: acceleration_2026.csv
      autocross: autocross_2026.csv
      endurance: endurance_2026_backstretch.csv
    lap_whole_folder: true                      # also lap every other .csv in `folder`
    extra: []                                   # more tracks to lap (.csv or a logged .xrk), from the root

Use it:

    ts = load_track_set("ic_2026")                       # configs/tracks/ic_2026.yaml
    ts = load_track_set("data/tracks/test_day_0412")     # or just a folder of track .csv files
    ts = load_track_set("ic_2026", override={"autocross": "data/tracks/ic_tracks2026/autocross_2024.csv"})
    ts.apply(cfg)                                         # cfg.events.autocross_track / endurance_track
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parents[1]
SET_DIR = ROOT / "configs" / "tracks"
DEFAULT_TRACK_SET = "ic_2026"
EVENTS = ("acceleration", "skidpad", "autocross", "endurance", "brake_test")
# a folder without a YAML: an event's file is the .csv whose name starts with one of these
_KEYWORDS = {"acceleration": ("acceleration", "accel"), "skidpad": ("skidpad",), "autocross": ("autocross", "autox"),
             "endurance": ("endurance", "enduro"), "brake_test": ("brake",)}


def _resolve(p, folder: Path, root: Path) -> Path:
    """A file named in a track set: absolute, else relative to the set's folder, else to the project root."""
    p = Path(str(p)).expanduser()
    if p.is_absolute():
        return p
    for base in (folder, root):
        if (base / p).exists():
            return (base / p).resolve()
    return (folder / p).resolve()


@dataclass
class TrackSet:
    name: str
    folder: Path
    events: dict = field(default_factory=dict)       # event -> Path
    extra: list = field(default_factory=list)        # more Paths to lap
    lap_whole_folder: bool = True
    images: list = field(default_factory=list)       # folders / files of layout images
    notes: dict = field(default_factory=dict)        # file stem -> description
    description: str = ""
    source: Path | None = None                       # the YAML (None: a bare folder)

    # ---------------------------------------------------------------- files
    def path(self, event: str):
        """The file of one event (None if this set has none)."""
        return self.events.get(event)

    def lap_files(self) -> list:
        """Every track file to lap: the folder's .csv files (if lap_whole_folder), the event files, extra."""
        files = sorted(self.folder.glob("*.csv")) if self.lap_whole_folder and self.folder.is_dir() else []
        for p in list(self.events.values()) + list(self.extra):
            if p is not None and p not in files:
                files.append(p)
        return [p for p in files if Path(p).exists()]

    def missing(self) -> list:
        return [str(p) for p in list(self.events.values()) + list(self.extra) if p is not None and not Path(p).exists()]

    def table(self) -> pd.DataFrame:
        """Which file each event uses (and whether it exists)."""
        rows = [{"use": e, "file": self._rel(p), "exists": p is not None and Path(p).exists()}
                for e, p in self.events.items()]
        rows += [{"use": "extra lap", "file": self._rel(p), "exists": Path(p).exists()} for p in self.extra]
        return pd.DataFrame(rows).set_index("use")

    @staticmethod
    def _rel(p):
        if p is None:
            return "-"
        try:
            return str(Path(p).resolve().relative_to(ROOT))
        except ValueError:
            return str(p)

    # ---------------------------------------------------------------- use
    def apply(self, cfg):
        """Point the car config's autocross / endurance tracks at this set (used by run_events)."""
        for e in ("autocross", "endurance"):
            p = self.events.get(e)
            setattr(cfg.events, f"{e}_track", str(p) if p is not None else None)
        return cfg

    def load(self, event: str, ds: float = 0.5):
        """The Track of one event (None if the set has no file for it)."""
        from .track import load_track
        p = self.events.get(event)
        return load_track(p, ds) if p is not None and Path(p).exists() else None

    def build_car_kwargs(self) -> dict:
        """Arguments for fsae_pt.calibrate.build_car(root, **ts.build_car_kwargs())."""
        return {"autocross_track": str(self.events["autocross"]) if self.events.get("autocross") else None,
                "endurance_track": str(self.events["endurance"]) if self.events.get("endurance") else None}

    def __repr__(self):
        ev = ", ".join(f"{e}={Path(p).name}" for e, p in self.events.items() if p is not None)
        return f"TrackSet({self.name!r}, folder={self._rel(self.folder)}, {ev})"


def list_track_sets(root: Path | None = None) -> pd.DataFrame:
    d = Path(root or ROOT) / "configs" / "tracks"
    rows = []
    for p in sorted(d.glob("*.yaml")):
        y = yaml.safe_load(p.read_text()) or {}
        rows.append({"track_set": p.stem, "folder": y.get("folder", ""), "description": y.get("description", "")})
    return pd.DataFrame(rows)


def _from_folder(folder: Path, name: str) -> TrackSet:
    """A folder of track .csv files with no YAML: guess each event's file from its name."""
    csvs = sorted(folder.glob("*.csv"))
    ev = {}
    for e, keys in _KEYWORDS.items():
        hit = [p for p in csvs if p.stem.lower().startswith(keys)]
        if hit:                              # newest year in the name first, then alphabetical
            ev[e] = min(hit, key=lambda q: (-max([int(y) for y in re.findall(r"(?:19|20)\d\d", q.stem)] or [0]), q.stem))
    return TrackSet(name=name, folder=folder, events=ev, images=[folder])


def load_track_set(track_set=None, override: dict | None = None, extra=None, root: Path | None = None) -> TrackSet:
    """Load a track set.

    track_set: a name in configs/tracks/ ("ic_2026"), a path to a track-set YAML, or a folder of
               track .csv files (events found by file name: acceleration*, skidpad*, autocross*,
               endurance*, brake*). None = DEFAULT_TRACK_SET.
    override:  {event: file} to swap single events, e.g. {"autocross": "data/logs/<run>.xrk"}.
    extra:     more files to lap (added to the set's own `extra`).
    """
    root = Path(root or ROOT)
    track_set = track_set or DEFAULT_TRACK_SET
    p = Path(str(track_set)).expanduser()
    cands = [p, root / p, root / "configs" / "tracks" / f"{track_set}.yaml", root / "configs" / "tracks" / str(track_set)]
    src = next((c for c in cands if c.exists()), None)
    if src is None:
        avail = ", ".join(list_track_sets(root)["track_set"]) or "none"
        raise FileNotFoundError(f"track set {track_set!r} not found: give a name in configs/tracks/ ({avail}), "
                                f"a .yaml path, or a folder of track .csv files")
    if src.is_dir():
        ts = _from_folder(src.resolve(), src.name)
    else:
        y = yaml.safe_load(src.read_text()) or {}
        folder = _resolve(y.get("folder", "."), root, root)
        ts = TrackSet(
            name=y.get("name", src.stem),
            folder=folder,
            events={e: (_resolve(f, folder, root) if f else None) for e, f in (y.get("events") or {}).items()},
            extra=[_resolve(f, root, root) for f in (y.get("extra") or [])],
            lap_whole_folder=bool(y.get("lap_whole_folder", True)),
            images=[_resolve(f, root, root) for f in (y.get("images") or [])],
            notes={str(k): str(v) for k, v in (y.get("notes") or {}).items()},
            description=str(y.get("description", "")),
            source=src.resolve(),
        )
    for e, f in (override or {}).items():
        ts.events[e] = _resolve(f, ts.folder, root) if f else None
    ts.extra += [_resolve(f, root, root) for f in (extra or [])]
    bad = [e for e in ts.events if e not in EVENTS]
    if bad:
        raise ValueError(f"unknown event(s) {bad} in track set {ts.name!r}; use {EVENTS}")
    return ts
