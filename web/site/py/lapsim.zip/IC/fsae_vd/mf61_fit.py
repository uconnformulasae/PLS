"""Fit MF 6.1 coefficients to tire-test (FSAE TTC / Calspan) data.

Standard staged procedure, each stage a robust (soft-L1) least-squares fit on the data that
isolate its coefficients:
  1. pure lateral        |SL| small       -> PCY, PDY, PEY, PKY, PHY, PVY (+ PPY if >1 pressure)
  2. pure longitudinal   |SA| small       -> PCX, PDX, PEX, PKX, PHX, PVX (+ PPX)
  3. combined            SA and SL both   -> RBX, RCX, REX, RHX, RBY, RCY, REY, RHY, RVY
  4. aligning moment     MZ available     -> QBZ, QCZ, QDZ, QEZ, QHZ (+ PPZ)
Raw rig data are noisy and include sweep transients, so before fitting: samples at very low
speed or load are dropped, each stage is thinned to an even spread of samples, and a robust
loss keeps residual spikes from steering the fit. Starting values are generic MF shape values
(optimiser starting points, not tire data). Units: SA, IA in degrees and FZ, FY, FX in N as in
TTC exports; pressure in kPa (converted); SL as a ratio.
"""
from __future__ import annotations

import numpy as np
from scipy import optimize

from .mf61 import DEFAULTS, MF61, write_tir

LAT = ["PCY1", "PDY1", "PDY2", "PDY3", "PEY1", "PEY2", "PEY3", "PEY4", "PKY1", "PKY2", "PKY4", "PKY6", "PKY7",
       "PHY1", "PHY2", "PVY1", "PVY2", "PVY3", "PVY4"]
LAT_P = ["PPY1", "PPY2", "PPY3", "PPY4"]
LON = ["PCX1", "PDX1", "PDX2", "PDX3", "PEX1", "PEX2", "PEX3", "PEX4", "PKX1", "PKX2", "PKX3", "PHX1", "PHX2",
       "PVX1", "PVX2"]
LON_P = ["PPX1", "PPX2", "PPX3", "PPX4"]
COMB = ["RBX1", "RBX2", "RCX1", "REX1", "RHX1", "RBY1", "RBY2", "RBY3", "RCY1", "REY1", "RHY1", "RVY1", "RVY4",
        "RVY5", "RVY6"]
ALN = ["QBZ1", "QBZ2", "QBZ3", "QCZ1", "QDZ1", "QDZ2", "QDZ3", "QDZ4", "QEZ1", "QEZ2", "QEZ4", "QHZ1", "QHZ2",
       "QBZ9", "QDZ6", "QDZ8"]
ALN_P = ["PPZ1"]

START = {"PCY1": 1.4, "PDY1": 2.0, "PKY1": 40.0, "PKY2": 1.5, "PKY4": 2.0, "PEY1": 0.0,
         "PCX1": 1.6, "PDX1": 2.0, "PKX1": 40.0,
         "RBX1": 10.0, "RBX2": 10.0, "RCX1": 1.0, "RBY1": 10.0, "RBY2": 10.0, "RCY1": 1.0,
         "QBZ1": 8.0, "QCZ1": 1.2, "QDZ1": 0.1, "QEZ1": -1.0, "QBZ9": 10.0}
BOUNDS = {"PCY1": (1.0, 2.0), "PCX1": (1.0, 2.0), "PEY1": (-10, 1), "PEX1": (-10, 1), "PKY4": (1.0, 3.0),
          "PKY2": (0.2, 10), "RCX1": (0.5, 2), "RCY1": (0.5, 2), "QCZ1": (0.8, 2.0), "PDY3": (-50, 50)}


def _prep(ttc, nompres_kpa=None, settle_s=0.5):
    d = {k: (None if v is None else np.asarray(v, float)) for k, v in ttc.items()}
    n = d["SA"].size
    ok = np.isfinite(d["SA"]) & np.isfinite(d["FY"]) & np.isfinite(d["FZ"]) & (np.abs(d["FZ"]) > 100)
    # drop the settling transient at the start of every sweep (a gap in elapsed time = new sweep)
    if d.get("ET") is not None and settle_s:
        et = d["ET"]
        starts = np.r_[0, np.flatnonzero(np.diff(et) > 0.5) + 1]
        since = et - et[starts[np.searchsorted(starts, np.arange(n), side="right") - 1]]
        ok &= since >= settle_s
    if d.get("V") is not None:
        ok &= d["V"] > 10
    d["FZ"] = np.abs(d["FZ"])
    d["IA"] = d["IA"] if d.get("IA") is not None else np.zeros(n)
    d["SL"] = d["SL"] if d.get("SL") is not None else np.zeros(n)
    P = d.get("P")
    if P is None:
        P = np.full(n, nompres_kpa or 82.737)
    d["P_Pa"] = P * 1000.0
    return d, ok


def _thin(mask, n_max, seed=0):
    idx = np.flatnonzero(mask)
    if idx.size > n_max:
        idx = np.sort(np.random.default_rng(seed).choice(idx, n_max, replace=False))
    return idx


def _fit(coef, names, fun, idx, y, scale):
    names = [n for n in names]
    x0 = np.array([coef.get(n, START.get(n, 0.0)) or START.get(n, 0.0) for n in names], float)
    lb = np.array([BOUNDS.get(n, (-np.inf, np.inf))[0] for n in names])
    ub = np.array([BOUNDS.get(n, (-np.inf, np.inf))[1] for n in names])
    x0 = np.clip(x0, lb + 1e-9, ub - 1e-9)

    def r(x):
        c = dict(coef); c.update(zip(names, x))
        return (fun(MF61(c), idx) - y) / scale
    res = optimize.least_squares(r, x0, bounds=(lb, ub), loss="soft_l1", f_scale=0.05, max_nfev=4000)
    coef.update(zip(names, res.x))
    resid = res.fun * scale
    return {"rms_N": float(np.sqrt(np.mean(resid ** 2))), "r2": float(1 - np.var(resid) / np.var(y)), "n": int(idx.size)}


def fit_mf61(ttc: dict, fnomin=None, nompres_kpa=None, unloaded_radius=0.2032, n_max=15000,
             stages=("lateral", "longitudinal", "combined", "aligning"), tir_out=None, seed=0, settle_s=0.5):
    """Fit MF 6.1 to TTC data. Returns (coefficients, report). Writes a .tir if tir_out is given.
    Pressure coefficients are fitted only for stages whose data cover more than one pressure."""
    d, ok = _prep(ttc, nompres_kpa, settle_s)
    coef = dict(DEFAULTS)
    coef["FNOMIN"] = fnomin or float(np.median(d["FZ"][ok]))
    coef["NOMPRES"] = (nompres_kpa * 1000.0) if nompres_kpa else float(np.median(d["P_Pa"][ok]))
    coef["UNLOADED_RADIUS"] = unloaded_radius
    multi = lambda m: np.ptp(d["P_Pa"][m]) > 5e3 if m.any() else False   # pressure terms only if that stage varies p
    rep = {}
    SA, SL = np.radians(d["SA"]), d["SL"]
    IA, FZ, P = np.radians(d["IA"]), d["FZ"], d["P_Pa"]
    pure_lat = ok & (np.abs(SL) < 0.01)
    pure_lon = ok & (np.abs(d["SA"]) < 0.5) & (np.abs(SL) > 0.0) & np.isfinite(d["FX"] if d.get("FX") is not None else SL * np.nan)
    # sign-aware start values from the data
    if "lateral" in stages and pure_lat.sum() > 200:
        lin = pure_lat & (np.abs(d["SA"]) < 1.0)
        slope = np.polyfit(SA[lin], d["FY"][lin], 1)[0] if lin.sum() > 20 else 30 * coef["FNOMIN"]
        coef["PKY1"] = slope / coef["FNOMIN"] / np.sin(2 * np.arctan(1 / 1.5))
        big = pure_lat & (np.abs(d["SA"]) > 5)
        coef["PDY1"] = float(np.median(np.abs(d["FY"][big]) / FZ[big])) if big.any() else 2.0
        idx = _thin(pure_lat, n_max, seed)
        rep["lateral"] = _fit(coef, LAT + (LAT_P if multi(pure_lat) else []),
                              lambda m, i: m.fy0(SA[i], FZ[i], IA[i], P[i]), idx, d["FY"][idx], coef["FNOMIN"])
    if "longitudinal" in stages and d.get("FX") is not None and pure_lon.sum() > 200:
        lin = pure_lon & (np.abs(SL) < 0.03)
        slope = np.polyfit(SL[lin], d["FX"][lin], 1)[0] if lin.sum() > 20 else 30 * coef["FNOMIN"]
        coef["PKX1"] = slope / coef["FNOMIN"]
        big = pure_lon & (np.abs(SL) > 0.1)
        coef["PDX1"] = float(np.median(np.abs(d["FX"][big]) / FZ[big])) if big.any() else 2.0
        idx = _thin(pure_lon, n_max, seed)
        rep["longitudinal"] = _fit(coef, LON + (LON_P if multi(pure_lon) else []),
                                   lambda m, i: m.fx0(SL[i], FZ[i], IA[i], P[i]), idx, d["FX"][idx], coef["FNOMIN"])
    comb = ok & (np.abs(d["SA"]) > 1.0) & (np.abs(SL) > 0.02)
    if "combined" in stages and d.get("FX") is not None and comb.sum() > 200:
        idx = _thin(comb, n_max, seed)
        y = np.r_[d["FX"][idx], d["FY"][idx]]
        rep["combined"] = _fit(coef, COMB, lambda m, i: np.r_[m.fx(SL[i], SA[i], FZ[i], IA[i], P[i]),
                                                               m.fy(SL[i], SA[i], FZ[i], IA[i], P[i])],
                               idx, y, coef["FNOMIN"])
    if "aligning" in stages and d.get("MZ") is not None and pure_lat.sum() > 200:
        idx = _thin(pure_lat & np.isfinite(d["MZ"]), n_max, seed)
        rep["aligning"] = _fit(coef, ALN + (ALN_P if multi(pure_lat) else []),
                               lambda m, i: m.mz(SL[i] * 0, SA[i], FZ[i], IA[i], P[i]), idx, d["MZ"][idx],
                               coef["FNOMIN"] * unloaded_radius * 0.1)
    if tir_out:
        write_tir(coef, tir_out, comment="MF 6.1 fitted by fsae_vd.mf61_fit", fitted_from="TTC data")
    return coef, rep
