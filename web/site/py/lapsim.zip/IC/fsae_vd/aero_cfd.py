"""CFD-coupled aerodynamics: the local full-car CFD (``fsae_cfd``) drives the lap simulation's
component aero model (``fsae_vd.aero``).

Chain
-----
1. **Design states** (`fit_states`): straight running at the reference speed, plus one change of
   each attitude the lap sim's aero model responds to - heave, pitch and body slip (yaw).
2. **CFD** (`run_states`): each state is a full-car LES run of the CT17 (``fsae_cfd.CarCase``),
   cached in ``results/cfd_lapsim/cfd_runs/`` and keyed by the geometry config, motion and
   resolution (a changed config or motion re-runs; an unchanged one is reused).
3. **Loads in lap-sim terms** (`component_loads`): the CFD part groups are summed into the lap
   sim's three components (front_wing, rear_wing, body = everything else) and converted to its
   turn-relative conventions, each with a 95 % statistical confidence half-width.
4. **Fit** (`fit_components`): ClA, CdA, centre of pressure, ride-height and pitch sensitivity,
   yaw loss, yaw drag rise, side-force slope and induced-drag share per component, with the
   uncertainty carried through; a sensitivity is "resolved" when the CFD change exceeds its own
   confidence interval.
5. **Into the lap sim** (`apply_fit`), three modes:
     * ``"sensitivities"`` (default at quick / coarse grids): keep the coast-down-calibrated
       downforce, drag and balance; replace the ASSUMED sensitivities (pitch, ride height, yaw,
       side force) with the CFD ones where the CFD resolves them;
     * ``"calibrated"``: CFD component split, centres of pressure and sensitivities; totals
       scaled to the coast-down ClA / CdA;
     * ``"absolute"``: everything from CFD (for medium / fine grids or CAD geometry).
6. **Check** (`check_states`, `compare_model`): the fitted model is compared with CFD at states the
   fit never saw, taken from the lap sim's own solution (skidpad, the fastest autocross corner,
   hardest braking) - cornering in a rotating frame, roll, combined attitude.
7. **Laps** (`compare_laps`): the four events with the baseline aero and each CFD mode, grip held
   at the baseline calibration.

Conventions
-----------
CFD (``fsae_cfd``): x rearward from the front axle, y to the driver's right, z up; ride-height
change ``dz`` + = higher; roll + = right side down; sideslip + = velocity left of the nose;
corner radius + = left turn; moments about the front-axle ground point.

Lap sim (``fsae_vd``): turn-relative. ``zf, zr`` body drop at the axles (+ = lower), ``phi`` + =
leaning to the outside, ``beta`` + = velocity into the turn, ``kappa`` > 0; side force + toward the
turn centre; yaw moment about the CG + into the turn; x from the front axle + forward.

For a turn with sign s (+1 left, -1 right):
    dz_front = -zf, dz_rear = -zr, roll_deg = s phi, sideslip_deg = s beta, R = s / kappa
    Fy = -s F_y,  Mz = s (M_z - x_cg F_y),  roll moment loading the outside wheels = -s M_x
"""
from __future__ import annotations

import copy
import dataclasses as dc
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

from .aero import AeroModel, Component, DEG
from .config import CarConfig

ROOT = Path(__file__).resolve().parents[1]
CFD_ROOT = ROOT                                   # the fsae_cfd package sits next to fsae_vd
CFD_CONFIG = ROOT / "configs" / "ct17_cfd.yaml"
RESULTS = ROOT / "results" / "cfd_lapsim"
CACHE = ROOT / "results" / "cfd" / "runs"            # one folder per CFD run, reused by every report

COMPONENTS = ("front_wing", "rear_wing", "body")
WING_GROUPS = {"front_wing": "front_wing", "rear_wing": "rear_wing"}     # every other CFD group -> body
MODES = ("sensitivities", "calibrated", "absolute")
SENSITIVITIES = ("dClA_dh", "dClA_dalpha", "yaw_loss_10deg", "yaw_drag_10deg", "side_area", "induced_drag")


def cfd():
    """Import fsae_cfd (the package next to fsae_vd)."""
    if str(CFD_ROOT) not in sys.path:
        sys.path.insert(0, str(CFD_ROOT))
    import fsae_cfd
    return fsae_cfd


def component_of(group: str) -> str:
    return WING_GROUPS.get(group, "body")


# =============================================================================== states
@dc.dataclass
class State:
    """One CFD run: a name, its motion and what it is for ('fit' or 'check')."""
    name: str
    motion: object                         # fsae_cfd.VehicleMotion
    role: str = "fit"
    turn: int = 1                          # +1 left / straight, -1 right
    lap: dict = dc.field(default_factory=dict)   # lap-sim attitude the state came from (check states)

    def describe(self):
        return f"{self.name:>10s} [{self.role}] {self.motion.describe()}"


def fit_states(speed=20.1, heave=0.015, pitch=0.010, sideslip_deg=5.0) -> list:
    """Straight running at ``speed`` (45 mph: the coast-down speed) and one change of each attitude:
    heave (both axles ``heave`` lower), pitch (front ``pitch`` lower, rear ``pitch`` higher: nose
    down by 2 pitch / L) and body slip (``sideslip_deg``, velocity left of the nose)."""
    VM = cfd().VehicleMotion
    return [State("base", VM(speed=speed)),
            State("heave", VM(speed=speed, dz_front=-heave, dz_rear=-heave)),
            State("pitch", VM(speed=speed, dz_front=-pitch, dz_rear=pitch)),
            State("yaw", VM(speed=speed, sideslip_deg=sideslip_deg))]


def motion_from_state(st: dict, i=0, turn: int | None = None):
    """CFD motion at index ``i`` of a lap-sim vehicle state (``Vehicle.state`` output)."""
    VM = cfd().VehicleMotion
    g = lambda k: float(np.ravel(st[k])[i])
    v, ay = g("v"), g("ay")
    s = turn if turn is not None else (1 if ay >= 0 else -1)
    kappa = g("kappa")
    R = s / kappa if kappa > 1e-4 else None
    return VM(speed=v, corner_radius=R, sideslip_deg=s * np.degrees(g("beta")) if R else 0.0,
              dz_front=-g("heave_front"), dz_rear=-g("heave_rear"), roll_deg=s * g("roll_deg") if R else 0.0), s


def check_states(veh, laps: dict, n_corner=1, braking=True) -> list:
    """Hold-out states from the lap sim's own solution: the skidpad, the fastest autocross corners
    and the hardest braking point (pitch + heave at speed)."""
    out = []

    def add(name, lap, i):
        st = veh.state(np.array([lap.v[i]]), np.array([lap.ax[i]]), np.array([lap.ay[i]]))
        m, s = motion_from_state(st, 0)
        lapd = {"v": float(lap.v[i]), "ax": float(lap.ax[i]), "ay": float(lap.ay[i]),
                "zf": float(st["heave_front"][0]), "zr": float(st["heave_rear"][0]), "phi": float(st["phi"][0]),
                "beta": float(st["beta"][0]), "kappa": float(st["kappa"][0])}
        out.append(State(name, m, "check", s, lapd))

    sk = laps.get("skidpad")
    if sk is not None and hasattr(sk, "v"):
        add("skidpad", sk, int(np.argmax(np.abs(sk.ay))))
    ax_ = laps.get("autocross")
    if ax_ is not None and hasattr(ax_, "v"):
        v, ay = np.asarray(ax_.v), np.asarray(ax_.ay)
        score = np.abs(ay) * v ** 2 * (np.abs(ay) > 0.8 * np.abs(ay).max())   # fast, near the grip limit
        taken = []
        for i in np.argsort(score)[::-1]:
            if len(taken) >= n_corner:
                break
            if all(abs(ax_.s[i] - ax_.s[j]) > 20 for j in taken):
                taken.append(i)
                add(f"corner{len(taken)}", ax_, i)
        if braking:
            add("braking", ax_, int(np.argmin(ax_.ax)))
    return out


# =============================================================================== CFD runs
def _cad_fingerprint(config) -> dict:
    """SHA1 of every CAD STL the CFD config uses, so a re-exported part reruns the CFD."""
    import yaml
    if not Path(str(config)).exists():
        return {}
    g = yaml.safe_load(Path(config).read_text())
    cad = g.get("cad") or {}
    files = [Path(config).parent / s["file"] for s in g.get("stl_parts") or []]
    if cad.get("enabled", False):
        folder = Path(config).parent / cad.get("folder", ".")
        for a in cad.get("assemblies", []):
            files += [folder / f"{a.get('prefix', '')}{q['file']}{a.get('suffix', '.STL')}" for q in a["parts"]]
    fr = g.get("frame") or {}
    if fr.get("enabled", False) and fr.get("tubes"):     # spaceframe tube list (fsae_frame)
        files.append(Path(config).parent / fr["tubes"])
    return {f.name: hashlib.sha1(f.read_bytes()).hexdigest()[:12] for f in files if f.exists()}


def _key(config, motion, resolution, run_kw):
    text = Path(config).read_text() if Path(str(config)).exists() else json.dumps(config, default=str)
    m = {k: v for k, v in dc.asdict(motion).items() if k not in ("cg", "wheelbase", "track_front")}
    blob = {"cfg": text, "m": m, "res": resolution, "run": run_kw}
    cad = _cad_fingerprint(config)
    if cad:
        blob["cad"] = cad
    blob = json.dumps(blob, sort_keys=True, default=str)
    return hashlib.sha1(blob.encode()).hexdigest()[:10]


def preflight(states, resolution="quick", config=CFD_CONFIG, cache=CACHE, car_lengths=10.0, average_from=4.0, log=print):
    """Everything short of running: which states are cached for the geometry as it is now, whether
    every part is a closed solid and survives the grid, and how long the runs took last time.
    Returns {"states": DataFrame, "parts": DataFrame, "ok": bool, "minutes_per_state": float | None}."""
    import pandas as pd
    C = cfd()
    cache = Path(cache)
    run_kw = {"car_lengths": car_lengths, "average_from": average_from}
    rows = []
    for s in states:
        folder = cache / f"{s.name}_{resolution}_{_key(config, s.motion, resolution, run_kw)}"
        rows.append({"state": s.name, "role": s.role, "cached": (folder / "meta.json").exists(), "folder": folder.name,
                     "describe": s.describe()})
    st = pd.DataFrame(rows)
    # time per state from earlier runs at this resolution (any geometry)
    mins = []
    for f in cache.glob(f"*_{resolution}_*/meta.json"):
        tm = json.loads(f.read_text()).get("timings") or {}
        if "run_s" in tm:
            mins.append((tm["run_s"] + tm.get("build_s", 0.0)) / 60.0)
    case = C.CarCase(str(config), copy.deepcopy(states[0].motion), resolution=resolution, log=lambda m: None)
    t0 = time.perf_counter()
    case.build()
    geom = case.geom
    info = {v["part"]: v for v in case.voxel_info} if isinstance(case.voxel_info, list) else dict(case.voxel_info)
    prow = []
    for q in case.parts:
        v = info.get(q.name, {})
        prow.append({"part": q.name, "group": q.group, "closed": bool(q.mesh.is_watertight()), "volume_m3": float(q.mesh.volume()),
                     "voxel_volume_m3": v.get("voxel_volume_m3"), "open_columns": v.get("open_columns", 0)})
    parts = pd.DataFrame(prow)
    by = parts.groupby("group").agg(parts=("part", "count"), closed=("closed", "all"), volume_m3=("volume_m3", "sum"),
                                    open_columns=("open_columns", "sum"))
    ok = bool(parts["closed"].all() and (parts["volume_m3"] > 0).all() and (parts["open_columns"].fillna(0) <= 3).all())
    log(case.grid.summary())
    log(f"built and voxelised in {time.perf_counter() - t0:.0f} s; frontal area {geom.frontal_area():.3f} m^2 "
        f"(reference {geom.reference['area']:.3f})")
    log(by.round(4).to_string())
    todo = int((~st["cached"]).sum())
    per = float(np.median(mins)) if mins else None
    log(f"{len(st) - todo} of {len(st)} states cached for this geometry; {todo} to run"
        + (f", about {per:.0f} min each at '{resolution}' on this machine last time ({todo * per / 60:.1f} h one after another)"
           if per and todo else ""))
    return {"states": st, "parts": parts, "groups": by, "ok": ok, "minutes_per_state": per}


def run_states(states, resolution="quick", config=CFD_CONFIG, cache=CACHE, car_lengths=10.0, average_from=4.0,
               log=print, rerun=False, only_cached=False) -> dict:
    """Run (or load from the cache) every state. Returns {name: CarResult}."""
    C = cfd()
    cache = Path(cache)
    out = {}
    run_kw = {"car_lengths": car_lengths, "average_from": average_from}
    for k, s in enumerate(states):
        folder = cache / f"{s.name}_{resolution}_{_key(config, s.motion, resolution, run_kw)}"
        if (folder / "meta.json").exists() and not rerun:
            log(f"[{k + 1}/{len(states)}] cached   {s.describe()}")
            out[s.name] = C.CarResult.load(folder)
            continue
        if only_cached:
            log(f"[{k + 1}/{len(states)}] MISSING  {s.describe()}  (run tools/cfd_lapsim.py --stage cfd)")
            continue
        log(f"[{k + 1}/{len(states)}] running  {s.describe()}")
        t0 = time.perf_counter()
        motion = copy.deepcopy(s.motion)
        res = C.CarCase(str(config), motion, resolution=resolution, log=lambda m: None).run(car_lengths, average_from)
        res.save(folder)
        (folder / "state.json").write_text(json.dumps({"name": s.name, "role": s.role, "turn": s.turn, "lap": s.lap,
                                                       "motion": dc.asdict(s.motion)}, indent=1, default=float))
        out[s.name] = res
        c = res.coefficients()
        log(f"      done in {(time.perf_counter() - t0) / 60:.1f} min: ClA {c['ClA_m2']:.3f}  CdA {c['CdA_m2']:.3f}"
            f"  balance {c['front_balance']:.3f}")
    return out


# =============================================================================== loads
def _ci(x, w):
    from scipy import stats
    x = np.asarray(x)[w]
    nb = 8
    if len(x) < 2 * nb:
        return float(np.mean(x)), np.nan
    m = len(x) // nb
    b = x[: m * nb].reshape(nb, m).mean(1)
    return float(x.mean()), float(stats.t.ppf(0.975, nb - 1) * b.std(ddof=1) / np.sqrt(nb))


def component_loads(res, turn: int = 1) -> pd.DataFrame:
    """Time-averaged loads of the lap sim's components from one CFD run, in lap-sim conventions,
    as coefficients (force / q) with 95 % confidence half-widths (``*_ci``).

    Columns: F (downforce), D (drag), F_front / F_rear (axle loads incl. the drag moment), Fy (side
    force toward the turn centre), Mz (about the CG, + into the turn), Mroll (about the ground
    centreline, + loads the outside wheels), Mpitch (= M_y about the front-axle ground point)."""
    L = res.loads
    meta = res.meta
    xcg = float(meta["reference"]["cg"][0])
    wb = float(L.wheelbase)
    q = L.q
    w = L.window if L.window.any() else np.ones(len(L.t), bool)
    dt = L.dt[w]
    comp = np.array([component_of(g) for g in L.groups])
    s = turn
    rows = []
    for c in list(COMPONENTS) + ["total"]:
        sel = np.ones(len(comp), bool) if c == "total" else comp == c
        F = L.F[:, sel].sum(1)
        M = L.M[:, sel].sum(1)
        ser = {"F": -F[:, 2], "D": F[:, 0], "F_rear": M[:, 1] / wb, "Fy": -s * F[:, 1],
               "Mz": s * (M[:, 2] - xcg * F[:, 1]), "Mroll": -s * M[:, 0], "Mpitch": M[:, 1]}
        ser["F_front"] = ser["F"] - ser["F_rear"]
        r = {"component": c}
        for k, x in ser.items():
            m, ci = _ci(x, w)
            r[k] = m / q
            r[k + "_ci"] = ci / q
        rows.append(r)
    return pd.DataFrame(rows).set_index("component")


def drag_heights(config=CFD_CONFIG) -> dict:
    """Height of each component's drag line: centroid of its frontal projection (from the CFD geometry)."""
    car = cfd().build_car(str(config))
    num, den = {}, {}
    for p in car.parts:
        c = component_of(p.group)
        m = p.mesh
        tri = m.vertices[m.faces]
        n = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
        a = 0.5 * np.abs(n[:, 0])                  # projected (y-z) area of each facet
        num[c] = num.get(c, 0.0) + float((a * tri[:, :, 2].mean(1)).sum())
        den[c] = den.get(c, 0.0) + float(a.sum())
    return {c: num[c] / den[c] for c in num}


def cfd_geometry_info(config=CFD_CONFIG) -> dict:
    """Front-wing chord / clearance and spans from the CFD config (for the lap-sim components)."""
    import yaml
    g = yaml.safe_load(Path(config).read_text())
    fw, rw = g["front_wing"], g["rear_wing"]
    return {"front_wing": {"chord": float(fw["elements"][0]["chord"]), "ground_clearance": float(fw["ground_clearance"]),
                           "span": float(fw["span"])},
            "rear_wing": {"chord": float(rw["elements"][0]["chord"]), "ground_clearance": None, "span": float(rw["span"])},
            "body": {"chord": None, "ground_clearance": None, "span": 2 * 0.585},
            "wheelbase": float(g["reference"]["wheelbase"]), "cg": g["reference"]["cg"]}


# =============================================================================== fit
@dc.dataclass
class CFDFit:
    params: pd.DataFrame          # component x parameter (lap-sim units)
    ci: pd.DataFrame              # 95 % half-widths of the same
    resolved: pd.DataFrame        # bool: CFD change larger than its confidence interval
    loads: dict                   # state -> component_loads table
    states: dict                  # state -> State
    info: dict

    def table(self) -> pd.DataFrame:
        rows = []
        for c in self.params.index:
            for p in self.params.columns:
                rows.append({"component": c, "parameter": p, "CFD": self.params.loc[c, p],
                             "95% CI +/-": self.ci.loc[c, p], "resolved": bool(self.resolved.loc[c, p])})
        return pd.DataFrame(rows).set_index(["component", "parameter"])

    def save(self, folder):
        folder = Path(folder)
        folder.mkdir(parents=True, exist_ok=True)
        self.table().to_csv(folder / "cfd_fit.csv")
        pd.concat({k: v for k, v in self.loads.items()}, names=["state"]).to_csv(folder / "cfd_component_loads.csv")
        (folder / "cfd_fit_info.json").write_text(json.dumps(self.info, indent=1, default=float))
        return folder


def _ground_factor(h, chord, clearance, ge=None):
    if chord is None or clearance is None:
        return 1.0
    m = AeroModel([], 1.0, 0.5, 1.0, ge)
    return float(m.ground_factor(np.array([h]), Component("x", 1, 0, 0, 0, 1, chord=chord, ground_clearance=clearance))[0])


def fit_components(results: dict, states: dict, wheelbase=None, a=None, config=CFD_CONFIG, ground_effect=None,
                   alpha_lin_deg=3.0, induced_default=0.5, heights: dict | None = None, geometry: dict | None = None) -> CFDFit:
    """Fit the lap sim's component parameters from the fit states (base, heave, pitch, yaw).

    ``a`` is the CG-to-front-axle distance of the lap-sim car (for the pitch lever arm)."""
    gi = geometry or cfd_geometry_info(config)
    L = wheelbase or gi["wheelbase"]
    a = a if a is not None else float(gi["cg"][0])
    zl = heights or drag_heights(config)
    loads = {n: component_loads(r, states[n].turn) for n, r in results.items()}
    need = ("base", "heave", "pitch", "yaw")
    miss = [n for n in need if n not in loads]
    if miss:
        raise ValueError(f"fit states missing: {miss}")
    B, H, P, Y = (loads[n] for n in need)
    mh, mp, my = states["heave"].motion, states["pitch"].motion, states["yaw"].motion
    dh = -0.5 * (mh.dz_front + mh.dz_rear)                 # heave drop (lap convention, + = lower)
    zf_p, zr_p = -mp.dz_front, -mp.dz_rear
    pitch_deg = np.degrees((zf_p - zr_p) / L)
    dalpha = alpha_lin_deg * np.tanh(pitch_deg / alpha_lin_deg)
    beta = np.radians(my.sideslip_deg)
    yr = (beta / (10 * DEG)) ** 2
    params, cis, res_ = {}, {}, {}
    for c in COMPONENTS:
        g = gi[c]
        F0, D0 = B.loc[c, "F"], B.loc[c, "D"]
        eF0, eD0 = B.loc[c, "F_ci"], B.loc[c, "D_ci"]
        z = zl[c]
        # centre of pressure: M_y = z D + x_cfd F  ->  x (lap, + forward) = -(M_y - z D) / F
        x_cfd = (B.loc[c, "Mpitch"] - z * D0) / F0 if abs(F0) > 1e-6 else np.nan
        x = -x_cfd
        ex = abs(B.loc[c, "Mpitch_ci"] / F0) + abs(x_cfd) * abs(eF0 / F0) if abs(F0) > 1e-6 else np.nan
        # heave / pitch: F/q = (ClA + s_a dalpha + s_h z_loc) g(h), solved for (s_h, s_a)
        def cla_obs(T, zl_):
            gf = _ground_factor(g["ground_clearance"] - zl_ if g["ground_clearance"] else 0, g["chord"],
                                g["ground_clearance"], ground_effect)
            return T.loc[c, "F"] / gf, T.loc[c, "F_ci"] / gf
        zloc_p = zf_p + (zf_p - zr_p) * x / L if np.isfinite(x) else zf_p
        yh, eh = cla_obs(H, dh)
        yp, ep = cla_obs(P, zloc_p)
        A = np.array([[dh, 0.0], [zloc_p, dalpha]])
        rhs = np.array([yh - F0, yp - F0])
        s_h, s_a = np.linalg.solve(A, rhs)
        e_rhs = np.array([np.hypot(eh, eF0), np.hypot(ep, eF0)])
        Ainv = np.linalg.inv(A)
        e_sh, e_sa = np.sqrt((Ainv ** 2) @ (e_rhs ** 2))
        # yaw: downforce loss and drag rise at the slip angle, side-force slope
        fy = Y.loc[c, "F"] / F0 if abs(F0) > 1e-6 else 1.0
        yaw_loss = (1 - fy) / yr
        e_yl = np.hypot(Y.loc[c, "F_ci"], eF0 * fy) / abs(F0) / yr if abs(F0) > 1e-6 else np.nan
        # induced drag share from the heave / pitch drag changes: D/D0 = 1 - k + k (F/F0)^2
        num = den = 0.0
        for T in (H, P):
            r2 = (T.loc[c, "F"] / F0) ** 2 - 1 if abs(F0) > 1e-6 else 0.0
            num += r2 * (T.loc[c, "D"] / D0 - 1)
            den += r2 * r2
        ind_fitted = c != "body" and den > 0.03 ** 2
        ind = float(np.clip(num / den, 0, 1)) if ind_fitted else (0.0 if c == "body" else induced_default)
        e_ind = np.nan
        f_ind = 1 - ind + ind * fy ** 2
        yaw_drag = (Y.loc[c, "D"] / D0 / f_ind - 1) / yr
        e_yd = np.hypot(Y.loc[c, "D_ci"], eD0 * Y.loc[c, "D"] / D0) / D0 / yr
        side = Y.loc[c, "Fy"] / (-beta)              # Fy = -CyA b q (b = beta for straight slip)
        e_side = Y.loc[c, "Fy_ci"] / abs(beta)
        params[c] = {"ClA": F0, "CdA": D0, "x": x, "z": z, "dClA_dh": s_h, "dClA_dalpha": s_a,
                     "yaw_loss_10deg": yaw_loss, "yaw_drag_10deg": yaw_drag, "side_area": side, "induced_drag": ind}
        cis[c] = {"ClA": eF0, "CdA": eD0, "x": ex, "z": np.nan, "dClA_dh": e_sh, "dClA_dalpha": e_sa,
                  "yaw_loss_10deg": e_yl, "yaw_drag_10deg": e_yd, "side_area": e_side, "induced_drag": e_ind}
        res_[c] = {k: (bool(abs(params[c][k]) > cis[c][k]) if np.isfinite(cis[c][k]) else True) for k in params[c]}
        res_[c]["induced_drag"] = bool(ind_fitted)
    info = {"wheelbase": L, "a": a, "heave_m": dh, "pitch_deg": pitch_deg, "sideslip_deg": float(my.sideslip_deg),
            "speed": float(states["base"].motion.speed), "drag_heights": zl, "geometry": gi,
            "resolution": results["base"].meta.get("resolution"), "cells": results["base"].meta.get("cells"),
            "h": results["base"].meta.get("h")}
    return CFDFit(pd.DataFrame(params).T, pd.DataFrame(cis).T, pd.DataFrame(res_).T, loads, states, info)


# =============================================================================== into the lap sim
def _base_model(cfg: CarConfig):
    L = cfg.geometry.wheelbase
    a = L * (1 - cfg.mass.front_weight_fraction)
    return AeroModel.from_config(cfg, L, a), L, a


LIFT_SENS = ("dClA_dh", "dClA_dalpha", "yaw_loss_10deg", "yaw_drag_10deg", "induced_drag")
GROUND_SENS = ("dClA_dh", "dClA_dalpha", "induced_drag")


def trust(fit: CFDFit, cfg: CarConfig, min_cells=4.0, level=(0.6, 1.6)) -> pd.DataFrame:
    """Is each CFD sensitivity physically usable at this grid? (component x parameter: trusted, reason)

    * a wing whose CFD downforce is outside ``level`` x the baseline (binder / coast-down) value is in a
      different flow state (e.g. flaps stalled because the slot gaps are below a cell): its lift
      sensitivities do not transfer;
    * the front wing's ride-height / pitch response needs the gap under the wing resolved by at least
      ``min_cells`` cells of the ground band (h / 3)."""
    base = model_for(cfg)
    h = fit.info.get("h")
    gi = fit.info["geometry"]
    rows = []
    for c in COMPONENTS:
        for k in SENSITIVITIES:
            ok, why = True, ""
            if c != "body" and k in LIFT_SENS:
                b = base.get(c)
                r = fit.params.loc[c, "ClA"] / b.ClA if b is not None and abs(b.ClA) > 1e-9 else 1.0
                if not (level[0] <= r <= level[1]):
                    ok, why = False, f"CFD downforce {100 * r:.0f} % of the baseline: different flow state (stalled flaps at this grid)"
            if ok and c == "front_wing" and k in GROUND_SENS and h and gi[c]["ground_clearance"]:
                n = gi[c]["ground_clearance"] / (h / 3.0)
                if n < min_cells:
                    ok, why = False, f"gap under the wing only {n:.1f} cells (need {min_cells:.0f}): ground effect not grid-resolved"
            rows.append({"component": c, "parameter": k, "trusted": ok, "reason": why})
    return pd.DataFrame(rows).set_index(["component", "parameter"])


def apply_fit(cfg: CarConfig, fit: CFDFit, mode="sensitivities") -> tuple:
    """A copy of ``cfg`` with CFD aero. Returns (cfg, notes DataFrame of what changed)."""
    if mode not in MODES:
        raise ValueError(f"mode must be one of {MODES}")
    new = cfg.copy()
    A = new.aero
    P, R = fit.params, fit.resolved
    gi = fit.info["geometry"]
    base, L, a = _base_model(cfg)
    T = trust(fit, cfg)
    notes = []
    comps = {}
    for c in COMPONENTS:
        old = dict(cfg.aero.components.get(c, {}))
        bc = base.get(c)
        p = P.loc[c]
        if mode == "sensitivities":
            d = old
            for k in SENSITIVITIES:
                cfd_v = float(p[k])
                if k in ("dClA_dh", "dClA_dalpha") and c != "body":
                    # relative to the component's downforce (the CFD level may be off; the % change transfers)
                    cfd_v = cfd_v / p["ClA"] * bc.ClA if abs(p["ClA"]) > 1e-6 else 0.0
                if k == "yaw_loss_10deg":
                    cfd_v = max(cfd_v, 0.0)                     # the lap-sim model cannot gain downforce with yaw
                if k == "induced_drag" and c == "body":
                    continue
                prev = old.get(k, _DEFAULTS.get(k))
                if not bool(T.loc[(c, k), "trusted"]):
                    notes.append({"component": c, "parameter": k, "baseline": prev, "new": prev,
                                  "source": "baseline (" + T.loc[(c, k), "reason"] + ")"})
                elif bool(R.loc[c, k]):
                    d[k] = cfd_v
                    notes.append({"component": c, "parameter": k, "baseline": prev, "new": cfd_v, "source": "CFD"})
                else:
                    notes.append({"component": c, "parameter": k, "baseline": prev, "new": prev,
                                  "source": "baseline (CFD change within its confidence interval)"})
        else:
            d = {"ClA": float(p["ClA"]), "CdA": float(p["CdA"]), "x": float(p["x"]), "z": float(p["z"]),
                 "span": float(old.get("span", gi[c]["span"])), "chord": gi[c]["chord"],
                 "ground_clearance": gi[c]["ground_clearance"], "alpha_lin_deg": float(old.get("alpha_lin_deg", 3.0)),
                 "dClA_dh": float(p["dClA_dh"]), "dClA_dalpha": float(p["dClA_dalpha"]),
                 "yaw_loss_10deg": max(float(p["yaw_loss_10deg"]), 0.0), "yaw_drag_10deg": float(p["yaw_drag_10deg"]),
                 "side_area": float(p["side_area"]), "induced_drag": float(p["induced_drag"]),
                 "mass": float(old.get("mass", 0.0))}
            for k in ("drs_cl_ratio", "drs_cd_ratio"):
                if k in old:
                    d[k] = old[k]
            for k in ("ClA", "CdA", "x", "z") + SENSITIVITIES:
                notes.append({"component": c, "parameter": k, "baseline": _baseline_value(old, bc, k),
                              "new": d[k], "source": "CFD"})
        comps[c] = d
    A.components = comps
    A.model = "components"
    if mode == "absolute":
        A.calib_ClA = A.calib_CdA = None
        notes.append({"component": "car", "parameter": "calibration", "baseline": "coast-down",
                      "new": "none", "source": "CFD absolute"})
    elif mode == "calibrated":
        notes.append({"component": "car", "parameter": "calibration", "baseline": "coast-down",
                      "new": "coast-down totals, CFD split / balance", "source": ""})
    return new, pd.DataFrame(notes)


_DEFAULTS = {f.name: f.default for f in dc.fields(Component) if f.default is not dc.MISSING}


def _baseline_value(old, bc, k):
    if bc is None:
        return old.get(k)
    v = getattr(bc, k, None)
    return v


def model_for(cfg: CarConfig) -> AeroModel:
    """The (uncalibrated) component aero model a config gives, for comparisons at fixed attitude."""
    return _base_model(cfg)[0]


def compare_model(veh_or_model, results: dict, states: dict, rho=None) -> pd.DataFrame:
    """The lap sim's aero model against CFD at every state, as coefficients (force / q).

    ``veh_or_model``: a Vehicle (its calibrated aero model) or an AeroModel."""
    AM = getattr(veh_or_model, "aero_model", veh_or_model)
    rows = []
    for n, res in results.items():
        s = states[n]
        m = s.motion
        cl = component_loads(res, s.turn)
        L = AM.L
        if s.lap:
            zf, zr, phi, beta, kappa, v = (s.lap[k] for k in ("zf", "zr", "phi", "beta", "kappa", "v"))
        else:
            v = m.speed
            zf, zr = -m.dz_front, -m.dz_rear
            phi = np.radians(m.roll_deg) * s.turn
            beta = np.radians(m.sideslip_deg) * s.turn
            kappa = abs(m.yaw_rate) / m.speed if m.yaw_rate else 0.0
        e = AM.evaluate(np.array([v]), zf, zr, phi, beta, kappa, detail=True)
        q = float(e["q"][0])
        comp = e["comps"]
        mdl = {"F": e["F"][0] / q, "D": e["D"][0] / q, "F_front": e["F_front"][0] / q, "F_rear": e["F_rear"][0] / q,
               "Fy": e["Fy"][0] / q, "Mz": e["Mz"][0] / q, "Mroll": (e["Mx"][0] - e["Fy_z"][0]) / q}
        for k, val in mdl.items():
            rows.append({"state": n, "role": s.role, "component": "total", "quantity": k, "CFD": cl.loc["total", k],
                         "CFD 95% CI": cl.loc["total", k + "_ci"], "model": val})
        for c in COMPONENTS:
            if c in comp:
                for k in ("F", "D", "Fy"):
                    rows.append({"state": n, "role": s.role, "component": c, "quantity": k, "CFD": cl.loc[c, k],
                                 "CFD 95% CI": cl.loc[c, k + "_ci"], "model": float(np.ravel(comp[c][k])[0]) / q})
    df = pd.DataFrame(rows)
    df["model - CFD"] = df["model"] - df["CFD"]
    ref = df[(df.component == "total") & (df.quantity == "F")].set_index("state")["CFD"].abs()
    df["error / total ClA"] = df["model - CFD"] / df["state"].map(ref)
    df["within CI"] = df["model - CFD"].abs() <= df["CFD 95% CI"]
    return df


def change_table(results: dict, states: dict, base="base") -> pd.DataFrame:
    """Change of every coefficient from the base state, per state and component (CFD only)."""
    b = component_loads(results[base], states[base].turn)
    rows = []
    for n, r in results.items():
        if n == base:
            continue
        t = component_loads(r, states[n].turn)
        for c in t.index:
            for k in ("F", "D", "F_front", "Fy"):
                d = t.loc[c, k] - b.loc[c, k]
                e = np.hypot(t.loc[c, k + "_ci"], b.loc[c, k + "_ci"])
                rows.append({"state": n, "component": c, "quantity": k, "change": d, "95% CI": e,
                             "resolved": abs(d) > e})
    return pd.DataFrame(rows)


# =============================================================================== laps
def compare_laps(cfgs: dict, ptc=None, tracks=None) -> tuple:
    """Run the events for each config. Returns (table, {name: event results})."""
    from . import aero_study as AS
    rows, out = {}, {}
    for name, c in cfgs.items():
        r = AS.run(c, ptc, tracks)
        out[name] = r
        rows[name] = AS.score(r)
    df = pd.DataFrame(rows).T
    return df, out


def aero_summary(cfgs: dict, ptc=None, speed=20.1) -> pd.DataFrame:
    """Whole-car aero each config gives in the lap sim (calibrated vehicle, equilibrium ride height)."""
    rows = {}
    for name, c in cfgs.items():
        if ptc is not None:
            import fsae_pt as fp
            veh = fp.PTVehicle(c, ptc)
        else:
            from .vehicle import Vehicle
            veh = Vehicle(c)
        st = veh.state(np.array([speed]), np.zeros(1), np.zeros(1))
        q = 0.5 * veh.rho * speed ** 2
        rows[name] = {"ClA": float(st["downforce"][0] / q), "CdA": float(st["drag"][0] / q),
                      "front-axle share": float(st["aero_front"][0] / st["downforce"][0]),
                      "CoP balance": float(np.ravel(st["aero_balance"])[0]),
                      "pitch [deg]": float(st["pitch_deg"][0])}
    return pd.DataFrame(rows).T


def new_run_folder(tag="") -> Path:
    """results/cfd_lapsim/<date_time>[_tag]/, with results/cfd_lapsim/latest pointing at it (as the
    other notebooks do through notebook_utils)."""
    stamp = time.strftime("%Y-%m-%d_%H-%M-%S") + (f"_{tag}" if tag else "")
    try:
        from .notebook_utils import Run
        return Run("cfd_lapsim", stamp=stamp).dir
    except ImportError:
        f = RESULTS / stamp
        f.mkdir(parents=True, exist_ok=True)
        return f


# =============================================================================== plots
def plot_check(df: pd.DataFrame, model_name=None, ax=None):
    """Parity plot: lap-sim aero model vs CFD (coefficients) at every state; error bars = CFD 95 % CI."""
    import matplotlib.pyplot as plt
    d = df if model_name is None else df[df["aero model"] == model_name]
    d = d[d.component == "total"]
    if ax is None:
        _, ax = plt.subplots(figsize=(6.2, 6))
    marks = {"F": "o", "D": "s", "F_front": "^", "F_rear": "v", "Fy": "D", "Mz": "P", "Mroll": "X"}
    cols = {"fit": "C0", "check": "C3"}
    for (role, qn), g in d.groupby(["role", "quantity"]):
        ax.errorbar(g["CFD"], g["model"], xerr=g["CFD 95% CI"], fmt=marks.get(qn, "o"), color=cols.get(role, "k"),
                    ms=6, capsize=2, label=f"{qn} ({role})")
    lim = np.nanmax(np.abs(np.r_[d["CFD"], d["model"]])) * 1.1
    ax.plot([-lim, lim], [-lim, lim], "k-", lw=0.8)
    ax.set_xlim(-0.3 * lim, lim); ax.set_ylim(-0.3 * lim, lim)
    ax.set_xlabel("CFD  [force / q, m^2; moment / q, m^3]"); ax.set_ylabel("lap-sim aero model")
    ax.set_title(model_name or "aero model vs CFD")
    ax.legend(fontsize=7, ncol=2)
    ax.grid(alpha=0.3)
    return ax


def plot_changes(ct: pd.DataFrame, quantity="F", ax=None):
    """Change of each component's coefficient from the base state, with its 95 % CI."""
    import matplotlib.pyplot as plt
    d = ct[ct.quantity == quantity]
    states = list(dict.fromkeys(d.state))
    comps = list(dict.fromkeys(d.component))
    if ax is None:
        _, ax = plt.subplots(figsize=(9, 4))
    w = 0.8 / len(comps)
    for j, c in enumerate(comps):
        g = d[d.component == c].set_index("state").reindex(states)
        ax.bar(np.arange(len(states)) + (j - (len(comps) - 1) / 2) * w, g["change"], w, yerr=g["95% CI"], capsize=3,
               label=c)
    ax.axhline(0, color="k", lw=0.8)
    ax.set_xticks(range(len(states)), states)
    ax.set_ylabel(f"change of {quantity} / q from base [m^2]")
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3, axis="y")
    return ax


def plot_events(tab: pd.DataFrame, base_name=None, ax=None):
    """Points change of each aero model against the baseline, per event."""
    import matplotlib.pyplot as plt
    base_name = base_name or tab.index[0]
    cols = [c for c in tab.columns if c.endswith("_pts")]
    d = tab[cols].subtract(tab.loc[base_name, cols], axis=1).drop(index=base_name)
    if ax is None:
        _, ax = plt.subplots(figsize=(9, 4))
    w = 0.8 / max(len(d), 1)
    for j, (n, r) in enumerate(d.iterrows()):
        ax.bar(np.arange(len(cols)) + (j - (len(d) - 1) / 2) * w, r.values, w, label=n)
    ax.axhline(0, color="k", lw=0.8)
    ax.set_xticks(range(len(cols)), [c.replace("_pts", "") for c in cols], rotation=0)
    ax.set_ylabel(f"points vs {base_name}")
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3, axis="y")
    return ax


def plot_lap_channels(vehs: dict, laps: dict, event="autocross", channels=("v", "downforce", "front_share", "rear_wing_yaw_deg")):
    """Lap channels of one event for several aero models (aero_study.lap_channels)."""
    import matplotlib.pyplot as plt
    from . import aero_study as AS
    fig, axs = plt.subplots(len(channels), 1, figsize=(11, 2.3 * len(channels)), sharex=True)
    for name, res in laps.items():
        lap = res.laps.get(event)
        if lap is None:
            continue
        ch = AS.lap_channels(vehs[name], lap)
        for ax, k in zip(axs, channels):
            if k in ch:
                ax.plot(ch.s, ch[k], lw=1, label=name)
    for ax, k in zip(axs, channels):
        ax.set_ylabel(k, fontsize=8)
        ax.grid(alpha=0.3)
    axs[0].legend(fontsize=7, ncol=2)
    axs[-1].set_xlabel("distance [m]")
    fig.suptitle(f"{event}: lap channels per aero model")
    fig.tight_layout()
    return fig
