"""Suspension and steering kinematics (front view, side view, steering).

Two ways to describe each axle's front-view geometry:
  * hardpoints given  -> instant centre, roll centre, swing-arm length and the
    camber / roll-centre curves over wheel travel are solved from the linkage;
  * otherwise         -> roll-centre height + FVSA length are used directly
    (the white-paper values), which fixes the instant centre.
"""
from __future__ import annotations

import numpy as np

from .config import Axle, MissingDataError


# ------------------------------------------------------------ front view
def instant_centre_from_rc(rc_height, fvsa, half_track):
    """IC position (y from car centreline, + toward the far side; z) for the left
    wheel, on the line contact-patch -> roll centre, a horizontal distance fvsa
    inboard of the patch."""
    y = -half_track + fvsa
    z = fvsa * rc_height / half_track
    return y, z


def _intersect(p1, p2, p3, p4):
    """Intersection of line p1p2 with line p3p4 (2-D)."""
    p1, p2, p3, p4 = map(np.asarray, (p1, p2, p3, p4))
    d1, d2 = p2 - p1, p4 - p3
    A = np.array([d1, -d2]).T
    if abs(np.linalg.det(A)) < 1e-12:
        return np.array([np.inf, np.inf])
    t = np.linalg.solve(A, p3 - p1)
    return p1 + t[0] * d1


def front_view_from_hardpoints(hp: dict, half_track: float):
    """Instant centre, roll-centre height and FVSA from front-view hardpoints.

    hp: {'UBJ','LBJ','UI','LI'} as [y, z] with y measured from the car
    centreline, positive outboard on the left side; optional 'CP' (contact patch).
    """
    # convert to a frame with y positive toward the car centreline from the left wheel
    P = {k: np.array([-v[0], v[1]], float) for k, v in hp.items()}
    cp = P.get("CP", np.array([-half_track, 0.0]))
    ic = _intersect(P["UBJ"], P["UI"], P["LBJ"], P["LI"])
    if not np.isfinite(ic).all():                      # parallel arms: IC at infinity
        return {"ic": ic, "rc_height": cp[1], "fvsa": np.inf}
    rc = _intersect(cp, ic, np.array([0, 0]), np.array([0, 1]))
    return {"ic": ic, "rc_height": float(rc[1]), "fvsa": float(np.hypot(*(ic - cp)))}


def _circle_intersection(c0, r0, c1, r1, pick_near):
    d = np.linalg.norm(c1 - c0)
    a = (r0 ** 2 - r1 ** 2 + d ** 2) / (2 * d)
    h = np.sqrt(max(r0 ** 2 - a ** 2, 0.0))
    m = c0 + a * (c1 - c0) / d
    perp = np.array([-(c1 - c0)[1], (c1 - c0)[0]]) / d
    s1, s2 = m + h * perp, m - h * perp
    return s1 if np.linalg.norm(s1 - pick_near) < np.linalg.norm(s2 - pick_near) else s2


def sweep_hardpoints(hp: dict, half_track: float, travel=np.linspace(-0.0254, 0.0254, 21)):
    """Solve the front-view four-bar over wheel travel (+ = bump).
    Returns travel, camber change [deg], roll-centre height, track change."""
    P = {k: np.array([-v[0], v[1]], float) for k, v in hp.items()}
    cp0 = P.get("CP", np.array([-half_track, 0.0]))
    LI, UI, LBJ0, UBJ0 = P["LI"], P["UI"], P["LBJ"], P["UBJ"]
    rl, ru, ku = np.linalg.norm(LBJ0 - LI), np.linalg.norm(UBJ0 - UI), np.linalg.norm(UBJ0 - LBJ0)
    up0 = UBJ0 - LBJ0
    cp_local = cp0 - LBJ0
    th0 = np.arctan2(*(LBJ0 - LI)[::-1])
    out = {"travel": [], "camber_deg": [], "rc_height": [], "track_change": []}
    for z in travel:
        # rotate lower arm until the contact point (approx) has moved z vertically
        th = th0
        for _ in range(30):
            LBJ = LI + rl * np.array([np.cos(th), np.sin(th)])
            UBJ = _circle_intersection(LBJ, ku, UI, ru, UBJ0)
            ang = np.arctan2(*(UBJ - LBJ)[::-1]) - np.arctan2(*up0[::-1])
            c, s = np.cos(ang), np.sin(ang)
            cp = LBJ + np.array([[c, -s], [s, c]]) @ cp_local
            err = (cp[1] - cp0[1]) - z
            if abs(err) < 1e-7:
                break
            th -= err / (rl * np.cos(th) + 1e-9) * 0.9
        ic = _intersect(UBJ, UI, LBJ, LI)
        rc = _intersect(cp, ic, np.array([0, 0]), np.array([0, 1]))
        out["travel"].append(z)
        out["camber_deg"].append(np.degrees(ang))
        out["rc_height"].append(rc[1])
        out["track_change"].append(-(cp[0] - cp0[0]))
    return {k: np.array(v) for k, v in out.items()}


def axle_front_view(ax: Axle, half_track: float):
    """Front-view quantities for one axle, from hardpoints if given."""
    if ax.hardpoints:
        r = front_view_from_hardpoints(ax.hardpoints, half_track)
        return {"rc_height": r["rc_height"], "fvsa": r["fvsa"], "ic": r["ic"], "source": "hardpoints"}
    if ax.roll_center_height is None or ax.fvsa_length is None:
        raise MissingDataError("axle needs roll_center_height and fvsa_length, or hardpoints")
    ic = instant_centre_from_rc(ax.roll_center_height, ax.fvsa_length, half_track)
    return {"rc_height": ax.roll_center_height, "fvsa": ax.fvsa_length, "ic": ic, "source": "rc+fvsa"}


def camber_gain_per_m(fvsa):
    """Camber change relative to the body per metre of bump [rad/m] (negative in bump)."""
    return -1.0 / fvsa


def jacking_ratio(rc_height, half_track):
    return rc_height / half_track


# ------------------------------------------------------------ side view
def anti_angles(anti_dive, anti_lift, anti_squat, h, L, front_brake):
    """Side-view line angles [deg] as in the SolidWorks equations (B19)."""
    hl = h / L
    return {"front_phi": np.degrees(np.arctan(anti_dive * hl / front_brake)),
            "rear_phi": np.degrees(np.arctan(anti_lift * hl / (1 - front_brake))),
            "rear_theta": np.degrees(np.arctan(anti_squat * hl))}


# ------------------------------------------------------------ steering
def ackermann_angles(R, L, t, fraction):
    """Inner/outer road-wheel angles [rad] at turn radius R for an Ackermann fraction."""
    do = np.arctan(L / (R + t / 2))
    di_ideal = np.arctan(L / (R - t / 2))
    di = do + fraction * (di_ideal - do)
    return di, do


def steer_camber_deg(delta_rad, caster_deg, kpi_deg):
    """Turn-relative camber change of the (outside, inside) front wheel when steered by delta.
    Caster leans both tops toward the turn (helpful, negative); KPI leans both tops
    outward relative to the car, which hurts the outside wheel and helps the inside."""
    nu, sig = np.radians(caster_deg), np.radians(kpi_deg)
    cas = -np.degrees(nu * np.sin(delta_rad))
    kpi = np.degrees(sig * (1 - np.cos(delta_rad)))
    return cas + kpi, cas - kpi


def steering_effort(tie_rod_force, pinion_radius, rack_eff, ujoint_eff, wheel_radius):
    """Driver hand force [N] for a given tie-rod force (B55/B58 method, corrected)."""
    tp = tie_rod_force * pinion_radius / rack_eff
    tu = tp / ujoint_eff
    return {"pinion_torque": tp, "column_torque": tu, "hand_force": tu / wheel_radius}


def ujoint_max_phase_deg(beta_deg, n=20000):
    th = np.linspace(1e-6, np.pi / 2 - 1e-6, n)
    th2 = np.arctan(np.cos(np.radians(beta_deg)) * np.tan(th))
    return float(np.degrees(np.max(np.abs(th2 - th))))
