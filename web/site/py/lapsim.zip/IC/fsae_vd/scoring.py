"""FSAE dynamic-event scoring.

Formulas follow the FSAE rules (Tmax = k * Tmin). They change between rule
years: check SCORING against the rules for the competition you simulate.
The Michigan 2026 maxima (accel 100, skidpad 75, autocross 125, endurance 275)
are consistent with these constants.
"""
from __future__ import annotations

import numpy as np

SCORING = {
    #  event:       (max_points_variable, min_points, Tmax/Tmin, exponent)
    "acceleration": (95.5, 4.5, 1.5, 1),
    "skidpad":      (71.5, 3.5, 1.25, 2),
    "autocross":    (118.5, 6.5, 1.45, 1),
    "endurance":    (250.0, 25.0, 1.45, 1),
}


def points(event: str, t: float, tmin: float) -> float:
    A, B, k, p = SCORING[event]
    tmax = k * tmin
    if t >= tmax:
        return B if event != "endurance" else B   # finishing points
    t = max(t, tmin)
    return A * ((tmax / t) ** p - 1) / (k ** p - 1) + B


def infer_tmin(event: str, score: float, t: float) -> float:
    """Back out the best time Tmin from a team's score and time (same formula).
    Example: Michigan 2026 skidpad, 70 pts at 5.159 s -> Tmin ~ 5.09 s."""
    A, B, k, p = SCORING[event]
    if score >= A + B - 1e-9:
        return t
    r = ((score - B) * (k ** p - 1) / A + 1) ** (1 / p)   # r = Tmax/t
    return r * t / k
