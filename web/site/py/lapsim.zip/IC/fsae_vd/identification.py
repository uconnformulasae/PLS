"""Identify model parameters from measured data.

All fits use robust losses (soft-L1 / Huber) or upper-quantile envelopes so
that residual outliers in the cleaned data cannot drag the estimates, and each
returns its parameter uncertainty (bootstrap or Jacobian based).
"""
from __future__ import annotations

import dataclasses as dc

import numpy as np
import pandas as pd
from scipy import optimize

from .config import CarConfig, MissingDataError
from .units import G0


# ------------------------------------------------------------ TTC tire data
def fit_ttc(ttc: dict, fz0: float = 1000.0, sa_peak_range=(3.0, 15.0), ia_sign: float = -1.0,
            n_boot: int = 200, seed: int = 0):
    """Fit peak lateral friction mu(Fz, gamma) and cornering stiffness from TTC data.

    1. Data are grouped by load (clusters of FZ) and inclination (rounded IA).
    2. In each group the peak |FY| is the 98th percentile of |FY| for
       |SA| in ``sa_peak_range`` (robust to single spikes).
    3. mu = Fpeak/FZ is fitted to mu0 + mu_fz*(FZ - fz0), times
       (1 - k_gamma*(gamma - gamma_opt)^2), with soft-L1 loss.
    4. Cornering stiffness per load = robust slope of FY vs SA for |SA| < 1.5 deg.
    ``ia_sign`` converts TTC IA into the turn-relative convention (negative =
    top leaning toward the turn) - check against your TTC round's sign convention.
    """
    SA, FY, FZ, IA = (np.asarray(ttc[k], float) for k in ("SA", "FY", "FZ", "IA"))
    ok = np.isfinite(SA + FY + FZ + IA) & (FZ > 50)
    SA, FY, FZ, IA = SA[ok], FY[ok], FZ[ok], IA[ok]
    # load clusters: histogram peaks of FZ
    hist, edges = np.histogram(FZ, bins=60)
    centres = 0.5 * (edges[1:] + edges[:-1])
    peaks = [centres[i] for i in range(1, len(hist) - 1)
             if hist[i] >= hist[i - 1] and hist[i] >= hist[i + 1] and hist[i] > 0.02 * hist.sum()]
    groups = []
    for fzc in peaks:
        selz = np.abs(FZ - fzc) < 0.08 * fzc
        for ia in np.unique(np.round(IA[selz])):
            sel = selz & (np.round(IA) == ia) & (np.abs(SA) >= sa_peak_range[0]) & (np.abs(SA) <= sa_peak_range[1])
            if sel.sum() < 30:
                continue
            fpk = np.percentile(np.abs(FY[sel]), 98)
            groups.append((np.median(FZ[sel]), ia_sign * ia, fpk))
    if len(groups) < 3:
        raise ValueError("TTC fit needs at least 3 load/IA groups with slip sweeps")
    G = np.array(groups)
    fz, gam, fpk = G[:, 0], G[:, 1], G[:, 2]
    mu = fpk / fz
    has_camber = np.unique(np.round(gam)).size >= 3

    def model(p, fz, gam):
        m = p[0] + p[1] * (fz - fz0)
        if has_camber:
            m = m * (1 - p[3] * (gam - p[2]) ** 2)
        return m

    p0 = [np.median(mu), -1e-4, -1.0, 0.002] if has_camber else [np.median(mu), -1e-4]
    res = optimize.least_squares(lambda p: model(p, fz, gam) - mu, p0, loss="soft_l1", f_scale=0.05)
    rng = np.random.default_rng(seed)
    boots = []
    for _ in range(n_boot):
        i = rng.integers(0, len(mu), len(mu))
        try:
            boots.append(optimize.least_squares(lambda p: model(p, fz[i], gam[i]) - mu[i], res.x,
                                                loss="soft_l1", f_scale=0.05).x)
        except Exception:
            pass
    sd = np.std(boots, axis=0) if boots else np.full_like(res.x, np.nan)
    # cornering stiffness per load
    lin = np.abs(SA) < 1.5
    cpl = []
    for fzc in peaks:
        sel = lin & (np.abs(FZ - fzc) < 0.08 * fzc)
        if sel.sum() > 30:
            slope = optimize.least_squares(lambda c: c[0] * np.radians(SA[sel]) - np.abs(FY[sel]) * np.sign(SA[sel]),
                                           [1e4], loss="soft_l1").x[0]
            cpl.append(abs(slope) / np.median(FZ[sel]))
    out = {"mu0": res.x[0], "mu_fz": res.x[1], "fz0": fz0, "mu0_sd": sd[0], "mu_fz_sd": sd[1],
           "cornering_stiffness_per_load": float(np.median(cpl)) if cpl else None, "groups": G}
    if has_camber:
        out.update({"gamma_opt_deg": res.x[2], "k_gamma": res.x[3], "gamma_opt_sd": sd[2], "k_gamma_sd": sd[3]})
    return out


def apply_tire_fit(cfg: CarConfig, fit: dict):
    for k in ("mu0", "mu_fz", "fz0", "gamma_opt_deg", "k_gamma", "cornering_stiffness_per_load"):
        if fit.get(k) is not None:
            setattr(cfg.tires, k, float(fit[k]))
    return cfg


def tire_from_two_points(fz1, f1, fz2, f2, fz0=1000.0):
    """Linear load sensitivity through two (load, peak force) points, e.g. read
    from a published Fy-SA plot. Returns (mu0, mu_fz)."""
    m1, m2 = f1 / fz1, f2 / fz2
    mu_fz = (m2 - m1) / (fz2 - fz1)
    return m1 + mu_fz * (fz0 - fz1), mu_fz


# ------------------------------------------------------------ logged g-g
def gg_points(plog, v_min=5.0):
    d = plog.df
    sel = (d["v"] > v_min) if "v" in d else np.ones(len(d), bool)
    return d.loc[sel, ["v", "ax", "ay"]].dropna()


def gg_envelope(plog, n_angle=36, q=0.99, v_bins=None):
    """Robust g-g envelope: in angular sectors (and optional speed bins) the
    q-quantile of the combined acceleration magnitude. Using a high quantile
    rather than the maximum makes the envelope immune to the few residual
    spikes that survive cleaning."""
    p = gg_points(plog)
    ang = np.arctan2(p["ax"], p["ay"])
    r = np.hypot(p["ax"], p["ay"])
    edges = np.linspace(-np.pi, np.pi, n_angle + 1)
    rows = []
    vb = v_bins if v_bins is not None else [p["v"].min(), p["v"].max() + 1]
    for i in range(len(vb) - 1):
        sv = (p["v"] >= vb[i]) & (p["v"] < vb[i + 1])
        for j in range(n_angle):
            s = sv & (ang >= edges[j]) & (ang < edges[j + 1])
            if s.sum() >= 20:
                rq = np.quantile(r[s], q)
                th = 0.5 * (edges[j] + edges[j + 1])
                rows.append({"v_lo": vb[i], "v_hi": vb[i + 1], "angle": th, "ax": rq * np.sin(th),
                             "ay": rq * np.cos(th), "r": rq, "n": int(s.sum())})
    return pd.DataFrame(rows)


def lateral_envelope(plog, v_bins=np.arange(5, 31, 2.5), ax_tol=0.15 * G0, q=0.98):
    """Lateral limit vs speed from near-pure cornering samples (|ax| < ax_tol)."""
    p = gg_points(plog)
    p = p[np.abs(p["ax"]) < ax_tol]
    rows = []
    for a, b in zip(v_bins[:-1], v_bins[1:]):
        s = (p["v"] >= a) & (p["v"] < b)
        if s.sum() >= 30:
            rows.append({"v": 0.5 * (a + b), "ay_env": np.quantile(np.abs(p.loc[s, "ay"]), q), "n": int(s.sum())})
    return pd.DataFrame(rows)


def calibrate_grip(cfg: CarConfig, env: pd.DataFrame, fit_load_sensitivity=False, n_boot=30, seed=0):
    """Scale tire grip (lambda_mu, optionally mu_fz) so that the vehicle model's
    lateral limit matches the logged lateral envelope.

    The cost is a robust (soft-L1) sum over speed bins weighted by sqrt(n). The
    model output comes from a bisection and can plateau (e.g. wheel-lift
    limited), so a derivative-free bounded search is used; the uncertainty is
    the spread of a bootstrap over speed bins."""
    from .vehicle import Vehicle
    if cfg.tires.model != "mf61" and cfg.tires.mu0 is None:
        raise MissingDataError("calibrate_grip needs a starting tire (mu0, mu_fz, or an MF 6.1 .tir)")
    v_all, y_all, w_all = env["v"].to_numpy(), env["ay_env"].to_numpy(), np.sqrt(env["n"].to_numpy())

    def model(p, v):
        c = cfg.copy()
        c.tires.lambda_mu = float(p[0])
        if fit_load_sensitivity:
            c.tires.mu_fz = float(p[1])
        return Vehicle(c).ay_max(v)

    def cost(p, idx):
        r = w_all[idx] * (model(p, v_all[idx]) - y_all[idx]) / 0.5
        return float(np.sum(2 * (np.sqrt(1 + r ** 2) - 1)))       # soft-L1

    def solve(idx):
        if fit_load_sensitivity:
            r = optimize.minimize(lambda p: cost(p, idx), [0.7, cfg.tires.mu_fz], method="Nelder-Mead",
                                  options={"xatol": 1e-4, "fatol": 1e-6, "maxiter": 400})
            return r.x
        r = optimize.minimize_scalar(lambda l: cost([l], idx), bounds=(0.2, 2.0), method="bounded",
                                     options={"xatol": 1e-4})
        return np.array([r.x])

    idx = np.arange(len(v_all))
    x = solve(idx)
    rng = np.random.default_rng(seed)
    boots = [solve(rng.integers(0, len(idx), len(idx))) for _ in range(n_boot)] if len(idx) > 2 else []
    sd = np.std(boots, axis=0) if boots else np.full_like(x, np.nan)
    out = cfg.copy()
    out.tires.lambda_mu = float(x[0])
    if fit_load_sensitivity:
        out.tires.mu_fz = float(x[1])
    err = model(x, v_all) - y_all
    info = {"lambda_mu": float(x[0]), "lambda_mu_sd": float(sd[0]), "rms_error_ms2": float(np.sqrt(np.mean(err ** 2)))}
    if fit_load_sensitivity:
        info.update({"mu_fz": float(x[1]), "mu_fz_sd": float(sd[1])})
    return out, info


# ------------------------------------------------------------ coast-down
def coastdown_mask(plog, throttle_max=2.0, brake_max=2e5, ay_max=0.1 * G0, v_min=6.0):
    d = plog.df
    m = (d["v"] > v_min) & (d["ay"].abs() < ay_max)
    if "throttle" in d:
        m &= d["throttle"] < throttle_max
    else:
        raise MissingDataError("coast-down fit needs a throttle channel (or pass your own mask)")
    for b in ("brake_f", "brake_r"):
        if b in d:
            m &= d[b] < brake_max
    return m.to_numpy()


def fit_coastdown(plog, cfg: CarConfig, mask=None):
    """Fit CdA and Crr from coasting:  m*ax = -(0.5*rho*CdA*v^2 + Crr*(m*g + downforce)).
    Linear in the unknowns; solved with a Huber loss."""
    d = plog.df
    mask = coastdown_mask(plog) if mask is None else mask
    # deceleration from the fused, GPS-anchored speed rather than the accelerometer: a slowly
    # drifting accelerometer bias (or pitch) would otherwise trade off directly against Crr
    from .processing import savgol_derivative
    dvdt = savgol_derivative(d["v"].to_numpy(), plog.fs, 1.0)
    v, ax = d["v"].to_numpy()[mask], dvdt[mask]
    m = cfg.mass.total
    cla = cfg.aero.cla() or (0, 0)
    q = 0.5 * cfg.aero.rho * v ** 2
    N = m * G0 + (cla[0] + cla[1]) * q
    A = np.column_stack([q, N])
    y = -m * ax
    r = optimize.least_squares(lambda p: A @ p - y, [1.0, 0.015], loss="huber", f_scale=20.0,
                               bounds=([0, 0], [5, 0.1]))
    cov = np.linalg.pinv(r.jac.T @ r.jac) * np.sum(r.fun ** 2) / max(len(y) - 2, 1)
    return {"CdA": r.x[0], "Crr": r.x[1], "CdA_sd": float(np.sqrt(cov[0, 0])),
            "Crr_sd": float(np.sqrt(cov[1, 1])), "n": int(mask.sum())}


# ------------------------------------------------------------ powertrain
def fit_power(plog, cfg: CarConfig, throttle_min=95.0, q=0.5, v_bins=np.arange(2, 36, 1.5)):
    """Tractive force from full-throttle running:
    F = m*ax + drag + rolling, median per speed bin (at full throttle every sample is at the
    powertrain/traction limit, so the median is unbiased; an upper quantile would pick up
    accelerometer noise and over-estimate power), fitted to
    F(v) = min(F_max, P_max/v) (traction/torque-limited then power-limited)."""
    from .vehicle import Vehicle
    d = plog.df
    sel = d["v"] > 1.0
    if "throttle" in d:
        sel &= d["throttle"] > throttle_min
    veh = Vehicle(cfg) if cfg.tires.mu0 is not None else None
    v = d.loc[sel, "v"].to_numpy()
    F = cfg.mass.total * d.loc[sel, "ax"].to_numpy()
    if veh is not None:
        F = F + veh.resist(v)
    rows = []
    for a, b in zip(v_bins[:-1], v_bins[1:]):
        s = (v >= a) & (v < b)
        if s.sum() >= 15:
            rows.append((0.5 * (a + b), np.quantile(F[s], q)))
    if len(rows) < 4:
        raise ValueError("not enough full-throttle data for the power fit")
    vv, ff = np.array(rows).T
    # bins are already medians (robust), so an ordinary least-squares fit is used: a robust loss
    # would treat the few power-limited high-speed bins as outliers and lose the power estimate
    hi = vv >= np.quantile(vv, 0.7)
    p0 = [np.median(ff[~hi]), np.median(ff[hi] * vv[hi])]
    
    # Ensure all values in p0 are positive to prevent the ValueError
    p0 = [max(1e-3, val) for val in p0]
    
    r = optimize.least_squares(lambda p: np.minimum(p[0], p[1] / vv) - ff, p0, x_scale=p0)
    
    return {"max_drive_force": r.x[0], "max_power": r.x[1], "envelope": pd.DataFrame({"v": vv, "F": ff})}


# ------------------------------------------------------------ dampers
def fit_damper_fv(path, knee_guess=0.05):
    """Bilinear damper fit per direction from a dyno .csv (velocity [m/s], force [N]).
    Returns low/high-speed coefficients and knee velocity for bump (+) and rebound (-)."""
    d = pd.read_csv(path)
    v, f = d.iloc[:, 0].to_numpy(float), d.iloc[:, 1].to_numpy(float)
    out = {}
    for name, s in (("bump", v > 0), ("rebound", v < 0)):
        vv, ff = np.abs(v[s]), np.abs(f[s])
        def bil(p, x):
            c1, c2, vk = p
            return np.where(x < vk, c1 * x, c1 * vk + c2 * (x - vk))
        r = optimize.least_squares(lambda p: bil(p, vv) - ff, [ff.max() / vv.max() * 3, ff.max() / vv.max(), knee_guess],
                                   bounds=([0, 0, 0.005], [np.inf, np.inf, 0.5]), loss="soft_l1")
        out[name] = {"c_low": r.x[0], "c_high": r.x[1], "v_knee": r.x[2]}
    return out


def fit_mf61(ttc, **kw):
    """Full MF 6.1 fit (lateral, longitudinal, combined, aligning). See mf61_fit.fit_mf61."""
    from .mf61_fit import fit_mf61 as _f
    return _f(ttc, **kw)


def grip_to_skidpad(cfg: CarConfig, t_target: float, lo: float = 0.2, hi: float = 1.5):
    """Scale tires.lambda_mu so the steady-state skidpad lap equals ``t_target`` [s] (radius
    events.skidpad_radius). Uses Vehicle.ay_max only (no GGV), so it is quick. Returns (cfg, lambda)."""
    from scipy.optimize import brentq
    from .vehicle import Vehicle
    R = cfg.events.skidpad_radius

    def lap(lam):
        c = cfg.copy()
        c.tires.lambda_mu = lam
        v = Vehicle(c)
        f = lambda s: float(v.ay_max(np.array([s]))[0]) - s * s / R
        if f(2.0) <= 0:
            return 1e3
        s = brentq(f, 2.0, 40.0) if f(40.0) < 0 else 40.0
        return 2 * np.pi * R / s

    lam = brentq(lambda l: lap(l) - t_target, lo, hi, xtol=1e-4)
    cfg.tires.lambda_mu = float(lam)
    return cfg, float(lam)
