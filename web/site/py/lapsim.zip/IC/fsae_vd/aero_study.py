"""Aero studies on the full car: aero variants, ClA x CdA and balance sweeps, ride-height and
wing-clearance studies, lap aero channels, wing loads and energy.

Every study runs the four dynamic events (plus efficiency) through the coupled car:
``fsae_pt`` (gear-by-gear powertrain) when a powertrain config ``ptc`` is given, otherwise
``fsae_vd.run_events``. Grip (lambda_mu) is held at the baseline calibration in every
variant - it is a tire property, not an aero one.
"""
from __future__ import annotations

import copy

import numpy as np
import pandas as pd

from .config import CarConfig
from .units import G0, LBF

EVENTS = ("acceleration", "skidpad", "autocross", "endurance")


# --------------------------------------------------------------------------- running
def run(cfg: CarConfig, ptc=None, tracks=None, events=EVENTS):
    """Event results for one configuration (fsae_pt when ptc is given)."""
    if ptc is not None:
        import fsae_pt as fp
        return fp.run_events_pt(cfg, ptc, tracks, events=events)
    from .lapsim import run_events
    return run_events(cfg, tracks, events=events)


def score(res) -> dict:
    d = {f"{e}_s": res.times.get(e, np.nan) for e in EVENTS}
    for e in list(EVENTS) + ["efficiency"]:
        d[f"{e}_pts"] = res.points.get(e, np.nan)
    d["dynamic_pts"] = float(np.nansum([res.points.get(e, np.nan) for e in list(EVENTS) + ["efficiency"]]))
    lap = res.laps.get("endurance")
    if lap is not None:
        d["endurance_lap_s"] = lap.time
    return d


# --------------------------------------------------------------------------- variants
def wings_off(cfg: CarConfig, veh=None) -> CarConfig:
    """The car without front and rear wing: body only, scaled to the wings-off coast-down
    (CL -0.104, CD 0.58, aero binder p.38), wing masses removed and the CG moved."""
    from .aero import BINDER
    from .vehicle import Vehicle
    c = cfg.copy()
    veh = veh or Vehicle(cfg)
    A = veh.aero_model
    body = A.get("body")
    area = c.aero.reference_area or 1.098
    m = c.mass.total
    wings = [x for x in A.comps if x.name != "body"]
    mw = sum(w.mass for w in wings)
    if mw > 0:
        L = c.geometry.wheelbase
        h_new = (m * c.mass.cg_height - sum(w.mass * w.z for w in wings)) / (m - mw)
        ff_new = (m * c.mass.front_weight_fraction - sum(w.mass * (w.x + L) / L for w in wings)) / (m - mw)
        c.mass.mass_no_driver -= mw
        c.mass.cg_height, c.mass.front_weight_fraction = h_new, ff_new
    bd = copy.deepcopy(c.aero.components["body"])
    bd["x_from_front_axle"] = body.x
    for k in ("cfd_downforce", "cfd_drag"):
        bd.pop(k, None)
    bd.pop("cfd_lift", None)
    bd["ClA"] = BINDER["coastdown_wings_off"]["CL"] * area
    bd["CdA"] = BINDER["coastdown_wings_off"]["CD"] * area
    c.aero.components = {"body": bd}
    c.aero.calib_ClA, c.aero.calib_CdA = bd["ClA"], bd["CdA"]
    c.aero.calib_front_fraction = None
    return c


def constant_aero(cfg: CarConfig, veh=None) -> CarConfig:
    """The original model: the same nominal ClA_front / ClA_rear / CdA, but fixed (no ride-height,
    pitch, roll, yaw or drag-moment effects)."""
    from .vehicle import Vehicle
    veh = veh or Vehicle(cfg)
    c = cfg.copy()
    c.aero.model = "constant"
    c.aero.ClA_front, c.aero.ClA_rear, c.aero.CdA = veh.claf, veh.clar, veh.cda
    # balance of the constant model = downforce CoP (no drag moment)
    st = veh.aero_model.evaluate(np.ones(1))
    tot = veh.claf + veh.clar
    bal = float(st["balance"][0])
    c.aero.ClA_front, c.aero.ClA_rear = bal * tot, (1 - bal) * tot
    return c


def with_drs(cfg: CarConfig) -> CarConfig:
    c = cfg.copy()
    c.aero.drs = dict(c.aero.drs or {}, enabled=True)
    return c


def variants(cfg: CarConfig) -> dict:
    from .vehicle import Vehicle
    veh = Vehicle(cfg)
    return {"wings off": wings_off(cfg, veh), "constant aero (old model)": constant_aero(cfg, veh),
            "full attitude model": cfg.copy(), "full + DRS (what-if)": with_drs(cfg)}


def compare(cfgs: dict, ptc=None, tracks=None) -> pd.DataFrame:
    rows = {}
    results = {}
    for name, c in cfgs.items():
        r = run(c, ptc, tracks)
        results[name] = r
        rows[name] = score(r)
    return pd.DataFrame(rows).T, results


# --------------------------------------------------------------------------- sweeps
def scaled(cfg: CarConfig, k_lift=1.0, k_drag=1.0, front_fraction=None, fw_clearance=None) -> CarConfig:
    c = cfg.copy()
    if c.aero.calib_ClA is not None:
        c.aero.calib_ClA *= k_lift
    if c.aero.calib_CdA is not None:
        c.aero.calib_CdA *= k_drag
    if front_fraction is not None:
        c.aero.calib_front_fraction = front_fraction
    if fw_clearance is not None:
        c.aero.components["front_wing"]["ground_clearance"] = fw_clearance
    return c


def sweep_cla_cda(cfg, ptc=None, tracks=None, k_lift=(0.6, 0.8, 1.0, 1.2, 1.4), k_drag=(0.6, 0.8, 1.0, 1.2, 1.4),
                  verbose=False) -> pd.DataFrame:
    rows = []
    for kl in k_lift:
        for kd in k_drag:
            c = scaled(cfg, kl, kd)
            d = score(run(c, ptc, tracks))
            d.update(k_lift=kl, k_drag=kd, ClA=cfg.aero.calib_ClA * kl, CdA=cfg.aero.calib_CdA * kd)
            rows.append(d)
            if verbose:
                print(f"ClA x{kl:.2f} CdA x{kd:.2f}: {d['dynamic_pts']:.1f} pts")
    return pd.DataFrame(rows)


def sweep_param(cfg, ptc, tracks, name, values, make) -> pd.DataFrame:
    rows = []
    for v in values:
        d = score(run(make(cfg, v), ptc, tracks))
        d[name] = v
        rows.append(d)
    return pd.DataFrame(rows)


def sweep_balance(cfg, ptc=None, tracks=None, fractions=np.arange(0.44, 0.665, 0.03)):
    return sweep_param(cfg, ptc, tracks, "front_fraction", fractions,
                       lambda c, f: scaled(c, front_fraction=float(f)))


def sweep_fw_clearance(cfg, ptc=None, tracks=None, clearances_mm=(25, 35, 45, 51, 60, 75, 90)):
    """Front-wing ground clearance (static). The wing's CFD downforce is kept at the design
    height (51 mm); other heights move it along the ground-effect curve."""
    from .vehicle import Vehicle
    base = cfg.aero.components["front_wing"]["ground_clearance"]

    def make(c, mm):
        c2 = c.copy()
        h = mm / 1e3
        fw = c2.aero.components["front_wing"]
        # keep the CFD value tied to the design height: scale the shares by GE(h)/GE(h_design)
        v0 = Vehicle(c)
        g = float(v0.aero_model.ground_factor(np.array(h), v0.aero_model.get("front_wing")))
        fw["cfd_downforce"] = fw["cfd_downforce"] * g
        fw["ground_clearance"] = h
        # whole-car calibration follows the wing (the coast-down was at the design height);
        # the body centre of pressure stays where the baseline put it
        tot0 = sum(x["cfd_downforce"] for x in c.aero.components.values())
        tot1 = sum(x["cfd_downforce"] for x in c2.aero.components.values())
        c2.aero.calib_ClA = c.aero.calib_ClA * tot1 / tot0
        c2.aero.components["body"]["x_from_front_axle"] = v0.aero_model.get("body").x
        c2.aero.calib_front_fraction = None
        return c2
    out = sweep_param(cfg, ptc, tracks, "fw_clearance_mm", clearances_mm, make)
    out.attrs["design_mm"] = base * 1e3
    return out


# --------------------------------------------------------------------------- lap channels
def lap_channels(veh, lap) -> pd.DataFrame:
    """Aero channels along a solved lap: per-component downforce / drag, CoP balance, front-axle
    share (incl. drag moment), pitch, roll, body slip, wing yaw angles and ground clearance."""
    st = lap.state
    d = veh.aero_detail(st)
    c = d["comps"]
    sgn = np.where(np.asarray(lap.ay) >= 0, 1.0, -1.0)
    out = {"s": lap.s, "t": lap.t, "v": lap.v, "ax": lap.ax, "ay": lap.ay,
           "downforce": st["downforce"], "aero_front": st["aero_front"], "aero_rear": st["aero_rear"],
           "drag": st["drag"], "cornering_drag": st.get("cornering_drag", np.zeros_like(lap.v)),
           "balance_cop": st["aero_balance"],
           "front_share": st["aero_front"] / np.maximum(st["downforce"], 1e-6),
           "pitch_deg": st["pitch_deg"], "roll_deg": st["roll_deg"], "beta_deg": st["beta_deg"],
           "heave_front_mm": 1e3 * st["heave_front"], "heave_rear_mm": 1e3 * st["heave_rear"],
           "aero_Mz": st["aero"]["Mz"], "aero_Fy": st["aero"]["Fy"], "aero_Mx": st["aero"]["Mx"],
           "drs": st["drs"].astype(float), "turn_sign": sgn}
    for k, x in c.items():
        out[f"{k}_F"] = x["F"]
        out[f"{k}_D"] = x["D"]
        out[f"{k}_yaw_deg"] = x["yaw_deg"]
    if "front_wing" in c:
        out["fw_clear_mm"] = 1e3 * c["front_wing"]["clearance"]
        out["fw_clear_min_mm"] = 1e3 * c["front_wing"]["clearance_min"]
    return pd.DataFrame(out)


def lap_summary(veh, laps: dict) -> pd.DataFrame:
    rows = {}
    for e, lap in laps.items():
        if not hasattr(lap, "state"):
            continue
        ch = lap_channels(veh, lap)
        dt = np.diff(ch["t"], append=ch["t"].iloc[-1])
        T = max(float(ch["t"].iloc[-1]), 1e-9)
        r = {"lap time [s]": lap.time, "mean downforce [N]": float((ch.downforce * dt).sum() / T),
             "peak downforce [N]": ch.downforce.max(), "mean drag [N]": float((ch.drag * dt).sum() / T),
             "drag energy [kJ]": float((ch.drag * ch.v * dt).sum() / 1e3),
             "cornering-drag energy [kJ]": float((ch.cornering_drag * ch.v * dt).sum() / 1e3),
             "CoP balance range": f"{ch.balance_cop.quantile(0.05):.3f}-{ch.balance_cop.quantile(0.95):.3f}",
             "front-axle share (time mean)": float((ch.front_share * dt).sum() / T),
             "max pitch [deg] (+ nose down)": ch.pitch_deg.max(), "min pitch [deg]": ch.pitch_deg.min(),
             "max roll [deg]": ch.roll_deg.max(), "max |body slip| [deg]": ch.beta_deg.abs().max()}
        if "front_wing_yaw_deg" in ch:
            r["max |front-wing yaw| [deg]"] = ch.front_wing_yaw_deg.abs().max()
            r["max |rear-wing yaw| [deg]"] = ch.rear_wing_yaw_deg.abs().max()
            r["min front-wing clearance [mm]"] = ch.fw_clear_min_mm.min()
            r["peak front-wing downforce [lbf]"] = ch.front_wing_F.max() / LBF
            r["peak rear-wing downforce [lbf]"] = ch.rear_wing_F.max() / LBF
            r["peak rear-wing drag [lbf]"] = ch.rear_wing_D.max() / LBF
        rows[e] = r
    return pd.DataFrame(rows)


def wing_loads(veh, laps: dict) -> pd.DataFrame:
    """Peak wing loads per event against the mount design loads (aero binder p.29)."""
    from .aero import BINDER
    rows = []
    for e, lap in laps.items():
        if not hasattr(lap, "state"):
            continue
        ch = lap_channels(veh, lap)
        if "front_wing_F" not in ch:
            continue
        rows.append({"event": e, "front wing downforce [lbf]": ch.front_wing_F.max() / LBF,
                     "front wing drag [lbf]": ch.front_wing_D.max() / LBF,
                     "rear wing downforce [lbf]": ch.rear_wing_F.max() / LBF,
                     "rear wing drag [lbf]": ch.rear_wing_D.max() / LBF,
                     "top speed [mph]": float(np.max(lap.v)) / 0.44704})
    df = pd.DataFrame(rows).set_index("event")
    df.loc["front-wing mount design (AB29)", ["front wing downforce [lbf]", "front wing drag [lbf]"]] = \
        [BINDER["front_wing_design_downforce_lbf"], BINDER["front_wing_design_drag_lbf"]]
    return df


def energy(veh, lap) -> dict:
    """Energy per lap [kJ]: aero drag, rolling + toe, tire cornering drag, kinetic energy lost to the brakes."""
    st = lap.state
    v = np.asarray(lap.v)
    dt = np.diff(lap.t, append=lap.t[-1])
    D = st["drag"]
    roll = (veh.crr + veh.toe_drag_coef) * (veh.m * G0 + st["downforce"])
    cd = st.get("cornering_drag", np.zeros_like(v))
    need = veh.m * np.asarray(lap.ax) + D + roll + cd
    brk = np.maximum(-need, 0.0)
    return {"aero drag": float(np.sum(D * v * dt) / 1e3), "rolling + toe": float(np.sum(roll * v * dt) / 1e3),
            "tire cornering drag": float(np.sum(cd * v * dt) / 1e3), "brakes": float(np.sum(brk * v * dt) / 1e3)}


# --------------------------------------------------------------------------- logs
def logged_rates(log_path, v_min=5.0) -> pd.DataFrame:
    """Yaw / roll / pitch rate [deg/s] and speed from a logged run (moving samples, bias removed)."""
    from .io_data import load_log
    lg = load_log(log_path)
    ch = lg.channels
    t = ch["speed_gps"].t
    v = ch["speed_gps"].x
    v = v / 3.6 if np.nanmax(v) > 60 else v
    out = {"v": v}
    for k in ("yaw_rate", "roll_rate", "pitch_rate", "ay"):
        if k in ch:
            out[k] = np.interp(t, ch[k].t, ch[k].x)
    df = pd.DataFrame(out)
    still = df["v"] < 0.5
    for k in ("yaw_rate", "roll_rate", "pitch_rate"):
        if k in df:
            df[k] = np.degrees(df[k])             # the loader returns SI (rad/s)
            if still.sum() > 50:
                df[k] -= df.loc[still, k].median()
    return df[df["v"] > v_min].reset_index(drop=True)
