"""Per-event results (lap time plus the quantities judges and engineers look at)
and a design-event summary of the suspension."""
from __future__ import annotations

import numpy as np
import pandas as pd

from . import scoring
from .units import G0, LBF, to_unit


def _fractions(lr, ggv):
    ay_lim = ggv.ay_lim(lr.v)
    acc_lim = np.array([ggv.acc(v, a) for v, a in zip(lr.v, lr.ay)])
    dt = np.diff(lr.t, append=lr.t[-1])
    T = dt.sum()
    full = (lr.ax > 0) & (lr.ax >= 0.97 * acc_lim)
    brake = lr.ax < -0.05 * G0
    corner = np.abs(lr.ay) >= 0.97 * ay_lim
    return {"time_full_throttle_%": 100 * dt[full].sum() / T, "time_braking_%": 100 * dt[brake].sum() / T,
            "time_at_lateral_limit_%": 100 * dt[corner].sum() / T}


def lap_metrics(lr, veh, ggv):
    st = lr.state
    d = {"lap_time_s": lr.time, "distance_m": lr.track.length, "avg_speed_kph": lr.track.length / lr.time * 3.6,
         "max_speed_kph": lr.v.max() * 3.6, "min_speed_kph": lr.v.min() * 3.6,
         "peak_lat_g": np.abs(lr.ay).max() / G0, "peak_accel_g": lr.ax.max() / G0, "peak_brake_g": -lr.ax.min() / G0,
         "max_roll_deg": np.abs(st["roll_deg"]).max(), "max_pitch_deg": np.abs(st["pitch_deg"]).max(),
         "tractive_energy_kWh": lr.energy_J / 3.6e6}
    for k, nm in (("fo", "front_outside"), ("ro", "rear_outside")):
        d[f"max_damper_travel_{nm}_mm"] = 1000 * np.max(np.abs(st["damper"][k]))
        d[f"max_Fz_{nm}_N"] = float(np.max(st["Fz"][k]))
    cfg = veh.cfg
    if cfg.front.ride_height is not None:
        d["min_clearance_front_mm"] = 1000 * (cfg.front.ride_height + veh.Af.body_rise - np.max(st["heave_front"]))
    if cfg.rear.ride_height is not None:
        d["min_clearance_rear_mm"] = 1000 * (cfg.rear.ride_height + veh.Ar.body_rise - np.max(st["heave_rear"]))
    if lr.time > 0:
        d.update(_fractions(lr, ggv))
    return d


def event_report(res, event):
    """Dictionary of results for one event from lapsim.EventResults."""
    veh, ggv, ev = res.vehicle, res.ggv, veh_events(res)
    out = {"event": event}
    if event not in res.times:
        return out
    t = res.times[event]
    lr = res.laps.get(event)
    if event == "acceleration":
        out.update({"time_s": t, "trap_speed_kph": lr.v[-1] * 3.6,
                    "time_to_30m_s": float(np.interp(30, lr.s, lr.t)),
                    "peak_accel_g": lr.ax.max() / G0, "mean_accel_g": lr.track.length * 2 / t ** 2 / G0})
        need = veh.m * lr.ax + veh.resist(lr.v)
        try:
            pl = need >= 0.99 * veh.pt.force(lr.v)
            out["distance_powertrain_limited_%"] = 100 * pl[:-1].mean()
        except Exception:
            pass
        out["tractive_energy_kWh"] = lr.energy_J / 3.6e6
    elif event == "skidpad":
        R = veh.cfg.events.skidpad_radius
        v = 2 * np.pi * R / t
        st = veh.state(v, 0.0, v ** 2 / R)
        aym, mf, mr = veh.limit_balance(np.array([v]))
        out.update({"time_s": t, "note": "time per timed circle (FSAE averages left and right)",
                    "speed_kph": v * 3.6, "lateral_g": v ** 2 / R / G0,
                    "limit": "front-limited (understeer)" if mf[0] < mr[0] else "rear-limited (oversteer)",
                    "roll_deg": float(st["roll_deg"]), "camber_front_outside_deg": float(st["camber"]["fo"]),
                    "camber_rear_outside_deg": float(st["camber"]["ro"]),
                    "front_LLT_share_%": float(100 * st["lt_front"] * veh.tf /
                                               (st["lt_front"] * veh.tf + st["lt_rear"] * veh.tr)),
                    "road_wheel_inner_deg": float(np.degrees(st["steer_inner"])),
                    "road_wheel_outer_deg": float(np.degrees(st["steer_outer"]))})
        if veh.cfg.steering.steer_ratio:
            out["steering_wheel_deg"] = float(np.degrees(0.5 * (st["steer_inner"] + st["steer_outer"]))
                                              * veh.cfg.steering.steer_ratio)
        try:
            out.update(steering_effort(veh, v, v ** 2 / R))
        except Exception as e:      # missing steering or tire data
            out["steering_effort_note"] = str(e)
    else:
        out.update(lap_metrics(lr, veh, ggv))
        out["time_s"] = t
        if event == "endurance":
            n = max(1, int(round(veh.cfg.events.endurance_distance / lr.track.length)))
            out.update({"laps": n, "flying_lap_s": lr.time,
                        "total_energy_kWh": res.laps.get("endurance_energy_J", np.nan) / 3.6e6,
                        "average_power_kW": res.laps.get("endurance_energy_J", np.nan) / t / 1e3})
    if event in res.points:
        out["points"] = res.points[event]
        A, B, k, p = scoring.SCORING[event]
        out["max_points"] = A + B
    return out


def veh_events(res):
    return res.vehicle.cfg.events


def events_table(res):
    rows = [event_report(res, e) for e in ("acceleration", "skidpad", "autocross", "endurance") if e in res.times]
    return pd.DataFrame(rows).set_index("event").T


def design_report(veh):
    """Suspension numbers design judges ask about, from the current model."""
    c = veh.cfg
    rows = {}
    for nm, A, R, t in (("front", veh.Af, veh.Rf, veh.tf), ("rear", veh.Ar, veh.Rr, veh.tr)):
        s = A.summary()
        rows[nm] = {
            "kinematics source": s["source"], "roll-centre height [in]": s["rc_static_in"],
            "front-view swing arm [in]": s["fvsa_in"], "static camber [deg]": s["static_camber_deg"],
            "camber gain [deg/in bump]": float(A.dcamber(0.0254) - A.dcamber(0.0)),
            "KPI [deg]": s["kpi_deg"], "caster [deg]": s["caster_deg"],
            "scrub radius [mm]": s["scrub_radius_mm"], "mechanical trail [mm]": s["mech_trail_mm"],
            "motion ratio wheel/damper": s.get("motion_ratio_wheel_per_damper", 1 / (veh.mrf if nm == "front" else veh.mrr)),
            "pull-rod angle [deg]": s.get("rod_angle_deg", np.nan),
            "wheel rate [lbf/in]": to_unit(R.wheel_rate, "lbf/in"), "ride rate [lbf/in]": to_unit(R.ride_rate, "lbf/in"),
            "ride frequency [Hz]": R.ride_frequency,
            "roll stiffness springs [N*m/deg]": R.roll_stiffness_springs / 57.2958,
            "roll stiffness ARB [N*m/deg]": R.roll_stiffness_arb / 57.2958,
            "roll stiffness total incl. tire [N*m/deg]": R.roll_stiffness / 57.2958,
        }
    df = pd.DataFrame(rows)
    ay1 = veh.state(15.0, 0.0, G0)
    extra = {
        "roll gradient [deg/g]": float(ay1["roll_deg"]),
        "front roll-stiffness share [%]": 100 * veh.Kf / (veh.Kf + veh.Kr),
        "front lateral load-transfer share at 1 g [%]": float(100 * ay1["lt_front"] * veh.tf /
                                                              (ay1["lt_front"] * veh.tf + ay1["lt_rear"] * veh.tr)),
        "anti-dive [%]": 100 * veh.anti["anti_dive"], "anti-lift [%]": 100 * veh.anti["anti_lift"],
        "anti-squat [%]": 100 * veh.anti["anti_squat"], "CG height used [in]": veh.h / 0.0254,
    }
    for v in (10, 20, 30):
        aym, mf, mr = veh.limit_balance(np.array([float(v)]))
        extra[f"lateral limit at {v} m/s [g]"] = float(aym[0] / G0)
        extra[f"limit balance at {v} m/s"] = "front-limited (understeer)" if mf[0] < mr[0] else "rear-limited (oversteer)"
    return df, pd.Series(extra, dtype=object)


def component_loads(res, events=("skidpad", "autocross", "endurance", "acceleration")):
    """Peak pull-rod and damper forces per corner over the simulated events (quasi-static).
    Rod force = (wheel vertical load) / cos(rod angle); damper force = wheel load / MR(damper/wheel)."""
    veh = res.vehicle
    rows = []
    for e in events:
        lr = res.laps.get(e)
        if lr is None or not hasattr(lr, "state"):
            continue
        for k, A, mr in (("fo", veh.Af, veh.mrf), ("ro", veh.Ar, veh.mrr)):
            Fz = float(np.max(lr.state["Fz"][k]))
            r = {"event": e, "corner": {"fo": "front outside", "ro": "rear outside"}[k], "max Fz [N]": Fz,
                 "damper force [N]": Fz / mr}
            if A.rod_angle_deg is not None:
                r["pull-rod force [N]"] = Fz / np.cos(np.radians(A.rod_angle_deg))
            rows.append(r)
    return pd.DataFrame(rows)


def steering_effort(veh, v, ay):
    """Steady-state steering effort from the tire model.

    Front slip angle is solved so the two front tires carry the front axle's yaw-balance share;
    the moment about each king-pin axis is Mz + Fy * mechanical trail (both self-aligning), the
    rack force is their sum over the steering arm, and the chain to the driver's hands is the
    binder's rack / U-joint / wheel calculation."""
    from scipy.optimize import brentq
    from . import kinematics as kin
    c = veh.cfg
    c.require("steering.steering_arm", "steering.pinion_radius", "steering.rack_efficiency",
              "steering.ujoint_efficiency", "steering.wheel_radius", purpose="steering effort")
    st = veh.state(v, 0.0, ay)
    req = veh.m * abs(ay) * veh.b / veh.L
    p = veh.p_f
    f = lambda al: float(veh.tire.fy(al, st["Fz"]["fo"], st["camber"]["fo"], p) +
                         veh.tire.fy(al, st["Fz"]["fi"], st["camber"]["fi"], p) - req)
    grid = np.radians(np.linspace(0, 25, 501))
    vals = np.array([f(a) for a in grid])
    pos = np.flatnonzero(vals >= 0)
    if pos.size == 0:                        # axle at (or past) its peak: take the peak slip angle
        alpha = float(grid[np.argmax(vals)])
    else:
        j = pos[0]
        alpha = brentq(f, grid[j - 1], grid[j]) if j > 0 else 0.0
    trail = veh.Af.trail if veh.Af.trail is not None else 0.0
    M, mz_known = 0.0, True
    for k in ("fo", "fi"):
        fy = float(veh.tire.fy(alpha, st["Fz"][k], st["camber"][k], p))
        mz = veh.tire.mz(alpha, st["Fz"][k], st["camber"][k], p)
        if mz is None:
            mz_known, mz = False, 0.0
        M += float(mz) + fy * trail
    rack = M / c.steering.steering_arm
    e = kin.steering_effort(rack, c.steering.pinion_radius, c.steering.rack_efficiency,
                            c.steering.ujoint_efficiency, c.steering.wheel_radius)
    out = {"front_slip_angle_deg": float(np.degrees(alpha)), "kingpin_moment_total_Nm": M,
           "rack_force_N": rack, "steering_wheel_torque_Nm": e["column_torque"],
           "driver_hand_force_N": e["hand_force"]}
    if not mz_known:
        out["steering_effort_note"] = "tire aligning moment unknown - mechanical trail only (lower bound)"
    return out
