"""Dynamic tire: deformation, transient slip, wheel spin and temperature.

The steady-state tire models (tire.py, mf61.py) give force from slip. This module adds what the
tire *does* while it makes that force, so braking and cornering can be followed in time:

Deformation (``TireStructure``)
    vertical    deflection dz from the measured stiffness table (tires.kt_*: rate vs load and
                pressure, integrated so the rate's load dependence is kept)
    radii       loaded radius R0 - dz (lever arm of Fx), effective rolling radius R0 - f*dz
                (sets wheel speed, so slip)
    patch       length 2a = factor * 2*sqrt(2 R0 dz - dz^2), width, area, mean contact pressure
    carcass     in-plane deflection u = F / k_carcass, longitudinal and lateral
    tread       brush model: adhesion and sliding zones of the patch, tread (bristle) deflection

Slip dynamics (``CornerTire``)
    The carcass deflections are the states (stretched-string model, Pacejka ch. 7):
        du_x/dt = (omega*Re - Vx) - |Vx|/sigma_x * u_x       kappa' = u_x / sigma_x
        du_y/dt = -Vy             - |Vx|/sigma_y * u_y       alpha' = atan(u_y / sigma_y)
    with relaxation lengths sigma = (slip stiffness) / (carcass stiffness), so they follow the
    load and pressure. Forces come from the steady model at the transient slips (kappa', alpha').
    Writing the states as deflections instead of slips keeps the equations finite at low speed.
    Wheel spin:  I dw/dt = T_drive - T_brake - Fx * R_loaded - rolling resistance moment;
    a locked wheel (w = 0, kappa = -1) is reached naturally when brake torque beats tire torque.

Temperature (``TireThermal``)
    two nodes per tire: tread surface (heated by contact sliding power |Fx Vsx| + |Fy Vsy|,
    cooled by air, road and the carcass) and carcass (heated by hysteresis ~ Fz v). Grip falls off
    either side of an optimum surface temperature; the inflation pressure follows the carcass
    temperature (ideal gas), which changes the vertical stiffness and the patch.

Uses
    lap_tire_channels(veh, lap)   deformation and temperature along a quasi-steady lap
    simulate_braking(veh, v0)     straight-line stop with wheel spin, lock-up and pitch, driven by a
                                  pedal ramp or a logged pressure trace
    fit_brake_torque(df, veh)     brake torque per bar from a logged braking run
    multibody.Chassis(..., dynamic_tires=True)   the full transient car with these tires

Parameters live in ``cfg.tire_dynamics`` (and ``cfg.brakes`` for torque). Values tagged ASSUMED
are typical 10-inch FSAE numbers; the deformation and temperature results are only as good as
those until they are measured.
"""
from __future__ import annotations

import dataclasses as dc
import math

import numpy as np
import pandas as pd

from .config import MissingDataError
from .units import G0

P_ATM = 101325.0
WHEELS = ("fo", "fi", "ro", "ri")


# ======================================================================= helpers
def _lin(x, xp, fp):
    """np.interp with linear extrapolation at both ends."""
    xp, fp = np.asarray(xp, float), np.asarray(fp, float)
    x = np.asarray(x, float)
    y = np.interp(x, xp, fp)
    if xp.size > 1:
        y = np.where(x < xp[0], fp[0] + (x - xp[0]) * (fp[1] - fp[0]) / (xp[1] - xp[0]), y)
        y = np.where(x > xp[-1], fp[-1] + (x - xp[-1]) * (fp[-1] - fp[-2]) / (xp[-1] - xp[-2]), y)
    return y


class _Grid2:
    """Bilinear lookup on a uniform (x, y) grid; pure-Python scalar path for the time-domain loops."""

    def __init__(self, x0, dx, nx, y0, dy, ny, Z):
        self.x0, self.dx, self.nx, self.y0, self.dy, self.ny = x0, dx, nx, y0, dy, ny
        self.Z = np.asarray(Z, float)
        self.Zl = self.Z.tolist()

    def __call__(self, x, y):
        fx = min(max((x - self.x0) / self.dx, 0.0), self.nx - 1.000001)
        fy = min(max((y - self.y0) / self.dy, 0.0), self.ny - 1.000001)
        i, j = int(fx), int(fy)
        tx, ty = fx - i, fy - j
        Z = self.Zl
        a = Z[i][j] + (Z[i][j + 1] - Z[i][j]) * ty
        b = Z[i + 1][j] + (Z[i + 1][j + 1] - Z[i + 1][j]) * ty
        return a + (b - a) * tx

    def vec(self, x, y):
        x, y = np.broadcast_arrays(np.asarray(x, float), np.asarray(y, float))
        fx = np.clip((x - self.x0) / self.dx, 0, self.nx - 1.000001)
        fy = np.clip((y - self.y0) / self.dy, 0, self.ny - 1.000001)
        i, j = fx.astype(int), fy.astype(int)
        tx, ty = fx - i, fy - j
        Z = self.Z
        a = Z[i, j] + (Z[i, j + 1] - Z[i, j]) * ty
        b = Z[i + 1, j] + (Z[i + 1, j + 1] - Z[i + 1, j]) * ty
        return a + (b - a) * tx


# ======================================================================= structure
class TireStructure:
    """Vertical, in-plane and contact-patch deformation of the tire (one design, any pressure)."""
    FZ_MAX = 6000.0

    def __init__(self, cfg):
        tp, td = cfg.tires, cfg.tire_dynamics
        if tp.tire_radius is None:
            raise MissingDataError("tires.tire_radius needed for the tire structure model")
        self.td = td
        self.R0 = float(tp.tire_radius)
        self.width = float(tp.width) if tp.width else 0.19
        self.notes = []
        if not tp.width:
            self.notes.append("tires.width not set - 0.19 m (7.5 in) used for the contact patch")
        pres = [p for p in (tp.pressure_front, tp.pressure_rear) if p is not None]
        # vertical stiffness: measured table (rate vs load, per pressure), else a constant
        if tp.kt_pressures and tp.kt_loads and tp.kt_rates:
            P, L, K = np.asarray(tp.kt_pressures, float), np.asarray(tp.kt_loads, float), np.asarray(tp.kt_rates, float)
            if K.shape != (P.size, L.size):
                raise ValueError(f"tires.kt_rates must be [pressure][load] = {P.size} x {L.size}")
            self.p_nom = float(np.mean(pres)) if pres else float(np.median(P))
            p_lo, p_hi = 0.4 * P.min(), 1.6 * P.max()
            self.kt_range = (P.min(), P.max())
        else:
            kz = None
            if tp.model == "mf61" and tp.tir_file:
                from .mf61 import load_tir
                kz = load_tir(tp.tir_file).get("VERTICAL_STIFFNESS") or None
            if not kz:
                raise MissingDataError("tire deformation needs the vertical stiffness table tires.kt_pressures / "
                                       "kt_loads / kt_rates (or VERTICAL_STIFFNESS in the .tir file)")
            self.p_nom = float(np.mean(pres)) if pres else 70e3
            P, L, K = np.array([self.p_nom]), np.array([1000.0]), np.array([[kz]])
            p_lo, p_hi = 0.4 * self.p_nom, 1.6 * self.p_nom
            self.kt_range = (self.p_nom, self.p_nom)
        npg, nfz = 49, 241
        pg = np.linspace(p_lo, p_hi, npg)
        fz = np.linspace(0.0, self.FZ_MAX, nfz)
        kmin = 0.4 * K.min()
        KZ = np.empty((npg, nfz))
        DZ = np.empty((npg, nfz))
        for i, p in enumerate(pg):
            k_at_loads = np.array([_lin(p, P, K[:, j]) for j in range(L.size)]) if P.size > 1 else K[0]
            k = np.maximum(_lin(fz, L, k_at_loads) if L.size > 1 else np.full(nfz, k_at_loads[0]), kmin)
            KZ[i] = k
            DZ[i] = np.r_[0.0, np.cumsum(np.diff(fz) * 0.5 * (1 / k[1:] + 1 / k[:-1]))]
        self._kz = _Grid2(p_lo, pg[1] - pg[0], npg, 0.0, fz[1] - fz[0], nfz, KZ)
        self._dz = _Grid2(p_lo, pg[1] - pg[0], npg, 0.0, fz[1] - fz[0], nfz, DZ)
        self.p_lo, self.p_hi = p_lo, p_hi

    # ---- vertical
    def deflection(self, fz, p):
        """Vertical deflection [m] at load fz [N] and gauge pressure p [Pa] (scalar fast path)."""
        if fz <= 0.0:
            return 0.0
        return self._dz(p, fz)

    def deflection_vec(self, fz, p):
        return np.where(np.asarray(fz) > 0, self._dz.vec(p, np.maximum(fz, 0.0)), 0.0)

    def vertical_rate(self, fz, p):
        return self._kz.vec(p, np.maximum(fz, 0.0))

    def radii(self, dz):
        """(loaded radius, effective rolling radius) [m] for vertical deflection dz."""
        return self.R0 - dz, self.R0 - self.td.rolling_radius_fraction * dz

    def patch(self, dz):
        """(half length a, width w, area) [m, m, m^2] of the contact patch."""
        dz = np.maximum(dz, 0.0)
        a = 0.5 * self.td.patch_length_factor * 2.0 * np.sqrt(np.maximum(2 * self.R0 * dz - dz * dz, 0.0))
        w = self.width * self.td.patch_width_fraction
        return a, w, 2.0 * a * w

    # ---- in-plane
    def carcass_stiffness(self, p):
        """(kx, ky) [N/m] at gauge pressure p."""
        r = max(float(np.mean(p)) if np.ndim(p) else float(p), 0.2 * self.p_nom) / self.p_nom
        f = r ** self.td.carcass_pressure_exponent
        return self.td.carcass_kx * f, self.td.carcass_ky * f

    def relaxation(self, Ck, Ca, p):
        """(sigma_x, sigma_y) [m] = slip stiffness / carcass stiffness, bounded."""
        kx, ky = self.carcass_stiffness(p)
        lo = self.td.relaxation_min
        return min(max(Ck / kx, lo), 1.0), min(max(Ca / ky, lo), 1.5)

    # ---- tread (brush model)
    @staticmethod
    def brush(kappa, alpha, fz, a, Dx, Dy, Ck, Ca):
        """Brush-model state of the contact patch (Pacejka ch. 3, parabolic pressure).

        Returns dict: adhesion fraction of the patch length, sliding fraction, tread deflection at
        the breakaway point and the largest tread deflection in the patch [m]. Works on arrays."""
        kappa = np.clip(np.asarray(kappa, float), -0.999, 5.0)
        alpha = np.clip(np.asarray(alpha, float), -1.3, 1.3)
        fz = np.maximum(np.asarray(fz, float), 1.0)
        a = np.maximum(np.asarray(a, float), 1e-4)
        Dx, Dy = np.maximum(Dx, 1.0), np.maximum(Dy, 1.0)
        sx = kappa / (1 + kappa)
        sy = np.tan(alpha) / (1 + kappa)
        psi = np.hypot(Ck * sx / (3 * Dx), Ca * sy / (3 * Dy))
        lam = np.clip(1.0 - psi, 0.0, 1.0)                       # adhesion fraction of the length
        s_mag = np.hypot(sx, sy)
        cpx, cpy = Ck / (2 * a * a), Ca / (2 * a * a)            # bristle stiffness per length
        e_break = s_mag * 2 * a * lam                             # adhesion deflection grows from the leading edge
        nx = np.where(s_mag > 1e-12, np.abs(sx) / np.maximum(s_mag, 1e-12), 1.0)
        ny = np.where(s_mag > 1e-12, np.abs(sy) / np.maximum(s_mag, 1e-12), 0.0)
        # sliding zone: friction limit mu q(xi) / c, q parabolic with peak 3Fz/(4a) at the centre
        xi_s = 2 * a * lam
        xi_pk = np.maximum(xi_s, a)                               # max of the parabola inside the slide zone
        q = 3 * fz / (4 * a) * (1 - ((a - xi_pk) / a) ** 2)
        e_slide = np.hypot(Dx / fz * q * nx / cpx, Dy / fz * q * ny / cpy)
        e_slide = np.where(lam < 1.0, e_slide, 0.0)
        return {"adhesion": lam, "sliding": 1.0 - lam, "tread_break": e_break,
                "tread_max": np.maximum(e_break, e_slide)}

    @staticmethod
    def brush_profile(kappa, alpha, fz, a, Dx, Dy, Ck, Ca, n=81):
        """Tread deflection along the patch for one operating point (for plots).
        Returns x [m] (+ = leading edge), deflection x and y components [m], sliding mask."""
        kappa = float(np.clip(kappa, -0.999, 5.0))
        sx = kappa / (1 + kappa)
        sy = math.tan(float(np.clip(alpha, -1.3, 1.3))) / (1 + kappa)
        x = np.linspace(a, -a, n)                                 # leading edge first
        xi = a - x                                                # distance travelled in the patch
        cpx, cpy = Ck / (2 * a * a), Ca / (2 * a * a)
        ex, ey = sx * xi, sy * xi                                 # adhesion: deflection grows linearly (sign = force sign)
        q = 3 * fz / (4 * a) * np.clip(1 - (x / a) ** 2, 0, None)
        need = np.hypot(cpx * ex / max(Dx / fz, 1e-6), cpy * ey / max(Dy / fz, 1e-6))   # pressure needed to hold it
        exceed = need > q + 1e-9
        slide = np.zeros(n, bool)
        if exceed.any():                                          # once sliding, slides to the trailing edge
            slide[int(np.argmax(exceed)):] = True
        scale = np.ones(n)
        scale[slide] = q[slide] / np.maximum(need[slide], 1e-12)
        return x, ex * scale, ey * scale, slide


# ======================================================================= thermal
@dc.dataclass
class TireTemps:
    surface: float
    carcass: float


class TireThermal:
    def __init__(self, td):
        self.td = td

    def start(self):
        return TireTemps(self.td.start_temp_C, self.td.start_temp_C)

    def grip_factor(self, Ts):
        td = self.td
        if not td.thermal:
            return 1.0
        x = (Ts - td.optimum_temp_C) / td.temp_window_C
        return min(max(1.0 - td.grip_temp_loss * x * x, td.grip_temp_min), 1.0)

    def grip_factor_vec(self, Ts):
        td = self.td
        if not td.thermal:
            return np.ones_like(np.asarray(Ts, float))
        x = (np.asarray(Ts, float) - td.optimum_temp_C) / td.temp_window_C
        return np.clip(1.0 - td.grip_temp_loss * x * x, td.grip_temp_min, 1.0)

    def pressure(self, p_ref, Tc):
        """Gauge pressure at carcass temperature Tc, from p_ref measured at pressure_ref_temp_C."""
        if p_ref is None:
            return None
        if not self.td.thermal:
            return p_ref
        return (p_ref + P_ATM) * (Tc + 273.15) / (self.td.pressure_ref_temp_C + 273.15) - P_ATM

    def step(self, T: TireTemps, dt, P_slide, fz, v, area):
        """Advance the two temperatures by dt [s]. P_slide [W] = contact sliding power."""
        td = self.td
        if not td.thermal or dt <= 0:
            return T
        Ts, Tc = T.surface, T.carcass
        q_s = td.heat_to_tire_fraction * max(P_slide, 0.0)
        q_c = td.hysteresis_coef * max(fz, 0.0) * abs(v)
        hA = (td.h_air_0 + td.h_air_v * abs(v) ** 0.8) * td.area_air
        gR = td.h_road * max(area, 0.0)
        n = max(1, int(math.ceil(dt / 0.25)))
        h = dt / n
        for _ in range(n):
            dTs = (q_s - hA * (Ts - td.ambient_temp_C) - gR * (Ts - td.track_temp_C)
                   - td.g_surface_carcass * (Ts - Tc)) / td.heat_cap_surface
            dTc = (q_c + td.g_surface_carcass * (Ts - Tc) - td.g_carcass_air * (Tc - td.ambient_temp_C)) / td.heat_cap_carcass
            Ts += h * dTs
            Tc += h * dTc
        return TireTemps(Ts, Tc)


# ======================================================================= steady forces
class SteadyForces:
    """Combined-slip forces of the configured steady tire model at a slip state (fast scalar path).

    simple tire ('pacejka_simple'): normalised-slip similarity method. Each direction has its own
    stiffness (C_alpha, C_kappa) and peak (mu_y Fz, mu_x Fz); the combined normalised slip runs
    through one Magic-Formula shape, so the force never exceeds the friction ellipse and pure
    lateral slip gives exactly tire.Tire.fy. Past the peak the force falls smoothly to
    sliding_friction_ratio of the peak (locked-wheel friction).
    mf61: the MF 6.1 combined-slip equations.
    ``mu_s`` scales the force (temperature)."""
    CX, CY = 1.65, 1.40

    def __init__(self, veh):
        self.veh = veh
        self.tire = veh.tire
        c = veh.cfg
        tp, td = c.tires, c.tire_dynamics
        self.mf = tp.model == "mf61"
        self.no_long = False
        self.r_slide = td.sliding_friction_ratio
        if not self.mf:
            if tp.cornering_stiffness_per_load is None or tp.mu0 is None or tp.mu_fz is None:
                raise MissingDataError("dynamic tire needs tires.mu0, mu_fz and cornering_stiffness_per_load "
                                       "(or an MF 6.1 tire)")
            self.cpl = tp.cornering_stiffness_per_load
            self.kpl = td.slip_stiffness_per_load
            self.tp = (tp.lambda_mu, tp.mu0, tp.mu_fz, tp.fz0, tp.gamma_opt_deg, tp.k_gamma, tp.mux_over_muy)
        else:
            fzg = np.linspace(50, 4000, 80)
            self._fzg = fzg
            self._ca = np.abs(np.asarray(self.tire.m.cornering_stiffness(fzg), float))
            # cornering-only fit (no longitudinal curve): slip stiffness from tire_dynamics, forces by
            # the similarity method on the MF peaks
            self.no_long = bool(getattr(self.tire, "no_longitudinal", False))
            self._ck = (td.slip_stiffness_per_load * fzg if self.no_long
                        else np.abs(np.asarray(self.tire.m.slip_stiffness(fzg), float)))

    # ---- simple model pieces (pure Python)
    def _mu_y(self, fz, gam):
        lam, mu0, mufz, fz0, gopt, kg, _ = self.tp
        mu = lam * (mu0 + mufz * (fz - fz0))
        if gopt is not None and kg is not None:
            mu *= min(max(1.0 - kg * (gam - gopt) ** 2, 0.3), 1.0)
        return max(mu, 0.05)

    def stiffness(self, fz):
        """(C_kappa, C_alpha) [N per unit slip, N/rad]."""
        fz = max(fz, 1.0)
        if not self.mf:
            return self.kpl * fz, self.cpl * fz
        return float(np.interp(fz, self._fzg, self._ck)), float(np.interp(fz, self._fzg, self._ca))

    def peaks(self, fz, gam, p, braking=True):
        """(Dx, Dy) peak longitudinal and lateral force [N] at mu_s = 1."""
        fz = max(fz, 1.0)
        if not self.mf:
            dy = self._mu_y(fz, gam) * fz
            return self.tp[6] * dy, dy
        return (float(self.tire.peak_fx(fz, gam, p, drive=not braking)), float(self.tire.peak_fy(fz, gam, p)))

    def forces(self, kappa, alpha, fz, gam, p, mu_s=1.0):
        """(Fx, Fy) [N]; kappa practical slip (+ drive), alpha [rad] (+ gives + Fy), gam turn-relative [deg]."""
        if fz <= 1.0:
            return 0.0, 0.0
        if self.mf and not self.no_long:
            t = self.tire
            g = t._gamma_mf(gam, t.sK * (1.0 if alpha >= 0 else -1.0))
            fx = float(t.m.fx(kappa, alpha, fz, g, p))
            fy = t.sK * float(t.m.fy(kappa, alpha, fz, g, p))
            return mu_s * fx, mu_s * fy
        if self.mf:
            Dx, Dy = self.peaks(fz, gam, p)
            Dx, Dy = Dx * mu_s, Dy * mu_s
            Ck, Ca = self.stiffness(fz)
        else:
            mu_y = self._mu_y(fz, gam) * mu_s
            Dy = mu_y * fz
            Dx = self.tp[6] * Dy
            Ck, Ca = self.kpl * fz, self.cpl * fz
        sx, sy = Ck * kappa / Dx, Ca * alpha / Dy
        s = math.hypot(sx, sy)
        if s < 1e-9:
            return Ck * kappa, Ca * alpha
        C = (self.CX * sx * sx + self.CY * sy * sy) / (s * s)
        s_pk = C * math.tan(math.pi / (2 * C))
        if s <= s_pk:
            f = math.sin(C * math.atan(s / C))
        else:
            z = (s - s_pk) / s_pk
            f = 1.0 - (1.0 - self.r_slide) * (1.0 - math.exp(-z * z))
        return Dx * f * sx / s, Dy * f * sy / s


# ======================================================================= one corner
class CornerTire:
    """One wheel: carcass-deflection slip states, wheel spin, temperature and deformation."""
    W_EPS = 0.05         # rad/s: below this the wheel counts as stopped (brake can hold it)
    V_LOW = 1.5          # m/s: slip is measured against at least this speed (stretched-string low-speed fix)
    K_PEAK = 2.29        # slip of peak Fx ~ K_PEAK * Dx / C_kappa (exact for the simple model, MF approx.)
    TARGET = 0.90        # ideal ABS / traction control aims at this fraction of the peak slip
    GAIN = 0.5           # slip controller gain [x C_kappa * R]

    def __init__(self, struct: TireStructure, forces: SteadyForces, thermal: TireThermal, p_ref, inertia, crr):
        self.S, self.F, self.Th = struct, forces, thermal
        self.p_ref = p_ref if p_ref is not None else struct.p_nom
        self.I = inertia
        self.crr = crr
        self.temps = thermal.start()
        self.mu_T = thermal.grip_factor(self.temps.surface)
        self.p = thermal.pressure(self.p_ref, self.temps.carcass)

    def rates(self, ux, uy, w, vx, vy, fz, lean_deg, T_drive, T_brake, ideal_abs=False, ideal_tc=True):
        """Time derivatives (du_x, du_y, dw) and the corner outputs for the current state.

        vx, vy: wheel-centre velocity in the wheel frame [m/s]; lean_deg: top of the wheel toward
        +y [deg] (turned into turn-relative camber from the force direction). ideal_abs / ideal_tc
        cap brake / drive torque just below what the tire can carry (driver modulation)."""
        p = self.p
        dz = self.S.deflection(fz, p) if fz > 0 else 0.0
        Rl, Re = self.S.radii(dz)
        Ck, Ca = self.F.stiffness(fz)
        sx_, sy_ = self.S.relaxation(Ck, Ca, p)
        avx = max(abs(vx), self.V_LOW)          # low-speed floor: keeps the carcass/wheel mode damped near standstill
        kap = max(min(ux / sx_, 3.0), -1.0)
        alp = math.atan(uy / sy_)
        gam = -lean_deg * (1.0 if alp >= 0 else -1.0)
        Fx, Fy = self.F.forces(kap, alp, fz, gam, p, self.mu_T) if fz > 1.0 else (0.0, 0.0)
        if ((ideal_abs and T_brake > 0) or (ideal_tc and T_drive > 0)) and fz > 1.0:
            # perfect driver / ABS / traction control: a slip controller. The torque allowed is what
            # the tire is reacting now plus a correction toward the target slip (TARGET x the slip of
            # peak force, reduced by the lateral force in use). Slip-based, so the wheel's own
            # inertia and the lateral demand are handled and it never runs over the peak.
            Dx, Dy = self.F.peaks(fz, gam, p, braking=T_brake > 0)
            Dx, Dy = Dx * self.mu_T, Dy * self.mu_T
            avail = math.sqrt(max(1.0 - (Fy / max(Dy, 1.0)) ** 2, 0.0025))
            k_t = self.TARGET * self.K_PEAK * Dx * avail / max(Ck, 1.0)
            gain = self.GAIN * Ck * Rl
            if ideal_abs and T_brake > 0:
                T_brake = min(T_brake, max(-Fx * Rl + self.crr * fz * Rl + gain * (k_t + kap), 0.0))
            if ideal_tc and T_drive > 0:
                T_drive = min(T_drive, max(Fx * Rl + gain * (k_t - kap), 0.0))
        T_tire = T_drive - Fx * Rl                     # everything except the brake and rolling loss
        if w > self.W_EPS:
            dw = (T_tire - T_brake - self.crr * fz * Rl) / self.I
        elif T_tire > T_brake:                         # stopped wheel breaks free
            dw = (T_tire - T_brake) / self.I
        else:                                          # brake holds the wheel: locked
            dw = 0.0 if w <= 0.0 else -w / 0.002
        vsx = w * Re - vx
        dux = vsx - avx / sx_ * ux
        duy = -vy - avx / sy_ * uy
        out = (Fx, Fy, kap, alp, Rl, Re, dz, vsx, gam, T_brake)
        return dux, duy, dw, out

    def update_thermal(self, dt, Fx, Fy, vsx, vy, fz, v):
        dz = self.S.deflection(fz, self.p) if fz > 0 else 0.0
        _, _, area = self.S.patch(dz)
        P = abs(Fx * vsx) + abs(Fy * vy)
        self.temps = self.Th.step(self.temps, dt, P, fz, v, float(area))
        self.mu_T = self.Th.grip_factor(self.temps.surface)
        self.p = self.Th.pressure(self.p_ref, self.temps.carcass)
        return P

    def deformation(self, fz, Fx, Fy, kap, alp, gam):
        """Deformation snapshot (all lengths in m, pressure in Pa)."""
        p = self.p
        dz = self.S.deflection(fz, p) if fz > 0 else 0.0
        Rl, Re = self.S.radii(dz)
        a, w, area = self.S.patch(dz)
        kx, ky = self.S.carcass_stiffness(p)
        Ck, Ca = self.F.stiffness(fz)
        Dx, Dy = self.F.peaks(fz, gam, p, braking=Fx < 0)
        b = self.S.brush(kap, alp, fz, a, Dx * self.mu_T, Dy * self.mu_T, Ck, Ca)
        return {"dz": dz, "R_loaded": Rl, "Re": Re, "patch_len": 2 * float(a), "patch_w": w, "area": float(area),
                "contact_p": fz / max(float(area), 1e-6), "carcass_x": Fx / kx, "carcass_y": Fy / ky,
                "tread_max": float(b["tread_max"]), "sliding": float(b["sliding"]),
                "util": math.hypot(Fx / max(Dx * self.mu_T, 1.0), Fy / max(Dy * self.mu_T, 1.0))}


def make_corners(veh):
    """Four CornerTire objects (fl, fr, rl, rr) for a Vehicle."""
    c = veh.cfg
    S = TireStructure(c)
    Fo = SteadyForces(veh)
    Th = TireThermal(c.tire_dynamics)
    td = c.tire_dynamics
    crr = veh.crr
    out = []
    for i in range(4):
        front = i < 2
        out.append(CornerTire(S, Fo, Th, veh.p_f if front else veh.p_r,
                              td.wheel_inertia_front if front else td.wheel_inertia_rear, crr))
    return out, S


# ======================================================================= quasi-steady lap
def lap_tire_channels(veh, lap, n_laps=1, thermal=True) -> pd.DataFrame:
    """Deformation, slip and temperature of each tire along a quasi-steady LapResult.

    Per-wheel forces come from the lap state (loads, longitudinal split by brake bias / diff,
    lateral split by each wheel's capacity). Slips are recovered from the forces with the brush
    model, and the temperatures integrate the resulting sliding power over the lap time
    (``n_laps`` repeats the lap, e.g. to see an endurance warm-up). The quasi-steady lap itself
    is not re-solved with the temperature-dependent grip; ``grip_T`` shows what it would change.
    Wheel keys: fo/fi/ro/ri = front/rear, outside/inside of the turn."""
    c = veh.cfg
    st = lap.state
    S = TireStructure(c)
    Th = TireThermal(c.tire_dynamics)
    tire = veh.tire
    v, ax, t = np.asarray(lap.v, float), np.asarray(lap.ax, float), np.asarray(lap.t, float)
    fxd, drive, brk = veh._wheel_fx(v, ax, st)
    sgn = np.where(brk > 0, -1.0, 1.0)
    fx = {k: sgn * np.asarray(fxd[k], float) for k in WHEELS}
    req_f, req_r = veh.axle_requirements(st)
    cap = veh._capacity(st, fx)
    out = {"s": np.asarray(lap.s, float), "t": t, "v": v, "ax": ax, "ay": np.asarray(lap.ay, float)}
    sl = {}
    for k in WHEELS:
        front = k[0] == "f"
        fz = np.asarray(st["Fz"][k], float)
        gam = np.asarray(st["camber"][k], float)
        p = veh.p_f if front else veh.p_r
        p = p if p is not None else S.p_nom
        o = "fo" if front else "ro"
        i = "fi" if front else "ri"
        share = cap[k] / np.maximum(cap[o] + cap[i], 1e-6)
        Fy = (req_f if front else req_r) * share
        Fx = fx[k]
        Dy = np.asarray(tire.peak_fy(fz, gam, p), float)
        Dx = np.where(Fx >= 0, tire.peak_fx(fz, gam, p, True), tire.peak_fx(fz, gam, p, False))
        if c.tires.model == "mf61":
            Ck = np.interp(fz, *_mf_ck(tire))
            Ca = np.asarray(tire.cornering_stiffness(np.maximum(fz, 1.0), 0.0, p), float)
        else:
            Ck = c.tire_dynamics.slip_stiffness_per_load * fz
            Ca = c.tires.cornering_stiffness_per_load * fz
        # brush inverse: utilisation u -> combined theoretical slip
        fxn, fyn = Fx / np.maximum(Dx, 1.0), Fy / np.maximum(Dy, 1.0)
        u = np.clip(np.hypot(fxn, fyn), 0.0, 0.999)
        psi = 1.0 - (1.0 - u) ** (1 / 3)
        safe = np.maximum(u, 1e-9)
        sx = np.where(u > 0, 3 * np.maximum(Dx, 1) * psi * fxn / safe / np.maximum(Ck, 1.0), 0.0)
        sy = np.where(u > 0, 3 * np.maximum(Dy, 1) * psi * fyn / safe / np.maximum(Ca, 1.0), 0.0)
        kap = sx / (1 - sx)
        alp = np.arctan(sy * (1 + kap))
        P_slide = np.abs(Fx) * np.abs(kap) * v + np.abs(Fy) * np.abs(np.tan(alp)) * v
        sl[k] = dict(fz=fz, Fx=Fx, Fy=Fy, kap=kap, alp=alp, Dx=Dx, Dy=Dy, Ck=Ck, Ca=Ca, P=P_slide, p=p, u=u)
    # temperatures (sequential in time)
    dt = np.r_[np.diff(t), 0.0]
    for k in WHEELS:
        d = sl[k]
        Ts = np.empty((n_laps, t.size))
        Tc = np.empty((n_laps, t.size))
        T = Th.start()
        dz0 = S.deflection_vec(d["fz"], d["p"])
        area = S.patch(dz0)[2]
        for L in range(n_laps):
            for j in range(t.size):
                Ts[L, j], Tc[L, j] = T.surface, T.carcass
                if thermal:
                    T = Th.step(T, dt[j], d["P"][j], d["fz"][j], v[j], area[j])
        d["Ts"], d["Tc"] = Ts[-1], Tc[-1]
    for k in WHEELS:
        d = sl[k]
        p_hot = Th.pressure(d["p"], d["Tc"])
        dz = S.deflection_vec(d["fz"], p_hot)
        Rl, Re = S.radii(dz)
        a, w, area = S.patch(dz)
        kx, ky = S.carcass_stiffness(np.mean(p_hot))
        b = S.brush(d["kap"], d["alp"], d["fz"], a, d["Dx"], d["Dy"], d["Ck"], d["Ca"])
        out.update({f"Fz_{k}": d["fz"], f"Fx_{k}": d["Fx"], f"Fy_{k}": d["Fy"], f"util_{k}": d["u"],
                    f"kappa_{k}": d["kap"], f"alpha_deg_{k}": np.degrees(d["alp"]),
                    f"dz_mm_{k}": 1e3 * dz, f"R_loaded_mm_{k}": 1e3 * Rl, f"Re_mm_{k}": 1e3 * Re,
                    f"patch_len_mm_{k}": 2e3 * a, f"contact_kPa_{k}": d["fz"] / np.maximum(area, 1e-6) / 1e3,
                    f"carcass_x_mm_{k}": 1e3 * d["Fx"] / kx, f"carcass_y_mm_{k}": 1e3 * d["Fy"] / ky,
                    f"tread_mm_{k}": 1e3 * b["tread_max"], f"slide_pct_{k}": 100 * b["sliding"],
                    f"P_slide_W_{k}": d["P"], f"T_surf_{k}": d["Ts"], f"T_carc_{k}": d["Tc"],
                    f"p_kPa_{k}": np.asarray(p_hot, float) / 1e3 + 0 * d["fz"],
                    f"grip_T_{k}": Th.grip_factor_vec(d["Ts"])})
    df = pd.DataFrame(out)
    df.attrs["notes"] = S.notes + ["slips are brush-model inverses of the lap forces (not re-solved)"]
    return df


def _mf_ck(tire):
    fzg = np.linspace(50, 4000, 80)
    return fzg, np.abs(np.asarray(tire.m.slip_stiffness(fzg), float))


# ======================================================================= braking simulator
@dc.dataclass
class BrakingResult:
    df: pd.DataFrame
    summary: dict
    notes: list


def _load_table(veh, v_max, ay_max=0.0, ax_lo=-3.0 * G0, ax_hi=1.0 * G0):
    """Wheel loads fo, fi, ro, ri on a (v, ax, |ay|) grid from the quasi-static vehicle (aero, pitch,
    roll, anti geometry). Returns a function (v, ax, ay_abs) -> (fo, fi, ro, ri)."""
    vg = np.linspace(0.0, max(v_max, 1.0) * 1.05, 30)
    ag = np.linspace(ax_lo, ax_hi, 33)
    yg = np.linspace(0.0, max(ay_max, 0.0) * 1.05 + 1e-3, 9 if ay_max > 0 else 2)
    V, A, Y = np.meshgrid(vg, ag, yg, indexing="ij")
    st = veh.state(V.ravel(), A.ravel(), Y.ravel(), _need_tire=False)
    grids = {k: [_Grid2(0.0, vg[1] - vg[0], vg.size, ax_lo, ag[1] - ag[0], ag.size,
                        np.asarray(st["Fz"][k], float).reshape(V.shape)[:, :, j]) for j in range(yg.size)]
             for k in WHEELS}
    dy, ny = yg[1] - yg[0], yg.size

    def f(v, ax, ay):
        fj = min(max(ay / dy, 0.0), ny - 1.000001)
        j = int(fj)
        tj = fj - j
        return tuple(g[j](v, ax) * (1 - tj) + g[j + 1](v, ax) * tj for g in (grids[k] for k in WHEELS))
    return f


def _series(src, name):
    """None, a constant, a callable of t, or (t, values) arrays -> function of t (or None)."""
    if src is None:
        return None
    if callable(src):
        return lambda t: float(src(t))
    if np.ndim(src) == 0:
        return lambda t: float(src)
    tt, vv = np.asarray(src[0], float), np.asarray(src[1], float)
    if tt.size != vv.size:
        raise ValueError(f"{name}: time and value arrays differ in length")
    return lambda t: float(np.interp(t, tt, vv))


def _pressure_source(pressure, cfg, p_max, ramp, t_apply):
    """Normalise the pressure input to a function t -> (p_front, p_rear) [Pa]."""
    br = cfg.brakes

    def rear_of(pf):
        if br.rear_pressure_ratio is not None:
            return max(br.rear_pressure_ratio * pf + br.rear_pressure_offset * (pf > 0), 0.0)
        return None

    if pressure is None:
        def f(t):
            pf = 0.0 if t < t_apply else min((t - t_apply) * ramp, p_max)
            return pf, rear_of(pf)
        return f
    if callable(pressure):
        def f(t):
            r = pressure(t)
            if np.ndim(r) == 0:
                return float(r), rear_of(float(r))
            return float(r[0]), (float(r[1]) if r[1] is not None else rear_of(float(r[0])))
        return f
    tt = np.asarray(pressure[0], float)
    pf = np.asarray(pressure[1], float)
    pr = np.asarray(pressure[2], float) if len(pressure) > 2 and pressure[2] is not None else None

    def f(t):
        a = float(np.interp(t, tt, pf))
        return a, (float(np.interp(t, tt, pr)) if pr is not None else rear_of(a))
    return f


def _alpha_for(ct, fy_req, kap, fz, lean, alpha_max=0.35):
    """Slip angle that gives lateral force fy_req at longitudinal slip kap (bisection). Returns
    (alpha, fy_reached); if the tire cannot reach fy_req, the slip angle of its largest Fy."""
    if fy_req <= 1.0 or fz <= 1.0:
        return 0.0, 0.0
    F = ct.F

    def fy(a):
        return F.forces(kap, a, fz, -lean, ct.p, ct.mu_T)[1]
    # largest Fy on a coarse sweep, then bisection on the rising side
    best_a, best_f = 0.0, 0.0
    for a in np.linspace(0.01, alpha_max, 15):
        f = fy(float(a))
        if f > best_f:
            best_a, best_f = float(a), f
    if best_f <= fy_req:
        return best_a, best_f
    lo, hi = 0.0, best_a
    for _ in range(22):
        mid = 0.5 * (lo + hi)
        if fy(mid) < fy_req:
            lo = mid
        else:
            hi = mid
    return hi, fy_req


def simulate_braking(veh, v0, pressure=None, ay=None, t_end=6.0, dt=5e-4, p_max=40e5, ramp=150e5, t_apply=0.1,
                     ideal_abs=False, pitch_tau=0.05, engine_brake=0.0, tire_temp_C=None, record_every=4,
                     stop_speed=0.5):
    """Braking with dynamic tires on all four wheels: wheel spin and lock-up, slip relaxation, pitch
    and roll load transfer, aero, tire deformation and temperature.

    pressure: None -> pedal ramp at ``ramp`` [Pa/s] from ``t_apply`` up to ``p_max`` [Pa] (front);
              callable t -> p_front or (p_front, p_rear);
              or (t, p_front[, p_rear]) arrays, e.g. a logged trace (seconds, Pa).
              The rear pressure, when not given, comes from brakes.rear_pressure_ratio/offset.
    ay:       lateral acceleration [m/s^2] held while braking (trail braking): None/0 = straight line,
              a constant, a callable of t, or (t, ay) arrays. The tires must then also make the
              lateral force (split front/rear by the CG position, left/right by load); the slip angle
              is solved each step, so braking capacity shrinks along the friction circle and the
              unloaded inside wheels lock first. Load transfer uses the vehicle's roll model.
    ideal_abs: slip-controlled brake torque (a perfect driver / ABS); False lets wheels lock.
    pitch_tau: first-order lag of the load transfer behind the accelerations [s].
    engine_brake: extra constant retarding force [N] (closed throttle in gear).
    tire_temp_C: starting tire temperature (default tire_dynamics.start_temp_C); use a warm value
              to replay a stop from the middle of a run.
    Wheels: fo/fi/ro/ri = front/rear, outside/inside of the turn (left = right in a straight line)."""
    c = veh.cfg
    gains = c.brakes.torque_gains()
    if gains is None:
        raise MissingDataError("braking simulation needs brakes.torque_per_bar_front/rear, or the brake hardware "
                               "(piston areas, pad_mu, rotor radii), or fit them: tire_dynamic.fit_brake_torque")
    kf, kr = gains
    src = _pressure_source(pressure, c, p_max, ramp, t_apply)
    if src(t_apply + 1.0)[1] is None:
        raise MissingDataError("rear line pressure unknown: give it, or set brakes.rear_pressure_ratio")
    ay_f = _series(ay, "ay")
    if ay_f is not None and not callable(ay) and np.ndim(ay) > 0:
        ay_max = float(np.nanmax(np.abs(np.asarray(ay[1], float))))
    elif ay_f is not None:
        ay_max = max(abs(ay_f(t)) for t in np.linspace(0, t_end, 200))
    else:
        ay_max = 0.0
    corners, S = make_corners(veh)               # fl, fr, rl, rr -> used here as fo, fi, ro, ri
    if tire_temp_C is not None:
        for ct in corners:
            ct.temps = TireTemps(tire_temp_C, tire_temp_C)
            ct.mu_T = ct.Th.grip_factor(tire_temp_C)
            ct.p = ct.Th.pressure(ct.p_ref, tire_temp_C)
    loads = _load_table(veh, v0, ay_max)
    m, a_cg, b_cg, L = veh.m, veh.a, veh.b, veh.L
    notes = list(S.notes)
    if veh.cfg.tires.pressure_front is None:
        notes.append(f"tire pressure not set - {S.p_nom / 1e3:.0f} kPa used")
    T = (kf, kf, kr, kr)
    # state: x, v, ax_lag, ay_lag, omega[4], u_x[4]
    fz0 = loads(v0, 0.0, abs(ay_f(0.0)) if ay_f else 0.0)
    y = [0.0, float(v0), 0.0, abs(ay_f(0.0)) if ay_f else 0.0] + \
        [v0 / S.radii(S.deflection(fz0[i], corners[i].p))[1] for i in range(4)] + [0.0] * 4

    def drag(v):
        return float(veh.aero(np.array(abs(v)))[2])

    def rhs(y, pf, pr, ay_now, alphas):
        v, axl, ayl = y[1], y[2], y[3]
        fz = loads(v, axl, ayl)
        out, dw, du = [], [], []
        Fx = 0.0
        for i in range(4):
            ct = corners[i]
            sy = ct.S.relaxation(*ct.F.stiffness(fz[i]), ct.p)[1]
            uy = sy * math.tan(alphas[i])                    # lateral slip held at the solved angle
            d_ux, _, d_w, o = ct.rates(y[8 + i], uy, y[4 + i], v, 0.0, fz[i], 0.0, 0.0,
                                       T[i] * (pf if i < 2 else pr), ideal_abs)
            Fx += o[0]
            out.append(o)
            dw.append(d_w)
            du.append(d_ux)
        Fx -= engine_brake if v > 0.5 else 0.0
        ax = (Fx - drag(v)) / m
        return [v, ax, (ax - axl) / pitch_tau, (ay_now - ayl) / pitch_tau] + dw + du, (fz, out, ax)

    rec = []
    t = 0.0
    step = 0
    n_max = int(t_end / dt) + 1
    alphas = [0.0] * 4
    fy_short = 0.0
    while step < n_max:
        pf, pr = src(t)
        ay_now = abs(ay_f(t)) if ay_f else 0.0
        if ay_now > 0:            # slip angles that carry the lateral force, held over the step
            fz = loads(y[1], y[2], y[3])
            Ttot = m * y[3]
            req = (Ttot * b_cg / L, Ttot * a_cg / L)
            fy_short = 0.0
            for i in range(4):
                o_, i_ = (0, 1) if i < 2 else (2, 3)
                share = fz[i] / max(fz[o_] + fz[i_], 1.0)
                sx_ = corners[i].S.relaxation(*corners[i].F.stiffness(fz[i]), corners[i].p)[0]
                kap = max(min(y[8 + i] / sx_, 3.0), -1.0)
                alphas[i], got = _alpha_for(corners[i], req[0 if i < 2 else 1] * share, kap, fz[i], 0.0)
                fy_short += req[0 if i < 2 else 1] * share - got
        else:
            alphas = [0.0] * 4
        k1, info = rhs(y, pf, pr, ay_now, alphas)
        k2, _ = rhs([p + 0.5 * dt * q for p, q in zip(y, k1)], pf, pr, ay_now, alphas)
        k3, _ = rhs([p + 0.5 * dt * q for p, q in zip(y, k2)], pf, pr, ay_now, alphas)
        k4, _ = rhs([p + dt * q for p, q in zip(y, k3)], pf, pr, ay_now, alphas)
        fz, outs, ax = info
        for i in range(4):        # temperatures, once per step; lateral sliding speed ~ v tan(alpha)
            o = outs[i]
            corners[i].update_thermal(dt, o[0], o[1], o[7], y[1] * math.tan(o[3]), fz[i], y[1])
        if step % record_every == 0:
            row = {"t": t, "x": y[0], "v": y[1], "ax_g": ax / G0, "ay_g": y[3] / G0, "p_f_bar": pf / 1e5,
                   "p_r_bar": pr / 1e5, "lateral_shortfall_N": fy_short}
            for i, tag in enumerate(WHEELS):
                ct, o = corners[i], outs[i]
                Fx_, Fy_, kap, alp, Rl, Re, dz, vsx, gam, Tb = o
                d = ct.deformation(fz[i], Fx_, Fy_, kap, alp, gam)
                row.update({f"Fz_{tag}": fz[i], f"Fx_{tag}": Fx_, f"Fy_{tag}": Fy_, f"kappa_{tag}": kap,
                            f"alpha_deg_{tag}": math.degrees(alp), f"T_brake_{tag}": Tb,
                            f"omega_{tag}": y[4 + i], f"wheel_v_{tag}": y[4 + i] * Re, f"util_{tag}": d["util"],
                            f"dz_mm_{tag}": 1e3 * d["dz"], f"R_loaded_mm_{tag}": 1e3 * d["R_loaded"],
                            f"Re_mm_{tag}": 1e3 * d["Re"], f"patch_len_mm_{tag}": 1e3 * d["patch_len"],
                            f"contact_kPa_{tag}": d["contact_p"] / 1e3, f"carcass_x_mm_{tag}": 1e3 * d["carcass_x"],
                            f"carcass_y_mm_{tag}": 1e3 * d["carcass_y"],
                            f"tread_mm_{tag}": 1e3 * d["tread_max"], f"slide_pct_{tag}": 100 * d["sliding"],
                            f"T_surf_{tag}": ct.temps.surface, f"T_carc_{tag}": ct.temps.carcass,
                            f"grip_T_{tag}": ct.mu_T, f"p_tire_kPa_{tag}": ct.p / 1e3, f"locked_{tag}": kap < -0.9})
            rec.append(row)
        y = [p + dt / 6 * (q1 + 2 * q2 + 2 * q3 + q4) for p, q1, q2, q3, q4 in zip(y, k1, k2, k3, k4)]
        for i in range(4, 8):
            y[i] = max(y[i], 0.0)            # wheels do not spin backwards
        t += dt
        step += 1
        if y[1] <= stop_speed and t > t_apply:
            break
    df = pd.DataFrame(rec)
    on = df["p_f_bar"] > 0.5
    t_on = float(df.loc[on, "t"].iloc[0]) if on.any() else 0.0
    x_on = float(np.interp(t_on, df["t"], df["x"]))
    lock = lambda ks: float(df[[f"locked_{k}" for k in ks]].any(axis=1).sum() * dt * record_every)
    front, rear = ("fo", "fi"), ("ro", "ri")
    summ = {"v0_kph": 3.6 * v0, "v_end_kph": 3.6 * float(df["v"].iloc[-1]),
            "stop_time_s": float(df["t"].iloc[-1] - t_on), "stop_distance_m": float(df["x"].iloc[-1] - x_on),
            "peak_decel_g": float(-df["ax_g"].min()),
            "mean_decel_g": float((v0 - df["v"].iloc[-1]) / max(df["t"].iloc[-1] - t_on, 1e-3) / G0),
            "front_locked_s": lock(front), "rear_locked_s": lock(rear),
            "peak_dz_front_mm": float(df[[f"dz_mm_{k}" for k in front]].max().max()),
            "peak_carcass_x_front_mm": float(df[[f"carcass_x_mm_{k}" for k in front]].abs().max().max()),
            "peak_tread_front_mm": float(df[[f"tread_mm_{k}" for k in front]].max().max()),
            "max_patch_front_mm": float(df[[f"patch_len_mm_{k}" for k in front]].max().max()),
            "min_patch_rear_mm": float(df[[f"patch_len_mm_{k}" for k in rear]].min().min()),
            "dT_surface_front_C": float(df["T_surf_fo"].iloc[-1] - df["T_surf_fo"].iloc[0]),
            "max_lateral_shortfall_N": float(df["lateral_shortfall_N"].max()),
            "ideal_abs": ideal_abs}
    if summ["max_lateral_shortfall_N"] > 50:
        notes.append("the tires could not hold the requested lateral acceleration for part of the stop "
                     "(lateral_shortfall_N): the car would run wide there")
    return BrakingResult(df, summ, notes)


# ======================================================================= calibration from a log
def fit_brake_torque(df, veh, p_min=3.0, v_min=5.0, max_lag=0.3, front_bias=None):
    """Brake torque per unit line pressure from a logged run.

    ``df`` columns: t [s], v_s [m/s], ax_speed [g, negative braking], p_f [bar], and p_r [bar] if a
    rear sensor exists (this is the frame tools/brake_analysis.build_frame makes). The front/rear
    split cannot be separated from the deceleration alone (the two pressures move together), so
    it is fixed by brakes.front_bias (force fraction) at the median braking pressures.
    Fits  m*decel - drag = (2 kf p_f + 2 kr p_r)/R_loaded + c0  with the pressure delayed by the
    best lag (pitch and carcass take time). Returns a dict ready for cfg.set()."""
    from scipy.optimize import least_squares
    c = veh.cfg
    bias = front_bias if front_bias is not None else c.brakes.front_bias
    if bias is None:
        raise MissingDataError("brakes.front_bias needed to split front/rear brake torque")
    from scipy import signal
    S = TireStructure(c)
    t = df["t"].to_numpy(float)
    v = df["v_s"].to_numpy(float)
    fs = 1 / np.nanmedian(np.diff(t))
    pf = df["p_f"].to_numpy(float)
    pr = df["p_r"].to_numpy(float) if "p_r" in df else None
    # the pressure gets exactly the filter the deceleration signal had, so the two line up
    if "ax_imu" in df and df["ax_imu"].notna().mean() > 0.9:
        dec = -df["ax_imu"].to_numpy(float) * G0
        b, a = signal.butter(2, 3.0 / (fs / 2))
        filt = lambda x: signal.filtfilt(b, a, pd.Series(x).interpolate(limit_direction="both").to_numpy())
        src = "IMU (3 Hz)"
    else:
        dec = -df["ax_speed"].to_numpy(float) * G0
        win = int(0.9 * fs) | 1
        filt = lambda x: signal.savgol_filter(pd.Series(x).interpolate(limit_direction="both").to_numpy(), win, 2)
        src = "d(speed)/dt (0.9 s)"
    pf = filt(pf)
    pr = filt(pr) if pr is not None else None
    m = veh.m
    D = np.asarray(veh.aero(np.nan_to_num(v)), float)[2]
    F_brake = m * dec - D
    base = (pf > p_min) & (v > v_min) & np.isfinite(F_brake)
    if pr is not None:
        base &= np.isfinite(pr)
        ratio = float(np.nanmedian(pf[base] / np.maximum(pr[base], 0.3)))
        rho = ratio * (1 - bias) / bias               # kr / kf
        slope, off = np.polyfit(pf[base], pr[base], 1)
    else:
        rho, slope, off = None, None, 0.0
    fzf = m * G0 * veh.ff / 2
    Rl = S.radii(S.deflection(fzf, veh.p_f or S.p_nom))[0]
    best = None
    for lag in np.arange(0.0, max_lag + 1e-9, 0.02):
        sh = int(round(lag * fs))
        pfl = np.roll(pf, sh)
        prl = np.roll(pr, sh) if pr is not None else None
        mk = base & (np.arange(t.size) >= sh)
        if mk.sum() < 30:
            continue
        if prl is not None:
            X = 2 * (pfl[mk] + rho * prl[mk]) * 1e5 / Rl
        else:
            X = 2 * pfl[mk] * 1e5 / Rl / bias          # rear share implied by the bias
        res = least_squares(lambda q: q[0] * X + q[1] - F_brake[mk], x0=[10 / 1e5, 0.0], loss="soft_l1",
                            f_scale=200.0, x_scale=[1e-4, 100.0])
        r2 = 1 - np.sum(res.fun ** 2) / np.sum((F_brake[mk] - F_brake[mk].mean()) ** 2)
        if best is None or r2 > best["r2"]:
            best = {"lag_s": float(lag), "kf": float(res.x[0]), "c0_N": float(res.x[1]), "r2": float(r2), "n": int(mk.sum())}
    if best is None:
        raise ValueError("not enough braking samples to fit brake torque")
    kf = best["kf"]
    kr = kf * rho if rho is not None else kf * (1 - bias) / bias
    out = {"brakes.torque_per_bar_front": kf, "brakes.torque_per_bar_rear": kr,
           "fit": {**best, "kf_Nm_per_bar": kf * 1e5, "kr_Nm_per_bar": kr * 1e5, "R_loaded_m": Rl,
                   "front_bias_used": bias, "decel_source": src}}
    if slope is not None:
        out["brakes.rear_pressure_ratio"] = float(slope)
        out["brakes.rear_pressure_offset"] = float(off) * 1e5
    return out
