"""Quasi-steady-state lap simulation and the four dynamic events.

Road (``Track.z`` / ``bank`` / ``grip``): on a track with elevation, banking or a surface grip map the
solver works per station with

    gt = -g grade / sqrt(1 + grade^2)          gravity along the track (+ forward)
    gn =  g sin(bank) / sqrt(1 + grade^2)      gravity across it (+ left, i.e. into a left turn)
    c  =  cos(bank) / sqrt(1 + grade^2)        share of the weight pressing the car on the road
    f(v) = grip (m g c + F_aero(v)) / (m g + F_aero(v))      tire capacity relative to the flat road

The tires must supply  ay_tire = v^2 kappa - gn  and  ax_tire = ax - gt.  Their envelope is the
flat-road GGV with every tire force scaled by f: lateral limit f ay_max(v), longitudinal
f a_GGV(v, ay_tire / f) (resistance taken out before scaling). The power limit is not scaled
(it is taken from the powertrain separately), and gravity is added to whichever branch limits.
The road is a plane tilted by the local grade and banking: crests and dips, and the different
load transfer on a slope, are not modelled; ``state`` (loads, roll, pitch) is evaluated at the
tire accelerations with the flat-road weight. A flat track with grip 1 takes the original path
unchanged.
"""
from __future__ import annotations

import dataclasses as dc

import numpy as np
import pandas as pd

from . import scoring
from .config import CarConfig, MissingDataError
from .track import Track, circle, load_track, straight
from .units import G0
from .vehicle import GGV, Vehicle


@dc.dataclass
class LapResult:
    track: Track
    s: np.ndarray
    v: np.ndarray
    ax: np.ndarray          # dv/dt along the path (includes gravity on a slope)
    ay: np.ndarray          # v^2 kappa
    t: np.ndarray
    time: float
    state: dict             # vehicle state at the tire accelerations
    energy_J: float
    road: dict | None = None    # per station: grade, bank, grip, ax_tire, ay_tire (None: flat road, grip 1)

    def frame(self) -> pd.DataFrame:
        d = {"s": self.s, "t": self.t, "v": self.v, "ax": self.ax, "ay": self.ay,
             "roll_deg": self.state["roll_deg"], "pitch_deg": self.state["pitch_deg"]}
        if self.road is not None:
            for k in ("grade", "bank", "grip", "ax_tire", "ay_tire"):
                d[k] = self.road[k]
        for k in ("fo", "fi", "ro", "ri"):
            d[f"Fz_{k}"] = self.state["Fz"][k]
            d[f"camber_{k}"] = self.state["camber"][k]
            d[f"damper_{k}"] = self.state["damper"][k]
        return pd.DataFrame(d)


def _v_lateral_limit(kappa, ggv: GGV, v_top):
    vv = np.linspace(0.5, v_top, 600)
    A = ggv.ay_lim(vv)
    ak = np.abs(kappa)[:, None]
    ok = vv[None, :] ** 2 * ak <= A[None, :]
    idx = np.where(ok.any(1), ok.shape[1] - 1 - np.argmax(ok[:, ::-1], axis=1), 0)
    return vv[idx]


# --------------------------------------------------------------------------- road
def road_profile(track: Track):
    """Per-station grade, banking, grip and the gravity terms of a track (module docstring), or None
    when the track is flat with grip 1 (or has no road data)."""
    if not hasattr(track, "at"):
        return None
    s = track.s
    grade, bank, grip = track.at("grade", s, 0.0), track.at("bank", s, 0.0), track.at("grip", s, 1.0)
    if not (np.any(grade != 0) or np.any(bank != 0) or np.any(grip != 1)):
        return None
    cg = 1.0 / np.sqrt(1.0 + grade ** 2)
    return {"grade": grade, "bank": bank, "grip": grip, "gt": -G0 * grade * cg, "gn": G0 * np.sin(bank) * cg,
            "c": np.cos(bank) * cg}


class RoadEnvelope:
    """Tire envelope of a vehicle on a track's road (module docstring). ``ggv``: a GGV whose
    accelerations are tire-limited (the traction GGV) - its brake table may come from any GGV."""

    def __init__(self, track: Track, veh, prof: dict, v_max: float):
        self.p, self.k = prof, np.asarray(track.kappa, float)
        self.m = veh.m
        self.vg = np.linspace(0.0, max(v_max, 1.0) * 1.05, 400)
        try:
            self.Fa = np.asarray(veh.aero_model.evaluate(self.vg)["F"], float)
        except Exception:                          # no aero model: no downforce
            self.Fa = np.zeros_like(self.vg)
        self.R = np.asarray(veh.resist(self.vg), float)
        self._gt, self._gn, self._c, self._grip = prof["gt"], prof["gn"], prof["c"], prof["grip"]

    def _i(self, v):
        dv = self.vg[1] - self.vg[0]
        j = min(max(v / dv, 0.0), self.vg.size - 1.000001)
        j0 = int(j)
        return j0, j - j0

    def _lin(self, arr, v):
        j0, w = self._i(v)
        return arr[j0] * (1 - w) + arr[j0 + 1] * w

    def factor(self, i, v):
        Fa = self._lin(self.Fa, v)
        W = self.m * G0
        return self._grip[i] * (W * self._c[i] + Fa) / (W + Fa)

    def ay_tire(self, i, v):
        return v * v * self.k[i] - self._gn[i]

    def acc(self, i, v, tggv):
        """Tire-limited acceleration along the path (with gravity)."""
        f = self.factor(i, v)
        a_flat = float(tggv.acc(v, self.ay_tire(i, v) / f))
        return f * a_flat + (f - 1.0) * self._lin(self.R, v) / self.m + self._gt[i]

    def brk(self, i, v, ggv):
        """Largest deceleration along the path (positive; with gravity)."""
        f = self.factor(i, v)
        d_flat = float(ggv.brk(v, self.ay_tire(i, v) / f))
        return f * d_flat + (1.0 - f) * self._lin(self.R, v) / self.m - self._gt[i]

    def v_lateral_limit(self, ggv, v_top):
        """Highest speed per station whose tire lateral demand fits the scaled envelope."""
        vv = np.linspace(0.5, v_top, 600)
        A = ggv.ay_lim(vv)
        Fa = np.interp(vv, self.vg, self.Fa)
        W = self.m * G0
        f = self._grip[:, None] * (W * self._c[:, None] + Fa[None, :]) / (W + Fa[None, :])
        need = np.abs(vv[None, :] ** 2 * self.k[:, None] - self._gn[:, None])
        ok = need <= f * A[None, :]
        idx = np.where(ok.any(1), ok.shape[1] - 1 - np.argmax(ok[:, ::-1], axis=1), 0)
        return vv[idx]

    def tire_accelerations(self, v, ax):
        """(ax_tire, ay_tire) along a solved speed profile."""
        return ax - self._gt, v ** 2 * self.k - self._gn


def traction_envelope(veh, ggv: GGV):
    """Tire-only GGV on the same grid as ``ggv`` (cached on the vehicle)."""
    key = (float(ggv.v[-1]), len(ggv.v), len(ggv.frac))
    cache = veh.__dict__.setdefault("_tggv_cache", {})
    if key not in cache:
        cache[key] = veh.traction_ggv(v_max=key[0], n_v=key[1], n_ay=key[2])
    return cache[key]


def top_speed(ggv: GGV):
    a0 = ggv.acc(ggv.v, np.zeros_like(ggv.v))
    neg = np.where(a0 <= 1e-3)[0]
    return float(ggv.v[neg[0]]) if neg.size else float(ggv.v[-1])


def solve(track: Track, veh: Vehicle, ggv: GGV, v0: float | None = 0.0, flying: bool = False,
          tggv: GGV | None = None) -> LapResult:
    """Quasi-steady lap. On a track with road data (grade / banking / grip) the tire-only envelope
    ``tggv`` is needed as well; by default it is built once from the vehicle on ``ggv``'s grid."""
    s, k = track.s, track.kappa
    ds = np.diff(s, append=s[-1] + (s[-1] - s[-2]))
    n = s.size
    prof = road_profile(track)
    if prof is None:
        vtop = top_speed(ggv)
        vlim = np.minimum(_v_lateral_limit(k, ggv, vtop), vtop)
        acc = lambda i, v: float(ggv.acc(v, v * v * k[i]))
        brk = lambda i, v: float(ggv.brk(v, v * v * k[i]))
    else:
        vtop = float(ggv.v[-1])                     # downhill the car can pass its flat-road top speed
        tggv = tggv or traction_envelope(veh, ggv)
        env = RoadEnvelope(track, veh, prof, vtop)
        vlim = np.minimum(env.v_lateral_limit(tggv, vtop), vtop)
        try:
            veh.pt.force(1.0)
            F_pow = lambda v: float(veh.pt.force(v))
        except Exception:                           # no powertrain data: tire-limited
            F_pow = lambda v: np.inf
        R_drive = getattr(veh, "resist_drive", veh.resist)
        m = veh.m

        def acc(i, v):
            a_pow = (F_pow(v) - float(R_drive(v))) / m + prof["gt"][i]
            return min(env.acc(i, v, tggv), a_pow)

        brk = lambda i, v: env.brk(i, v, ggv)

    def forward(v_start):
        v = np.empty(n)
        v[0] = min(v_start, vlim[0])
        for i in range(n - 1):
            a = acc(i, v[i])
            v[i + 1] = min(np.sqrt(max(v[i] ** 2 + 2 * a * ds[i], 0.01)), vlim[i + 1])
        return v

    def backward(v_end):
        v = np.empty(n)
        v[-1] = min(v_end, vlim[-1])
        for i in range(n - 1, 0, -1):
            d = brk(i, v[i])
            v[i - 1] = min(np.sqrt(max(v[i] ** 2 + 2 * d * ds[i - 1], 0.01)), vlim[i - 1])
        return v

    if flying:   # periodic: iterate start speed = end speed
        vs = vlim[0]
        for _ in range(4):
            vf = forward(vs)
            vb = backward(vf[-1])
            v = np.minimum(vf, vb)
            if abs(v[0] - vs) < 0.01:
                break
            vs = v[-1]
    else:
        vf = forward(v0 if v0 is not None else vlim[0])
        v = np.minimum(vf, backward(vtop))
    vm = np.maximum(0.5 * (v[:-1] + v[1:]), 0.05)
    dt = np.diff(s) / vm
    t = np.r_[0, np.cumsum(dt)]
    ax = np.r_[np.diff(v ** 2) / (2 * np.diff(s)), 0.0]
    ay = v ** 2 * k
    ax_t, ay_t, road = _tire_side(track, prof, v, ax, ay)
    st = veh.state(v, ax_t, ay_t)
    drive = np.maximum(veh.m * ax_t + veh.resist_state(st), 0.0)
    eta = veh.cfg.powertrain.drivetrain_efficiency or 1.0
    energy = float(np.sum((drive * v / eta)[:-1] * dt))
    return LapResult(track, s, v, ax, ay, t, float(t[-1]), st, energy, road)


def _tire_side(track, prof, v, ax, ay):
    """Tire accelerations (ax - gt, v^2 kappa - gn) and the result's road record (None when flat)."""
    if prof is None:
        return ax, ay, None
    ax_t, ay_t = ax - prof["gt"], ay - prof["gn"]
    return ax_t, ay_t, {"grade": prof["grade"], "bank": prof["bank"], "grip": prof["grip"], "ax_tire": ax_t,
                        "ay_tire": ay_t}


def skidpad_time(veh: Vehicle, ggv: GGV, radius: float):
    """Steady-state circle: v^2/R = ay_max(v). Returns (time per lap, speed)."""
    from scipy.optimize import brentq
    f = lambda v: ggv.ay_lim(v) - v ** 2 / radius
    v = brentq(f, ggv.v[0], ggv.v[-1]) if f(ggv.v[-1]) < 0 else ggv.v[-1]
    return 2 * np.pi * radius / v, v


@dc.dataclass
class EventResults:
    times: dict
    points: dict
    laps: dict
    ggv: GGV
    vehicle: Vehicle
    notes: list

    def table(self) -> pd.DataFrame:
        rows = []
        for e in ("acceleration", "skidpad", "autocross", "endurance"):
            if e in self.times:
                rows.append({"event": e, "time_s": self.times[e], "points": self.points.get(e)})
        df = pd.DataFrame(rows).set_index("event")
        return df


def run_events(cfg: CarConfig, tracks: dict | None = None, ggv: GGV | None = None,
               events=("acceleration", "skidpad", "autocross", "endurance")) -> EventResults:
    """Simulate the dynamic events. ``tracks`` may supply Track objects for
    'autocross' and 'endurance'; otherwise the config's track files are used."""
    veh = Vehicle(cfg)
    ggv = ggv or veh.ggv()
    ev = cfg.events
    times, laps, notes = {}, {}, list(veh.warnings)
    tracks = dict(tracks or {})
    if "acceleration" in events:
        r = solve(straight(ev.accel_length, cfg.sim.ds), veh, ggv, v0=0.0)
        times["acceleration"], laps["acceleration"] = r.time, r
    if "skidpad" in events:
        tl, vs = skidpad_time(veh, ggv, ev.skidpad_radius)
        times["skidpad"] = tl
        laps["skidpad"] = solve(circle(ev.skidpad_radius), veh, ggv, flying=True)
    for e, f in (("autocross", ev.autocross_track), ("endurance", ev.endurance_track)):
        if e not in events:
            continue
        tr = tracks.get(e) or (load_track(f, cfg.sim.ds) if f else None)
        if tr is None:
            notes.append(f"{e}: no track supplied (events.{e}_track) - not simulated")
            continue
        if e == "autocross":
            r = solve(tr, veh, ggv, v0=0.0)
            times[e], laps[e] = r.time, r
        else:
            first = solve(tr, veh, ggv, v0=0.0)
            fly = solve(tr, veh, ggv, flying=True)
            n = max(1, int(round(ev.endurance_distance / tr.length)))
            times[e] = first.time + (n - 1) * fly.time
            laps[e] = fly
            laps["endurance_energy_J"] = first.energy_J + (n - 1) * fly.energy_J
            notes.append(f"endurance: {n} laps of {tr.length:.0f} m (driver change not modelled)")
    pts = {}
    for e, t in times.items():
        tmin = getattr(ev, f"tmin_{'accel' if e == 'acceleration' else e}")
        if tmin is not None:
            pts[e] = scoring.points(e, t, tmin)
    return EventResults(times, pts, laps, ggv, veh, notes)
