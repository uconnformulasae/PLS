"""Quasi-steady-state lap simulation and the four dynamic events."""
from __future__ import annotations

import dataclasses as dc

import numpy as np
import pandas as pd

from . import scoring
from .config import CarConfig, MissingDataError
from .track import Track, circle, load_track, straight
from .units import G0
from .vehicle import GGV, Vehicle


@dc.dataclass
class LapResult:
    track: Track
    s: np.ndarray
    v: np.ndarray
    ax: np.ndarray
    ay: np.ndarray
    t: np.ndarray
    time: float
    state: dict
    energy_J: float

    def frame(self) -> pd.DataFrame:
        d = {"s": self.s, "t": self.t, "v": self.v, "ax": self.ax, "ay": self.ay,
             "roll_deg": self.state["roll_deg"], "pitch_deg": self.state["pitch_deg"]}
        for k in ("fo", "fi", "ro", "ri"):
            d[f"Fz_{k}"] = self.state["Fz"][k]
            d[f"camber_{k}"] = self.state["camber"][k]
            d[f"damper_{k}"] = self.state["damper"][k]
        return pd.DataFrame(d)


def _v_lateral_limit(kappa, ggv: GGV, v_top):
    vv = np.linspace(0.5, v_top, 600)
    A = ggv.ay_lim(vv)
    ak = np.abs(kappa)[:, None]
    ok = vv[None, :] ** 2 * ak <= A[None, :]
    idx = np.where(ok.any(1), ok.shape[1] - 1 - np.argmax(ok[:, ::-1], axis=1), 0)
    return vv[idx]


def top_speed(ggv: GGV):
    a0 = ggv.acc(ggv.v, np.zeros_like(ggv.v))
    neg = np.where(a0 <= 1e-3)[0]
    return float(ggv.v[neg[0]]) if neg.size else float(ggv.v[-1])


def solve(track: Track, veh: Vehicle, ggv: GGV, v0: float | None = 0.0, flying: bool = False) -> LapResult:
    s, k = track.s, track.kappa
    ds = np.diff(s, append=s[-1] + (s[-1] - s[-2]))
    vtop = top_speed(ggv)
    vlim = np.minimum(_v_lateral_limit(k, ggv, vtop), vtop)
    n = s.size

    def forward(v_start):
        v = np.empty(n)
        v[0] = min(v_start, vlim[0])
        for i in range(n - 1):
            a = float(ggv.acc(v[i], v[i] ** 2 * k[i]))
            v[i + 1] = min(np.sqrt(max(v[i] ** 2 + 2 * a * ds[i], 0.01)), vlim[i + 1])
        return v

    def backward(v_end):
        v = np.empty(n)
        v[-1] = min(v_end, vlim[-1])
        for i in range(n - 1, 0, -1):
            d = float(ggv.brk(v[i], v[i] ** 2 * k[i]))
            v[i - 1] = min(np.sqrt(v[i] ** 2 + 2 * d * ds[i - 1]), vlim[i - 1])
        return v

    if flying:   # periodic: iterate start speed = end speed
        vs = vlim[0]
        for _ in range(4):
            vf = forward(vs)
            vb = backward(vf[-1])
            v = np.minimum(vf, vb)
            if abs(v[0] - vs) < 0.01:
                break
            vs = v[-1]
    else:
        vf = forward(v0 if v0 is not None else vlim[0])
        v = np.minimum(vf, backward(vtop))
    vm = np.maximum(0.5 * (v[:-1] + v[1:]), 0.05)
    dt = np.diff(s) / vm
    t = np.r_[0, np.cumsum(dt)]
    ax = np.r_[np.diff(v ** 2) / (2 * np.diff(s)), 0.0]
    ay = v ** 2 * k
    st = veh.state(v, ax, ay)
    drive = np.maximum(veh.m * ax + veh.resist_state(st), 0.0)
    eta = veh.cfg.powertrain.drivetrain_efficiency or 1.0
    energy = float(np.sum((drive * v / eta)[:-1] * dt))
    return LapResult(track, s, v, ax, ay, t, float(t[-1]), st, energy)


def skidpad_time(veh: Vehicle, ggv: GGV, radius: float):
    """Steady-state circle: v^2/R = ay_max(v). Returns (time per lap, speed)."""
    from scipy.optimize import brentq
    f = lambda v: ggv.ay_lim(v) - v ** 2 / radius
    v = brentq(f, ggv.v[0], ggv.v[-1]) if f(ggv.v[-1]) < 0 else ggv.v[-1]
    return 2 * np.pi * radius / v, v


@dc.dataclass
class EventResults:
    times: dict
    points: dict
    laps: dict
    ggv: GGV
    vehicle: Vehicle
    notes: list

    def table(self) -> pd.DataFrame:
        rows = []
        for e in ("acceleration", "skidpad", "autocross", "endurance"):
            if e in self.times:
                rows.append({"event": e, "time_s": self.times[e], "points": self.points.get(e)})
        df = pd.DataFrame(rows).set_index("event")
        return df


def run_events(cfg: CarConfig, tracks: dict | None = None, ggv: GGV | None = None,
               events=("acceleration", "skidpad", "autocross", "endurance")) -> EventResults:
    """Simulate the dynamic events. ``tracks`` may supply Track objects for
    'autocross' and 'endurance'; otherwise the config's track files are used."""
    veh = Vehicle(cfg)
    ggv = ggv or veh.ggv()
    ev = cfg.events
    times, laps, notes = {}, {}, list(veh.warnings)
    tracks = dict(tracks or {})
    if "acceleration" in events:
        r = solve(straight(ev.accel_length, cfg.sim.ds), veh, ggv, v0=0.0)
        times["acceleration"], laps["acceleration"] = r.time, r
    if "skidpad" in events:
        tl, vs = skidpad_time(veh, ggv, ev.skidpad_radius)
        times["skidpad"] = tl
        laps["skidpad"] = solve(circle(ev.skidpad_radius), veh, ggv, flying=True)
    for e, f in (("autocross", ev.autocross_track), ("endurance", ev.endurance_track)):
        if e not in events:
            continue
        tr = tracks.get(e) or (load_track(f, cfg.sim.ds) if f else None)
        if tr is None:
            notes.append(f"{e}: no track supplied (events.{e}_track) - not simulated")
            continue
        if e == "autocross":
            r = solve(tr, veh, ggv, v0=0.0)
            times[e], laps[e] = r.time, r
        else:
            first = solve(tr, veh, ggv, v0=0.0)
            fly = solve(tr, veh, ggv, flying=True)
            n = max(1, int(round(ev.endurance_distance / tr.length)))
            times[e] = first.time + (n - 1) * fly.time
            laps[e] = fly
            laps["endurance_energy_J"] = first.energy_J + (n - 1) * fly.energy_J
            notes.append(f"endurance: {n} laps of {tr.length:.0f} m (driver change not modelled)")
    pts = {}
    for e, t in times.items():
        tmin = getattr(ev, f"tmin_{'accel' if e == 'acceleration' else e}")
        if tmin is not None:
            pts[e] = scoring.points(e, t, tmin)
    return EventResults(times, pts, laps, ggv, veh, notes)
