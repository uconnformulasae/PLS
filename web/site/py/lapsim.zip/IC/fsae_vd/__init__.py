"""fsae_vd - vehicle-dynamics section of the predictive lap simulation.

Typical use (see notebooks/vehicle_dynamics.ipynb):

    from fsae_vd import load_config, Vehicle, run_events
    cfg = load_config("configs/ct17_baseline.yaml")
    cfg.set("rear.spring_rate", "275 lbf/in")      # change anything
    results = run_events(cfg)
"""
from .config import CarConfig, MissingDataError, load_config, save_config
from .io_data import load_log, load_ttc
from .processing import process_log, qc_table, distance_ensemble
from .vehicle import Vehicle
from .lapsim import run_events, solve
from . import identification, kinematics, optimize, plots, scoring, suspension, track, validate
from . import hardpoints, adjust, reports, mf61, mf61_fit
from . import aero, aero_study, multibody, plots_aero
from . import aero_cfd
from . import brakes

__all__ = ["CarConfig", "MissingDataError", "load_config", "save_config", "load_log", "load_ttc",
           "process_log", "qc_table", "distance_ensemble", "Vehicle", "run_events", "solve",
           "identification", "kinematics", "optimize", "plots", "scoring", "suspension", "track", "validate",
           "hardpoints", "adjust", "reports", "mf61", "mf61_fit",
           "aero", "aero_study", "multibody", "plots_aero", "aero_cfd", "brakes"]
