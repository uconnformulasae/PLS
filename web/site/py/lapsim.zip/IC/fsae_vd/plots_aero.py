"""Aerodynamics figures. Every function returns a matplotlib Figure.

Same visual system as fsae_pt.plots_pt: categorical colours in fixed order, one-hue ramps for
magnitudes, red/blue diverging with a grey midpoint for signed quantities, one y-scale per axes.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection

from .aero import BINDER, GROUND_EFFECT_DEFAULT
from .units import G0, LBF

CAT = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
INK, INK2, GRID = "#0b0b0b", "#52514e", "#d9d8d3"
COMP_COL = {"front_wing": CAT[0], "rear_wing": CAT[1], "body": CAT[2], "total": INK}
EV_COL = {"acceleration": CAT[0], "skidpad": CAT[1], "autocross": CAT[2], "endurance": CAT[3]}
plt.rcParams.update({"figure.dpi": 110, "axes.grid": True, "grid.alpha": 0.35, "grid.color": GRID,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": INK2,
                     "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2, "lines.linewidth": 2.0,
                     "legend.frameon": False, "axes.titleweight": "bold", "axes.titlesize": 11})


def _label(name):
    return name.replace("_", " ")


# =========================================================================== the model
def components(veh, v=20.0):
    """Downforce and drag per component at speed v (static attitude), next to the binder CFD split."""
    A = veh.aero_model
    d = A.evaluate(np.array([v]), detail=True)
    q = float(d["q"][0])
    names = [c.name for c in A.comps]
    F = [float(d["comps"][n]["F"][0]) for n in names]
    D = [float(d["comps"][n]["D"][0]) for n in names]
    fig, ax = plt.subplots(1, 3, figsize=(15, 4.4))
    x = np.arange(len(names))
    ax[0].bar(x, F, color=[COMP_COL.get(n, INK2) for n in names], width=0.6)
    ax[0].axhline(0, color=INK2, lw=1)
    ax[0].set(xticks=x, xticklabels=[_label(n) for n in names], ylabel="downforce [N]",
              title=f"Downforce at {v:.0f} m/s ({v / 0.44704:.0f} mph)")
    for i, f in enumerate(F):
        ax[0].annotate(f"{f:.0f} N\nClA {f / q:.2f}", (i, f), ha="center", va="bottom" if f >= 0 else "top",
                       fontsize=8, color=INK)
    ax[1].bar(x, D, color=[COMP_COL.get(n, INK2) for n in names], width=0.6)
    ax[1].set(xticks=x, xticklabels=[_label(n) for n in names], ylabel="drag [N]", title="Drag")
    for i, f in enumerate(D):
        ax[1].annotate(f"{f:.0f} N\nCdA {f / q:.2f}", (i, f), ha="center", va="bottom", fontsize=8, color=INK)
    # side view: centres of pressure
    L = veh.L
    ax[2].plot([0, -L], [veh.cfg.tires.tire_radius] * 2, "o", color=INK2, ms=14, mfc="none", label="axles")
    ax[2].plot([-veh.a], [veh.h], "x", color=INK, ms=10, mew=2, label="CG")
    for c in A.comps:
        f = float(d["comps"][c.name]["F"][0])
        ax[2].scatter([c.x], [c.z], s=40 + 2 * abs(f), color=COMP_COL.get(c.name, INK2), alpha=0.8,
                      label=f"{_label(c.name)} CoP")
        ax[2].annotate("", (c.x, c.z - np.sign(f) * 0.12), (c.x, c.z), arrowprops=dict(arrowstyle="->", color=INK2))
    bal = float(d["balance"][0])
    ax[2].axvline(-L * (1 - bal), color=CAT[7], lw=1.5, ls="--", label=f"downforce CoP ({bal:.1%} front)")
    ax[2].set(xlabel="x from front axle [m] (+ forward)", ylabel="height [m]", title="Centres of pressure (side view)",
              ylim=(-0.2, 1.2))
    ax[2].legend(fontsize=8, loc="upper left")
    fig.tight_layout()
    return fig


def ground_effect(veh, laps=None):
    """Front-wing CL / CL(max) against clearance / chord, with each event's operating range."""
    A = veh.aero_model
    fw = A.get("front_wing")
    fig, ax = plt.subplots(1, 2, figsize=(14, 4.4))
    hc = np.linspace(0.03, 1.0, 300)
    f = np.interp(hc, A.ge_hc, A.ge_f)
    ax[0].plot(hc, f, color=CAT[0], label="CL / CL max (Zerihan & Zhang shape)")
    if fw is not None and fw.chord:
        h0 = fw.ground_clearance / fw.chord
        ax[0].axvline(h0, color=INK2, ls="--", lw=1.2)
        ax[0].annotate(f"static {fw.ground_clearance * 1e3:.0f} mm\nh/c {h0:.3f}", (h0, 0.55), fontsize=8, color=INK)
    ax[0].axvspan(0.03, A.ge_hc[np.argmax(A.ge_f)], color=CAT[7], alpha=0.08)
    ax[0].annotate("force reduction\n(separation)", (0.035, 0.98), fontsize=8, color=INK2)
    ax[0].set(xlabel="ground clearance / main-element chord h/c", ylabel="CL / CL max", title="Front wing in ground effect")
    ax[0].legend(fontsize=8, loc="lower right")
    if laps and fw is not None:
        from .aero_study import lap_channels
        data, labels = [], []
        for e, lap in laps.items():
            if not hasattr(lap, "state"):
                continue
            ch = lap_channels(veh, lap)
            data.append(ch["fw_clear_min_mm"].to_numpy())
            labels.append(e)
        bp = ax[1].boxplot(data, vert=False, whis=(0, 100), patch_artist=True)
        ax[1].set_yticks(range(1, len(labels) + 1), labels)
        for p, e in zip(bp["boxes"], labels):
            p.set_facecolor(EV_COL.get(e, CAT[4])); p.set_alpha(0.6)
        ax[1].axvline(fw.ground_clearance * 1e3, color=INK2, ls="--", lw=1.2, label="static")
        ax[1].axvline(fw.chord * A.ge_hc[np.argmax(A.ge_f)] * 1e3, color=CAT[7], lw=1.2,
                      label="max-downforce height")
        ax[1].set(xlabel="front-wing lowest-tip clearance [mm] (heave + pitch + roll)",
                  title="Operating clearance per event (min / quartiles / max)")
        ax[1].legend(fontsize=8)
    fig.tight_layout()
    return fig


def attitude_sensitivity(veh, v=20.0):
    """Total ClA, CdA and downforce balance against each attitude variable, the others at zero."""
    A = veh.aero_model
    q = 0.5 * veh.rho * v ** 2
    L = veh.L
    cases = {
        "heave (body drop) [mm]": (np.linspace(-15, 25, 81), lambda x: dict(zf=x / 1e3, zr=x / 1e3)),
        "pitch [deg] (+ nose down)": (np.linspace(-1.5, 1.5, 81),
                                      lambda x: dict(zf=np.radians(x) * L * veh.b / L, zr=-np.radians(x) * L * veh.a / L)),
        "roll [deg]": (np.linspace(0, 3, 61), lambda x: dict(phi=np.radians(x))),
        "body slip at CG [deg] (straight, no yaw rate)": (np.linspace(-12, 12, 81), lambda x: dict(beta=np.radians(x))),
        "path curvature [1/m] (beta = b kappa - 6 deg)": (np.linspace(0, 0.11, 56),
                                                          lambda x: dict(kappa=x, beta=veh.b * x - np.radians(6.0))),
    }
    fig, ax = plt.subplots(3, len(cases), figsize=(20, 9), sharey="row")
    for j, (name, (x, mk)) in enumerate(cases.items()):
        kw = mk(x)
        r = A.evaluate(np.full_like(x, v), **{k: np.broadcast_to(val, x.shape) for k, val in kw.items()})
        ax[0, j].plot(x, r["F"] / q, color=CAT[0])
        ax[1, j].plot(x, r["D"] / q, color=CAT[1])
        ax[2, j].plot(x, r["balance"], color=CAT[2], label="downforce CoP")
        ax[2, j].plot(x, r["F_front"] / r["F"], color=CAT[6], ls="--", label="front-axle share incl. drag moment")
        ax[2, j].set_xlabel(name)
        ax[0, j].set_title(name.split(" [")[0].split(" (")[0])
    ax[0, 0].set_ylabel("ClA [m^2]")
    ax[1, 0].set_ylabel("CdA [m^2]")
    ax[2, 0].set_ylabel("front fraction")
    ax[2, 0].legend(fontsize=8)
    fig.suptitle(f"Aero sensitivity to chassis attitude at {v:.0f} m/s", fontweight="bold")
    fig.tight_layout()
    return fig


def aero_map(veh, v=20.0, laps=None):
    """ClA and balance over front / rear body drop, with the lap operating points."""
    A = veh.aero_model
    q = 0.5 * veh.rho * v ** 2
    zf = np.linspace(-0.01, 0.03, 61)
    zr = np.linspace(-0.01, 0.03, 61)
    ZF, ZR = np.meshgrid(zf, zr, indexing="ij")
    r = A.evaluate(np.full(ZF.shape, v), ZF, ZR)
    fig, ax = plt.subplots(1, 2, figsize=(14, 5.4))
    c0 = ax[0].contourf(ZR * 1e3, ZF * 1e3, r["F"] / q, 16, cmap="Blues")
    fig.colorbar(c0, ax=ax[0], label="ClA [m^2]")
    c1 = ax[1].contourf(ZR * 1e3, ZF * 1e3, r["balance"], 16, cmap="RdBu_r")
    fig.colorbar(c1, ax=ax[1], label="downforce CoP, front fraction")
    if laps:
        for e, lap in laps.items():
            if not hasattr(lap, "state"):
                continue
            st = lap.state
            for a_ in ax:
                a_.scatter(1e3 * st["heave_rear"], 1e3 * st["heave_front"], s=3, alpha=0.5,
                           color=EV_COL.get(e, INK2), label=e)
    for a_, t in zip(ax, ("ClA", "Downforce balance")):
        a_.set(xlabel="rear body drop [mm] (+ lower)", ylabel="front body drop [mm] (+ lower)",
               title=f"{t} map (no roll / yaw) with lap operating points")
    ax[0].legend(fontsize=8, markerscale=4, loc="upper left")
    fig.tight_layout()
    return fig


def speed_sweep(veh):
    """Straight-line aero vs speed at the aero-loaded ride height, with the binder test points."""
    v = np.linspace(2, 35, 120)
    st = veh.state(v, 0 * v, 0 * v)
    q = 0.5 * veh.rho * v ** 2
    area = veh.cfg.aero.reference_area or 1.098
    mph = v / 0.44704
    fig, ax = plt.subplots(2, 2, figsize=(14, 8))
    ax[0, 0].plot(mph, st["aero_front"] / LBF, color=CAT[0], label="front axle")
    ax[0, 0].plot(mph, st["aero_rear"] / LBF, color=CAT[1], label="rear axle")
    ax[0, 0].plot(mph, st["downforce"] / LBF, color=INK, label="total")
    ax[0, 0].plot(mph, st["drag"] / LBF, color=CAT[3], ls="--", label="drag")
    b = BINDER["axle_split_35mph_lbf"]
    ax[0, 0].plot([35, 35], b, "s", color=INK2, mfc="none", ms=8, label="AB8 35 mph split (CHECK)")
    co = BINDER["coastdown_wings_on"]
    q45 = 0.5 * veh.rho * (45 * 0.44704) ** 2
    ax[0, 0].plot([45], [co["CL"] * area * q45 / LBF], "D", color=CAT[2], ms=8, label="AB38 coast-down (rho of the event)")
    ax[0, 0].set(xlabel="speed [mph]", ylabel="force [lbf]", title="Aero loads (straight line)")
    ax[0, 0].legend(fontsize=8)
    ax[0, 1].plot(mph, st["downforce"] / q / area, color=CAT[0], label="CL")
    ax[0, 1].plot(mph, st["drag"] / q / area, color=CAT[1], label="CD")
    ax[0, 1].plot([45, 45], [co["CL"], co["CD"]], "D", color=INK2, label="coast-down (AB38)")
    cf = BINDER["cfd_full_car"]
    ax[0, 1].plot([45, 45], [cf["CL"], cf["CD"]], "o", color=CAT[6], mfc="none", ms=8, label="3D CFD (AB33)")
    ax[0, 1].set(xlabel="speed [mph]", ylabel="coefficient (A = %.3f m^2)" % area,
                 title="CL, CD at the aero-loaded ride height")
    ax[0, 1].legend(fontsize=8)
    ax[1, 0].plot(mph, st["aero_balance"], color=CAT[2], label="downforce centre of pressure")
    ax[1, 0].plot(mph, st["aero_front"] / st["downforce"], color=CAT[6], ls="--",
                  label="front-axle share incl. drag moment")
    ax[1, 0].axhline(veh.ff, color=INK2, lw=1, ls=":", label=f"static weight {veh.ff:.0%} front")
    ax[1, 0].set(xlabel="speed [mph]", ylabel="front fraction", title="Aero balance")
    ax[1, 0].legend(fontsize=8)
    ax[1, 1].plot(mph, 1e3 * st["heave_front"], color=CAT[0], label="front body drop")
    ax[1, 1].plot(mph, 1e3 * st["heave_rear"], color=CAT[1], label="rear body drop")
    ax[1, 1].set(xlabel="speed [mph]", ylabel="ride-height change [mm]", title="Ride height under aero load")
    ax[1, 1].legend(fontsize=8)
    fig.tight_layout()
    return fig


def ggv_compare(vehs: dict):
    """Lateral limit and straight-line acceleration / braking per aero variant."""
    fig, ax = plt.subplots(1, 3, figsize=(16, 4.4))
    v = np.linspace(4, 32, 40)
    for i, (name, veh) in enumerate(vehs.items()):
        col = CAT[i % len(CAT)]
        ax[0].plot(v * 3.6, veh.ay_max(v) / G0, color=col, label=name)
        ax[1].plot(v * 3.6, veh.ax_brake_max(v, 0 * v) / G0, color=col, label=name)
        try:
            ax[2].plot(v * 3.6, veh.ax_accel_max(v, 0 * v) / G0, color=col, label=name)
        except Exception:
            pass
    ax[0].set(xlabel="speed [km/h]", ylabel="lateral limit [g]", title="Steady cornering limit")
    ax[1].set(xlabel="speed [km/h]", ylabel="braking limit [g]", title="Straight-line braking")
    ax[2].set(xlabel="speed [km/h]", ylabel="acceleration limit [g]", title="Straight-line acceleration")
    ax[0].legend(fontsize=8)
    fig.tight_layout()
    return fig


# =========================================================================== laps
def event_traces(veh, lap, title=None):
    """Aero channels along one event: speed, loads, balance, attitude, wing yaw and clearance."""
    from .aero_study import lap_channels
    ch = lap_channels(veh, lap)
    s = ch["s"]
    fig, ax = plt.subplots(6, 1, figsize=(14, 15), sharex=True)
    ax[0].plot(s, ch.v * 3.6, color=INK)
    ax[0].set(ylabel="speed [km/h]", title=title or f"{lap.track.name}: aero along the lap")
    ax[1].plot(s, ch.aero_front, color=CAT[0], label="front axle")
    ax[1].plot(s, ch.aero_rear, color=CAT[1], label="rear axle")
    ax[1].plot(s, ch.drag, color=CAT[3], label="drag")
    ax[1].plot(s, ch.cornering_drag, color=CAT[4], lw=1.2, label="tire cornering drag")
    ax[1].set(ylabel="force [N]")
    ax[1].legend(fontsize=8, ncol=4, loc="upper left")
    ax[2].plot(s, ch.balance_cop, color=CAT[2], label="downforce CoP")
    ax[2].plot(s, ch.front_share, color=CAT[6], ls="--", label="front-axle share incl. drag moment")
    ax[2].axhline(veh.ff, color=INK2, lw=1, ls=":", label="static weight")
    ax[2].set(ylabel="front fraction")
    ax[2].legend(fontsize=8, ncol=3, loc="upper left")
    ax[3].plot(s, ch.pitch_deg, color=CAT[0], label="pitch (+ nose down)")
    ax[3].plot(s, ch.roll_deg, color=CAT[1], label="roll (to the outside)")
    ax[3].plot(s, ch.beta_deg, color=CAT[2], label="body slip at CG")
    ax[3].set(ylabel="angle [deg]")
    ax[3].legend(fontsize=8, ncol=3, loc="upper left")
    if "front_wing_yaw_deg" in ch:
        ax[4].plot(s, ch.front_wing_yaw_deg, color=COMP_COL["front_wing"], label="front wing")
        ax[4].plot(s, ch.rear_wing_yaw_deg, color=COMP_COL["rear_wing"], label="rear wing")
        ax[4].set(ylabel="local flow angle [deg]")
        ax[4].legend(fontsize=8, ncol=2, loc="upper left")
        ax[5].plot(s, ch.fw_clear_mm, color=CAT[0], label="front wing centre")
        ax[5].plot(s, ch.fw_clear_min_mm, color=CAT[7], lw=1.2, label="lowest tip (with roll)")
        ax[5].set(ylabel="clearance [mm]")
        ax[5].legend(fontsize=8, ncol=2, loc="upper left")
    ax[5].set_xlabel("distance [m]")
    fig.tight_layout()
    return fig


def track_maps(veh, lap, title=None):
    """Track coloured by total downforce, downforce balance and front-wing flow angle."""
    from .aero_study import lap_channels
    tr = lap.track
    if tr.x is None:
        return None
    ch = lap_channels(veh, lap)
    x, y = np.asarray(tr.x), np.asarray(tr.y)
    n = min(len(x), len(ch))
    x, y = x[:n], y[:n]
    specs = [("downforce", "total downforce [N]", "Blues", None),
             ("balance_cop", "downforce CoP [front fraction]", "RdBu_r", float(np.nanmedian(ch["balance_cop"]))),
             ("front_wing_yaw_deg", "front-wing flow angle [deg]", "RdBu_r", 0.0)]
    wide = (np.ptp(x) / max(np.ptp(y), 1e-6)) > 2.5
    fig, ax = plt.subplots(3, 1, figsize=(14, 12)) if wide else plt.subplots(1, 3, figsize=(18, 5.6))
    pts = np.column_stack([x, y]).reshape(-1, 1, 2)
    seg = np.concatenate([pts[:-1], pts[1:]], axis=1)
    for a_, (k, lab, cm, mid) in zip(ax, specs):
        if k not in ch:
            a_.axis("off")
            continue
        c = ch[k].to_numpy()[:n]
        lim = None
        if mid is not None:
            m = np.nanmax(np.abs(c - mid))
            lim = (mid - m, mid + m)
        lc = LineCollection(seg, cmap=cm, linewidth=4)
        lc.set_array(c[:-1])
        if lim:
            lc.set_clim(*lim)
        a_.add_collection(lc)
        a_.autoscale()
        a_.set_aspect("equal")
        a_.set_xticks([]); a_.set_yticks([])
        a_.grid(False)
        fig.colorbar(lc, ax=a_, shrink=0.8 if wide else 0.7, label=lab, orientation="vertical")
        a_.set_title(lab.split(" [")[0])
    fig.suptitle(title or f"{tr.name}", fontweight="bold")
    fig.tight_layout()
    return fig


def lap_energy(e_by_event: dict):
    fig, ax = plt.subplots(figsize=(10, 4))
    evs = list(e_by_event)
    keys = list(next(iter(e_by_event.values())).keys())
    left = np.zeros(len(evs))
    for i, k in enumerate(keys):
        val = np.array([e_by_event[e][k] for e in evs])
        ax.barh(evs, val, left=left, color=CAT[i], label=k, height=0.55, edgecolor="white", linewidth=2)
        left += val
    for i, t in enumerate(left):
        ax.annotate(f"{t:.0f} kJ", (t, i), xytext=(4, 0), textcoords="offset points", va="center", fontsize=8)
    ax.set(xlabel="energy per run / lap [kJ]", title="Where the energy goes (resistances at the wheels + brakes)")
    ax.legend(fontsize=8, ncol=4, loc="lower right")
    fig.tight_layout()
    return fig


# =========================================================================== studies
def variant_bars(table: pd.DataFrame):
    """Times and points per event for each aero variant."""
    evs = ["acceleration", "skidpad", "autocross", "endurance_lap"]
    fig, ax = plt.subplots(1, 2, figsize=(16, 4.8))
    names = list(table.index)
    w = 0.8 / len(names)
    x = np.arange(len(evs))
    base = table.loc[names[0]]
    for i, nme in enumerate(names):
        r = table.loc[nme]
        dt = [r.get(f"{e}_s", r.get(e)) - base.get(f"{e}_s", base.get(e)) for e in evs]
        ax[0].bar(x + i * w, dt, w, color=CAT[i], label=nme)
    ax[0].axhline(0, color=INK2, lw=1)
    ax[0].set(xticks=x + w * (len(names) - 1) / 2, xticklabels=["accel", "skidpad", "autocross", "endurance lap"],
              ylabel=f"time vs '{names[0]}' [s]", title="Time change per event (negative = faster)")
    ax[0].legend(fontsize=8)
    pts = ["acceleration_pts", "skidpad_pts", "autocross_pts", "endurance_pts", "efficiency_pts"]
    x2 = np.arange(len(names))
    bottom = np.zeros(len(names))
    for j, p in enumerate(pts):
        val = np.nan_to_num(table[p].to_numpy(float))
        ax[1].bar(x2, val, bottom=bottom, color=CAT[j], label=p.replace("_pts", ""), width=0.6,
                  edgecolor="white", linewidth=2)
        bottom += val
    for i, t in enumerate(bottom):
        ax[1].annotate(f"{t:.1f}", (i, t), ha="center", va="bottom", fontsize=9)
    ax[1].set(xticks=x2, xticklabels=names, ylabel="points", title="Dynamic-event points")
    ax[1].tick_params(axis="x", labelsize=8)
    ax[1].legend(fontsize=8, ncol=5, loc="upper center", bbox_to_anchor=(0.5, -0.12))
    fig.tight_layout()
    return fig


def cla_cda_map(grid: pd.DataFrame, current=None, extra_points=None):
    """Total dynamic points over ClA x CdA, with lines of constant L/D."""
    piv = grid.pivot_table(index="CdA", columns="ClA", values="dynamic_pts")
    fig, ax = plt.subplots(1, 2, figsize=(15, 5.4))
    C = ax[0].contourf(piv.columns, piv.index, piv.values, 14, cmap="Blues")
    fig.colorbar(C, ax=ax[0], label="dynamic points (accel + skidpad + autocross + endurance + efficiency)")
    cl = np.linspace(piv.columns.min(), piv.columns.max(), 10)
    for ld in (1.0, 1.5, 2.0, 2.5):
        ax[0].plot(cl, cl / ld, color=INK2, lw=1, ls=":")
        xs = cl[(cl / ld >= piv.index.min()) & (cl / ld <= piv.index.max())]
        if xs.size:
            xm = xs[len(xs) // 2]
            ax[0].annotate(f"L/D {ld:g}", (xm, xm / ld), fontsize=8, color=INK, rotation=0,
                           bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none", alpha=0.8))
    if current is not None:
        ax[0].plot(*current, "*", color=CAT[7], ms=16, label="CT-17 (coast-down)")
    for name, (x, y) in (extra_points or {}).items():
        ax[0].plot(x, y, "o", mfc="none", color=INK, ms=8)
        ax[0].annotate(name, (x, y), xytext=(4, 4), textcoords="offset points", fontsize=8)
    ax[0].set(xlabel="ClA [m^2]", ylabel="CdA [m^2]", title="Dynamic points vs downforce and drag",
              ylim=(piv.index.min(), piv.index.max()))
    ax[0].legend(fontsize=8, loc="upper left")
    # per-event sensitivity at constant drag / constant downforce
    mid_d = piv.index[len(piv.index) // 2]
    mid_l = piv.columns[len(piv.columns) // 2]
    for i, e in enumerate(["acceleration", "skidpad", "autocross", "endurance", "efficiency"]):
        g1 = grid[np.isclose(grid.CdA, mid_d)].sort_values("ClA")
        ax[1].plot(g1.ClA, g1[f"{e}_pts"] - g1[f"{e}_pts"].iloc[len(g1) // 2], color=CAT[i], label=f"{e} (vary ClA)")
        g2 = grid[np.isclose(grid.ClA, mid_l)].sort_values("CdA")
        ax[1].plot(g2.CdA * (mid_l / mid_d), g2[f"{e}_pts"] - g2[f"{e}_pts"].iloc[len(g2) // 2], color=CAT[i],
                   ls="--", lw=1.4)
    ax[1].axhline(0, color=INK2, lw=1)
    ax[1].set(xlabel="ClA [m^2] (solid)  /  CdA scaled to the ClA axis (dashed)", ylabel="points vs the CT-17",
              title="Per-event points: solid = more downforce, dashed = more drag")
    ax[1].legend(fontsize=8)
    fig.tight_layout()
    return fig


def sweep_lines(df: pd.DataFrame, x: str, xlabel: str, title: str, mark=None):
    fig, ax = plt.subplots(1, 2, figsize=(15, 4.4))
    for i, e in enumerate(["skidpad", "autocross", "endurance_lap"]):
        col = f"{e}_s" if f"{e}_s" in df else e
        ax[0].plot(df[x], df[col] - df[col].iloc[np.argmin(np.abs(df[x] - (mark if mark is not None else df[x].median())))],
                   "o-", color=CAT[i + 1], label=e.replace("_", " "))
    ax[0].axhline(0, color=INK2, lw=1)
    ax[0].set(xlabel=xlabel, ylabel="time vs the CT-17 setting [s]", title=title + ": time")
    ax[0].legend(fontsize=8)
    ax[1].plot(df[x], df["dynamic_pts"], "o-", color=INK)
    ax[1].set(xlabel=xlabel, ylabel="dynamic points", title=title + ": points")
    if mark is not None:
        for a_ in ax:
            a_.axvline(mark, color=CAT[7], ls="--", lw=1.2, label="CT-17")
    fig.tight_layout()
    return fig


def wing_loads(df: pd.DataFrame):
    fig, ax = plt.subplots(1, 2, figsize=(14, 4.2))
    evs = [i for i in df.index if "design" not in i]
    x = np.arange(len(evs))
    for a_, comp, ttl in ((ax[0], "front wing", "Front wing"), (ax[1], "rear wing", "Rear wing")):
        a_.bar(x - 0.2, df.loc[evs, f"{comp} downforce [lbf]"], 0.4, color=CAT[0], label="peak downforce")
        a_.bar(x + 0.2, df.loc[evs, f"{comp} drag [lbf]"], 0.4, color=CAT[1], label="peak drag")
        a_.set(xticks=x, xticklabels=evs, ylabel="load [lbf]", title=f"{ttl}: peak aero load per event")
    d = [i for i in df.index if "design" in i]
    if d:
        ax[0].axhline(df.loc[d[0], "front wing downforce [lbf]"], color=CAT[7], ls="--", lw=1.4,
                      label="mount design downforce (AB29)")
        ax[0].axhline(df.loc[d[0], "front wing drag [lbf]"], color=CAT[3], ls=":", lw=1.4,
                      label="mount design drag (AB29)")
    ax[0].legend(fontsize=8)
    ax[1].legend(fontsize=8)
    fig.tight_layout()
    return fig


# =========================================================================== transient
def transient_compare(tr, title=None):
    """Quasi-steady vs transient multibody along one event."""
    d, q = tr.df, tr.qss
    s = d["s"]
    fig, ax = plt.subplots(6, 1, figsize=(14, 15), sharex=True)
    ax[0].plot(s, d["v"] * 3.6, color=CAT[0], label="transient")
    ax[0].plot(s, q["v"] * 3.6, color=INK2, ls="--", lw=1.4, label="quasi-steady")
    ax[0].set(ylabel="speed [km/h]",
              title=title or f"{tr.name}: transient multibody vs quasi-steady "
                             f"({tr.summary['time_s']:.2f} s vs {tr.summary['qss_time_s']:.2f} s)")
    ax[0].legend(fontsize=8)
    ax[1].plot(s, np.degrees(d["yaw_rate"]), color=CAT[0], label="transient")
    ax[1].plot(s, np.degrees(q["yaw_rate"]), color=INK2, ls="--", lw=1.4, label="quasi-steady")
    ax[1].set(ylabel="yaw rate [deg/s]")
    ax[2].plot(s, d["roll_deg"], color=CAT[0], label="transient")
    ax[2].plot(s, q["roll_deg"], color=INK2, ls="--", lw=1.4, label="quasi-steady")
    ax[2].set(ylabel="roll [deg]")
    ax[3].plot(s, d["pitch_deg"], color=CAT[0], label="transient")
    ax[3].plot(s, q["pitch_deg"], color=INK2, ls="--", lw=1.4, label="quasi-steady")
    ax[3].set(ylabel="pitch [deg] (+ nose down)")
    ax[4].plot(s, d["beta_deg"], color=CAT[0], label="body slip (transient)")
    ax[4].plot(s, q["beta_deg"], color=INK2, ls="--", lw=1.4, label="body slip (quasi-steady)")
    ax[4].plot(s, d["fw_yaw_deg"], color=CAT[3], lw=1.2, label="front-wing flow angle")
    ax[4].plot(s, d["rw_yaw_deg"], color=CAT[1], lw=1.2, label="rear-wing flow angle")
    ax[4].set(ylabel="angle [deg]")
    ax[4].legend(fontsize=8, ncol=4)
    ax[5].plot(s, d["aero_F"], color=CAT[0], label="downforce (transient)")
    ax[5].plot(s, q["aero_F"], color=INK2, ls="--", lw=1.4, label="downforce (quasi-steady)")
    ax[5].set(ylabel="downforce [N]", xlabel="distance [m]")
    ax[5].legend(fontsize=8)
    fig.tight_layout()
    return fig


def transient_overview(trs: dict):
    """Per event: attitude extremes and transient-minus-quasi-steady differences."""
    rows = []
    for e, r in trs.items():
        S = r.summary
        rows.append((e, S["time_s"], S["qss_time_s"], S["max_roll_deg"], S["max_pitch_deg"], S["max_beta_deg"],
                     S["min_fw_clearance_mm"]))
    df = pd.DataFrame(rows, columns=["event", "transient", "qss", "roll", "pitch", "beta", "fw_clear"]).set_index("event")
    fig, ax = plt.subplots(1, 3, figsize=(16, 4.2))
    x = np.arange(len(df))
    ax[0].bar(x, 100 * (df.transient / df.qss - 1), color=[EV_COL.get(e, INK2) for e in df.index], width=0.55)
    ax[0].axhline(0, color=INK2, lw=1)
    ax[0].set(xticks=x, xticklabels=df.index, ylabel="transient vs quasi-steady time [%]",
              title="Lap time: transient driver at 98 %")
    w = 0.27
    ax[1].bar(x - w, df.roll, w, color=CAT[0], label="max |roll|")
    ax[1].bar(x, df.pitch, w, color=CAT[1], label="max |pitch|")
    ax[1].bar(x + w, df.beta, w, color=CAT[2], label="max |body slip|")
    ax[1].set(xticks=x, xticklabels=df.index, ylabel="deg", title="Peak attitude (transient)")
    ax[1].legend(fontsize=8)
    ax[2].bar(x, df.fw_clear, color=CAT[3], width=0.55)
    ax[2].set(xticks=x, xticklabels=df.index, ylabel="mm", title="Minimum front-wing tip clearance (transient)")
    fig.tight_layout()
    return fig


def rates_vs_log(tr, logged: pd.DataFrame, title="Autocross: body rates, transient model vs logged (distributions)"):
    d = tr.df
    sim = {"yaw_rate": np.degrees(d["yaw_rate"].to_numpy()), "roll_rate": d["roll_rate"].to_numpy(),
           "pitch_rate": d["pitch_rate"].to_numpy()}
    fig, ax = plt.subplots(1, 3, figsize=(16, 4.2))
    for a_, k in zip(ax, ("yaw_rate", "roll_rate", "pitch_rate")):
        lim = np.nanpercentile(np.abs(np.r_[sim[k], logged[k].to_numpy() if k in logged else []]), 99.5)
        bins = np.linspace(-lim, lim, 50)
        if k in logged:
            a_.hist(logged[k], bins, density=True, color=CAT[1], alpha=0.5, label="logged (Michigan)")
        a_.hist(sim[k], bins, density=True, histtype="step", color=CAT[0], lw=2, label="transient model")
        a_.set(xlabel=f"{k.replace('_', ' ')} [deg/s]", ylabel="density", title=k.replace("_", " "))
        a_.legend(fontsize=8)
    fig.suptitle(title, fontweight="bold")
    fig.tight_layout()
    return fig


def crosswind(df: pd.DataFrame):
    fig, ax = plt.subplots(1, 2, figsize=(14, 4.2))
    for i, (sp, g) in enumerate(df.groupby("wind_mps")):
        ax[0].plot(g.direction_deg, g.time_s, "o-", color=CAT[i], label=f"{sp:.0f} m/s wind")
        ax[1].plot(g.direction_deg, g.mean_downforce_N, "o-", color=CAT[i], label=f"{sp:.0f} m/s wind")
    ax[0].set(xlabel="wind direction [deg] (blowing toward, track frame)", ylabel="lap time [s]",
              title="Crosswind: endurance lap time (transient)")
    ax[1].set(xlabel="wind direction [deg]", ylabel="mean downforce [N]", title="Crosswind: mean downforce")
    ax[0].legend(fontsize=8)
    fig.tight_layout()
    return fig
