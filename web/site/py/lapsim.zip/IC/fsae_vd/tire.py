"""Tire model.

Peak friction with load sensitivity and an inclination-angle term:

    mu(Fz, g) = lambda_mu * (mu0 + mu_fz * (Fz - Fz0)) * (1 - k_gamma * (g - g_opt)^2)

``g`` is the *turn-relative* inclination angle in degrees: negative when the
top of the tire leans toward the centre of the turn (the helpful direction).
Lateral force versus slip angle uses a simplified Magic Formula whose slope at
the origin is the cornering stiffness and whose peak is mu*Fz.
"""
from __future__ import annotations

import numpy as np

from .config import MissingDataError, Tires


class Tire:
    def __init__(self, p: Tires):
        if p.mu0 is None or p.mu_fz is None:
            raise MissingDataError(
                "tires.mu0 and tires.mu_fz are not set. Fit them from TTC data "
                "(identification.fit_ttc) or from a logged g-g envelope "
                "(identification.calibrate_grip), or enter them in the config.")
        self.p = p

    # ---- common interface (pressure is ignored by the simple model)
    def peak_fy(self, fz, gamma_deg=0.0, p=None):
        return self.mu(fz, gamma_deg) * np.asarray(fz, float)

    def peak_fx(self, fz, gamma_deg=0.0, p=None, drive=True):
        return np.maximum(self.p.mux_over_muy * self.peak_fy(fz, gamma_deg), 1.0)

    def lateral_capacity(self, fz, gamma_deg, fx, p=None):
        """Friction ellipse."""
        fmax = self.peak_fy(fz, gamma_deg)
        u = np.clip(np.abs(fx) / np.maximum(self.p.mux_over_muy * fmax, 1e-6), 0, 1)
        return np.where(u < 1, fmax * np.sqrt(1 - u ** 2), 0.0), u >= 1

    def cornering_stiffness(self, fz, gamma_deg=0.0, p=None):
        if self.p.cornering_stiffness_per_load is None:
            raise MissingDataError("tires.cornering_stiffness_per_load not set")
        return self.p.cornering_stiffness_per_load * np.asarray(fz, float)

    def mz(self, alpha_rad, fz, gamma_deg=0.0, p=None, kappa=0.0):
        """Aligning moment from the configured pneumatic trail (None if not recorded)."""
        if self.p.pneumatic_trail is None:
            return None
        return self.p.pneumatic_trail * self.fy(alpha_rad, fz, gamma_deg)

    def rolling_resistance(self, fz, v, p=None):
        return None

    def mu(self, fz, gamma_deg=0.0, p=None):
        p = self.p
        m = p.lambda_mu * (p.mu0 + p.mu_fz * (np.asarray(fz, float) - p.fz0))
        if p.gamma_opt_deg is not None and p.k_gamma is not None:
            m = m * np.clip(1.0 - p.k_gamma * (np.asarray(gamma_deg, float) - p.gamma_opt_deg) ** 2, 0.3, 1.0)
        return np.maximum(m, 0.05)

    def fy(self, alpha_rad, fz, gamma_deg=0.0, p=None, C=1.4, E=0.0):
        """Lateral force [N] (simplified MF). Needs cornering_stiffness_per_load."""
        if self.p.cornering_stiffness_per_load is None:
            raise MissingDataError("tires.cornering_stiffness_per_load needed for slip-angle curves")
        D = self.mu(fz, gamma_deg) * fz
        B = self.p.cornering_stiffness_per_load * fz / (C * D)
        x = B * alpha_rad
        return D * np.sin(C * np.arctan(x - E * (x - np.arctan(x))))

    def peak_slip_deg(self, fz, gamma_deg=0.0, C=1.4):
        """Slip angle of peak lateral force (E=0)."""
        D = self.mu(fz, gamma_deg) * fz
        B = self.p.cornering_stiffness_per_load * fz / (C * D)
        return np.degrees(np.tan(np.pi / (2 * C)) / B)


def make_tire(p: Tires):
    """Tire model selected by ``tires.model``: 'pacejka_simple' or 'mf61' (needs tires.tir_file)."""
    if p.model == "mf61":
        from .mf61 import MF61Tire, load_tir
        if not p.tir_file:
            raise MissingDataError("tires.model = 'mf61' needs tires.tir_file (fit one with identification.fit_mf61)")
        return MF61Tire(load_tir(p.tir_file), lambda_mu=p.lambda_mu, mux_over_muy=p.mux_over_muy)
    return Tire(p)
