"""Event geometry: straight, skidpad circle, and tracks from files or logs."""
from __future__ import annotations

import dataclasses as dc
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import interpolate

from .processing import smooth_path_curvature


@dc.dataclass
class Track:
    name: str
    s: np.ndarray          # m
    kappa: np.ndarray      # 1/m (sign: + left)
    closed: bool = False
    x: np.ndarray | None = None
    y: np.ndarray | None = None

    @property
    def length(self):
        return float(self.s[-1])


def straight(length: float, ds: float = 0.5, name="acceleration") -> Track:
    s = np.arange(0, length + ds / 2, ds)
    return Track(name, s, np.zeros_like(s), False, s.copy(), np.zeros_like(s))


def circle(radius: float, ds: float = 0.25, name="skidpad") -> Track:
    L = 2 * np.pi * radius
    s = np.arange(0, L + ds / 2, ds)
    th = s / radius
    return Track(name, s, np.full_like(s, 1 / radius), True, radius * np.sin(th), radius * (1 - np.cos(th)))


def from_xy(x, y, ds=0.5, pos_sigma=0.05, name="track", closed=None) -> Track:
    """Track from centre-line or racing-line points. ``pos_sigma`` is the position
    uncertainty of the points (e.g. 0.05 m for a survey/CAD line, ~0.5 m for GPS)."""
    x, y = np.asarray(x, float), np.asarray(y, float)
    seg = np.hypot(np.diff(x), np.diff(y))
    keep = np.r_[True, seg > 1e-6]
    x, y = x[keep], y[keep]
    s_raw = np.r_[0, np.cumsum(np.hypot(np.diff(x), np.diff(y)))]
    if closed is None:
        closed = np.hypot(x[0] - x[-1], y[0] - y[-1]) < 5.0
    xs, ys, k = smooth_path_curvature(s_raw, x, y, pos_sigma)
    s = np.arange(0, s_raw[-1], ds)
    return Track(name, s, np.interp(s, s_raw, k), closed, np.interp(s, s_raw, xs), np.interp(s, s_raw, ys))


def from_csv(path, ds=0.5, pos_sigma=0.05, name=None) -> Track:
    """CSV with columns x,y [m] (or lat,lon [deg]) or s,kappa/curvature [m, 1/m]."""
    d = pd.read_csv(path)
    # accept unit-suffixed names too (s_m, x_m, y_m, curvature_1pm)
    c = {}
    for k in d.columns:
        key = k.lower().strip()
        for suf in ("_m", "_1pm", "_1/m", "_deg"):
            if key.endswith(suf) and key[: -len(suf)] in ("s", "x", "y", "curvature", "kappa", "lat", "lon"):
                key = key[: -len(suf)]
        c.setdefault(key, k)
    name = name or Path(path).stem
    if "s" in c and ("kappa" in c or "curvature" in c):
        s0 = d[c["s"]].to_numpy(float)
        k0 = d[c.get("kappa", c.get("curvature"))].to_numpy(float)
        s = np.arange(0, s0[-1], ds)
        x = np.interp(s, s0, d[c["x"]].to_numpy(float)) if "x" in c else None
        y = np.interp(s, s0, d[c["y"]].to_numpy(float)) if "y" in c else None
        closed = bool(x is not None and np.hypot(x[0] - x[-1], y[0] - y[-1]) < 5.0)
        return Track(name, s, np.interp(s, s0, k0), closed, x, y)
    if "x" in c and "y" in c:
        return from_xy(d[c["x"]], d[c["y"]], ds, pos_sigma, name)
    if "lat" in c and "lon" in c:
        from .processing import latlon_to_xy
        x, y = latlon_to_xy(d[c["lat"]].to_numpy(float), d[c["lon"]].to_numpy(float))
        return from_xy(x, y, ds, max(pos_sigma, 0.3), name)
    raise ValueError(f"{path}: need columns x,y or lat,lon or s,kappa")


def from_processed_log(plog, ds=0.5, name="logged track") -> Track:
    """Track from the lap ensemble (median curvature across all good laps)."""
    from .processing import distance_ensemble
    if not plog.laps:
        raise ValueError("no laps found in the log - set gate_latlon or check the beacon channel")
    ens = distance_ensemble(plog.df, plog.laps, ["kappa", "x", "y", "v"])
    s = np.arange(0, ens["s"].iloc[-1], ds)
    k = np.interp(s, ens["s"], ens["kappa_med"])
    x = np.interp(s, ens["s"], ens["x_med"]) if "x_med" in ens else None
    y = np.interp(s, ens["s"], ens["y_med"]) if "y_med" in ens else None
    return Track(name, s, k, True, x, y)


def resolve_track_path(path, root=None):
    """Find a track file: as given, else by name under data/tracks/ and any of its subfolders
    (track files live in per-year / per-car folders such as data/tracks/ic_tracks2026/)."""
    p = Path(path)
    if root is not None and not p.is_absolute():
        p = Path(root) / p
    if p.exists():
        return p
    bases = [p.parent, p.parent / "tracks"]
    for b in ([Path(root)] if root is not None else []) + [Path(__file__).resolve().parents[1]]:
        bases += [b / "data/tracks"]
    for b in bases:
        if (b / p.name).exists():
            return b / p.name
    for b in bases[2:]:
        hits = sorted(x for x in b.rglob(p.name) if ".ipynb_checkpoints" not in x.parts) if b.is_dir() else []
        if hits:
            return hits[0]
    return p


def load_track(path, ds=0.5, **process_kw) -> Track:
    """A track .csv, or a logged run (.xrk/.xrz, or a RaceStudio .csv with a Time column)."""
    p = resolve_track_path(path)
    if p.suffix.lower() in (".xrk", ".xrz"):
        from .io_data import load_log
        from .processing import process_log
        return from_processed_log(process_log(load_log(p), **process_kw), ds, p.stem)
    head = p.read_text(errors="replace")[:4000].lower()
    if "time" in head.split("\n")[0] or '"time"' in head:
        from .io_data import load_log
        from .processing import process_log
        return from_processed_log(process_log(load_log(p), **process_kw), ds, p.stem)
    return from_csv(p, ds)
