"""Event geometry: straight, skidpad circle, and tracks from files, cone lines or logs.

A ``Track`` is a reference line (distance ``s``, curvature ``kappa``, optionally ``x``, ``y``) plus,
per station and all optional:

    w_left, w_right   m from the reference line to the left / right edge of the drivable corridor
                      (cones, kerbs, paint). The reference line need not be the middle.
    z                 elevation [m]; ``grade`` = dz/ds (+ uphill)
    bank              road roll angle [rad], + when the left edge is lower (banked for a left turn,
                      the same sense as + kappa)
    grip              surface friction multiplier (1.0 = the surface the tires were calibrated on)

Sources: ``from_csv`` (centre line with any of those columns), ``from_boundaries`` (two edge / cone
lines), ``boundaries_from_lines`` (envelope of driven GPS lines on an existing track),
``Track.with_width`` / ``with_surface`` (constants or arrays), ``from_processed_log`` (a logged run).
See configs/tracks/README.md for the file format.
"""
from __future__ import annotations

import dataclasses as dc
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import interpolate
from scipy.spatial import cKDTree

from .processing import smooth_path_curvature

_STATION_FIELDS = ("w_left", "w_right", "z", "bank", "grip")


@dc.dataclass
class Track:
    name: str
    s: np.ndarray          # m
    kappa: np.ndarray      # 1/m (sign: + left)
    closed: bool = False
    x: np.ndarray | None = None
    y: np.ndarray | None = None
    w_left: np.ndarray | None = None     # m, reference line to the left edge (>= 0)
    w_right: np.ndarray | None = None    # m, reference line to the right edge (>= 0)
    z: np.ndarray | None = None          # m, elevation
    bank: np.ndarray | None = None       # rad, + left edge lower
    grip: np.ndarray | None = None       # -, surface friction multiplier

    def __post_init__(self):
        n = np.asarray(self.s).size
        for f in _STATION_FIELDS:
            v = getattr(self, f)
            if v is None:
                continue
            v = np.asarray(v, float)
            if v.ndim == 0:
                v = np.full(n, float(v))
            if v.size != n:
                raise ValueError(f"track '{self.name}': {f} has {v.size} values for {n} stations")
            if not np.all(np.isfinite(v)):
                raise ValueError(f"track '{self.name}': {f} has missing values")
            setattr(self, f, v)
        if (self.w_left is None) != (self.w_right is None):
            raise ValueError(f"track '{self.name}': give both w_left and w_right (or neither)")
        if self.w_left is not None and (self.w_left.min() < 0 or self.w_right.min() < 0):
            raise ValueError(f"track '{self.name}': the reference line leaves the corridor "
                             f"(w_left / w_right < 0)")
        if self.grip is not None and self.grip.min() <= 0:
            raise ValueError(f"track '{self.name}': grip must be > 0")

    # ------------------------------------------------------------------ properties
    @property
    def length(self):
        return float(self.s[-1])

    @property
    def has_boundaries(self):
        return self.w_left is not None

    @property
    def is_flat(self):
        """No elevation change and no banking in the data."""
        return ((self.z is None or float(np.ptp(self.z)) < 1e-6)
                and (self.bank is None or float(np.abs(self.bank).max()) < 1e-6))

    @property
    def grade(self):
        """dz/ds along the reference line (+ uphill); None without elevation."""
        return None if self.z is None else np.gradient(self.z, self.s)

    @property
    def _period(self):
        return self.length if self.closed else None

    def heading(self):
        """Direction of the reference line [rad, unwrapped]."""
        return np.unwrap(np.arctan2(np.gradient(np.asarray(self.y, float)), np.gradient(np.asarray(self.x, float))))

    # ------------------------------------------------------------------ lookups
    def at(self, field, s, default=None):
        """``field`` ("kappa", "w_left", "grip", "grade", ...) interpolated at distance(s) ``s``."""
        v = getattr(self, field)
        if v is None:
            if default is None:
                raise ValueError(f"track '{self.name}' has no {field}")
            return np.full(np.shape(s), float(default))
        return np.interp(s, self.s, v, period=self._period)

    def n_limits(self, s, clearance=0.0, half_width=None):
        """Allowed lateral offset of the car's centre, (n_min, n_max) at ``s`` [m, + left]: the
        corridor less ``clearance`` (half the car's width + a cone margin) on each side. Without
        boundaries ``half_width`` is used on both sides. Where the corridor is narrower than the
        car the two limits meet on its middle."""
        if self.has_boundaries:
            hi = self.at("w_left", s) - clearance
            lo = -(self.at("w_right", s) - clearance)
        elif half_width is not None:
            hi = np.full(np.shape(s), float(half_width) - clearance)
            lo = -hi
        else:
            raise ValueError(f"track '{self.name}' has no boundaries: pass half_width")
        mid = 0.5 * (lo + hi)
        tight = lo > hi
        return np.where(tight, mid, lo), np.where(tight, mid, hi)

    def edges(self):
        """x, y of the left and right edges (xl, yl, xr, yr)."""
        if not self.has_boundaries or self.x is None:
            raise ValueError(f"track '{self.name}' needs x, y and boundaries")
        h = self.heading()
        x, y = np.asarray(self.x, float), np.asarray(self.y, float)
        return (x - self.w_left * np.sin(h), y + self.w_left * np.cos(h),
                x + self.w_right * np.sin(h), y - self.w_right * np.cos(h))

    # ------------------------------------------------------------------ edits
    def with_width(self, left, right=None):
        """Copy with boundaries: one half width, or left and right (numbers or one per station)."""
        return dc.replace(self, w_left=left, w_right=left if right is None else right)

    def with_surface(self, z=None, bank=None, grip=None):
        """Copy with elevation [m], banking [rad, + left edge lower] and / or grip multiplier
        (numbers or one per station)."""
        new = {k: v for k, v in (("z", z), ("bank", bank), ("grip", grip)) if v is not None}
        return dc.replace(self, **new)

    # ------------------------------------------------------------------ files
    def to_frame(self) -> pd.DataFrame:
        d = {"s_m": self.s}
        if self.x is not None:
            d.update({"x_m": self.x, "y_m": self.y})
        d["curvature_1pm"] = self.kappa
        for f, col in (("w_left", "w_left_m"), ("w_right", "w_right_m"), ("z", "z_m"), ("bank", "bank_rad"),
                       ("grip", "grip")):
            if getattr(self, f) is not None:
                d[col] = getattr(self, f)
        return pd.DataFrame(d)

    def to_csv(self, path):
        """Write a track file that ``from_csv`` reads back (same stations)."""
        self.to_frame().to_csv(path, index=False, float_format="%.6g")
        return Path(path)


# =========================================================================== simple shapes
def straight(length: float, ds: float = 0.5, name="acceleration") -> Track:
    s = np.arange(0, length + ds / 2, ds)
    return Track(name, s, np.zeros_like(s), False, s.copy(), np.zeros_like(s))


def circle(radius: float, ds: float = 0.25, name="skidpad") -> Track:
    L = 2 * np.pi * radius
    s = np.arange(0, L + ds / 2, ds)
    th = s / radius
    return Track(name, s, np.full_like(s, 1 / radius), True, radius * np.sin(th), radius * (1 - np.cos(th)))


# =========================================================================== from points
def _is_closed(x, y, closed=None, gap=5.0):
    return bool(np.hypot(x[0] - x[-1], y[0] - y[-1]) < gap) if closed is None else bool(closed)


def from_xy(x, y, ds=0.5, pos_sigma=0.05, name="track", closed=None, **station) -> Track:
    """Track from centre-line or racing-line points. ``pos_sigma`` is the position
    uncertainty of the points (e.g. 0.05 m for a survey/CAD line, ~0.5 m for GPS).
    ``station``: w_left, w_right, z, bank, grip - a number or one value per input point.
    ``closed``: None = closed when the ends are within 5 m of each other."""
    x, y = np.asarray(x, float), np.asarray(y, float)
    bad = [k for k in station if k not in _STATION_FIELDS]
    if bad:
        raise TypeError(f"from_xy: unknown argument(s) {bad}")
    seg = np.hypot(np.diff(x), np.diff(y))
    keep = np.r_[True, seg > 1e-6]
    n_in = x.size
    x, y = x[keep], y[keep]
    s_raw = np.r_[0, np.cumsum(np.hypot(np.diff(x), np.diff(y)))]
    closed = _is_closed(x, y, closed)
    pad = min(20.0, 0.25 * s_raw[-1]) if closed and x.size > 8 else 0.0
    if pad > 0:      # closed: smooth with the lap wrapped round both ends, so the curvature has no end effects
        lap = s_raw[-1] + float(np.hypot(x[0] - x[-1], y[0] - y[-1]))
        a, b = s_raw > s_raw[-1] - pad, s_raw < pad
        xs, ys, k = smooth_path_curvature(np.r_[s_raw[a] - lap, s_raw, s_raw[b] + lap], np.r_[x[a], x, x[b]],
                                          np.r_[y[a], y, y[b]], pos_sigma)
        m = slice(int(a.sum()), int(a.sum()) + x.size)
        xs, ys, k = xs[m], ys[m], k[m]
    else:
        xs, ys, k = smooth_path_curvature(s_raw, x, y, pos_sigma)
    s = np.arange(0, s_raw[-1], ds)
    extra = {}
    for key, v in station.items():
        if v is None:
            continue
        v = np.asarray(v, float)
        if v.ndim == 0:
            extra[key] = float(v)
        elif v.size == n_in:
            extra[key] = np.interp(s, s_raw, v[keep])
        else:
            raise ValueError(f"from_xy: {key} has {v.size} values for {n_in} points")
    return Track(name, s, np.interp(s, s_raw, k), closed, np.interp(s, s_raw, xs), np.interp(s, s_raw, ys), **extra)


def lateral_offset(track: Track, x, y):
    """Distance along the track and lateral offset (s, n; n + left) of points x, y, from the
    nearest point of the reference line."""
    if track.x is None:
        raise ValueError(f"track '{track.name}' has no x, y coordinates")
    tx, ty = np.asarray(track.x, float), np.asarray(track.y, float)
    h = track.heading()
    x, y = np.atleast_1d(np.asarray(x, float)), np.atleast_1d(np.asarray(y, float))
    _, j = cKDTree(np.c_[tx, ty]).query(np.c_[x, y])
    dx, dy = x - tx[j], y - ty[j]
    along = dx * np.cos(h[j]) + dy * np.sin(h[j])
    n = -dx * np.sin(h[j]) + dy * np.cos(h[j])
    s = track.s[j] + along
    s = np.mod(s, track.length) if track.closed else np.clip(s, 0.0, track.length)
    return s, n


def _densify(p, step, closed):
    """Polyline (N, 2) resampled to at most ``step`` between points (straight between the inputs)."""
    p = np.asarray(p, float)
    if p.ndim != 2 or p.shape[1] != 2 or p.shape[0] < 2:
        raise ValueError("an edge needs at least two (x, y) points, in driving order")
    if closed and np.hypot(*(p[0] - p[-1])) > 1e-6:
        p = np.vstack([p, p[:1]])
    d = np.r_[0, np.cumsum(np.hypot(np.diff(p[:, 0]), np.diff(p[:, 1])))]
    u = np.linspace(0.0, d[-1], max(int(np.ceil(d[-1] / step)) + 1, 2))
    return np.c_[np.interp(u, d, p[:, 0]), np.interp(u, d, p[:, 1])]


def from_boundaries(left, right, ds=0.5, pos_sigma=0.05, name="track", closed=None, **station) -> Track:
    """Track from its two edges: ``left`` and ``right`` are (N, 2) arrays of x, y [m] in driving
    order - surveyed edge lines, or the cones of each side (the corridor runs straight from cone to
    cone). The reference line is their smoothed middle; w_left / w_right are the distances from it
    to the nearest point of each edge, so a car held inside them is inside the cones.
    ``station``: z, bank, grip as numbers (use ``with_surface`` for per-station values)."""
    left, right = np.asarray(left, float), np.asarray(right, float)
    if closed is None:
        closed = bool(np.hypot(*(left[0] - left[-1])) < 5.0 and np.hypot(*(right[0] - right[-1])) < 5.0)
    L, R = _densify(left, 0.1, closed), _densify(right, 0.1, closed)
    tl, tr_ = cKDTree(L), cKDTree(R)
    # first guess: mid points at equal fractions of each edge's length, then recentre on the nearest points
    m = max(L.shape[0], R.shape[0])
    u = np.linspace(0.0, 1.0, m)
    c = 0.5 * (np.c_[np.interp(u, np.linspace(0, 1, L.shape[0]), L[:, 0]), np.interp(u, np.linspace(0, 1, L.shape[0]), L[:, 1])]
               + np.c_[np.interp(u, np.linspace(0, 1, R.shape[0]), R[:, 0]), np.interp(u, np.linspace(0, 1, R.shape[0]), R[:, 1])])
    for _ in range(3):
        c = 0.5 * (L[tl.query(c)[1]] + R[tr_.query(c)[1]])
    if closed:
        c = np.vstack([c, c[:1]])
    t = from_xy(c[:, 0], c[:, 1], ds, pos_sigma, name, closed)
    P = np.c_[t.x, t.y]
    wl, wr = tl.query(P)[0], tr_.query(P)[0]
    # the reference line must have the left edge on its left
    h = t.heading()
    jl = tl.query(P)[1]
    side = -(L[jl, 0] - P[:, 0]) * np.sin(h) + (L[jl, 1] - P[:, 1]) * np.cos(h)
    if np.median(side) < 0:
        raise ValueError("from_boundaries: `left` is on the right of the driving direction - swap the edges "
                         "or reverse their order")
    bad = [k for k in station if k not in ("z", "bank", "grip")]
    if bad:
        raise TypeError(f"from_boundaries: unknown argument(s) {bad}")
    return dc.replace(t, w_left=wl, w_right=wr, **{k: v for k, v in station.items() if v is not None})


def boundaries_from_lines(track: Track, lines, car_half_width=0.0, extra=0.0, min_half_width=0.0) -> Track:
    """Boundaries from driven lines: ``lines`` is a list of (x, y) arrays (logged GPS laps in the
    track's coordinates). At every station the corridor is the envelope of the car's centre over
    all lines, widened by ``car_half_width`` (the car itself was inside the cones) and ``extra``.
    A stand-in for a cone map: it only shows where the drivers went, so it needs several laps and
    is no wider than they used."""
    hi = np.full(track.s.size, -np.inf)
    lo = np.full(track.s.size, np.inf)
    for x, y in lines:
        s, n = lateral_offset(track, x, y)
        o = np.argsort(s, kind="stable")
        s, n = s[o], n[o]
        ni = np.interp(track.s, s, n, period=track._period)
        hi, lo = np.maximum(hi, ni), np.minimum(lo, ni)
    if not np.all(np.isfinite(hi)):
        raise ValueError("boundaries_from_lines: no lines given")
    add = car_half_width + extra
    return dc.replace(track, w_left=np.maximum(hi + add, min_half_width), w_right=np.maximum(-lo + add, min_half_width))


# =========================================================================== files
_UNITS = ("_m", "_1pm", "_1/m", "_deg", "_rad", "_pct")
_ALIASES = {"curvature": "kappa", "w_tr_left": "w_left", "w_tr_right": "w_right", "elevation": "z", "altitude": "z",
            "banking": "bank", "mu": "grip", "grip_scale": "grip", "slope": "grade"}


def _columns(d):
    """{canonical name: (column, unit suffix)} - accepts unit-suffixed names (s_m, x_m, curvature_1pm,
    bank_deg), a leading '#' (racetrack-database files) and the aliases above."""
    c = {}
    for col in d.columns:
        key, unit = str(col).lower().strip().lstrip("#").strip(), ""
        for suf in _UNITS:
            if key.endswith(suf) and len(key) > len(suf):
                key, unit = key[: -len(suf)], suf
                break
        c.setdefault(_ALIASES.get(key, key), (col, unit))
    return c


def _station_columns(d, c):
    """Per-row boundary / surface values of a track file (those it has)."""
    get = lambda k: d[c[k][0]].to_numpy(float)
    out = {}
    if "w_left" in c and "w_right" in c:
        out["w_left"], out["w_right"] = get("w_left"), get("w_right")
    elif "width" in c:
        out["w_left"] = out["w_right"] = 0.5 * get("width")
    elif "half_width" in c:
        out["w_left"] = out["w_right"] = get("half_width")
    if "z" in c:
        out["z"] = get("z")
    if "bank" in c:
        out["bank"] = np.radians(get("bank")) if c["bank"][1] == "_deg" else get("bank")
    if "grip" in c:
        out["grip"] = get("grip")
    return out


def from_csv(path, ds=0.5, pos_sigma=0.05, name=None, closed=None) -> Track:
    """Track .csv: columns x,y [m] (or lat,lon [deg]) or s,kappa/curvature [m, 1/m]; or the two
    edges xl,yl,xr,yr [m]. Optional per-row columns: w_left, w_right (or width / half_width) [m],
    z [m] (or grade, dz/ds; _pct for percent), bank [rad, or bank_deg; + left edge lower], grip."""
    d = pd.read_csv(path)
    c = _columns(d)
    get = lambda k: d[c[k][0]].to_numpy(float)
    name = name or Path(path).stem
    st = _station_columns(d, c)
    grade = None
    if "grade" in c and "z" not in st:
        grade = get("grade") * (0.01 if c["grade"][1] == "_pct" else 1.0)
    if "s" in c and "kappa" in c:
        s0, k0 = get("s"), get("kappa")
        s = np.arange(0, s0[-1], ds)
        x = np.interp(s, s0, get("x")) if "x" in c else None
        y = np.interp(s, s0, get("y")) if "y" in c else None
        if closed is None:
            closed = bool(x is not None and np.hypot(x[0] - x[-1], y[0] - y[-1]) < 5.0)
        if grade is not None:
            st["z"] = np.r_[0, np.cumsum(0.5 * (grade[1:] + grade[:-1]) * np.diff(s0))]
        return Track(name, s, np.interp(s, s0, k0), closed, x, y, **{k: np.interp(s, s0, v) for k, v in st.items()})
    if "x" in c and "y" in c:
        xy = get("x"), get("y")
        sigma = pos_sigma
    elif "lat" in c and "lon" in c:
        from .processing import latlon_to_xy
        xy = latlon_to_xy(get("lat"), get("lon"))
        sigma = max(pos_sigma, 0.3)
    elif all(k in c for k in ("xl", "yl", "xr", "yr")):
        return from_boundaries(np.c_[get("xl"), get("yl")], np.c_[get("xr"), get("yr")], ds, pos_sigma, name, closed)
    else:
        raise ValueError(f"{path}: need columns x,y or lat,lon or s,kappa (or the edges xl,yl,xr,yr)")
    if grade is not None:
        d0 = np.r_[0, np.cumsum(np.hypot(np.diff(xy[0]), np.diff(xy[1])))]
        st["z"] = np.r_[0, np.cumsum(0.5 * (grade[1:] + grade[:-1]) * np.diff(d0))]
    return from_xy(xy[0], xy[1], ds, sigma, name, closed, **st)


def from_processed_log(plog, ds=0.5, name="logged track") -> Track:
    """Track from the lap ensemble (median curvature across all good laps)."""
    from .processing import distance_ensemble
    if not plog.laps:
        raise ValueError("no laps found in the log - set gate_latlon or check the beacon channel")
    ens = distance_ensemble(plog.df, plog.laps, ["kappa", "x", "y", "v"])
    s = np.arange(0, ens["s"].iloc[-1], ds)
    k = np.interp(s, ens["s"], ens["kappa_med"])
    x = np.interp(s, ens["s"], ens["x_med"]) if "x_med" in ens else None
    y = np.interp(s, ens["s"], ens["y_med"]) if "y_med" in ens else None
    return Track(name, s, k, True, x, y)


def resolve_track_path(path, root=None):
    """Find a track file: as given, else by name under data/tracks/ and any of its subfolders
    (track files live in per-year / per-car folders such as data/tracks/ic_tracks2026/)."""
    p = Path(path)
    if root is not None and not p.is_absolute():
        p = Path(root) / p
    if p.exists():
        return p
    bases = [p.parent, p.parent / "tracks"]
    for b in ([Path(root)] if root is not None else []) + [Path(__file__).resolve().parents[1]]:
        bases += [b / "data/tracks"]
    for b in bases:
        if (b / p.name).exists():
            return b / p.name
    for b in bases[2:]:
        hits = sorted(x for x in b.rglob(p.name) if ".ipynb_checkpoints" not in x.parts) if b.is_dir() else []
        if hits:
            return hits[0]
    return p


def load_track(path, ds=0.5, **process_kw) -> Track:
    """A track .csv, or a logged run (.xrk/.xrz, or a RaceStudio .csv with a Time column)."""
    p = resolve_track_path(path)
    if p.suffix.lower() in (".xrk", ".xrz"):
        from .io_data import load_log
        from .processing import process_log
        return from_processed_log(process_log(load_log(p), **process_kw), ds, p.stem)
    head = p.read_text(errors="replace")[:4000].lower()
    if "time" in head.split("\n")[0] or '"time"' in head:
        from .io_data import load_log
        from .processing import process_log
        return from_processed_log(process_log(load_log(p), **process_kw), ds, p.stem)
    return from_csv(p, ds)
