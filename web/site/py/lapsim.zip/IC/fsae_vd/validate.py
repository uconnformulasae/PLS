"""Check the code against every number derived in the suspension white paper."""
from __future__ import annotations

import numpy as np
import pandas as pd

from . import kinematics as kin
from .config import CarConfig
from .scoring import infer_tmin
from .suspension import arb_tip_stiffness, series, wheel_rate
from .units import LBF, INCH, G0, to_unit


def paper_checks(cfg: CarConfig) -> pd.DataFrame:
    rows = []
    def chk(name, got, expected, tol, unit=""):
        rows.append({"check": name, "computed": got, "paper": expected, "unit": unit,
                     "pass": bool(abs(got - expected) <= tol)})
    h, L = cfg.mass.cg_height, cfg.geometry.wheelbase
    a = kin.anti_angles(cfg.anti.anti_dive, cfg.anti.anti_lift, cfg.anti.anti_squat, h, L, cfg.brakes.front_bias)
    chk("anti-dive line angle", a["front_phi"], 8.55, 0.01, "deg")
    chk("anti-lift line angle", a["rear_phi"], 2.58, 0.01, "deg")
    chk("anti-squat line angle", a["rear_theta"], 4.64, 0.01, "deg")
    chk("front FVSA from camber ROC", 1 / np.tan(np.radians(0.674037)) , to_unit(cfg.front.fvsa_length, "in"), 0.05, "in")
    chk("rear FVSA from camber ROC", 1 / np.tan(np.radians(0.716160)), to_unit(cfg.rear.fvsa_length, "in"), 0.05, "in")
    chk("braking force (620 lb, 1.88 g)", 620 * 1.88, 1165.6, 0.05, "lb")
    chk("braking load transfer", 620 * 1.88 * 11 / 61, 210.19, 0.01, "lb")
    th = cfg.front.rod_angle_deg
    fp = 138.42 / np.cos(np.radians(th))
    chk("front pull-rod force (static)", fp, 347.69, 0.5, "lbf")
    chk("front damper force (static)", fp * cfg.front.rocker_force_ratio, 178.04, 0.3, "lbf")
    res = 250 * (8 - 7.34) - 178.04
    chk("front static residual (k=250)", res, -13.04, 0.01, "lbf")
    kw = to_unit(wheel_rate(cfg.front), "lbf/in")
    chk("front wheel rate 350/1.18^2", kw, 251.4, 0.3, "lbf/in")
    chk("ride rate 354 & 700 lbf/in", series(354.0, 700.0), 235.1, 0.2, "lbf/in")
    eff = kin.steering_effort(150, 0.05, 0.85, 0.87, 5 / 12)
    chk("steering hand force", eff["hand_force"], 24.34, 0.01, "lbf")
    chk("U-joint phase at 25 deg", kin.ujoint_max_phase_deg(25), 2.82, 0.01, "deg")
    chk("U-joint phase at 35 deg", kin.ujoint_max_phase_deg(35), 5.71, 0.01, "deg")
    chk("front jacking ratio", kin.jacking_ratio(cfg.front.roll_center_height, cfg.geometry.track_front / 2), 0.136, 0.001)
    chk("rear jacking ratio", kin.jacking_ratio(cfg.rear.roll_center_height, cfg.geometry.track_rear / 2), 0.100, 0.001)
    ic = kin.instant_centre_from_rc(cfg.front.roll_center_height, cfg.front.fvsa_length, cfg.geometry.track_front / 2)
    chk("front IC height", to_unit(ic[1], "in"), 11.57, 0.01, "in")
    chk("tire inertia (corrected)", 0.5 * 4.64 * (0.127 ** 2 + 0.2032 ** 2), 0.1332, 0.0001, "kg m^2")
    c = cfg.copy(); c.front.arb_blade_length = 2.42 * INCH
    chk("ARB tip stiffness, 2.42 in blade", arb_tip_stiffness(c.front), 40339.72, 5, "N/m")
    chk("skidpad Tmin from 70 pts", infer_tmin("skidpad", 70, 5.159), 5.094, 0.001, "s")
    cla = cfg.aero.cla()
    chk("front downforce back at 35 mph", 0.5 * cfg.aero.rho * 15.6464 ** 2 * cla[0] / LBF, 62.16, 0.01, "lbf")
    return pd.DataFrame(rows)


def hardpoint_checks(cfg: CarConfig) -> pd.DataFrame:
    """Compare the CT17 hardpoint kinematics with the white paper / binder values.
    'agrees' is False where the files and the paper genuinely differ (reported, not hidden)."""
    from .hardpoints import Corner, analyse_corner, load_optimumk_csv
    rows = []
    def row(name, got, ref, tol, unit, src):
        rows.append({"quantity": name, "hardpoints": got, "paper": ref, "unit": unit, "paper source": src,
                     "agrees": bool(abs(got - ref) <= tol)})
    f = Corner(load_optimumk_csv(cfg.front.hardpoint_file), True)
    r = Corner(load_optimumk_csv(cfg.rear.hardpoint_file), False)
    kf = analyse_corner(f, np.array([0.0]), cfg.mass.cg_height, cfg.geometry.wheelbase, cfg.brakes.front_bias).static
    kr = analyse_corner(r, np.array([0.0]), cfg.mass.cg_height, cfg.geometry.wheelbase, cfg.brakes.front_bias).static
    row("front track", 2 * kf["track_half"] / INCH, 47, 0.01, "in", "N, B7")
    row("rear track", 2 * kr["track_half"] / INCH, 46, 0.01, "in", "N, B7")
    row("front KPI", kf["kpi_deg"], 16.0, 0.05, "deg", "B67, notes")
    row("front scrub radius", kf["scrub_radius"] * 1000, 35.3, 0.1, "mm", "B67")
    row("front scrub radius (notes)", kf["scrub_radius"] / INCH, 1.55, 0.02, "in", "notes (1.55 in)")
    row("front caster", kf["caster_deg"], 4.0, 0.1, "deg", "B67 (OptimumK 4.3)")
    row("front mechanical trail", kf["mech_trail"] * 1000, 14.3, 0.3, "mm", "B67")
    row("front pull-rod angle", kf["pull_rod_angle_from_vertical_deg"], 66.54, 0.05, "deg", "B59/62 derived")
    row("front damper static length", kf["damper_length_static"] / INCH, 7.34, 0.01, "in", "B22")
    row("rear damper static length", kr["damper_length_static"] / INCH, 7.34, 0.01, "in", "B22")
    row("front FVSA", kf["fvsa"] / INCH, 85.0, 1.0, "in", "B19 derived")
    row("rear FVSA", kr["fvsa"] / INCH, 80.0, 1.0, "in", "B19 derived")
    row("front roll-centre height", kf["rc_height"] / INCH, 3.2, 0.05, "in", "notes (confirmed); B67 3.50")
    row("rear roll-centre height", kr["rc_height"] / INCH, 2.3, 0.05, "in", "notes (confirmed); B67 2.50")
    row("front motion ratio (wheel/damper)", kf["motion_ratio_wheel_per_damper"], 1.18, 0.02, "-", "B67")
    row("rear motion ratio (wheel/damper)", kr["motion_ratio_wheel_per_damper"], 1.12, 0.02, "-", "B67")
    row("anti-dive", 100 * kf["anti_dive"], 50, 1, "%", "N (confirmed)")
    row("anti-lift", 100 * kr["anti_lift"], 10, 1, "%", "B19")
    row("anti-squat", 100 * kr["anti_squat"], 45, 1, "%", "N, B19")
    row("front ARB blade length in file", kf["blade_length_in_file"] / INCH, 2.42, 0.02, "in", "B43 (nearest setting)")
    return pd.DataFrame(rows)
