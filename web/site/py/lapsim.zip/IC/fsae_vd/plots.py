"""All result plots. Every function returns the matplotlib Figure."""
from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
from scipy import signal

from .units import G0

PURPLE, DEEP, MID, GREY = "#7A3FE0", "#4C1D95", "#A78BFA", "#6B7280"
plt.rcParams.update({"figure.dpi": 110, "axes.grid": True, "grid.alpha": 0.3, "axes.spines.top": False,
                     "axes.spines.right": False})


# ---------------------------------------------------------- data quality
def qc_channel(plog, name, t_window=None):
    """Raw vs cleaned signal, Winter residual curve, and PSD with the cut-off."""
    from .processing import winter_cutoff
    d = plog.df
    raw = d.get(name + "_raw", d[name]).to_numpy()
    clean = d[name].to_numpy()
    t = d["t"].to_numpy()
    fs = plog.fs
    fig, ax = plt.subplots(1, 3, figsize=(15, 3.8))
    sel = slice(None) if t_window is None else (t >= t_window[0]) & (t <= t_window[1])
    ax[0].plot(t[sel], raw[sel], color=MID, lw=0.6, label="raw (after spike/range removal)")
    ax[0].plot(t[sel], clean[sel], color=DEEP, lw=1.2, label="cleaned")
    ax[0].set(title=name, xlabel="t [s]"); ax[0].legend(fontsize=8)
    lo, hi = 0.5, 0.45 * fs
    fc, noise, (fcs, res) = winter_cutoff(raw, fs, lo, hi)
    ax[1].plot(fcs, res, color=PURPLE); ax[1].axhline(noise, color=GREY, ls="--", label=f"noise RMS {noise:.3g}")
    ax[1].axvline(plog.qc["channels"].get(name, {}).get("cutoff_hz", fc), color=DEEP, ls=":", label="chosen cut-off")
    ax[1].set(title="Winter residual analysis", xlabel="cut-off [Hz]", ylabel="RMS residual"); ax[1].legend(fontsize=8)
    ok = np.isfinite(raw)
    f, P = signal.welch(raw[ok] - np.nanmean(raw), fs, nperseg=min(4096, ok.sum()))
    f2, P2 = signal.welch(clean[ok] - np.nanmean(clean), fs, nperseg=min(4096, ok.sum()))
    ax[2].semilogy(f, P, color=MID, label="raw"); ax[2].semilogy(f2, P2, color=DEEP, label="cleaned")
    ax[2].set(title="Power spectral density", xlabel="f [Hz]"); ax[2].legend(fontsize=8)
    fig.tight_layout()
    return fig


def qc_summary(plog):
    from .processing import qc_table
    q = qc_table(plog)
    fig, ax = plt.subplots(1, 2, figsize=(13, 3.8))
    cols = [c for c in ("n_spikes", "n_out_of_range", "n_stuck") if c in q]
    q[cols].fillna(0).plot.bar(ax=ax[0], color=[PURPLE, DEEP, MID][:len(cols)])
    ax[0].set(title="Samples removed per channel", ylabel="count")
    if "snr_db" in q:
        q["snr_db"].dropna().plot.bar(ax=ax[1], color=PURPLE)
        ax[1].set(title="Signal-to-noise ratio after cleaning", ylabel="dB")
    fig.tight_layout()
    return fig


def lap_ensemble(ens, channel, ylabel=None):
    fig, ax = plt.subplots(figsize=(12, 3.5))
    m, s = ens[channel + "_med"], ens[channel + "_mad"]
    ax.fill_between(ens["s"], m - 2 * s, m + 2 * s, color=MID, alpha=0.35, label="±2 robust σ (lap-to-lap)")
    ax.plot(ens["s"], m, color=DEEP, label=f"median of {ens.attrs.get('n_laps')} laps")
    ax.set(xlabel="distance [m]", ylabel=ylabel or channel); ax.legend(fontsize=8)
    return fig


# ---------------------------------------------------------- envelopes
def gg(plog=None, env=None, ggv=None, speeds=(10, 20, 30)):
    fig, ax = plt.subplots(figsize=(6, 6))
    if plog is not None:
        d = plog.df[plog.df["v"] > 5]
        ax.scatter(d["ay"] / G0, d["ax"] / G0, s=1, color=MID, alpha=0.25, label="logged")
    if env is not None and len(env):
        e = env.sort_values("angle")
        ax.plot(e["ay"] / G0, e["ax"] / G0, "o-", color=DEEP, ms=3, label="99% envelope")
    if ggv is not None:
        for v in speeds:
            aym = ggv.ay_lim(v)
            ays = np.linspace(-aym, aym, 81)
            ax.plot(ays / G0, ggv.acc(np.full_like(ays, v), ays) / G0, color=PURPLE, lw=1)
            ax.plot(ays / G0, -ggv.brk(np.full_like(ays, v), ays) / G0, color=PURPLE, lw=1)
            ax.text(aym / G0, 0, f"{v} m/s", fontsize=7, color=PURPLE)
    ax.set(xlabel="lateral [g]", ylabel="longitudinal [g]", aspect="equal", title="g-g diagram")
    ax.legend(fontsize=8)
    return fig


def ggv_surface(ggv):
    fig, ax = plt.subplots(1, 3, figsize=(15, 3.8))
    ax[0].plot(ggv.v, ggv.ay_max / G0, color=DEEP); ax[0].set(title="lateral limit", xlabel="v [m/s]", ylabel="g")
    for j, f in enumerate(ggv.frac[::max(1, len(ggv.frac) // 5)]):
        jj = list(ggv.frac).index(f)
        ax[1].plot(ggv.v, ggv.ax_acc[:, jj] / G0, color=plt.cm.Purples(0.3 + 0.7 * f), label=f"{f:.0%} ay")
        ax[2].plot(ggv.v, ggv.ax_brk[:, jj] / G0, color=plt.cm.Purples(0.3 + 0.7 * f))
    ax[1].set(title="driving limit", xlabel="v [m/s]"); ax[1].legend(fontsize=7)
    ax[2].set(title="braking limit", xlabel="v [m/s]")
    fig.tight_layout()
    return fig


# ---------------------------------------------------------- laps & events
def lap(lr, logged=None, title=None):
    """Speed, accelerations, roll and wheel loads vs distance; logged ensemble overlay."""
    fig, ax = plt.subplots(4, 1, figsize=(12, 10), sharex=True)
    ax[0].plot(lr.s, lr.v, color=DEEP, label="simulated")
    if logged is not None and "v_med" in logged:
        sc = lr.s[-1] / logged["s"].iloc[-1]
        ax[0].plot(logged["s"] * sc, logged["v_med"], color=MID, label="logged (median)")
    ax[0].set(ylabel="v [m/s]", title=title or f"{lr.track.name}: {lr.time:.3f} s"); ax[0].legend(fontsize=8)
    ax[1].plot(lr.s, lr.ax / G0, color=PURPLE, label="ax"); ax[1].plot(lr.s, lr.ay / G0, color=DEEP, label="ay")
    ax[1].set(ylabel="g"); ax[1].legend(fontsize=8)
    ax[2].plot(lr.s, lr.state["roll_deg"], color=PURPLE, label="roll"); ax[2].plot(lr.s, lr.state["pitch_deg"], color=DEEP, label="pitch")
    ax[2].set(ylabel="deg"); ax[2].legend(fontsize=8)
    for k, c in zip(("fo", "fi", "ro", "ri"), (DEEP, MID, PURPLE, GREY)):
        ax[3].plot(lr.s, lr.state["Fz"][k], color=c, lw=1, label={"fo": "front outside", "fi": "front inside",
                                                                  "ro": "rear outside", "ri": "rear inside"}[k])
    ax[3].set(ylabel="Fz [N]", xlabel="distance [m]"); ax[3].legend(fontsize=7, ncol=4)
    fig.tight_layout()
    return fig


def track_map(lr):
    if lr.track.x is None:
        return None
    fig, ax = plt.subplots(figsize=(7, 6))
    sc = ax.scatter(lr.track.x, lr.track.y, c=lr.v, s=4, cmap="Purples")
    fig.colorbar(sc, label="v [m/s]")
    ax.set(aspect="equal", title=f"{lr.track.name} speed map", xlabel="x [m]", ylabel="y [m]")
    return fig


def events_summary(res, logged_times: dict | None = None):
    t = res.table()
    fig, ax = plt.subplots(1, 2, figsize=(12, 3.8))
    x = np.arange(len(t))
    ax[0].bar(x - 0.2, t["time_s"], 0.4, color=DEEP, label="simulated")
    if logged_times:
        ax[0].bar(x + 0.2, [logged_times.get(e, np.nan) for e in t.index], 0.4, color=MID, label="measured")
    ax[0].set_xticks(x, t.index); ax[0].set(ylabel="time [s]", yscale="log", title="event times"); ax[0].legend(fontsize=8)
    if t["points"].notna().any():
        ax[1].bar(x, t["points"].fillna(0), color=PURPLE)
        ax[1].set_xticks(x, t.index); ax[1].set(title="predicted points", ylabel="points")
    else:
        ax[1].text(0.5, 0.5, "set events.tmin_* to score", ha="center", transform=ax[1].transAxes)
    fig.tight_layout()
    return fig


# ---------------------------------------------------------- suspension
def suspension_summary(veh):
    from .units import to_unit
    fig, ax = plt.subplots(1, 3, figsize=(15, 3.8))
    R = {"front": veh.Rf, "rear": veh.Rr}
    names = list(R)
    ax[0].bar(names, [to_unit(R[n].wheel_rate, "lbf/in") for n in names], color=PURPLE, label="wheel rate")
    ax[0].bar(names, [to_unit(R[n].ride_rate, "lbf/in") for n in names], color=DEEP, width=0.4, label="ride rate (with tire)")
    ax[0].set(ylabel="lbf/in", title="rates"); ax[0].legend(fontsize=8)
    ax[1].bar(names, [R[n].ride_frequency for n in names], color=PURPLE); ax[1].set(ylabel="Hz", title="ride frequency")
    ays = np.linspace(0.1, 1.0, 10) * float(veh.ay_max(15.0)[0])
    st = veh.state(15.0, 0.0, ays)
    lltd = st["lt_front"] * veh.tf / (st["lt_front"] * veh.tf + st["lt_rear"] * veh.tr)
    ax[2].plot(ays / G0, lltd * 100, color=DEEP, label="front lateral load transfer share")
    ax[2].axhline(veh.Kf / (veh.Kf + veh.Kr) * 100, color=GREY, ls="--", label="front roll-stiffness share")
    ax[2].set(xlabel="ay [g]", ylabel="%", title="load-transfer distribution"); ax[2].legend(fontsize=8)
    fig.tight_layout()
    return fig


def kinematics(cfg, veh=None, roll_max=3.0):
    """Turn-relative camber of each wheel vs body roll (static camber + FVSA gain),
    instant-centre geometry, and (if a Vehicle is given) the roll gradient."""
    from . import kinematics as kin
    phi = np.linspace(0, roll_max, 31)
    fig, ax = plt.subplots(1, 3 if veh is not None else 2, figsize=(15 if veh is not None else 11, 3.8))
    for axle, a, t, col in (("front", cfg.front, cfg.geometry.track_front, DEEP),
                            ("rear", cfg.rear, cfg.geometry.track_rear, PURPLE)):
        fv = kin.axle_front_view(a, t / 2)
        r = (t / 2) / fv["fvsa"]
        c0 = a.static_camber_deg or 0
        ax[0].plot(phi, c0 + phi * (1 - r), color=col, label=f"{axle} outside")
        ax[0].plot(phi, -c0 + phi * (1 - r), color=col, ls="--", label=f"{axle} inside")
        icy, icz = fv["ic"]
        ax[1].plot([-t / 2, icy], [0, icz], color=col, lw=1)
        ax[1].plot([t / 2, -icy], [0, icz], color=col, lw=1, ls="--")
        ax[1].plot(0, fv["rc_height"], "o", color=col, label=f"{axle} RC {fv['rc_height'] / 0.0254:.2f} in")
    ax[0].set(xlabel="body roll [deg]", ylabel="turn-relative camber [deg]  (− = leaning into turn)",
              title="camber vs roll"); ax[0].legend(fontsize=7)
    ax[1].axhline(cfg.mass.cg_height, color=GREY, ls=":", label="CG")
    ax[1].set(xlabel="lateral [m]", ylabel="height [m]", title="front-view swing arms (to scale)")
    ax[1].legend(fontsize=7)
    if veh is not None:
        ays = np.linspace(0, float(veh.ay_max(15.0)[0]), 20)
        st = veh.state(15.0, 0.0, ays)
        ax[2].plot(ays / G0, st["roll_deg"], color=DEEP)
        ax[2].set(xlabel="ay [g]", ylabel="roll [deg]", title="roll gradient (15 m/s)")
    fig.tight_layout()
    return fig


def rod_loads(cfg, loads_lbf=(138.42, 303.18)):
    """Pull/push-rod force amplification vs rod angle, with the configured angle marked."""
    from .units import LBF
    th = np.linspace(0, 80, 161)
    fig, ax = plt.subplots(figsize=(7, 3.8))
    for Fv, ls in zip(loads_lbf, ("-", "--")):
        ax.plot(th, Fv / np.cos(np.radians(th)), color=DEEP, ls=ls, label=f"F_v = {Fv} lbf")
    if cfg.front.rod_angle_deg is not None:
        a = cfg.front.rod_angle_deg
        ax.axvline(a, color=PURPLE, ls=":", label=f"front {cfg.front.rod_type} rod {a:.2f}°")
    ax.set(xlabel="rod angle from vertical [deg]", ylabel="rod force [lbf]", ylim=(0, 1300),
           title="rod force amplification"); ax.legend(fontsize=8)
    return fig


def sensitivity_tornado(sens, col="d_score_per_step"):
    s = sens.dropna(subset=[col]).sort_values(col, key=np.abs)
    fig, ax = plt.subplots(figsize=(8, 0.45 * len(s) + 1.5))
    ax.barh(s["param"], s[col], color=[DEEP if v > 0 else MID for v in s[col]])
    ax.axvline(0, color="k", lw=0.8)
    ax.set(title="sensitivity of objective to +1 step", xlabel=col)
    fig.tight_layout()
    return fig


def optimisation_history(opt):
    h = np.array([(i, s - p) for i, (_, s, p) in enumerate(opt["history"])])
    fig, ax = plt.subplots(figsize=(8, 3.5))
    ax.plot(h[:, 0], h[:, 1], ".", color=MID, ms=3)
    ax.plot(h[:, 0], np.maximum.accumulate(h[:, 1]), color=DEEP, label="best so far")
    ax.axhline(opt["base"]["score"], color=GREY, ls="--", label="baseline")
    ax.set(xlabel="evaluation", ylabel="objective", title="setup optimisation"); ax.legend(fontsize=8)
    return fig


# ---------------------------------------------------------- CT17 hardpoints
_LINKS = [("CHAS_LowFor", "UPRI_LowPnt"), ("CHAS_LowAft", "UPRI_LowPnt"), ("CHAS_UppFor", "UPRI_UppPnt"),
          ("CHAS_UppAft", "UPRI_UppPnt"), ("CHAS_TiePnt", "UPRI_TiePnt"), ("UPRI_LowPnt", "UPRI_UppPnt"),
          ("NSMA_PPAttPnt", "ROCK_RodPnt"), ("ROCK_RodPnt", "CHAS_RocPiv"), ("CHAS_RocPiv", "ROCK_CoiPnt"),
          ("ROCK_CoiPnt", "ROCK_RodPnt"), ("ROCK_CoiPnt", "CHAS_AttPnt"), ("NSMA_UBarAttPnt", "UBAR_AttPnt"),
          ("UBAR_AttPnt", "CHAS_PivPnt")]


def hardpoint_views(cfg):
    """CT17 hardpoints to scale (mm). Left column: rear views (looking forward, +y = left) of the
    front suspension and of the rear suspension, stacked. Right column: side and top views."""
    from .hardpoints import load_optimumk_csv
    fig = plt.figure(figsize=(16, 9))
    gs = fig.add_gridspec(2, 2, width_ratios=[1, 1.35])
    ax_rv = {"front": fig.add_subplot(gs[0, 0]), "rear": fig.add_subplot(gs[1, 0])}
    ax_sv, ax_tv = fig.add_subplot(gs[0, 1]), fig.add_subplot(gs[1, 1])
    for which, f, col in (("front", cfg.front.hardpoint_file, DEEP), ("rear", cfg.rear.hardpoint_file, PURPLE)):
        if not f:
            ax_rv[which].text(0.5, 0.5, f"no {which} hardpoint file", ha="center", transform=ax_rv[which].transAxes)
            continue
        d = load_optimumk_csv(f)
        P, w = d["points"], d["wheel"]
        R, Wd = w["tire_diameter"] * 500, w["tire_width"] * 1000
        for side in (1, -1):
            Q = {k: v * np.array([1, side, 1]) * 1000 for k, v in P.items()}
            for a_, i, j in ((ax_rv[which], 1, 2), (ax_sv, 0, 2), (ax_tv, 0, 1)):
                if a_ is ax_sv and side == -1:
                    continue
                for p, q in _LINKS:
                    if p in Q and q in Q:
                        a_.plot([Q[p][i], Q[q][i]], [Q[p][j], Q[q][j]], color=col, lw=1.3)
                for v in Q.values():
                    a_.plot(v[i], v[j], "o", ms=2.5, color=col)
            y, x0 = side * w["half_track"] * 1000, w["x_offset"] * 1000
            ax_rv[which].add_patch(plt.Rectangle((y - Wd / 2, 0), Wd, 2 * R, fill=False, color=GREY, lw=0.8))
            ax_tv.add_patch(plt.Rectangle((x0 - R, y - Wd / 2), 2 * R, Wd, fill=False, color=GREY, lw=0.8))
            if side == 1:
                ax_sv.add_patch(plt.Circle((x0, R), R, fill=False, color=GREY, lw=0.8))
        ax_rv[which].axhline(0, color="k", lw=0.8)
        ax_rv[which].axvline(0, color=GREY, lw=0.6, ls=":")
        ax_rv[which].set(title=f"{which} suspension — rear view (looking forward, +y = left)",
                         aspect="equal", xlabel="y [mm]", ylabel="z [mm]", ylim=(-30, 2 * R + 40))
    ax_sv.set(title="side view (left, +x = forward)", aspect="equal", xlabel="x [mm]", ylabel="z [mm]")
    ax_tv.set(title="top view", aspect="equal", xlabel="x [mm]", ylabel="y [mm]")
    ax_sv.plot([], [], color=DEEP, label="front"); ax_sv.plot([], [], color=PURPLE, label="rear")
    ax_sv.legend(fontsize=8)
    fig.suptitle("CT17 suspension hardpoints (OptimumK export), to scale")
    fig.tight_layout()
    return fig


def kinematic_curves(veh):
    """Camber, toe, roll-centre height and damper length vs wheel travel from the hardpoints."""
    fig, ax = plt.subplots(1, 4, figsize=(17, 3.8))
    for A, col, nm in ((veh.Af, DEEP, "front"), (veh.Ar, PURPLE, "rear")):
        if A.k is None:
            continue
        z = A.k.travel * 1000
        ax[0].plot(z, A.k.camber, color=col, label=nm)
        ax[1].plot(z, A.k.toe, color=col)
        ax[2].plot(z, A.k.rc_height / 0.0254, color=col)
        ax[3].plot(z, A.k.damper_len * 1000, color=col)
        ax[2].axvline(A.z_static * 1000, color=col, ls=":", lw=0.8)
    ax[0].set(title="camber change (body)", xlabel="wheel travel [mm] (+ bump)", ylabel="deg (+ top out)")
    ax[1].set(title="bump steer", xlabel="wheel travel [mm]", ylabel="toe [deg] (+ in)")
    ax[2].set(title="roll-centre height", xlabel="wheel travel [mm]", ylabel="in")
    ax[3].set(title="damper length (slope = motion ratio)", xlabel="wheel travel [mm]", ylabel="mm")
    ax[0].legend(fontsize=8)
    fig.tight_layout()
    return fig


def adaptation(out):
    """Baseline vs adapted time and points for each event."""
    s = out["summary"].dropna(subset=["baseline_s"]) if "baseline_s" in out["summary"] else out["summary"]
    fig, ax = plt.subplots(1, 2, figsize=(12, 3.8))
    x = np.arange(len(s))
    ax[0].bar(x, 100 * s["gain_s"] / s["baseline_s"], color=PURPLE)
    ax[0].set_xticks(x, s.index); ax[0].set(ylabel="time saved [%]", title="gain from best adaptation")
    for i, (b, a) in enumerate(zip(s["baseline_s"], s["adapted_s"])):
        ax[0].text(i, 0, f"{b:.3f} → {a:.3f} s", ha="center", va="bottom", fontsize=7, rotation=90, color="w")
    if s["adapted_pts"].notna().any():
        ax[1].bar(x - 0.2, s["baseline_pts"].fillna(0), 0.4, color=MID, label="baseline")
        ax[1].bar(x + 0.2, s["adapted_pts"].fillna(0), 0.4, color=DEEP, label="adapted")
        ax[1].set_xticks(x, s.index); ax[1].set(ylabel="points", title="predicted points"); ax[1].legend(fontsize=8)
    else:
        ax[1].text(0.5, 0.5, "set events.tmin_* to score", ha="center", transform=ax[1].transAxes)
    fig.tight_layout()
    return fig


def tire_curves(tire, ttc=None, loads=(300, 700, 1100), pressure=None, title="tire model"):
    """Fy-alpha, Fx-kappa, combined envelope, Mz-alpha and mu vs load (camber / pressure),
    with TTC points overlaid when given (dict from load_ttc)."""
    from .mf61 import MF61Tire
    fig, ax = plt.subplots(1, 5, figsize=(21, 3.8))
    a = np.radians(np.linspace(0, 15, 151))
    cols = [MID, PURPLE, DEEP]
    for L, col in zip(loads, cols):
        ax[0].plot(np.degrees(a), tire.fy(a, L, 0.0, pressure), color=col, label=f"Fz {L} N")
        if isinstance(tire, MF61Tire):
            k = np.linspace(-0.3, 0.3, 121)
            ax[1].plot(k, tire.m.fx0(k, L, 0.0, pressure), color=col)
            mz = tire.mz(a, L, 0.0, pressure)
            ax[3].plot(np.degrees(a), mz, color=col)
        u = np.linspace(0, 0.999, 60)
        fxp = tire.peak_fx(L, 0.0, pressure)
        fy, _ = tire.lateral_capacity(np.full_like(u, L), 0.0, u * fxp, pressure)
        ax[2].plot(u * fxp / L, fy / L, color=col)
    if ttc is not None:
        fz = np.abs(ttc["FZ"])
        for L, col in zip(loads, cols):
            s = (np.abs(fz - L) < 0.08 * L) & (np.abs(ttc["IA"]) < 0.5)
            if ttc.get("SL") is not None:
                s &= np.abs(ttc["SL"]) < 0.01
            sgn = np.sign(np.nanmedian(ttc["FY"][s & (ttc["SA"] > 3)])) if (s & (ttc["SA"] > 3)).any() else 1
            ax[0].plot(np.abs(ttc["SA"][s]), sgn * ttc["FY"][s] * np.sign(ttc["SA"][s]), ".", ms=1, color=col, alpha=0.2)
    fz = np.linspace(150, 2500, 60)
    for g, ls in ((-2.0, "-"), (0.0, "--"), (2.0, ":")):
        ax[4].plot(fz, tire.mu(fz, g, pressure), color=DEEP, ls=ls, label=f"camber {g:+.0f}° (turn-rel.)")
    ax[0].set(title="lateral force", xlabel="slip angle [deg]", ylabel="Fy [N]"); ax[0].legend(fontsize=7)
    ax[1].set(title="longitudinal force", xlabel="slip ratio", ylabel="Fx [N]")
    ax[2].set(title="combined-slip envelope", xlabel="Fx / Fz", ylabel="Fy available / Fz")
    ax[3].set(title="aligning moment", xlabel="slip angle [deg]", ylabel="Mz [N*m]")
    ax[4].set(title="peak lateral mu", xlabel="Fz [N]", ylabel="mu"); ax[4].legend(fontsize=7)
    fig.suptitle(title)
    fig.tight_layout()
    return fig
