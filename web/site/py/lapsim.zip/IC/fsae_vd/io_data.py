"""Loading logged data from AiM .xrk / .xrz files and .csv exports.

Every channel keeps its own native time base and sample rate; nothing is
interpolated at load time (the processing module resamples with proper
anti-aliasing). Channels are mapped to standard names and converted to SI.

Standard channel names used throughout the package
---------------------------------------------------
speed_gps [m/s]  lat, lon [deg]  alt [m]  heading_gps [deg]  gps_nsat [-]
gps_pos_acc [m]  gps_spd_acc [m/s]  ax, ay, az [m/s^2] (vehicle x fwd, y left, z up)
yaw_rate, roll_rate, pitch_rate [rad/s]  steer [deg at steering wheel]
wheel_fl ... wheel_rr [m/s]  damper_fl ... damper_rr [m] (compression +)
throttle [%]  brake_f, brake_r [Pa]  rpm [1/min]  beacon [-]
"""
from __future__ import annotations

import csv
import dataclasses as dc
import re
from pathlib import Path

import numpy as np

from .units import G0

# regex aliases (case-insensitive) -> standard name. Extend or override with
# ``channel_map={"Exact Logger Name": "std_name"}`` when loading.
CHANNEL_ALIASES = {
    r"^gps[ _]?speed$": "speed_gps",
    r"^gps[ _]?lat(itude)?$": "lat",
    r"^gps[ _]?lon(gitude)?$": "lon",
    r"^gps[ _]?alt(itude)?$": "alt",
    r"^gps[ _]?heading$": "heading_gps",
    r"^gps[ _]?nsat$": "gps_nsat",
    r"^gps[ _]?pos[ _]?accuracy$": "gps_pos_acc",
    r"^gps[ _]?spd[ _]?accuracy$": "gps_spd_acc",
    r"^(inline[ _]?acc|acc[ _]?x|long(itudinal)?[ _]?acc)$": "ax",
    r"^(lateral[ _]?acc|acc[ _]?y|lat[ _]?acc)$": "ay",
    r"^(vertical[ _]?acc|acc[ _]?z|vert[ _]?acc)$": "az",
    r"^(yaw[ _]?rate|gyro[ _]?z)$": "yaw_rate",
    r"^(roll[ _]?rate|gyro[ _]?x)$": "roll_rate",
    r"^(pitch[ _]?rate|gyro[ _]?y)$": "pitch_rate",
    r"^(steer(ing)?([ _]?(angle|pos(ition)?))?)$": "steer",
    r"^(wheel[ _]?speed[ _]?|speed[ _]?|ws[ _]?)fl$": "wheel_fl",
    r"^(wheel[ _]?speed[ _]?|speed[ _]?|ws[ _]?)fr$": "wheel_fr",
    r"^(wheel[ _]?speed[ _]?|speed[ _]?|ws[ _]?)rl$": "wheel_rl",
    r"^(wheel[ _]?speed[ _]?|speed[ _]?|ws[ _]?)rr$": "wheel_rr",
    r"^(damper|shock|susp(ension)?)[ _]?(pos(ition)?[ _]?)?fl$": "damper_fl",
    r"^(damper|shock|susp(ension)?)[ _]?(pos(ition)?[ _]?)?fr$": "damper_fr",
    r"^(damper|shock|susp(ension)?)[ _]?(pos(ition)?[ _]?)?rl$": "damper_rl",
    r"^(damper|shock|susp(ension)?)[ _]?(pos(ition)?[ _]?)?rr$": "damper_rr",
    r"^(throttle|tps|pedal|apps)([ _]?pos(ition)?)?$": "throttle",
    r"^brake[ _]?(press(ure)?[ _]?)?(f|front)$": "brake_f",
    r"^brake[ _]?(press(ure)?[ _]?)?(r|rear)$": "brake_r",
    r"^(engine[ _]?|motor[ _]?)?rpm$": "rpm",
    r"^(beacon|lap[ _]?marker)$": "beacon",
}

# unit string -> factor to the SI/standard unit of that channel
_UNIT_FACTORS = {
    "km/h": 1 / 3.6, "kph": 1 / 3.6, "mph": 0.44704, "m/s": 1.0,
    "g": G0, "m/s2": 1.0, "m/s^2": 1.0,
    "deg/s": np.pi / 180, "rad/s": 1.0,
    "mm": 1e-3, "m": 1.0, "in": 0.0254,
    "bar": 1e5, "psi": 6894.757, "kpa": 1e3, "pa": 1.0,
    "%": 1.0, "deg": 1.0, "rpm": 1.0, "#": 1.0, "": 1.0,
}
_DEFAULT_UNITS = {"speed_gps": "km/h", "ax": "g", "ay": "g", "az": "g",
                  "yaw_rate": "deg/s", "roll_rate": "deg/s", "pitch_rate": "deg/s"}


@dc.dataclass
class Channel:
    t: np.ndarray            # time [s]
    x: np.ndarray            # values in standard units
    unit_raw: str = ""
    name_raw: str = ""

    @property
    def fs(self) -> float:
        dt = np.diff(self.t)
        dt = dt[dt > 0]
        return float(1.0 / np.median(dt)) if dt.size else float("nan")


@dc.dataclass
class LogData:
    channels: dict            # std_name -> Channel
    raw_names: dict           # raw name -> std name (or None if unmapped)
    laps: list | None = None  # [(start_s, end_s), ...] from the logger, if present
    meta: dict = dc.field(default_factory=dict)
    source: str = ""

    def has(self, *names) -> bool:
        return all(n in self.channels for n in names)

    def __getitem__(self, name) -> Channel:
        return self.channels[name]

    def summary(self) -> str:
        rows = [f"{'standard':<12} {'raw name':<28} {'fs [Hz]':>8} {'n':>8}"]
        for k, c in self.channels.items():
            rows.append(f"{k:<12} {c.name_raw:<28} {c.fs:8.1f} {c.x.size:8d}")
        unmapped = [r for r, s in self.raw_names.items() if s is None]
        if unmapped:
            rows.append("unmapped: " + ", ".join(unmapped))
        return "\n".join(rows)


def _std_name(raw: str, channel_map: dict | None):
    if channel_map and raw in channel_map:
        return channel_map[raw]
    key = raw.strip().lower()
    for pat, std in CHANNEL_ALIASES.items():
        if re.match(pat, key):
            return std
    return None


def _to_si(std: str, values: np.ndarray, unit: str) -> np.ndarray:
    u = (unit or _DEFAULT_UNITS.get(std, "")).strip().lower().replace("²", "2")
    if std in ("lat", "lon", "heading_gps", "steer", "throttle", "gps_nsat", "rpm", "beacon"):
        return values
    if std.startswith("wheel_") and u == "":
        u = "km/h"
    f = _UNIT_FACTORS.get(u)
    if f is None:
        raise ValueError(f"channel '{std}' has unrecognised unit '{unit}'; pass units in channel_map "
                         "or convert before loading")
    return values * f


# --------------------------------------------------------------------- loaders
def load_log(path: str | Path, channel_map: dict | None = None) -> LogData:
    """Load a .xrk, .xrz or .csv log. ``channel_map`` maps raw names to standard names."""
    path = Path(path)
    ext = path.suffix.lower()
    if ext in (".xrk", ".xrz"):
        return _load_xrk(path, channel_map)
    if ext == ".csv":
        return _load_csv(path, channel_map)
    raise ValueError(f"unsupported file type {ext}; use .xrk, .xrz or .csv")


def _load_xrk(path: Path, channel_map):
    try:
        from libxrk import aim_xrk, ChannelMetadata
    except ImportError as e:
        raise ImportError("Reading .xrk/.xrz needs 'pip install libxrk' "
                          "(or export the session to .csv from RaceStudio)") from e
    log = aim_xrk(str(path))
    chans, names = {}, {}
    for raw, table in log.channels.items():
        std = _std_name(raw, channel_map)
        names[raw] = std
        if std is None:
            continue
        cols = [c for c in table.column_names if c != "timecodes"]
        t = np.asarray(table.column("timecodes").to_numpy(), dtype=float) / 1000.0
        x = np.asarray(table.column(cols[0]).to_numpy(zero_copy_only=False), dtype=float)
        try:
            unit = ChannelMetadata.from_channel_table(table).units or ""
        except Exception:
            unit = ""
        chans[std] = Channel(t, _to_si(std, x, unit), unit, raw)
    laps = None
    try:
        lt = log.laps
        laps = [(lt.column("start_time")[i].as_py() / 1000.0, lt.column("end_time")[i].as_py() / 1000.0)
                for i in range(lt.num_rows)]
    except Exception:
        pass
    meta = dict(getattr(log, "metadata", {}) or {})
    return LogData(chans, names, laps, meta, str(path))


def _is_num(s: str) -> bool:
    try:
        float(s)
        return True
    except ValueError:
        return False


def _load_csv(path: Path, channel_map):
    """RaceStudio CSV export (metadata header + Time/units rows) or a plain CSV with a time column."""
    with open(path, newline="", encoding="utf-8-sig", errors="replace") as fh:
        rows = list(csv.reader(fh))
    # the channel header is the first row starting with 'Time' that has further non-empty cells
    # (RaceStudio's metadata block also has a 'Time' row: "Time","10:00:00")
    hdr = next((i for i, r in enumerate(rows)
                if r and r[0].strip().lower() in ("time", "time (s)", "time [s]", "t", "time_s", "timestamp")
                and sum(1 for c in r[1:] if c.strip()) >= 2), None)
    if hdr is None:
        raise ValueError(f"{path.name}: no column named 'Time' found")
    header = [h.strip() for h in rows[hdr]]
    units = [""] * len(header)
    start = hdr + 1
    if start < len(rows) and rows[start] and not _is_num(rows[start][0] or "x"):
        units = [u.strip() for u in rows[start]] + [""] * len(header)
        start += 1
    meta = {r[0].strip(): r[1].strip() for r in rows[:hdr] if len(r) >= 2 and r[0].strip()}
    # RaceStudio exports list lap (beacon) times in a 'Beacon Markers' header row
    beacons = next(([float(v) for v in r[1:] if _is_num(v)] for r in rows[:hdr]
                    if r and r[0].strip().lower() == "beacon markers"), [])
    data = []
    for r in rows[start:]:
        if not r or not _is_num(r[0]):
            continue
        data.append([float(v) if _is_num(v) else np.nan for v in (r + [""] * len(header))[:len(header)]])
    arr = np.asarray(data, dtype=float)
    t = arr[:, 0]
    if units[0].lower() in ("ms",):
        t = t / 1000.0
    chans, names = {}, {}
    for j, raw in enumerate(header[1:], start=1):
        std = _std_name(raw, channel_map)
        names[raw] = std
        if std is None:
            continue
        good = np.isfinite(arr[:, j])
        chans[std] = Channel(t[good], _to_si(std, arr[good, j], units[j]), units[j], raw)
    laps = [(a, b) for a, b in zip(beacons[:-1], beacons[1:])] if len(beacons) >= 2 else None
    if beacons:
        meta["beacon_markers"] = beacons
    return LogData(chans, names, laps, meta, str(path))


def load_ttc(path: str | Path):
    """Load FSAE TTC (Calspan) tire data exported to .csv.

    Needs columns for slip angle [deg], lateral force [N], normal load [N] and
    inclination angle [deg]; optional pressure [kPa] and slip ratio. Common TTC
    names (SA, FY, FZ, IA, P, SL, FX) are recognised. Returns a dict of arrays
    with FZ positive and sign conventions as logged.
    """
    import pandas as pd
    if isinstance(path, (list, tuple)):                       # several runs -> one data set
        parts = [load_ttc(p) for p in path]
        return {k: (np.concatenate([d[k] for d in parts]) if all(d[k] is not None for d in parts) else None)
                for k in parts[0]}
    path = Path(path)
    if path.suffix.lower() == ".dat":
        df = _read_ttc_dat(path)
    else:
        df = pd.read_csv(path)
    cols = {c.strip().upper(): c for c in df.columns}
    def pick(*names):
        for n in names:
            if n in cols:
                return df[cols[n]].to_numpy(dtype=float)
        return None
    out = {"SA": pick("SA", "SLIPANGLE"), "FY": pick("FY"), "FZ": pick("FZ"), "IA": pick("IA", "CAMBER"),
           "P": pick("P", "PRESSURE"), "SL": pick("SL", "SR", "SLIPRATIO"), "FX": pick("FX"),
           "MZ": pick("MZ"), "ET": pick("ET", "TIME"), "V": pick("V")}
    if any(out[k] is None for k in ("SA", "FY", "FZ")):
        raise ValueError("TTC file needs SA, FY and FZ columns")
    out["FZ"] = np.abs(out["FZ"])
    if out["IA"] is None:
        out["IA"] = np.zeros_like(out["SA"])
    # free-rolling (cornering) runs: Calspan logs SR as a constant -1 (not measured) -> slip ratio 0
    if out["SL"] is not None and np.nanmedian(np.abs(out["SL"] + 1.0)) < 0.01:
        out["SL"] = np.zeros_like(out["SA"])
    return out


_TTC_UNIT = {"lb": 4.4482216152605, "lbf": 4.4482216152605, "psi": 6.894757293168,    # -> N, kPa
             "ft-lb": 1.3558179483314, "mph": 1.609344, "in": 25.4}                     # -> N*m, km/h, mm


def _read_ttc_dat(path):
    """Calspan TIRF raw ASCII (.dat): title line, channel names, units, tab-separated data.
    USCS files are converted to N, kPa, N*m, km/h, mm (angles stay in degrees)."""
    import pandas as pd
    with open(path, errors="replace") as fh:
        fh.readline()
        names = fh.readline().strip().split("\t")
        units = fh.readline().strip().split("\t")
    df = pd.read_csv(path, sep="\t", skiprows=3, header=None, names=names, engine="c")
    for n, u in zip(names, units):
        f = _TTC_UNIT.get(u.strip().lower())
        if f is not None:
            df[n] = df[n] * f
    return df
