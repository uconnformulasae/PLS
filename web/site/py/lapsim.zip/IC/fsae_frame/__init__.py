"""fsae_frame - the spaceframe: tubes from the CAD, mass properties, a beam finite-element model
(torsional stiffness) and what the frame does to the lap.

    from fsae_frame import load_tubes, FrameModel, load_pickups
    tubes = load_tubes("data/frame/ct17_spaceframe_tubes.csv")
    frame = FrameModel(tubes, pickups=load_pickups(front_csv, rear_csv))
    frame.mass_properties()            # mass, CG, inertia (car axes)
    frame.torsion_test()               # N*m/deg between the axles' suspension pickups

See notebooks/frame.ipynb and tools/frame.py.
"""
from .tubes import Tube, extract_tubes, load_tubes, save_tubes, summary
from .model import FrameModel, load_pickups, register, to_car, STEEL_4130
from . import lapsim

__all__ = ["Tube", "extract_tubes", "load_tubes", "save_tubes", "summary", "FrameModel", "load_pickups",
           "register", "to_car", "STEEL_4130", "lapsim"]
