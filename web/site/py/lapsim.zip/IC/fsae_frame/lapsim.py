"""What the frame does to the lap.

Two routes into the vehicle model (fsae_vd):

  mass     the frame's mass and where it sits move the car's total mass, CG height and front weight
           fraction (``swap_frame``)
  twist    its torsional stiffness sits between the front and rear roll stiffness: a soft frame
           pulls the lateral load-transfer split towards the weight distribution, so spring / bar
           changes do less than intended (``mass.chassis_torsional_stiffness`` ->
           ``Vehicle.elastic_share_front``)

``events(cfg, ptc)`` runs the four events (with the powertrain model when ``ptc`` is given) and
returns times and points; the sweeps below call it for a list of frames.
"""
from __future__ import annotations

import math

import numpy as np


def elastic_share_front(Kf, Kr, Kc, ff):
    """Front share of the elastic lateral load transfer with a frame of torsional stiffness Kc
    (same units as Kf, Kr; inf = rigid) and front sprung-weight fraction ff."""
    if Kc is None or not np.isfinite(Kc):
        return Kf / (Kf + Kr)
    return Kf * (ff * (Kr + Kc) + (1 - ff) * Kc) / (Kf * Kr + Kc * (Kf + Kr))


def roll_authority(Kf, Kr, Kc, ff):
    """How much of a roll-stiffness change reaches the tires: (share with this frame - share by
    weight) / (rigid-frame share - share by weight). 1 = rigid frame, 0 = springs do nothing."""
    rigid = Kf / (Kf + Kr)
    if abs(rigid - ff) < 1e-9:
        return 1.0
    return (elastic_share_front(Kf, Kr, Kc, ff) - ff) / (rigid - ff)


def events(cfg, ptc=None, tracks=None):
    """{event_s, event_pts, dynamic_pts, ...} for one car."""
    from fsae_vd import aero_study as AS
    return AS.score(AS.run(cfg, ptc, tracks))


def with_stiffness(cfg, k_per_deg):
    """Copy of the car with the frame's torsional stiffness [N*m/deg] (None / inf = rigid)."""
    c = cfg.copy()
    c.mass.chassis_torsional_stiffness = (None if k_per_deg is None or not np.isfinite(k_per_deg)
                                          else float(k_per_deg) * 180.0 / math.pi)
    return c


def swap_frame(cfg, old, new):
    """Copy of the car with the frame ``old`` replaced by ``new`` (both ``mass_properties()`` dicts,
    car axes: x rearward from the front axle). The rest of the car keeps its mass and position."""
    c = cfg.copy()
    L = c.geometry.wheelbase
    m0 = c.mass.total
    dm = new["mass"] - old["mass"]
    m1 = m0 + dm
    x0 = (1 - c.mass.front_weight_fraction) * L                     # car CG behind the front axle
    x1 = (m0 * x0 - old["mass"] * old["cg"][0] + new["mass"] * new["cg"][0]) / m1
    h1 = (m0 * c.mass.cg_height - old["mass"] * old["cg"][2] + new["mass"] * new["cg"][2]) / m1
    c.mass.mass_no_driver = c.mass.mass_no_driver + dm
    c.mass.front_weight_fraction = 1 - x1 / L
    c.mass.cg_height = h1
    return c


def stiffness_sweep(cfg, ptc, k_per_deg, tracks=None):
    """Events for a list of frame torsional stiffnesses [N*m/deg] (inf = rigid). One row each."""
    import pandas as pd
    from fsae_vd import Vehicle
    rows = []
    for k in k_per_deg:
        c = with_stiffness(cfg, k)
        v = Vehicle(c)
        kc = c.mass.chassis_torsional_stiffness
        r = {"frame_Nm_per_deg": k, "frame_over_roll_stiffness": (k * 180 / math.pi) / (v.Kf + v.Kr) if np.isfinite(k) else np.inf,
             "elastic_share_front": v.elastic_share_front(),
             "roll_authority": roll_authority(v.Kf, v.Kr, kc if kc is not None else np.inf, v.ff)}
        r.update(events(c, ptc, tracks))
        rows.append(r)
    return pd.DataFrame(rows)


def mass_sweep(cfg, ptc, frame, scale=(0.8, 0.9, 1.0, 1.1, 1.2), tracks=None):
    """Events with the frame's mass scaled (same shape, lighter or heavier tubes)."""
    import pandas as pd
    rows = []
    for s in scale:
        new = dict(frame, mass=frame["mass"] * s)
        c = swap_frame(cfg, frame, new)
        r = {"frame_mass_kg": new["mass"], "car_mass_kg": c.mass.total, "cg_height_m": c.mass.cg_height,
             "front_weight_fraction": c.mass.front_weight_fraction}
        r.update(events(c, ptc, tracks))
        rows.append(r)
    return pd.DataFrame(rows)


def balance_authority(cfg, ptc, k_per_deg, d_front_bar=0.25, tracks=None):
    """Does a set-up change still work on this frame? Stiffen the front roll stiffness by
    ``d_front_bar`` (fraction, through the front spring and bar) and see how far the front share of
    the lateral load transfer moves, for each frame stiffness. Returns a DataFrame."""
    import pandas as pd
    from fsae_vd import Vehicle
    rows = []
    for k in k_per_deg:
        c = with_stiffness(cfg, k)
        v0 = Vehicle(c)
        Kf2 = v0.Kf * (1 + d_front_bar)
        kc = c.mass.chassis_torsional_stiffness
        kc = np.inf if kc is None else kc
        s0 = elastic_share_front(v0.Kf, v0.Kr, kc, v0.ff)
        s1 = elastic_share_front(Kf2, v0.Kr, kc, v0.ff)
        r0 = v0.Kf / (v0.Kf + v0.Kr)
        r1 = Kf2 / (Kf2 + v0.Kr)
        rows.append({"frame_Nm_per_deg": k, "share_before": s0, "share_after": s1, "moved": s1 - s0,
                     "moved_rigid": r1 - r0, "fraction_of_rigid": (s1 - s0) / (r1 - r0)})
    return pd.DataFrame(rows)
