"""Tube members of a spaceframe from its SolidWorks part.

The tessellation SolidWorks stores in the file (tools/sw_read.py) keeps every CAD face apart, with
vertex normals. A point on a tube's outer surface, moved inward along its normal by the tube
radius, lands on the tube's centreline - for straight tubes and for bends alike. So

  round tube, straight   outer cylinder face  -> axis segment, outer diameter; the coaxial bore
                         gives the wall thickness
  round tube, bend       outer torus face     -> arc on the centreline, cut into short segments
  square tube            its four corner fillets (parallel quarter cylinders) -> axis, side, wall

Result: a list of ``Tube`` (end points in the part's axes, metres). ``save_tubes`` / ``load_tubes``
keep them as a CSV so the CFD and the frame model do not need the CAD file.
"""
from __future__ import annotations

import csv
import dataclasses as dc
import math
from pathlib import Path

import numpy as np

INCH = 0.0254


@dc.dataclass
class Tube:
    p0: np.ndarray               # end points [m], part axes
    p1: np.ndarray
    od: float                    # outer diameter (round) or side (square) [m]
    wall: float                  # wall thickness [m]
    shape: str = "round"         # "round" | "square"
    bend: bool = False           # a piece of a bent tube
    member: int = -1             # pieces of one bent tube share a member number

    @property
    def length(self):
        return float(np.linalg.norm(self.p1 - self.p0))

    @property
    def area(self):
        """Metal cross-section [m^2]."""
        if self.shape == "square":
            return self.od ** 2 - (self.od - 2 * self.wall) ** 2
        return math.pi / 4 * (self.od ** 2 - (self.od - 2 * self.wall) ** 2)

    @property
    def inertia(self):
        """(I bending, J torsion) of the section [m^4]."""
        di = self.od - 2 * self.wall
        if self.shape == "square":
            I = (self.od ** 4 - di ** 4) / 12
            am = (self.od - self.wall) ** 2                       # thin-wall closed section (Bredt)
            return I, 4 * am ** 2 * self.wall / (4 * (self.od - self.wall))
        I = math.pi / 64 * (self.od ** 4 - di ** 4)
        return I, 2 * I

    @property
    def drag_width(self):
        """Width the airflow sees [m]."""
        return self.od


# ----------------------------------------------------------------------------- face fits
def _cylinder(N, P, tol=2.5e-4):
    """(axis, centre on the axis, radius, s_min, s_max, outward?) if the face is a cylinder."""
    if len(P) < 6:
        return None
    _u, s, vt = np.linalg.svd(N, full_matrices=False)
    if s[0] == 0 or s[2] / s[0] > 3e-3:
        return None
    a, e1, e2 = vt[2], vt[0], vt[1]
    uv = np.c_[P @ e1, P @ e2]
    c = np.linalg.lstsq(np.c_[2 * uv, np.ones(len(uv))], (uv ** 2).sum(1), rcond=None)[0]
    r2 = c[2] + c[0] ** 2 + c[1] ** 2
    if r2 <= 0:
        return None
    r = math.sqrt(r2)
    if r > 0.2 or np.abs(np.hypot(uv[:, 0] - c[0], uv[:, 1] - c[1]) - r).max() > tol:
        return None
    outward = np.mean(np.einsum("ij,ij->i", uv - c[:2], np.c_[N @ e1, N @ e2])) > 0
    s_ = P @ a
    return a, c[0] * e1 + c[1] * e2, r, float(s_.min()), float(s_.max()), bool(outward)


def _arc(N, P, radii, tol=4e-4):
    """Centreline polyline of an outer bend face: the tube radius (from ``radii``) for which
    P - r N collapses onto a planar arc. Returns (points (k, 3), r) or None."""
    best = None
    for r in radii:
        C = P - r * N
        c0 = C.mean(0)
        _u, s, vt = np.linalg.svd(C - c0, full_matrices=False)
        q = (C - c0) @ vt[:2].T                              # in the bend plane
        off = np.abs((C - c0) @ vt[2]).max()
        if off > tol or s[0] < 2e-3:
            continue
        cc = np.linalg.lstsq(np.c_[2 * q, np.ones(len(q))], (q ** 2).sum(1), rcond=None)[0]
        R2 = cc[2] + cc[0] ** 2 + cc[1] ** 2
        if R2 <= 0:
            continue
        R = math.sqrt(R2)
        err = np.abs(np.hypot(q[:, 0] - cc[0], q[:, 1] - cc[1]) - R).max()
        if err < tol and R < 2.0 and (best is None or err < best[0]):
            ang = np.unwrap(np.sort(np.arctan2(q[:, 1] - cc[1], q[:, 0] - cc[0])))
            # the face covers one contiguous arc: take the span left after removing the largest gap
            a_sorted = np.sort(np.mod(np.arctan2(q[:, 1] - cc[1], q[:, 0] - cc[0]), 2 * np.pi))
            gaps = np.diff(np.r_[a_sorted, a_sorted[0] + 2 * np.pi])
            k = int(np.argmax(gaps))
            a0 = a_sorted[(k + 1) % len(a_sorted)]
            span = 2 * np.pi - gaps[k]
            if span < math.radians(2) or span > math.radians(200):
                continue
            n = max(2, int(math.ceil(span / math.radians(15))) + 1)
            th = a0 + np.linspace(0, span, n)
            pts = c0 + np.outer(cc[0] + R * np.cos(th), vt[0]) + np.outer(cc[1] + R * np.sin(th), vt[1])
            best = (err, pts, r)
    return None if best is None else (best[1], best[2])


def _merge_collinear(segs, tol=1.5e-3):
    """Join straight pieces that lie on the same line and touch or overlap (a tube's surface is
    stored as two half cylinders, and split again where other tubes meet it)."""
    out = []
    for a, c, r, s0, s1 in sorted(segs, key=lambda q: -(q[4] - q[3])):
        for o in out:
            if abs(o["r"] - r) > 2e-4 or abs(abs(o["a"] @ a) - 1) > 1e-5:
                continue
            d = c - o["c"]
            if np.linalg.norm(d - (d @ o["a"]) * o["a"]) > tol:
                continue
            sign = 1.0 if o["a"] @ a > 0 else -1.0
            t0, t1 = sorted((sign * s0, sign * s1))
            if t0 <= o["s1"] + 3e-3 and t1 >= o["s0"] - 3e-3:
                o["s0"], o["s1"] = min(o["s0"], t0), max(o["s1"], t1)
                break
        else:
            c_perp = c - (c @ a) * a
            out.append({"a": a, "c": c_perp, "r": r, "s0": s0, "s1": s1})
    return out


# ----------------------------------------------------------------------------- extraction
def extract_tubes(mesh, min_od=0.3 * INCH, min_length=0.012):
    """Tubes of a spaceframe ``Mesh`` (tools/sw_read.py: needs ``mesh.faces``)."""
    cyl_out, cyl_in, rest = [], [], []
    for _tris, N, P in mesh.faces:
        if np.ptp(N, axis=0).max() < 2e-3:
            continue                                        # flat face
        c = _cylinder(N, P)
        if c is None:
            rest.append((N, P))
        elif c[5]:
            cyl_out.append(c)
        else:
            cyl_in.append(c)

    def bore_of(a, c, r):
        """Radius of the bore coaxial with an outer cylinder (largest one inside it), or None."""
        best = None
        for a2, c2, r2, *_ in cyl_in:
            if r2 < r - 0.02 * INCH and abs(abs(a2 @ a) - 1) < 1e-5:      # thinnest real wall is 0.028 in
                d = c2 - c
                if np.linalg.norm(d - (d @ a) * a) < 3e-4 and r - r2 < 0.2 * INCH and (best is None or r2 > best):
                    best = r2
        return best

    tubes = []
    # ---- straight round tubes
    rounds = [(a, c, r, s0, s1) for a, c, r, s0, s1, _o in cyl_out if 2 * r >= min_od]
    radii = sorted({round(r, 5) for _a, _c, r, _s0, _s1 in rounds})
    for o in _merge_collinear(rounds):
        if o["s1"] - o["s0"] < min_length:
            continue
        bore = bore_of(o["a"], o["c"], o["r"])
        tubes.append(Tube(o["c"] + o["s0"] * o["a"], o["c"] + o["s1"] * o["a"], 2 * o["r"],
                          (o["r"] - bore) if bore else float("nan")))
    # ---- bends
    member = 0
    for N, P in rest:
        if len(P) < 12:
            continue
        arc = _arc(N, P, radii)
        if arc is None:
            continue
        pts, r = arc
        for p, q in zip(pts[:-1], pts[1:]):
            tubes.append(Tube(p, q, 2 * r, float("nan"), bend=True, member=member))
        member += 1
    # ---- square tubes: four corner fillets
    fil_out = [(a, c, r, s0, s1) for a, c, r, s0, s1, _o in cyl_out if 2 * r < min_od]
    fil_in = [r for _a, _c, r, *_ in cyl_in if 2 * r < 0.5 * min_od]
    wall_sq = (np.median([f[2] for f in fil_out]) - np.median(fil_in)) if fil_out and fil_in else float("nan")
    used = np.zeros(len(fil_out), bool)
    for i, (a, c, r, s0, s1) in enumerate(fil_out):
        if used[i]:
            continue
        grp = [i]
        for j in range(i + 1, len(fil_out)):
            a2, c2 = fil_out[j][0], fil_out[j][1]
            d = c2 - c
            if not used[j] and abs(abs(a2 @ a) - 1) < 1e-5 and np.linalg.norm(d - (d @ a) * a) < 2.5 * INCH:
                grp.append(j)
        if len(grp) < 4:
            continue
        cs = np.array([fil_out[j][1] - (fil_out[j][1] @ a) * a for j in grp])
        centre = cs.mean(0)
        dist = np.linalg.norm(cs - centre, axis=1)
        keep = [grp[k] for k in np.argsort(np.abs(dist - np.median(dist)))[:4]]
        used[keep] = True
        cs = np.array([fil_out[j][1] - (fil_out[j][1] @ a) * a for j in keep])
        centre = cs.mean(0)
        side = math.sqrt(2) * float(np.linalg.norm(cs - centre, axis=1).mean()) + 2 * r
        ext = [np.sign(fil_out[j][0] @ a) * np.array(fil_out[j][3:5]) for j in keep]
        s_lo, s_hi = min(e.min() for e in ext), max(e.max() for e in ext)
        if s_hi - s_lo >= min_length:
            tubes.append(Tube(centre + s_lo * a, centre + s_hi * a, side, wall_sq, shape="square"))
    # ---- walls the CAD did not give directly: a bend takes the wall of the straight tube it joins
    known = [t for t in tubes if not math.isnan(t.wall)]
    for t in tubes:
        if math.isnan(t.wall):
            same = [k for k in known if abs(k.od - t.od) < 2e-4 and k.shape == t.shape]
            if same:
                ends = np.array([[k.p0, k.p1] for k in same]).reshape(-1, 3)
                d = np.minimum(np.linalg.norm(ends - t.p0, axis=1), np.linalg.norm(ends - t.p1, axis=1))
                t.wall = same[int(np.argmin(d)) // 2].wall
            else:
                t.wall = 0.049 * INCH
    return tubes


# ----------------------------------------------------------------------------- summary / io
def summary(tubes, density=7850.0):
    L = np.array([t.length for t in tubes])
    m = density * np.array([t.area for t in tubes]) * L
    mid = np.array([0.5 * (t.p0 + t.p1) for t in tubes])
    sizes = {}
    for t, l, mm in zip(tubes, L, m):
        k = (t.shape, round(t.od / INCH, 3), round(t.wall / INCH, 3))
        s = sizes.setdefault(k, [0, 0.0, 0.0])
        s[0] += 1
        s[1] += l
        s[2] += mm
    return {"count": len(tubes), "length": float(L.sum()), "mass": float(m.sum()),
            "cg": (m[:, None] * mid).sum(0) / m.sum(), "sizes": sizes}


FIELDS = ("x0", "y0", "z0", "x1", "y1", "z1", "od", "wall", "shape", "bend", "member")


def save_tubes(tubes, path, note=""):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="") as fh:
        if note:
            fh.write(f"# {note}\n")
        w = csv.writer(fh)
        w.writerow(FIELDS)
        for t in tubes:
            w.writerow([f"{v:.6f}" for v in (*t.p0, *t.p1, t.od, t.wall)] + [t.shape, int(t.bend), t.member])


def load_tubes(path):
    out = []
    with open(path) as fh:
        rows = csv.DictReader(ln for ln in fh if not ln.startswith("#"))
        for r in rows:
            out.append(Tube(np.array([float(r["x0"]), float(r["y0"]), float(r["z0"])]),
                            np.array([float(r["x1"]), float(r["y1"]), float(r["z1"])]),
                            float(r["od"]), float(r["wall"]), r["shape"], bool(int(r["bend"])), int(r["member"])))
    return out
