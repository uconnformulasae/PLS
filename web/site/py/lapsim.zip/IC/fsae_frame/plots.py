"""Drawings of the frame (matplotlib)."""
from __future__ import annotations

import numpy as np

VIEWS = (("side", 0, 2, "x rearward [m]", "z up [m]"), ("top", 0, 1, "x rearward [m]", "y right [m]"),
         ("front", 1, 2, "y right [m]", "z up [m]"))
SIZE_COLOURS = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#7a5cc7", "#52514e"]


def _style(ax):
    ax.set_aspect("equal")
    ax.grid(True, color="#e4e3df", lw=0.6)
    ax.set_axisbelow(True)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)


def frame_views(tubes, values=None, label="", cmap="viridis", pickups=None, title=None, vmax=None, displaced=None):
    """Side / top / front views. ``values`` (one per tube) colours the tubes on a scale; without it
    they are coloured by size. ``displaced``: (model, u, scale) draws the deformed model on top."""
    import matplotlib.pyplot as plt
    import matplotlib
    from matplotlib import cm, colors
    fig, axs = plt.subplots(1, 3, figsize=(17, 5.2), constrained_layout=True, gridspec_kw={"width_ratios": [2.3, 2.3, 1]})
    if values is not None:
        v = np.asarray(values, float)
        norm = colors.Normalize(0.0, vmax if vmax is not None else np.nanmax(v))
        cmap = matplotlib.colormaps[cmap]
        col = [cmap(norm(x)) if np.isfinite(x) else "#c9c8c2" for x in v]
        order = np.argsort(np.nan_to_num(v))
    else:
        keys = sorted({(t.shape, round(t.od / 0.0254, 2), round(t.wall / 0.0254, 3)) for t in tubes})
        cmap_k = {k: SIZE_COLOURS[i % len(SIZE_COLOURS)] for i, k in enumerate(keys)}
        col = [cmap_k[(t.shape, round(t.od / 0.0254, 2), round(t.wall / 0.0254, 3))] for t in tubes]
        order = range(len(tubes))
    for ax, (name, i, j, xl, yl) in zip(axs, VIEWS):
        for k in order:
            t = tubes[k]
            ax.plot([t.p0[i], t.p1[i]], [t.p0[j], t.p1[j]], color=col[k], lw=1.0 + 2.2 * t.od / 0.0254, solid_capstyle="round",
                    alpha=0.35 if displaced is not None else 1.0)
        if displaced is not None:
            model, u, scale = displaced
            N = model.nodes + scale * u[:, :3]
            for e in model.elements:
                if e.tube >= 0:
                    ax.plot([N[e.i, i], N[e.j, i]], [N[e.i, j], N[e.j, j]], color="#eb6834", lw=1.2)
        if pickups:
            P = np.array(list(pickups.values()))
            ax.plot(P[:, i], P[:, j], "o", ms=4, mfc="none", mec="#0b0b0b", mew=1.0, label="suspension pickups")
        ax.set_xlabel(xl); ax.set_ylabel(yl); ax.set_title(name, fontsize=10, loc="left")
        _style(ax)
    if values is not None:
        fig.colorbar(cm.ScalarMappable(norm=norm, cmap=cmap), ax=axs[-1], label=label, shrink=0.85)
    else:
        from matplotlib.lines import Line2D
        axs[0].legend(handles=[Line2D([0], [0], color=c, lw=3, label=f"{k[0]} {k[1]:g} x {k[2]:.3f} in") for k, c in cmap_k.items()],
                      fontsize=7, frameon=False, loc="upper left", ncol=2)
    if pickups:
        axs[1].legend(fontsize=7, frameon=False, loc="upper right")
    if title:
        fig.suptitle(title, fontsize=11, x=0.01, ha="left")
    return fig
