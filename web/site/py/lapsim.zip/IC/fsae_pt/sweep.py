"""Design and setup studies on the coupled car.

* ``quick_events``     the four events + endurance estimate for one car (fast, no thermal)
* ``sprocket_study``   every front x rear sprocket pair
* ``shift_study``      upshift rpm
* ``diff_study``       Drexler preload x ramp angle, and open / spool / ideal references
* ``grid2``            any two powertrain (or suspension) settings -> heat map
* ``sensitivity``      tornado: lap time / points change for a step in each setting
* ``optimise_setup``   exhaustive search over the car's discrete adjustments

A 'setting' is a dotted path, prefixed ``pt.`` for the powertrain config or
``vd.`` for the vehicle-dynamics config, e.g. ``pt.final_drive.rear_sprocket``,
``pt.differential.preload``, ``vd.rear.spring_rate``.
"""
from __future__ import annotations

import itertools

import numpy as np
import pandas as pd

from fsae_vd import scoring
from fsae_vd.track import circle

from .lapsim_pt import PTTables, accel_run, skidpad_time, solve_pt
from .vehicle_pt import PTVehicle

EVENTS = ("acceleration", "skidpad", "autocross", "endurance")
_TRACTION_KEYS = ("pt.differential", "vd.", "pt.wheels.slip", "pt.resistance")


def _apply(cfg, pt, path, value):
    if path.startswith("vd."):
        cfg.set(path[3:], value)
    elif path.startswith("pt."):
        pt.set(path[3:], value)
    else:
        raise ValueError("setting paths start with 'pt.' or 'vd.'")


def quick_events(cfg, pt, tracks, events=EVENTS, tggv=None, veh=None, n_end=None):
    veh = veh or PTVehicle(cfg, pt)
    tggv = tggv or veh.traction_ggv()
    T = PTTables(veh)
    ev = cfg.events
    out = {}
    if "acceleration" in events:
        r = accel_run(veh, tggv, T, ev.accel_length)
        out["acceleration"] = r.summary["fsae_time_s"]
        out["trap_speed_kph"] = r.summary["trap_speed_kph"]
    if "skidpad" in events:
        out["skidpad"] = skidpad_time(veh, tggv, ev.skidpad_radius)[0]
    if "autocross" in events and "autocross" in tracks:
        r = solve_pt(tracks["autocross"], veh, tggv, T, v0=0.0)
        out["autocross"] = r.time
        out["autocross_fuel_L"] = r.summary["fuel_L"]
    if "endurance" in events and "endurance" in tracks:
        tr = tracks["endurance"]
        n = n_end or max(1, int(round(ev.endurance_distance / tr.length)))
        f = solve_pt(tr, veh, tggv, T, v0=0.0)
        fl = solve_pt(tr, veh, tggv, T, flying=True)
        out["endurance"] = 2 * f.time + (n - 2) * fl.time
        out["endurance_lap"] = fl.time
        out["endurance_fuel_L"] = 2 * f.summary["fuel_L"] + (n - 2) * fl.summary["fuel_L"]
    out["v_top_kph"] = 3.6 * T.v_top
    return out


def points_of(cfg, times: dict):
    ev, p = cfg.events, {}
    for e in EVENTS:
        if e in times:
            tmin = getattr(ev, f"tmin_{'accel' if e == 'acceleration' else e}")
            if tmin:
                p[e] = scoring.points(e, times[e], tmin)
    return p


def _run(cfg, pt, tracks, events, cache, need_traction):
    if not need_traction and "tggv" in cache:
        return quick_events(cfg, pt, tracks, events, cache["tggv"], PTVehicle(cfg, pt))
    veh = PTVehicle(cfg, pt)
    tg = veh.traction_ggv()
    if not need_traction:
        cache["tggv"] = tg
    return quick_events(cfg, pt, tracks, events, tg, veh)


def study(cfg, pt, settings: dict, tracks, events=EVENTS, label=None):
    """Full-factorial study. settings = {path: [values]}. Returns one row per combination."""
    paths = list(settings)
    need = any(p.startswith(_TRACTION_KEYS) for p in paths)
    cache = {}
    rows = []
    for combo in itertools.product(*[settings[p] for p in paths]):
        c, p_ = cfg.copy(), pt.copy()
        for path, val in zip(paths, combo):
            _apply(c, p_, path, val)
        r = _run(c, p_, tracks, events, cache, need)
        pts = points_of(c, r)
        rows.append({**dict(zip(paths, combo)), **r, **{f"pts_{k}": v for k, v in pts.items()},
                     "pts_total": sum(pts.values()) if pts else np.nan})
    return pd.DataFrame(rows)


def sprocket_study(cfg, pt, tracks, fronts=None, rears=None, events=EVENTS):
    fronts = fronts or [pt.final_drive.front_sprocket]
    rears = rears or list(pt.final_drive.rear_sprocket_options)
    df = study(cfg, pt, {"pt.final_drive.front_sprocket": fronts, "pt.final_drive.rear_sprocket": rears}, tracks, events)
    df["final_drive"] = df["pt.final_drive.rear_sprocket"] / df["pt.final_drive.front_sprocket"]
    df["label"] = df["pt.final_drive.front_sprocket"].astype(str) + "/" + df["pt.final_drive.rear_sprocket"].astype(str)
    return df


def shift_study(cfg, pt, tracks, rpms=None, events=EVENTS):
    rpms = rpms if rpms is not None else [9500, 10000, 10500, 11000, 11500, 12000, 12500, 12900]
    return study(cfg, pt, {"pt.gearbox.shift_rpm": list(rpms)}, tracks, events)


def diff_study(cfg, pt, tracks, preloads=None, ramps=None, events=("acceleration", "skidpad", "autocross")):
    preloads = preloads or list(pt.differential.preload_options)
    ramps = ramps or list(pt.differential.ramp_options)
    a = study(cfg, pt, {"pt.differential.preload": preloads, "pt.differential.drive_ramp_deg": ramps}, tracks, events)
    a["type"] = "drexler"
    refs = []
    for t in ("open", "spool", "ideal"):
        r = study(cfg, pt, {"pt.differential.type": [t]}, tracks, events)
        refs.append(r)
    b = pd.concat(refs, ignore_index=True).rename(columns={"pt.differential.type": "type"})
    return a, b


def grid2(cfg, pt, tracks, path_a, vals_a, path_b, vals_b, metric="autocross", events=EVENTS):
    df = study(cfg, pt, {path_a: vals_a, path_b: vals_b}, tracks, events)
    return df, df.pivot(index=path_a, columns=path_b, values=metric)


def sensitivity(cfg, pt, tracks, steps: dict, events=EVENTS):
    """steps = {path: (minus_value, plus_value)}. Returns the change of every event time and
    total points relative to the baseline, for each end of each setting."""
    b = _run(cfg, pt, tracks, events, {}, True)
    bp = points_of(cfg, b)
    rows = []
    for path, (lo, hi) in steps.items():
        for side, val in (("low", lo), ("high", hi)):
            c, p_ = cfg.copy(), pt.copy()
            _apply(c, p_, path, val)
            r = _run(c, p_, tracks, events, {}, True)
            pp = points_of(c, r)
            row = {"setting": path, "side": side, "value": val}
            for e in events:
                if e in r and e in b:
                    row[f"d_{e}_s"] = r[e] - b[e]
            row["d_points"] = sum(pp.values()) - sum(bp.values()) if bp else np.nan
            rows.append(row)
    return b, pd.DataFrame(rows)


def optimise_setup(cfg, pt, tracks, space: dict, events=EVENTS, objective="pts_total"):
    """Exhaustive search over discrete adjustments. space = {path: [values]}.
    Ranks by total points if Tmin values are set, otherwise by summed event time."""
    df = study(cfg, pt, space, tracks, events)
    if objective == "pts_total" and df["pts_total"].notna().any():
        df = df.sort_values("pts_total", ascending=False)
    else:
        df["time_sum"] = df[[e for e in events if e in df]].sum(1)
        df = df.sort_values("time_sum")
    return df.reset_index(drop=True)
