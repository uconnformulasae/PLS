"""Fuel properties, consumption bookkeeping, CO2 and the FSAE efficiency score."""
from __future__ import annotations

import dataclasses as dc

import numpy as np

# LHV [J/kg], stoichiometric AFR, density [kg/m^3], CO2 [kg per litre] (FSAE rules conversion)
FUELS = {
    "gasoline": {"lhv": 43.0e6, "afr": 14.7, "rho": 740.0, "co2_per_l": 2.31, "restrictor_rule": 0.020},
    "e85": {"lhv": 29.2e6, "afr": 9.8, "rho": 785.0, "co2_per_l": 1.65, "restrictor_rule": 0.019},
}


@dc.dataclass
class FuelProps:
    name: str
    lhv: float
    afr: float
    rho: float
    co2_per_l: float
    restrictor_rule: float


def props(fuel_type: str) -> FuelProps:
    t = (fuel_type or "gasoline").lower()
    if t not in FUELS:
        raise ValueError(f"fuel.type must be one of {list(FUELS)}")
    return FuelProps(t, **FUELS[t])


def co2_kg(volume_m3: float, fuel_type: str) -> float:
    return volume_m3 * 1e3 * props(fuel_type).co2_per_l


def efficiency_factor(t_lap, co2_lap, t_min_lap, co2_min_lap):
    """FSAE efficiency factor per lap: (Tmin/T) * (CO2min/CO2)."""
    return (t_min_lap / t_lap) * (co2_min_lap / co2_lap)


def efficiency_score(ef, ef_min, ef_max, max_points=100.0):
    """Linear between the event's worst (ef_min) and best (ef_max) efficiency factors.
    The constants change between rules years: set them in scoring.* of the powertrain config."""
    return float(np.clip(max_points * (ef - ef_min) / max(ef_max - ef_min, 1e-9), 0.0, max_points))
