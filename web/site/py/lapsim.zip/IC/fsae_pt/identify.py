"""Identify powertrain parameters from the AiM / Syvecs S8 logs.

* ``read_ecu``          all powertrain channels of a .xrk on one time base
* ``identify_gearing``  gear-channel offset, overall ratio per gear, implied
                        front sprocket and effective rolling radius
* ``shift_events``      upshift / downshift torque-interruption times
* ``launch_info``       launch-control rpm and clutch lock-up speed
* ``wot_points``        crank torque and MAP vs rpm from full-throttle running
                        (F = m_eq a + drag + rolling, back through the driveline)
* ``fit_engine``        VE table + indicated efficiency fitted to torque AND MAP
* ``fit_thermal``       cooling parameters fitted to the logged coolant trace
* ``fuel_check``        logged vs modelled fuel use
* ``logged_lap``        speed / rpm / gear / throttle vs distance for comparison plots
"""
from __future__ import annotations

import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import optimize, signal

from .config import PTConfig
from .engine import Engine

ECU_CHANNELS = {
    "GPS Speed": "v", "S8_RPM": "rpm", "S8_gear": "gear_raw", "S8_tps1": "tps", "S8_map1": "map_bar",
    "S8_lam1_01": "lambda", "S8_ect1": "ect", "S8_act1": "act", "S8_eot": "eot", "S8_eop": "eop",
    "S8_fuelConsVolHR": "fuel_used_l", "S8_FuelConsVolRA": "fuel_rate_lps", "S8_vbat": "vbat",
    "S8_gearCutState": "gear_cut", "S8_gearUpOut": "up_out", "S8_gearDownOut": "down_out",
    "S8_ignFinal1": "ign", "S8_revLimitActiv": "rev_limit", "InlineAcc": "ax_imu", "LateralAcc": "ay_imu",
    "FBrakePressCorr": "brake_f", "GPS Latitude": "lat", "GPS Longitude": "lon", "S8_fp1": "fuel_press",
    "External Voltage": "v_ext",
}
_HOLD = {"gear_raw", "gear_cut", "up_out", "down_out", "rev_limit"}       # step channels: hold, don't interpolate


def read_ecu(path, fs=50.0) -> pd.DataFrame:
    """Every powertrain channel of an AiM .xrk/.xrz on one ``fs`` time base (SI where it matters)."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        from libxrk import aim_xrk
        log = aim_xrk(str(path))
    raw = {}
    for name, std in ECU_CHANNELS.items():
        if name not in log.channels:
            continue
        tb = log.channels[name]
        c = [c for c in tb.column_names if c != "timecodes"][0]
        t = np.asarray(tb.column("timecodes").to_numpy(), float) / 1000
        x = np.asarray(tb.column(c).to_numpy(zero_copy_only=False), float)
        ok = np.isfinite(x) & np.isfinite(t)
        if ok.sum() > 2:
            raw[std] = (t[ok], x[ok])
    t0 = max(min(r[0][0] for r in raw.values()), 0.0)
    t1 = min(r[0][-1] for k, r in raw.items() if k in ("rpm", "v"))
    t = np.arange(t0, t1, 1 / fs)
    d = {"t": t}
    for k, (tt, x) in raw.items():
        if k in _HOLD:
            d[k] = x[np.clip(np.searchsorted(tt, t, side="right") - 1, 0, len(x) - 1)]
        else:
            d[k] = np.interp(t, tt, x)
    df = pd.DataFrame(d)
    if "v" in df:
        v = df["v"].to_numpy()
        win = int(0.9 * fs) | 1
        df["v_s"] = signal.savgol_filter(v, win, 2)
        df["a"] = signal.savgol_filter(v, win, 2, deriv=1, delta=1 / fs)
        df["s"] = np.r_[0, np.cumsum(0.5 * (df["v_s"].to_numpy()[1:] + df["v_s"].to_numpy()[:-1]) / fs)]
    if "map_bar" in df:
        df["map_Pa"] = df["map_bar"] * 1e5
    df.attrs["source"] = Path(path).name
    return df


def load_logs(log_dir, pattern="*.xrk", fs=50.0):
    return {p.stem: read_ecu(p, fs) for p in sorted(Path(log_dir).glob(pattern))}


# --------------------------------------------------------------------------- ambient
def ambient_from_logs(logs: dict):
    """Barometric pressure = MAP with the engine stopped (key on); intake air temperature."""
    p, t = [], []
    for d in logs.values():
        off = d[d["rpm"] < 50]
        if len(off) > 20 and "map_Pa" in d:
            p.append(float(off["map_Pa"].median()))
        if "act" in d:
            t.append(float(d["act"].median()))
    return {"pressure_Pa": float(np.median(p)) if p else None, "intake_air_C": float(np.median(t)) if t else None}


def apply_ambient(pt: PTConfig, amb: dict):
    if amb.get("pressure_Pa"):
        pt.ambient.pressure = amb["pressure_Pa"]
    if amb.get("intake_air_C"):
        pt.ambient.temperature = amb["intake_air_C"] - pt.ambient.intake_temp_rise
    return pt


# --------------------------------------------------------------------------- gearing
def _steady(df, min_v=6.0, hold_s=0.5, fs=50.0):
    g = df["gear_raw"].to_numpy()
    w = int(hold_s * fs)
    from scipy.ndimage import maximum_filter1d, minimum_filter1d
    stable = minimum_filter1d(g, 2 * w + 1) == maximum_filter1d(g, 2 * w + 1)
    return stable & (df["v_s"] > min_v) & (np.abs(df["a"]) < 1.5) & (df["rpm"] > 4000) & (df["gear_cut"] <= 1)


def identify_gearing(logs: dict, pt: PTConfig, tire_radius: float):
    """Gear-channel offset, overall ratio per gear, implied front sprocket and rolling radius.

    For every steady sample rpm / v = overall_ratio * 60 / (2 pi r_eff). The ratio steps between
    neighbouring logged gears don't depend on r_eff or the sprockets, so they identify which
    real gear each logged number is (offset). The overall ratios then give the final drive
    * (r / r_eff); with the rear sprocket known the front sprocket is the nearest integer."""
    rows = []
    for name, df in logs.items():
        m = _steady(df)
        for g in np.unique(df["gear_raw"][m]):
            sel = m & (df["gear_raw"] == g)
            if sel.sum() > 30:
                rows.append({"log": name, "gear_raw": int(g), "n": int(sel.sum()),
                             "k": float(np.median(df["rpm"][sel] / df["v_s"][sel]))})
    tab = pd.DataFrame(rows)
    per = tab.groupby("gear_raw").apply(lambda x: np.average(x["k"], weights=x["n"]), include_groups=False)
    per_n = tab.groupby("gear_raw")["n"].sum()
    g = np.asarray(pt.gearbox.gear_ratios, float)
    raw = per.index.to_numpy()
    best = None
    for off in range(0, 4):
        real = raw - off
        ok = (real >= 1) & (real <= g.size)
        if ok.sum() < 2:
            continue
        # fit a single constant c: k = c * gear_ratio  (c = primary*FD*60/(2 pi r_eff))
        kk, gg, ww = per.to_numpy()[ok], g[real[ok] - 1], per_n.to_numpy()[ok]
        c = np.sum(ww * kk * gg) / np.sum(ww * gg * gg)
        err = np.sqrt(np.average((kk / (c * gg) - 1) ** 2, weights=ww))
        if best is None or err < best[1]:
            best = (off, err, c)
    off, err, c = best
    r_eff = tire_radius * pt.wheels.rolling_radius_factor
    fd_r = c * 2 * np.pi * r_eff / 60 / pt.gearbox.primary_ratio     # final drive at the configured r_eff
    rear = pt.final_drive.rear_sprocket
    front = rear / fd_r
    z1 = int(round(front))
    fd = rear / z1
    r_from = fd * pt.gearbox.primary_ratio * 60 / (2 * np.pi * c)
    table = pd.DataFrame({"gear_raw": raw, "real_gear": raw - off, "rpm_per_mps": per.to_numpy(), "samples": per_n.to_numpy()})
    table["overall_ratio_at_r_eff"] = table["rpm_per_mps"] * 2 * np.pi * r_eff / 60
    # every sprocket pair that reproduces the logged ratio, with the rolling radius it implies.
    # Only final_drive / r_eff is observable from rpm and speed, so the pair is chosen by the most
    # physical rolling radius (Hoosier 16 in: loaded/effective radius ~96-98 % of unloaded).
    cand = []
    for zr in sorted(set(pt.final_drive.rear_sprocket_options) | {rear}):
        for zf in range(9, 15):
            r_i = (zr / zf) * pt.gearbox.primary_ratio * 60 / (2 * np.pi * c)
            cand.append({"front": zf, "rear": zr, "final_drive": zr / zf, "rolling_radius_m": r_i,
                         "radius_factor": r_i / tire_radius})
    cand = pd.DataFrame(cand)
    cand = cand[(cand["radius_factor"] > 0.88) & (cand["radius_factor"] < 1.03)]
    cand["plausibility"] = -np.abs(cand["radius_factor"] - 0.97)
    cand = cand.sort_values("plausibility", ascending=False).reset_index(drop=True)
    return {"gear_channel_offset": int(off), "ratio_fit_rms_%": 100 * err, "final_drive_at_r_eff": fd_r,
            "rpm_per_mps_per_gear_ratio": c, "front_sprocket_exact": front, "front_sprocket": z1, "final_drive": fd,
            "rolling_radius_implied_m": r_from, "rolling_radius_factor_implied": r_from / tire_radius,
            "candidates": cand, "table": table}


def apply_gearing(pt: PTConfig, gid: dict, front=None, rear=None, tire_radius=0.2032):
    """Set gear offset, sprockets and the rolling radius that reproduces the logged rpm/speed.
    front/rear None -> the most plausible candidate pair."""
    pt.gearbox.gear_channel_offset = gid["gear_channel_offset"]
    cand = gid["candidates"]
    if front is None or rear is None:
        sel = cand.iloc[0] if rear is None else cand[cand["rear"] == rear].iloc[0]
        front, rear = int(sel["front"]), int(sel["rear"])
    pt.final_drive.front_sprocket, pt.final_drive.rear_sprocket = int(front), int(rear)
    r_i = (rear / front) * pt.gearbox.primary_ratio * 60 / (2 * np.pi * gid["rpm_per_mps_per_gear_ratio"])
    pt.wheels.rolling_radius_factor = float(r_i / tire_radius)
    return pt


def real_gear(df, pt):
    return np.rint(df["gear_raw"].to_numpy()).astype(int) - int(pt.gearbox.gear_channel_offset)


# --------------------------------------------------------------------------- shifts / launch
def _pulses(t, x):
    x = (np.asarray(x) > 0.5).astype(int)
    d = np.diff(x)
    on, off = np.flatnonzero(d > 0) + 1, np.flatnonzero(d < 0) + 1
    if off.size and on.size and off[0] < on[0]:
        off = off[1:]
    n = min(on.size, off.size)
    return t[on[:n]], t[off[:n]] - t[on[:n]]


def shift_events(logs: dict):
    rows = []
    for name, df in logs.items():
        t = df["t"].to_numpy()
        for kind, ch in (("up", "up_out"), ("down", "down_out")):
            if ch in df:
                ts, dur = _pulses(t, df[ch])
                for a, b in zip(ts, dur):
                    i = np.searchsorted(t, a)
                    rows.append({"log": name, "type": kind, "t": a, "duration_s": b,
                                 "rpm": float(df["rpm"].iloc[i]), "v": float(df["v_s"].iloc[i]),
                                 "tps": float(df["tps"].iloc[i]) if "tps" in df else np.nan})
    ev = pd.DataFrame(rows)
    up = ev[(ev["type"] == "up") & (ev["tps"] > 80)] if len(ev) else ev
    return ev, {"upshift_time_s": float(up["duration_s"].median()) if len(up) else None,
                "upshift_rpm_median": float(up["rpm"].median()) if len(up) else None,
                "downshift_time_s": float(ev[ev["type"] == "down"]["duration_s"].median()) if len(ev) else None,
                "n_up": int((ev["type"] == "up").sum()) if len(ev) else 0}


def launch_info(df, pt, tire_radius):
    """Launch rpm and clutch lock-up from a standing start at full throttle."""
    t = df["t"].to_numpy()
    wot = (df["tps"] > 90).to_numpy()
    start = np.flatnonzero(wot & (df["v_s"] < 1.0))
    if not start.size:
        return None
    i0 = start[0]
    seg = slice(i0, min(i0 + int(6 * 50), len(df)))
    d = df.iloc[seg]
    g = real_gear(d, pt).astype(int)
    r_eff = tire_radius * pt.wheels.rolling_radius_factor
    ov = pt.gearbox.primary_ratio * np.asarray(pt.gearbox.gear_ratios)[np.clip(g, 1, 6) - 1] * \
        pt.final_drive.rear_sprocket / pt.final_drive.front_sprocket
    rpm_road = d["v_s"] / r_eff * ov * 60 / (2 * np.pi)
    slip = (d["rpm"] - rpm_road) / d["rpm"]
    lock = np.flatnonzero(slip.to_numpy() < 0.05)
    return {"launch_rpm": float(d["rpm"][(d["v_s"] < 8)].median()),
            "lockup_speed_mps": float(d["v_s"].iloc[lock[0]]) if lock.size else None,
            "trace": d.assign(rpm_road=rpm_road, clutch_slip=slip, t_rel=d["t"] - t[i0])}


# --------------------------------------------------------------------------- torque from WOT
def wot_points(logs: dict, veh, pt: PTConfig, tps_min=95.0, min_gear=2, slip_tol=0.04):
    """Crank torque (and MAP) at every clean full-throttle sample.
    T_crank from F = m_eq(gear) * a + R(v), inverted through the driveline model."""
    dt = veh.dt
    out = []
    for name, df in logs.items():
        g = real_gear(df, pt)
        ok = (df["tps"] > tps_min) & (df["gear_cut"] <= 1) & (df["v_s"] > 4) & (g >= min_gear) & (g <= dt.n_gears)
        if "rev_limit" in df:
            ok &= df["rev_limit"] < 0.5
        ok = np.array(ok, dtype=bool)
        if ok.sum() < 10:
            continue
        gg = np.clip(g, 1, dt.n_gears)
        rpm_road = dt.rpm(df["v_s"].to_numpy(), gg)
        ok &= np.abs(df["rpm"].to_numpy() / np.maximum(rpm_road, 1) - 1) < slip_tol
        # keep only samples whose gear has been held >= 0.3 s (no shift transient)
        from scipy.ndimage import minimum_filter1d, maximum_filter1d
        st = minimum_filter1d(g, 31) == maximum_filter1d(g, 31)
        ok &= st
        if ok.sum() < 10:
            continue
        d = df[ok]
        gs = gg[ok]
        v, a, rpm = d["v_s"].to_numpy(), d["a"].to_numpy(), d["rpm"].to_numpy()
        meq = np.array([dt.equivalent_mass(k, veh.m) for k in gs])
        F = meq * a + veh.resist(v)
        T0, _ = dt.transmit(np.zeros_like(v), rpm, gs)
        T1, _ = dt.transmit(np.ones_like(v), rpm, gs)
        Tc = (F * dt.r - T0) / (T1 - T0) + veh.elec.drag_torque(rpm)
        out.append(pd.DataFrame({"log": name, "rpm": rpm, "gear": gs, "v": v, "a": a, "F": F, "T_crank": Tc,
                                 "map_Pa": d["map_Pa"].to_numpy() if "map_Pa" in d else np.nan,
                                 "lambda": d["lambda"].to_numpy() if "lambda" in d else np.nan,
                                 "fuel_rate_lps": d["fuel_rate_lps"].to_numpy() if "fuel_rate_lps" in d else np.nan}))
    pts = pd.concat(out, ignore_index=True)
    return pts


def bin_points(pts, col, width=250.0, q=0.5, min_n=8):
    b = (pts["rpm"] // width) * width + width / 2
    g = pts.groupby(b)[col]
    r = pd.DataFrame({"rpm": g.median().index, col: g.quantile(q).to_numpy(), "n": g.size().to_numpy(),
                      col + "_iqr": (g.quantile(0.75) - g.quantile(0.25)).to_numpy()})
    return r[r["n"] >= min_n].reset_index(drop=True)


def load_dyno(path):
    """Motor dyno csv: rpm + torque_ftlb or torque_Nm (comment lines start with #)."""
    d = pd.read_csv(path, comment="#")
    c = {k.lower().strip(): k for k in d.columns}
    T = d[c["torque_nm"]].to_numpy(float) if "torque_nm" in c else d[c["torque_ftlb"]].to_numpy(float) * 1.3558179
    return pd.DataFrame({"rpm": d[c["rpm"]].to_numpy(float), "T_crank": T})


def dyno_engine(pt: PTConfig):
    """The engine at the dyno's (correction) ambient conditions."""
    p = pt.copy()
    p.ambient.pressure, p.ambient.temperature = pt.engine.dyno_pressure, pt.engine.dyno_temperature
    p.engine.torque_scale = 1.0
    return Engine(p)


def fit_engine(pt: PTConfig, pts: pd.DataFrame, w_map=1.0, smooth=0.6, prior_w=0.15, fit_eta=True,
               lambda_from_log=True, fuel_from_log=True, dyno=None, use_log_torque=None, w_fuel=1.0):
    """With a motor dyno curve (engine.dyno_file or ``dyno``) the torque comes from the dyno, fitted
    at the dyno's ambient, and the logged MAP sets VE / intake losses at the track ambient. The
    logged WOT torque is then used for drag identification (fit_resistance) instead.
    Without a dyno the logged WOT torque is fitted directly."""
    """Fit the VE table and indicated efficiency so the engine model reproduces the logged
    full-throttle crank torque AND plenum pressure (they constrain different things: when the
    restrictor is choked torque depends on eta and Cd only, MAP on VE)."""
    pt = pt.copy()
    if dyno is None and pt.engine.dyno_file:
        dyno = load_dyno(pt.engine.dyno_file)
    if use_log_torque is None:
        use_log_torque = dyno is None
    tq = bin_points(pts, "T_crank")
    mp = bin_points(pts.dropna(subset=["map_Pa"]), "map_Pa")
    if lambda_from_log and pts["lambda"].notna().sum() > 50:
        lam = float(np.nanmedian(pts["lambda"].clip(0.7, 1.3)))
        pt.engine.lambda_wot = lam
    ve0 = np.asarray(pt.engine.ve, float)
    rpm_n = np.asarray(pt.engine.ve_rpm, float)

    nv = len(pt.engine.ve)

    fa, fb, fc = pt.engine.fmep_a, pt.engine.fmep_b, pt.engine.fmep_c
    fu = bin_points(pts.dropna(subset=["fuel_rate_lps"]), "fuel_rate_lps") if w_fuel and \
        pts["fuel_rate_lps"].notna().sum() > 50 else None

    def model(x):
        p = pt.copy()
        p.engine.ve = list(x[:nv])
        p.engine.eta_indicated = x[nv]
        p.intake.loss_coef = x[nv + 1] * 1e6
        p.engine.fmep_a, p.engine.fmep_b, p.engine.fmep_c = fa * x[nv + 2], fb * x[nv + 2], fc * x[nv + 2]
        p.engine.fuel_scale = 1.0
        return Engine(p)

    dy = dyno[(dyno["rpm"] >= 5000) & (dyno["rpm"] <= pt.engine.rev_limit + 500)] if dyno is not None else None

    def res(x):
        e = model(x)
        r1 = (e.torque_wot(tq["rpm"]) - tq["T_crank"]) / 2.0 * np.sqrt(tq["n"] / tq["n"].max()) \
            if use_log_torque else np.zeros(0)
        if dy is not None:
            ed = dyno_engine(e.pt)
            ed_rl = ed.e.rev_limit
            ed.e.rev_limit = 1e9                         # dyno sweep goes past the race rev limit
            r0 = (ed.torque_wot(dy["rpm"]) - dy["T_crank"]) / 1.0
            ed.e.rev_limit = ed_rl
            r1 = np.r_[r0, r1]
        r2 = w_map * (e.wot(mp["rpm"])["map"] - mp["map_Pa"]) / 2000.0 * np.sqrt(mp["n"] / mp["n"].max()) \
            if len(mp) else np.zeros(0)
        r3 = smooth * np.diff(x[:nv], 2) / 0.02
        r4 = prior_w * (x[:nv] - ve0) / 0.05
        # logged fuel flow + logged lambda -> air flow at the track (constrains intake losses / choke)
        r5 = w_fuel * (e.wot(fu["rpm"])["m_fuel"] - fu["fuel_rate_lps"] * 1e-3 * e.fuel.rho) / 0.15e-3 \
            * np.sqrt(fu["n"] / fu["n"].max()) if fu is not None else np.zeros(0)
        r6 = np.r_[(x[nv + 2] - 1.0) / 0.3]                  # friction scale prior
        return np.r_[r1, r2, r3, r4, r5, r6]

    x0 = np.r_[ve0, min(max(pt.engine.eta_indicated, 0.3), 0.42), pt.intake.loss_coef / 1e6, 1.0]
    lo = np.r_[np.full(ve0.size, 0.3), 0.28 if fit_eta else pt.engine.eta_indicated - 1e-6, 0.0, 0.5]
    hi = np.r_[np.full(ve0.size, 1.5), 0.44 if fit_eta else pt.engine.eta_indicated + 1e-6, 5.0, 1.6]
    r = optimize.least_squares(res, x0, bounds=(lo, hi), x_scale=np.r_[np.full(ve0.size, 0.05), 0.02, 0.5, 0.1])
    pt.engine.ve = [float(v) for v in r.x[:nv]]
    pt.engine.eta_indicated = float(r.x[nv])
    pt.intake.loss_coef = float(r.x[nv + 1] * 1e6)
    pt.engine.fmep_a, pt.engine.fmep_b, pt.engine.fmep_c = fa * r.x[nv + 2], fb * r.x[nv + 2], fc * r.x[nv + 2]
    pt.engine.fuel_scale = 1.0
    e = Engine(pt)
    # injector flow correction: logged fuel flow (S8 l/s) vs modelled at the same WOT rpm
    if fuel_from_log and pts["fuel_rate_lps"].notna().sum() > 50:
        ff = pts.dropna(subset=["fuel_rate_lps"])
        model_f = e.wot(ff["rpm"].to_numpy())["m_fuel"] / pt.engine.fuel_scale
        logged_f = ff["fuel_rate_lps"].to_numpy() * 1e-3 * e.fuel.rho
        pt.engine.fuel_scale = float(np.clip(np.median(logged_f / model_f), 0.7, 1.5))
        e = Engine(pt)
    rep = {"eta_indicated": pt.engine.eta_indicated, "lambda_wot": pt.engine.lambda_wot,
           "friction_scale": float(r.x[nv + 2]),
           "intake_loss_coef": pt.intake.loss_coef, "fuel_scale": pt.engine.fuel_scale,
           "log_torque_rms_Nm": float(np.sqrt(np.mean((e.torque_wot(tq["rpm"]) - tq["T_crank"]) ** 2))),
           "log_torque_bias_%": float(100 * np.mean(tq["T_crank"] / e.torque_wot(tq["rpm"]) - 1)),
           "map_rms_kPa": float(np.sqrt(np.mean((e.wot(mp["rpm"])["map"] - mp["map_Pa"]) ** 2)) / 1e3) if len(mp) else None,
           "rpm_range_with_data": (float(tq["rpm"].min()), float(tq["rpm"].max())), **e.summary()}
    if dy is not None:
        ed = dyno_engine(pt); ed.e.rev_limit = 1e9
        rep["dyno_torque_rms_Nm"] = float(np.sqrt(np.mean((ed.torque_wot(dy["rpm"]) - dy["T_crank"]) ** 2)))
        rep["dyno_peak_power_kW"] = float(np.max(ed.wot(np.arange(5000, 14001, 50.0))["power"]) / 1e3)
    return pt, rep, tq, mp


def calibrate_driveline_to_hub(pt: PTConfig, tire_radius, gear=4):
    """Scale the gearbox mesh efficiency so crank -> hub efficiency at hub_dyno_rpm equals
    hub_dyno_power / motor-dyno power at that rpm (PT63 vs PT61)."""
    from .drivetrain import Drivetrain
    if not (pt.engine.hub_dyno_power and pt.engine.dyno_file):
        return pt, None
    dy = load_dyno(pt.engine.dyno_file)
    r = pt.engine.hub_dyno_rpm
    P_crank = float(np.interp(r, dy["rpm"], dy["T_crank"])) * r * np.pi / 30
    target = pt.engine.hub_dyno_power / P_crank
    T = float(np.interp(r, dy["rpm"], dy["T_crank"]))

    def eta(ls):
        p = pt.copy(); p.gearbox.loss_scale = ls
        dt = Drivetrain(p, tire_radius)
        _, L = dt.transmit(np.array([T]), np.array([r]), np.array([gear]))
        # hub dyno reads at the hubs: everything except the tire
        return float(L.power_out[0] / L.power_in[0])
    from scipy.optimize import brentq
    before = eta(pt.gearbox.loss_scale)
    ls = brentq(lambda m: eta(m) - target, 0.05, 3.0)
    pt = pt.copy(); pt.gearbox.loss_scale = float(ls)
    return pt, {"target_efficiency": target, "efficiency_before": before, "loss_scale": ls,
                "crank_power_kW": P_crank / 1e3, "hub_power_kW": pt.engine.hub_dyno_power / 1e3, "gear": gear}


def track_torque_factor(pts: pd.DataFrame, veh, rpm_min=8000):
    """Logged crank torque (from F = m_eq a + R with the configured drag) / modelled WOT torque at
    the track ambient: how much of the dyno engine the car delivered on track. Robust median."""
    d = pts[pts["rpm"] > rpm_min]
    model = veh.engine.torque_wot(d["rpm"].to_numpy()) / max(veh.ptc.engine.torque_scale, 1e-9)
    ratio = d["T_crank"].to_numpy() / np.maximum(model, 1.0)
    q = np.quantile(ratio, [0.25, 0.5, 0.75])
    return {"factor": float(q[1]), "iqr": (float(q[0]), float(q[2])), "n": int(len(d))}


def fit_resistance(pts: pd.DataFrame, veh, v_min=8.0):
    """Drag (CdA) and rolling resistance (Crr) from full-throttle running once the engine is known
    from the dyno:  F_engine(v, gear) - m_eq a = 0.5 rho CdA v^2 + Crr (m g + downforce)."""
    d = pts[pts["v"] > v_min]
    dt = veh.dt
    v, a, g = d["v"].to_numpy(), d["a"].to_numpy(), d["gear"].to_numpy().astype(int)
    F = np.array([float(dt.wheel_force_wot(np.array([vv]), gg, launch=False)[0]) for vv, gg in zip(v, g)])
    meq = np.array([dt.equivalent_mass(k, veh.m) for k in g])
    R = F - meq * a
    rho = veh.cfg.aero.rho
    q = 0.5 * rho * v ** 2
    Nn = veh.m * 9.80665 + (veh.claf + veh.clar) * q
    A = np.column_stack([q, Nn])
    r = optimize.least_squares(lambda x: A @ x - R, [1.2, 0.02], loss="huber", f_scale=150.0,
                               bounds=([0.2, 0.0], [4.0, 0.08]))
    J = r.jac
    cov = np.linalg.pinv(J.T @ J) * np.sum(r.fun ** 2) / max(len(R) - 2, 1)
    return {"CdA": float(r.x[0]), "Crr": float(r.x[1]), "CdA_sd": float(np.sqrt(cov[0, 0])),
            "Crr_sd": float(np.sqrt(cov[1, 1])), "n": int(len(R)),
            "data": pd.DataFrame({"v": v, "R_obs": R, "R_fit": A @ r.x, "gear": g})}


# --------------------------------------------------------------------------- thermal
def fit_thermal(df, pt: PTConfig, params=("heat_to_coolant", "ua_ref", "thermal_mass_coolant"), stride=10):
    """Fit cooling parameters so the model, driven by the logged speed, rpm and fuel flow,
    reproduces the logged coolant temperature."""
    from .thermal import Thermal
    from .fuel import props
    d = df.iloc[::stride].reset_index(drop=True)
    lhv, rho = props(pt.fuel.type).lhv, props(pt.fuel.type).rho
    fuel_W = d["fuel_rate_lps"].clip(lower=0).to_numpy() * 1e-3 * rho * lhv
    t, v, rpm, ect = d["t"].to_numpy(), d["v_s"].clip(lower=0).to_numpy(), d["rpm"].to_numpy(), d["ect"].to_numpy()
    x0 = np.array([getattr(pt.cooling, p) for p in params], float)

    def sim(x):
        p = pt.copy()
        for k, val in zip(params, x):
            setattr(p.cooling, k, float(val))
        return Thermal(p).simulate(t, v, rpm, fuel_W, Tc0=float(ect[0]))

    def res(xs):
        return (sim(xs * x0)["Tc"] - ect)[::2]

    r = optimize.least_squares(res, np.ones_like(x0), bounds=(0.15, 6.0), diff_step=0.02)
    best = pt.copy()
    for k, val in zip(params, r.x * x0):
        setattr(best.cooling, k, float(val))
    out = sim(r.x * x0)
    return best, {k: float(v) for k, v in zip(params, r.x * x0)} | {"rms_C": float(np.sqrt(np.mean((out["Tc"] - ect) ** 2)))}, \
        pd.DataFrame({"t": t, "ect_log": ect, "ect_model": out["Tc"], "fan": out["fan"], "v": v, "rpm": rpm,
                      "fuel_kW": fuel_W / 1e3, "Q_rad_kW": out["Q_rad"] / 1e3})


# --------------------------------------------------------------------------- fuel
def fuel_check(df, veh, pt):
    """Logged fuel flow vs the model's fuel flow at the same rpm and the logged throttle state."""
    eng = veh.engine
    m = (df["rpm"] > 3500).to_numpy()
    d = df[m]
    used = float(df["fuel_used_l"].iloc[-1] - df["fuel_used_l"].iloc[0]) if "fuel_used_l" in df else np.nan
    wot = d["tps"] > 95
    w = eng.wot(d["rpm"][wot].to_numpy())
    rho = eng.fuel.rho
    return {"logged_fuel_used_L": used, "logged_time_s": float(df["t"].iloc[-1] - df["t"].iloc[0]),
            "logged_distance_km": float(df["s"].iloc[-1] / 1e3),
            "wot_fuel_rate_log_g_s": float(np.median(d["fuel_rate_lps"][wot]) * rho) if wot.any() else np.nan,
            "wot_fuel_rate_model_g_s": float(np.median(w["m_fuel"]) * 1e3) if wot.any() else np.nan}


# --------------------------------------------------------------------------- comparison
def logged_lap(df, pt, t0=None, t1=None):
    """Speed, rpm, real gear, throttle vs distance (zero at t0) for overlay on the simulation."""
    d = df if t0 is None else df[(df["t"] >= t0) & (df["t"] <= (t1 if t1 is not None else df["t"].iloc[-1]))]
    s = d["s"].to_numpy() - d["s"].iloc[0]
    return pd.DataFrame({"s": s, "t": d["t"].to_numpy() - d["t"].iloc[0], "v": d["v_s"].to_numpy(),
                         "rpm": d["rpm"].to_numpy(), "gear": real_gear(d, pt), "tps": d["tps"].to_numpy(),
                         "map_kPa": d["map_Pa"].to_numpy() / 1e3 if "map_Pa" in d else np.nan,
                         "ect": d["ect"].to_numpy() if "ect" in d else np.nan,
                         "lambda": d["lambda"].to_numpy() if "lambda" in d else np.nan})


def find_runs(df, v_move=3.0, min_len_s=20.0):
    """(t_start, t_end) of each moving run (car rolling above v_move for > min_len_s)."""
    mv = (df["v_s"] > v_move).to_numpy()
    t = df["t"].to_numpy()
    d = np.diff(mv.astype(int))
    on, off = list(np.flatnonzero(d > 0) + 1), list(np.flatnonzero(d < 0) + 1)
    if mv[0]:
        on = [0] + on
    if mv[-1]:
        off = off + [len(mv) - 1]
    return [(t[a], t[b]) for a, b in zip(on, off) if t[b] - t[a] > min_len_s]
