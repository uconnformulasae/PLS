"""Engine cooling: two lumped thermal nodes (coolant+block, oil) and the radiator.

    C_c dTc/dt = f_c * P_fuel - Q_rad - Q_conv + UA_oc (To - Tc)
    C_o dTo/dt = f_o * P_fuel - UA_oc (To - Tc)

Radiator: crossflow, both fluids unmixed, effectiveness-NTU.
    air flow   V_air = duct_ratio * v * A_core  (+ fan_flow when the fan is on)
    UA         = ua_ref * (V_air / air_flow_ref)^0.6  (air-side film coefficient ~ Re^0.6)
    coolant    m_c = pump_flow_per_krpm * rpm/1000 * thermostat opening
    Q_rad      = eps * C_min * (Tc - T_amb)
The fan switches on at fan_on_temp and off at fan_off_temp (hysteresis) and its
electrical power goes to the electrical model. Above derate_start_temp the
engine model loses torque (ECU timing pull).
"""
from __future__ import annotations

import dataclasses as dc

import numpy as np

from .config import PTConfig

CP_W, CP_AIR, RHO_AIR = 3600.0, 1007.0, 1.15     # 50/50 glycol-water [J/kg K], air


def eps_crossflow(ntu, cr):
    ntu = np.maximum(ntu, 1e-9)
    cr = np.clip(cr, 1e-6, 1.0)
    return 1 - np.exp((ntu ** 0.22 / cr) * (np.exp(-cr * ntu ** 0.78) - 1))


@dc.dataclass
class ThermalState:
    Tc: float
    To: float
    fan: bool = False


class Thermal:
    def __init__(self, pt: PTConfig):
        self.c = pt.cooling
        self.T_amb = pt.ambient.temperature
        self.A = self.c.core_width * self.c.core_height

    def init_state(self, Tc=None):
        T = self.c.start_temp if Tc is None else Tc
        return ThermalState(T, T, False)

    def thermostat(self, Tc):
        c = self.c
        return np.clip((Tc - c.thermostat_open) / max(c.thermostat_full - c.thermostat_open, 1e-3), 0.02, 1.0)

    def radiator(self, Tc, v, rpm, fan):
        c = self.c
        V_air = c.duct_ratio * np.maximum(v, 0.0) * self.A + (c.fan_flow if fan else 0.0)
        V_air = max(V_air, 0.01)
        UA = c.ua_ref * (V_air / c.air_flow_ref) ** 0.6
        C_air = RHO_AIR * V_air * CP_AIR
        if c.pump_type == "electric":
            m_c = c.pump_flow / 60.0 * 1.0 * self.thermostat(Tc)          # L/min -> kg/s (~1 kg/L)
        else:
            m_c = c.pump_flow_per_krpm * max(rpm, 1000.0) / 1000.0 * self.thermostat(Tc)
        C_c = m_c * CP_W
        Cmin, Cmax = min(C_air, C_c), max(C_air, C_c)
        eps = eps_crossflow(UA / Cmin, Cmin / Cmax)
        return float(eps * Cmin * (Tc - self.T_amb)), V_air

    def step(self, s: ThermalState, dt, v, rpm, fuel_power):
        c = self.c
        if s.Tc >= c.fan_on_temp:
            s.fan = True
        elif s.Tc <= c.fan_off_temp:
            s.fan = False
        q_rad, _ = self.radiator(s.Tc, v, rpm, s.fan)
        q_conv = 4.0 * (s.Tc - self.T_amb)            # block/hoses to air
        q_oc = c.oil_to_coolant_ua * (s.To - s.Tc)
        dTc = (c.heat_to_coolant * fuel_power - q_rad - q_conv + q_oc) / c.thermal_mass_coolant
        dTo = (c.heat_to_oil * fuel_power - q_oc) / c.thermal_mass_oil
        s.Tc += dTc * dt
        s.To += dTo * dt
        return s, {"Q_in_coolant": c.heat_to_coolant * fuel_power, "Q_rad": q_rad, "Q_oil": q_oc}

    def simulate(self, t, v, rpm, fuel_power, Tc0=None):
        """Integrate over time series (arrays). Returns dict of arrays."""
        s = self.init_state(Tc0)
        n = len(t)
        out = {k: np.empty(n) for k in ("Tc", "To", "fan", "Q_in", "Q_rad")}
        for i in range(n):
            dt = t[i] - t[i - 1] if i else 0.0
            if dt > 0:
                # sub-step for stability
                nsub = max(1, int(dt / 0.5) + 1)
                for _ in range(nsub):
                    s, q = self.step(s, dt / nsub, v[i], rpm[i], fuel_power[i])
            else:
                _, q = self.step(ThermalState(s.Tc, s.To, s.fan), 0.0, v[i], rpm[i], fuel_power[i])
            out["Tc"][i], out["To"][i], out["fan"][i] = s.Tc, s.To, s.fan
            out["Q_in"][i], out["Q_rad"][i] = q["Q_in_coolant"], q["Q_rad"]
        return out
