"""fsae_pt - powertrain section of the predictive lap simulation (CT17, Yamaha R6).

Plugs into the vehicle-dynamics / suspension package ``fsae_vd``:

    import fsae_vd as vd, fsae_pt as pt
    cfg = vd.load_config("configs/ct17_baseline.yaml")       # suspension, tires, aero, mass
    ptc = pt.load_pt_config("configs/ct17_powertrain.yaml")   # engine, gearbox, chain, diff, cooling ...
    ptc.set("final_drive.rear_sprocket", 31)                   # change anything
    res = pt.run_events_pt(cfg, ptc)                           # all events, gear by gear
    res.laps["autocross"].frame()                              # suspension + powertrain channels together
"""
from .config import PTConfig, load_pt_config, save_pt_config
from .engine import Engine
from .drivetrain import Drivetrain, Differential, STAGES
from .electrical import Electrical
from .thermal import Thermal
from .vehicle_pt import PTVehicle
from .lapsim_pt import PTTables, LapPT, solve_pt, run_events_pt, endurance, make_tracks, LIMITS, LIMIT_COLORS
from . import fuel, identify, sweep, dynamics, plots_pt, calibrate

__all__ = ["PTConfig", "load_pt_config", "save_pt_config", "Engine", "Drivetrain", "Differential", "STAGES",
           "Electrical", "Thermal", "PTVehicle", "PTTables", "LapPT", "solve_pt", "run_events_pt", "endurance",
           "make_tracks", "LIMITS", "LIMIT_COLORS", "fuel", "identify", "sweep", "dynamics", "plots_pt", "calibrate"]
