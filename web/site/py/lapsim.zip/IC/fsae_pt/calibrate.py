"""One-call setup of the coupled suspension + powertrain model from the team's data.

``build_car`` reproduces the identification chain used in the notebook so a
sweep or script can start from the same calibrated car:
    gearing from the logs -> engine VE / efficiency from WOT torque and MAP ->
    shift time and launch rpm from the ECU -> grip scaled to the skidpad result.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
from scipy.optimize import brentq

import fsae_vd as vd
from fsae_vd import identification as ident
from fsae_vd.units import parse_quantity as Q

from . import identify as idf
from .config import load_pt_config
from .lapsim_pt import skidpad_time
from .vehicle_pt import PTVehicle


def grip_to_skidpad(cfg, pt, t_target, lo=0.3, hi=1.5):
    """Tire grip scale (tires.lambda_mu) for which the simulated skidpad lap equals t_target."""
    def f(lam):
        c = cfg.copy()
        c.tires.lambda_mu = lam
        veh = PTVehicle(c, pt)
        tg = veh.traction_ggv(n_v=14, n_ay=8)
        return skidpad_time(veh, tg, c.events.skidpad_radius)[0] - t_target
    lam = brentq(f, lo, hi, xtol=1e-3)
    cfg.tires.lambda_mu = float(lam)
    return cfg, float(lam)


def build_car(root, log_dir=None, skidpad_time=5.159, use_logs=True, verbose=True, track_calibrate=True,
              autocross_track="default", endurance_track="default"):
    root = Path(root)
    cfg = vd.load_config(root / "configs/ct17_baseline.yaml")
    pt = load_pt_config(root / "configs/ct17_powertrain.yaml")
    if cfg.tires.mu0 is None:
        cfg.tires.mu0, cfg.tires.mu_fz = ident.tire_from_two_points(Q("50 lbf"), 550, Q("250 lbf"), 2600)
    # tracks: "default" = the default track set (configs/tracks/ic_2026.yaml); pass a file, or
    # **load_track_set(name).build_car_kwargs() to use another set
    if "default" in (autocross_track, endurance_track):
        from fsae_vd.track_sets import load_track_set
        dflt = load_track_set(root=root).build_car_kwargs()
        autocross_track = dflt["autocross_track"] if autocross_track == "default" else autocross_track
        endurance_track = dflt["endurance_track"] if endurance_track == "default" else endurance_track
    cfg.events.autocross_track = str(root / autocross_track) if autocross_track else cfg.events.autocross_track
    cfg.events.endurance_track = str(root / endurance_track) if endurance_track else cfg.events.endurance_track
    info = {}
    logs = {}
    log_dir = Path(log_dir) if log_dir else root / "data/logs"
    if use_logs and any(log_dir.glob("*.xrk")):
        logs = idf.load_logs(log_dir)
        idf.apply_ambient(pt, idf.ambient_from_logs(logs))
        gid = idf.identify_gearing(logs, pt, cfg.tires.tire_radius)
        # sprockets from the powertrain binder (PT55); the logs then fix the rolling radius
        idf.apply_gearing(pt, gid, front=pt.final_drive.front_sprocket, rear=pt.final_drive.rear_sprocket,
                          tire_radius=cfg.tires.tire_radius)
        info["gearing"] = gid
        _, sh = idf.shift_events(logs)
        if sh["upshift_time_s"]:
            pt.gearbox.upshift_time = float(np.clip(sh["upshift_time_s"], 0.04, 0.25))
        info["shifts"] = sh
        acc = [k for k in logs if "accel" in k.lower()]
        if acc:
            li = idf.launch_info(logs[acc[-1]], pt, cfg.tires.tire_radius)
            if li:
                pt.engine.launch_rpm = float(round(li["launch_rpm"], -1))
                info["launch"] = li
        pt, hub = idf.calibrate_driveline_to_hub(pt, cfg.tires.tire_radius)
        info["hub"] = hub
        cfg.tires.lambda_mu = 0.6
        veh = PTVehicle(cfg, pt)
        pts = idf.wot_points(logs, veh, pt)
        pt, rep, tq, mp = idf.fit_engine(pt, pts)
        veh = PTVehicle(cfg, pt)
        pts = idf.wot_points(logs, veh, pt)
        tf = idf.track_torque_factor(pts, veh)
        info.update(engine_fit=rep, wot_points=pts, torque_bins=idf.bin_points(pts, "T_crank"), map_bins=mp,
                    track_factor=tf)
        if track_calibrate:
            pt.engine.torque_scale = tf["factor"]
    if skidpad_time:
        cfg, lam = grip_to_skidpad(cfg, pt, skidpad_time)
        info["lambda_mu"] = lam
    if verbose:
        g = info.get("gearing")
        if g is not None:
            print(f"gearing: logged gear = real + {g['gear_channel_offset']}, sprockets {pt.final_drive.front_sprocket}/"
                  f"{pt.final_drive.rear_sprocket}, rolling radius factor {pt.wheels.rolling_radius_factor:.3f}")
        if "engine_fit" in info:
            r = info["engine_fit"]
            print(f"engine (track ambient, before track factor): {r['peak_power_kW']:.1f} kW at {r['at_rpm_power']:.0f} rpm, "
                  f"{r['peak_torque_Nm']:.1f} N m; dyno fit rms {r.get('dyno_torque_rms_Nm', float('nan')):.2f} N m")
            print(f"track torque factor {info['track_factor']['factor']:.3f} "
                  f"({'applied' if track_calibrate else 'not applied'})")
        if "lambda_mu" in info:
            print(f"grip: lambda_mu = {info['lambda_mu']:.3f} (skidpad {skidpad_time} s)")
    return cfg, pt, logs, info
