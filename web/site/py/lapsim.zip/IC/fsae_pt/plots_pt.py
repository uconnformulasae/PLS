"""Powertrain figures. Every function returns a matplotlib Figure.

Colours: categorical slots in fixed order (gear 1..6, sprocket options, diff
types); one-hue ramps for magnitudes; red/blue diverging with a grey midpoint
for signed changes. One y-scale per axes (no twin axes): two measures are two panels.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.colors import ListedColormap, BoundaryNorm, TwoSlopeNorm
from matplotlib.patches import Patch

from fsae_vd.units import G0

from .drivetrain import STAGES
from .lapsim_pt import LIMIT_COLORS, LIMITS, PTTables

CAT = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
INK, INK2, GRID = "#0b0b0b", "#52514e", "#d9d8d3"
SEQ, DIV = "Blues", "RdBu_r"
plt.rcParams.update({"figure.dpi": 110, "axes.grid": True, "grid.alpha": 0.35, "grid.color": GRID,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": INK2,
                     "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2, "lines.linewidth": 2.0,
                     "legend.frameon": False, "axes.titleweight": "bold", "axes.titlesize": 11})


def gc(g):
    return CAT[(int(g) - 1) % len(CAT)]


def _gear_cmap(n):
    return ListedColormap([gc(g) for g in range(1, n + 1)]), BoundaryNorm(np.arange(0.5, n + 1.5), n)


# =========================================================================== ENGINE
def engine_curves(eng, tq_bins=None, pts=None, unrestricted=None, title="Engine at full throttle"):
    r = np.arange(3000, eng.e.rev_limit + 1, 50.0)
    w = eng.wot(r)
    fig, ax = plt.subplots(1, 2, figsize=(14, 4.6))
    if pts is not None and len(pts):
        ax[0].scatter(pts["rpm"], pts["T_crank"], s=4, color=CAT[0], alpha=0.12, label="logged WOT samples")
    if tq_bins is not None and len(tq_bins):
        ax[0].errorbar(tq_bins["rpm"], tq_bins["T_crank"], yerr=tq_bins["T_crank_iqr"] / 2, fmt="o", ms=5,
                       color=INK2, capsize=2, label="logged, median per 250 rpm")
    ax[0].plot(r, w["torque"], color=CAT[0], label="model (restricted)")
    if unrestricted is not None:
        wu = unrestricted.wot(r)
        ax[0].plot(r, wu["torque"], color=CAT[1], ls="--", lw=1.5, label="same engine, no restrictor")
        ax[1].plot(r, wu["power"] / 1e3, color=CAT[1], ls="--", lw=1.5, label="no restrictor")
    top = max(float(np.nanmax(w["torque"])), float(tq_bins["T_crank"].max()) if tq_bins is not None and len(tq_bins) else 0)
    ax[0].set(title="Crank torque", xlabel="engine speed [rpm]", ylabel="torque [N m]", ylim=(0, 1.6 * top))
    ax[1].plot(r, w["power"] / 1e3, color=CAT[0], label="model (restricted)")
    if tq_bins is not None and len(tq_bins):
        ax[1].plot(tq_bins["rpm"], tq_bins["T_crank"] * tq_bins["rpm"] * np.pi / 30 / 1e3, "o", color=INK2, ms=5,
                   label="logged")
    j = np.argmax(w["power"])
    ax[1].annotate(f"{w['power'][j] / 1e3:.1f} kW ({w['power'][j] / 745.7:.0f} hp)\n@ {r[j]:.0f} rpm",
                   (r[j], w["power"][j] / 1e3), xytext=(-110, -40), textcoords="offset points", color=INK,
                   arrowprops=dict(arrowstyle="-", color=INK2))
    ax[1].set(title="Crank power", xlabel="engine speed [rpm]", ylabel="power [kW]")
    for a in ax:
        ch = r[w["choked"]]
        if ch.size:
            a.axvspan(ch[0], r[-1], color=GRID, alpha=0.45, lw=0)
            a.text(ch[0] + 60, a.get_ylim()[0] + 0.04 * np.ptp(a.get_ylim()), "restrictor choked", color=INK2, fontsize=8)
        a.legend(fontsize=8, loc="lower center")
    fig.suptitle(title)
    fig.tight_layout()
    return fig


def restrictor(eng, map_bins=None, pts=None):
    r = np.arange(3000, eng.e.rev_limit + 500, 50.0)
    w = eng.wot(r)
    fig, ax = plt.subplots(1, 3, figsize=(16, 4.4))
    ax[0].plot(r, w["demand_at_p0"] * 1e3, color=CAT[1], label="engine demand if unrestricted (plenum = ambient)")
    ax[0].plot(r, w["m_air"] * 1e3, color=CAT[0], label="actual air flow")
    ax[0].axhline(eng.choked_flow() * 1e3, color=INK2, ls="--", lw=1.2,
                  label=f"choked limit {eng.choked_flow() * 1e3:.1f} g/s ({eng.i.restrictor_diameter * 1e3:.0f} mm, Cd {eng.i.restrictor_cd})")
    ax[0].set(title="Air mass flow through the restrictor", xlabel="rpm", ylabel="air flow [g/s]")
    ax[0].legend(fontsize=7.5)
    if pts is not None and "map_Pa" in pts:
        ax[1].scatter(pts["rpm"], pts["map_Pa"] / 1e3, s=4, color=CAT[0], alpha=0.12, label="logged WOT MAP")
    if map_bins is not None and len(map_bins):
        ax[1].plot(map_bins["rpm"], map_bins["map_Pa"] / 1e3, "o", color=INK2, ms=5, label="logged median")
    ax[1].plot(r, w["map"] / 1e3, color=CAT[0], label="model plenum pressure")
    ax[1].axhline(eng.choke_map() / 1e3, color=INK2, ls=":", lw=1.2, label="throat goes sonic below this MAP")
    ax[1].axhline(eng.p0 / 1e3, color=GRID, lw=1.2)
    ax[1].set(title="Plenum pressure (MAP) at WOT", xlabel="rpm", ylabel="MAP [kPa]")
    ax[1].legend(fontsize=7.5)
    ax[2].plot(r, 100 * w["m_air"] / w["demand_at_p0"], color=CAT[0])
    ax[2].set(title="Air flow delivered vs unrestricted demand", xlabel="rpm", ylabel="% of demand", ylim=(0, 110))
    fig.tight_layout()
    return fig


def ve_curve(eng, prior_rpm=None, prior_ve=None):
    r = np.arange(3000, 14001, 50.0)
    fig, ax = plt.subplots(figsize=(7.5, 4))
    if prior_ve is not None:
        ax.plot(prior_rpm, prior_ve, "o--", color=INK2, lw=1.2, ms=4, label="prior (before fit)")
    ax.plot(r, eng.ve(r), color=CAT[0], label="fitted to logged torque + MAP")
    ax.plot(eng._ve_rpm, eng._ve, "o", color=CAT[0], ms=5)
    ax.set(title="Volumetric efficiency (plenum density)", xlabel="rpm", ylabel="VE [-]")
    ax.legend(fontsize=8)
    fig.tight_layout()
    return fig


def engine_losses(eng):
    r = np.arange(3000, eng.e.rev_limit + 1, 50.0)
    w = eng.wot(r)
    fig, ax = plt.subplots(1, 2, figsize=(14, 4.2))
    ax[0].plot(r, w["T_ind"], color=CAT[0], label="indicated (gross)")
    ax[0].plot(r, w["T_fric"], color=CAT[1], label="friction (FMEP)")
    ax[0].plot(r, w["T_pump"], color=CAT[2], label="pumping (exhaust - plenum)")
    ax[0].plot(r, w["torque"], color=INK, lw=1.5, ls="--", label="brake")
    ax[0].set(title="Where the indicated torque goes (WOT)", xlabel="rpm", ylabel="torque [N m]")
    ax[0].legend(fontsize=8)
    fuel_kw = w["m_fuel"] * eng.fuel.lhv / 1e3
    P = w["power"] / 1e3
    fr, pu = w["T_fric"] * r * np.pi / 30 / 1e3, w["T_pump"] * r * np.pi / 30 / 1e3
    rest = fuel_kw - P - fr - pu
    ax[1].stackplot(r, P, fr, pu, rest, colors=[CAT[0], CAT[1], CAT[2], GRID], edgecolor="white", lw=0.6,
                    labels=["brake power", "friction", "pumping", "heat: coolant + oil + exhaust"])
    ax[1].set(title="Fuel power split at WOT", xlabel="rpm", ylabel="power [kW]")
    ax[1].legend(fontsize=8, loc="upper left")
    fig.tight_layout()
    return fig


def torque_bsfc_maps(eng, lap=None):
    rg = np.arange(3000, eng.e.rev_limit + 1, 100.0)
    lg = np.linspace(0.08, 1.0, 50)
    R, Lg, T, B, PM = eng.torque_map(rg, lg)
    fig, ax = plt.subplots(1, 3, figsize=(17, 4.6))
    c0 = ax[0].contourf(R, Lg * 100, T, levels=20, cmap=SEQ)
    fig.colorbar(c0, ax=ax[0], label="brake torque [N m]")
    ax[0].contour(R, Lg * 100, T, levels=[0], colors=INK, linewidths=1.2)
    ax[0].set(title="Torque map", xlabel="rpm", ylabel="load = air flow / WOT air flow [%]")
    Bc = np.where((B > 0) & (B < 900), B, np.nan)
    c1 = ax[1].contourf(R, Lg * 100, Bc, levels=np.arange(250, 900, 25), cmap=SEQ + "_r", extend="max")
    fig.colorbar(c1, ax=ax[1], label="BSFC [g/kWh]")
    ax[1].set(title="Brake-specific fuel consumption", xlabel="rpm", ylabel="load [%]")
    c2 = ax[2].contourf(R, Lg * 100, PM / 1e3, levels=20, cmap=SEQ)
    fig.colorbar(c2, ax=ax[2], label="MAP [kPa]")
    ax[2].set(title="Plenum pressure", xlabel="rpm", ylabel="load [%]")
    if lap is not None:
        p = lap.pt
        on = p["F_drive"] > 0
        for a in ax[:2]:
            a.scatter(p["rpm"][on], p["throttle"][on], s=3, color=CAT[1], alpha=0.35, label="lap operating points")
        ax[1].legend(fontsize=8, loc="lower right")
    fig.tight_layout()
    return fig


def tuning_whatif(pt, which="intake", lengths=None):
    from .engine import Engine
    key = "intake_runner_length" if which == "intake" else "exhaust_primary_length"
    ref = getattr(pt.engine, key)
    lengths = lengths or [ref * f for f in (0.7, 0.85, 1.0, 1.2, 1.4)]
    r = np.arange(4000, pt.engine.rev_limit + 1, 50.0)
    fig, ax = plt.subplots(1, 2, figsize=(14, 4.2))
    for i, L in enumerate(lengths):
        p = pt.copy()
        setattr(p.engine, key, L)
        e = Engine(p)
        w = e.wot(r)
        ax[0].plot(r, w["torque"], color=CAT[i], label=f"{L * 1e3:.0f} mm" + (" (current)" if abs(L - ref) < 1e-6 else ""))
        ax[1].plot(r, e.ve(r), color=CAT[i])
    ax[0].set(title=f"{which.capitalize()} length what-if: torque", xlabel="rpm", ylabel="torque [N m]")
    ax[1].set(title="VE", xlabel="rpm", ylabel="VE [-]")
    ax[0].legend(fontsize=8)
    fig.text(0.01, 0.01, "Simplified wave-tuning model (moves the VE peak); confirm with a 1-D engine code / dyno.",
             fontsize=7.5, color=INK2)
    fig.tight_layout()
    return fig


def restrictor_and_ambient(pt):
    from .engine import Engine
    r = np.arange(4000, pt.engine.rev_limit + 1, 50.0)
    fig, ax = plt.subplots(1, 3, figsize=(17, 4.2))
    for i, d in enumerate([0.019, 0.020, 0.022, 0.025]):
        p = pt.copy(); p.intake.restrictor_diameter = d
        ax[0].plot(r, Engine(p).wot(r)["power"] / 1e3, color=CAT[i], label=f"{d * 1e3:.0f} mm" + (" (rule, gasoline)" if d == 0.020 else " (rule, E85)" if d == 0.019 else ""))
    ax[0].set(title="Restrictor diameter", xlabel="rpm", ylabel="power [kW]")
    ax[0].legend(fontsize=8)
    for i, T in enumerate([10, 20, 30, 40]):
        p = pt.copy(); p.ambient.temperature = T
        ax[1].plot(r, Engine(p).wot(r)["power"] / 1e3, color=CAT[i], label=f"{T} °C")
    ax[1].set(title="Ambient temperature", xlabel="rpm", ylabel="power [kW]")
    ax[1].legend(fontsize=8)
    alt = np.linspace(0, 2000, 21)
    pk = []
    for h in alt:
        p = pt.copy(); p.ambient.pressure = 101325 * (1 - 2.25577e-5 * h) ** 5.25588
        pk.append(Engine(p).wot(r)["power"].max() / 1e3)
    ax[2].plot(alt, pk, color=CAT[0])
    ax[2].set(title="Peak power vs altitude", xlabel="altitude [m]", ylabel="peak power [kW]")
    fig.tight_layout()
    return fig


# =========================================================================== GEARING
def tractive_force(veh, tggv, sprockets=None, coolant_temp=None):
    """Tractive force per gear vs speed with the traction limit and resistance, one panel per sprocket pair."""
    from .vehicle_pt import PTVehicle
    pt = veh.ptc
    sprockets = sprockets or [(pt.final_drive.front_sprocket, z) for z in pt.final_drive.rear_sprocket_options]
    fig, ax = plt.subplots(1, len(sprockets), figsize=(5.2 * len(sprockets), 4.4), sharey=True, squeeze=False)
    v = np.linspace(0.2, 40, 400)
    trac = veh.m * tggv.acc(v, np.zeros_like(v)) + veh.resist(v)
    for a, (zf, zr) in zip(ax[0], sprockets):
        p = pt.copy(); p.final_drive.front_sprocket, p.final_drive.rear_sprocket = zf, zr
        vv = PTVehicle(veh.cfg, p)
        F = vv.dt.forces_all_gears(v, coolant_temp)
        for k in range(F.shape[0]):
            m = F[k] > 0
            a.plot(v[m] * 3.6, F[k][m], color=gc(k + 1), label=f"gear {k + 1}")
        a.plot(v * 3.6, trac, color=INK, ls="--", lw=1.4, label="tire traction limit (straight)")
        a.plot(v * 3.6, veh.resist(v), color=INK2, ls=":", lw=1.4, label="drag + rolling")
        a.set(title=f"{zf}/{zr}  (final drive {zr / zf:.3f})", xlabel="speed [km/h]", ylim=(0, max(trac.max(), F.max()) * 1.05))
    ax[0][0].set_ylabel("force at the rear contact patches [N]")
    ax[0][-1].legend(fontsize=7.5, loc="upper right")
    fig.suptitle("Tractive force per gear and sprocket")
    fig.tight_layout()
    return fig


def sawtooth(veh, sprockets=None):
    from .vehicle_pt import PTVehicle
    pt = veh.ptc
    sprockets = sprockets or [(pt.final_drive.front_sprocket, z) for z in pt.final_drive.rear_sprocket_options]
    fig, ax = plt.subplots(1, len(sprockets), figsize=(5.2 * len(sprockets), 4.2), sharey=True, squeeze=False)
    for a, (zf, zr) in zip(ax[0], sprockets):
        p = pt.copy(); p.final_drive.front_sprocket, p.final_drive.rear_sprocket = zf, zr
        vv = PTVehicle(veh.cfg, p)
        T = PTTables(vv)
        sr = T.shift_rpm + [pt.engine.rev_limit]
        x, y, cols = [], [], []
        v0 = 0.0
        for k in range(1, vv.dt.n_gears + 1):
            v1 = vv.dt.v_at(sr[k - 1], k)
            vs = np.linspace(v0, v1, 80)
            rpm = np.maximum(vv.dt.rpm(vs, k), pt.engine.launch_rpm if k == 1 else 0)
            a.plot(vs * 3.6, rpm, color=gc(k), label=f"gear {k}")
            if k < vv.dt.n_gears:
                a.plot([v1 * 3.6, v1 * 3.6], [sr[k - 1], vv.dt.rpm(v1, k + 1)], color=INK2, lw=1, ls=":")
                a.plot(v1 * 3.6, sr[k - 1], "o", color=gc(k), ms=6, mec="white", mew=1.5)
            v0 = v1
        a.axhline(pt.engine.rev_limit, color=INK2, lw=1, ls="--")
        a.text(2, pt.engine.rev_limit + 150, "rev limit", fontsize=8, color=INK2)
        a.set(title=f"{zf}/{zr}", xlabel="speed [km/h]", ylim=(3000, pt.engine.rev_limit + 800))
    ax[0][0].set_ylabel("engine speed [rpm]")
    ax[0][-1].legend(fontsize=7.5, loc="lower right")
    fig.suptitle("Gear sawtooth: rpm vs speed with the (optimal or set) upshift points  ·  gear 1 below lock-up = clutch slip at launch rpm")
    fig.tight_layout()
    return fig


def gear_chart(veh):
    dt = veh.dt
    df = pd.DataFrame(dt.summary(veh.m))
    fig, ax = plt.subplots(1, 3, figsize=(16, 4))
    lo = [dt.v_at(veh.ptc.engine.min_drive_rpm, k) * 3.6 for k in df["gear"]]
    for i, r in df.iterrows():
        ax[0].barh(r["gear"], r["v_at_rev_limit_kph"] - lo[i], left=lo[i], color=gc(r["gear"]), height=0.6)
        ax[0].text(r["v_at_rev_limit_kph"] + 1, r["gear"], f"{r['v_at_rev_limit_kph']:.0f}", va="center", fontsize=8, color=INK)
    ax[0].set(title=f"Usable speed band per gear ({veh.ptc.engine.min_drive_rpm:.0f}-{veh.ptc.engine.rev_limit:.0f} rpm)",
              xlabel="speed [km/h]", ylabel="gear")
    ax[0].invert_yaxis()
    steps = dt.gears[:-1] / dt.gears[1:]
    ax[1].bar([f"{k}->{k + 1}" for k in range(1, dt.n_gears)], (steps - 1) * 100, color=CAT[0], width=0.55)
    ax[1].set(title="Ratio step between gears (rpm drop on upshift)", ylabel="step [%]")
    parts = [dt.rotating_inertia_at_wheel(k) for k in df["gear"]]
    bottom = np.full(len(df), veh.m, float)
    ax[2].bar(df["gear"], veh.m, color=GRID, width=0.6, label="vehicle mass")
    for j, key in enumerate(["wheels_axle", "gearbox_output", "clutch", "crank"]):
        val = np.array([p[key] for p in parts]) / dt.r ** 2
        ax[2].bar(df["gear"], val, bottom=bottom, color=CAT[j], width=0.6, label=key.replace("_", " "), edgecolor="white", lw=1)
        bottom += val
    ax[2].set(title="Equivalent mass per gear (rotating inertia)", xlabel="gear", ylabel="kg")
    ax[2].legend(fontsize=7.5, loc="upper right")
    fig.tight_layout()
    return fig


def shift_points(veh, events=None):
    T = PTTables(veh)
    fig, ax = plt.subplots(1, 2, figsize=(13, 4))
    ks = np.arange(1, veh.dt.n_gears)
    ax[0].bar(ks, T.shift_rpm, color=[gc(k) for k in ks], width=0.55, label="model optimum")
    if events is not None and len(events):
        up = events[(events["type"] == "up") & (events["tps"] > 80)]
        ax[0].axhline(up["rpm"].median(), color=INK, ls="--", lw=1.4, label=f"drivers' median upshift {up['rpm'].median():.0f} rpm")
        ax[1].hist(up["rpm"], bins=30, color=CAT[0], edgecolor="white")
        ax[1].axvline(np.mean(T.shift_rpm), color=INK, ls="--", lw=1.4, label="model optimum (mean)")
        ax[1].set(title=f"Logged full-throttle upshift rpm ({len(up)} shifts)", xlabel="rpm", ylabel="count")
        ax[1].legend(fontsize=8)
    ax[0].set(title="Optimal upshift rpm per gear", xlabel="upshift from gear", ylabel="rpm",
              ylim=(8000, veh.ptc.engine.rev_limit + 500))
    ax[0].legend(fontsize=8, loc="lower right")
    fig.tight_layout()
    return fig


def accel_compare(runs: dict, logged=None):
    """runs = {label: LapPT from accel_run}; logged = list of DataFrames (t, v, rpm from identify)."""
    fig, ax = plt.subplots(1, 3, figsize=(17, 4.2))
    for i, (lab, r) in enumerate(runs.items()):
        ax[0].plot(r.t, r.v * 3.6, color=CAT[i], label=f"{lab}: {r.summary['fsae_time_s']:.3f} s")
        ax[1].plot(r.t, r.pt["rpm"], color=CAT[i])
        ax[2].plot(r.s, r.ax / G0, color=CAT[i])
    if logged is not None:
        for j, d in enumerate(logged):
            ax[0].plot(d["t"], d["v"] * 3.6, color=INK2, lw=1.2, ls="--", label="logged" if j == 0 else None)
            ax[1].plot(d["t"], d["rpm"], color=INK2, lw=1.2, ls="--")
    ax[0].set(title="Acceleration: speed", xlabel="time [s]", ylabel="km/h", xlim=(0, 5.5))
    ax[1].set(title="Engine speed", xlabel="time [s]", ylabel="rpm", xlim=(0, 5.5))
    ax[2].set(title="Longitudinal acceleration", xlabel="distance [m]", ylabel="g")
    ax[0].legend(fontsize=8)
    fig.tight_layout()
    return fig


# =========================================================================== LAP
def _limit_band(ax, lr, y0=0, h=1):
    lim = lr.limit
    s = lr.s
    i = 0
    while i < len(s) - 1:
        j = i
        while j < len(s) - 1 and lim[j] == lim[i]:
            j += 1
        ax.axvspan(s[i], s[j], ymin=0, ymax=1, color=LIMIT_COLORS.get(lim[i], GRID), lw=0)
        i = j


def lap_trace(lr, logged=None, title=None):
    p = lr.pt
    fig, ax = plt.subplots(6, 1, figsize=(15, 13), sharex=True,
                           gridspec_kw={"height_ratios": [3, 2.4, 1.6, 1.6, 1.6, 0.5]})
    ax[0].plot(lr.s, lr.v * 3.6, color=CAT[0], label=f"simulated {lr.time:.2f} s")
    ax[1].plot(lr.s, p["rpm"], color=CAT[0])
    for g in range(1, int(p["gear"].max()) + 1):
        m = p["gear"] == g
        ax[2].fill_between(lr.s, 0, np.where(m, g, np.nan), color=gc(g), step="mid", lw=0)
    ax[2].plot(lr.s, p["gear"], color=INK, lw=1, drawstyle="steps-mid")
    ax[3].plot(lr.s, p["throttle"], color=CAT[5])
    ax[3].fill_between(lr.s, 0, np.where(lr.ax < -0.3, -np.clip(-lr.ax / G0, 0, 2) * 50, 0), color=LIMIT_COLORS["braking"],
                       alpha=0.5, lw=0, label="braking (g x 50)")
    ax[4].plot(lr.s, lr.ax / G0, color=CAT[1], label="longitudinal")
    ax[4].plot(lr.s, lr.ay / G0, color=CAT[6], label="lateral")
    if logged is not None:
        L = logged
        sc = lr.s[-1] / L["s"].iloc[-1] if L["s"].iloc[-1] > 0 else 1
        ax[0].plot(L["s"] * sc, L["v"] * 3.6, color=INK2, lw=1.2, ls="--", label=f"logged {L['t'].iloc[-1]:.2f} s")
        ax[1].plot(L["s"] * sc, L["rpm"], color=INK2, lw=1.2, ls="--", label="logged")
        ax[2].plot(L["s"] * sc, L["gear"], color=INK2, lw=1.2, ls="--", drawstyle="steps-mid")
        ax[3].plot(L["s"] * sc, L["tps"], color=INK2, lw=1.2, ls="--")
        ax[1].legend(fontsize=8)
    _limit_band(ax[5], lr)
    ax[5].set_yticks([])
    ax[5].grid(False)
    ax[0].set(ylabel="speed [km/h]", title=title or f"{lr.track.name}: lap trace")
    ax[0].legend(fontsize=8, loc="upper right")
    ax[1].set(ylabel="rpm")
    ax[2].set(ylabel="gear", yticks=range(1, 7), ylim=(0.5, max(p["gear"].max(), 3) + 0.5))
    ax[3].set(ylabel="throttle [%]", ylim=(-110, 105))
    ax[3].legend(fontsize=8, loc="lower right")
    ax[4].set(ylabel="g")
    ax[4].legend(fontsize=8, loc="upper right", ncol=2)
    ax[5].set(xlabel="distance [m]", ylabel="limit")
    handles = [Patch(color=LIMIT_COLORS[k], label=k.replace("_", " ")) for k in LIMITS]
    ax[5].legend(handles=handles, ncol=len(LIMITS), fontsize=8, loc="upper center", bbox_to_anchor=(0.5, -1.6))
    fig.tight_layout()
    return fig


def track_maps(lr):
    if lr.track.x is None:
        return None
    x, y = lr.track.x, lr.track.y
    n = min(len(x), len(lr.s))
    pts = np.column_stack([x[:n], y[:n]])[:, None, :]
    seg = np.concatenate([pts[:-1], pts[1:]], axis=1)
    asp = max(np.ptp(y[:n]), 1.0) / max(np.ptp(x[:n]), 1.0)
    if asp < 0.6:      # long, thin course: stack the maps
        fig, ax = plt.subplots(3, 1, figsize=(15, 3 * max(15 * asp, 1.6) + 1.5))
    else:
        fig, ax = plt.subplots(1, 3, figsize=(18, 5.2))
    ng = int(lr.pt["gear"].max())
    cmap, norm = _gear_cmap(max(ng, 1))
    lc = LineCollection(seg, cmap=cmap, norm=norm, linewidths=4)
    lc.set_array(lr.pt["gear"][:n - 1])
    ax[0].add_collection(lc)
    ax[0].legend(handles=[Patch(color=gc(g), label=f"gear {g}") for g in range(1, ng + 1)], fontsize=8, loc="center left", bbox_to_anchor=(1.01, 0.5))
    ax[0].set_title("Gear")
    lim_idx = {k: i for i, k in enumerate(LIMITS)}
    cmap2 = ListedColormap([LIMIT_COLORS[k] for k in LIMITS])
    lc2 = LineCollection(seg, cmap=cmap2, norm=BoundaryNorm(np.arange(-0.5, len(LIMITS) + 0.5), len(LIMITS)), linewidths=4)
    lc2.set_array(np.array([lim_idx.get(c, 6) for c in lr.limit[:n - 1]]))
    ax[1].add_collection(lc2)
    ax[1].legend(handles=[Patch(color=LIMIT_COLORS[k], label=k.replace("_", " ")) for k in LIMITS], fontsize=8, loc="center left", bbox_to_anchor=(1.01, 0.5))
    ax[1].set_title("What limits the car")
    lc3 = LineCollection(seg, cmap=SEQ, linewidths=4)
    lc3.set_array(lr.v[:n - 1] * 3.6)
    ax[2].add_collection(lc3)
    fig.colorbar(lc3, ax=ax[2], label="km/h")
    ax[2].set_title("Speed")
    for a in ax:
        a.set_aspect("equal")
        a.autoscale()
        a.set_xticks([]); a.set_yticks([])
        a.grid(False)
    fig.suptitle(f"{lr.track.name}")
    fig.tight_layout()
    return fig


def lap_histograms(lr):
    p = lr.pt
    dt = np.diff(lr.t, append=lr.t[-1])
    fig, ax = plt.subplots(1, 4, figsize=(18, 3.8))
    ng = int(p["gear"].max())
    tg = [dt[p["gear"] == g].sum() for g in range(1, ng + 1)]
    ax[0].bar(range(1, ng + 1), np.array(tg) / lr.time * 100, color=[gc(g) for g in range(1, ng + 1)], width=0.6)
    ax[0].set(title="Time in gear", xlabel="gear", ylabel="% of lap")
    ax[1].hist(p["rpm"], bins=np.arange(3000, 13600, 250), weights=dt, color=CAT[0], edgecolor="white")
    ax[1].set(title="Time at engine speed", xlabel="rpm", ylabel="s")
    tl = [dt[lr.limit == c].sum() / lr.time * 100 for c in LIMITS]
    ax[2].barh([c.replace("_", " ") for c in LIMITS], tl, color=[LIMIT_COLORS[c] for c in LIMITS], height=0.6)
    for i, v_ in enumerate(tl):
        ax[2].text(v_ + 0.5, i, f"{v_:.1f}", va="center", fontsize=8, color=INK)
    ax[2].set(title="What limits the car (time)", xlabel="% of lap")
    ax[2].invert_yaxis()
    ax[3].hist(p["throttle"], bins=np.arange(0, 102, 5), weights=dt, color=CAT[5], edgecolor="white")
    ax[3].set(title="Throttle distribution", xlabel="throttle [%]", ylabel="s")
    fig.tight_layout()
    return fig


def sim_vs_log(lr, logged, title="Simulated vs logged (distributions - no course alignment needed)"):
    """Time-weighted distributions of rpm, gear, throttle and speed: simulation against a logged run."""
    p = lr.pt
    dt = np.diff(lr.t, append=lr.t[-1])
    L = logged
    dl = np.diff(L["t"].to_numpy(), append=L["t"].iloc[-1])
    mv = L["v"].to_numpy() > 3
    fig, ax = plt.subplots(1, 4, figsize=(19, 3.8))
    b = np.arange(3000, 13600, 250)
    ax[0].hist(p["rpm"], bins=b, weights=dt / dt.sum() * 100, color=CAT[0], alpha=0.75, label="sim")
    ax[0].hist(L["rpm"][mv], bins=b, weights=dl[mv] / dl[mv].sum() * 100, histtype="step", color=INK, lw=1.6, label="logged")
    ax[0].set(title="Engine speed", xlabel="rpm", ylabel="% of time"); ax[0].legend(fontsize=8)
    gs = np.arange(1, 7)
    sg = [100 * dt[p["gear"] == g].sum() / dt.sum() for g in gs]
    lg = [100 * dl[mv & (L["gear"].to_numpy() == g)].sum() / dl[mv].sum() for g in gs]
    ax[1].bar(gs - 0.18, sg, width=0.34, color=CAT[0], label="sim")
    ax[1].bar(gs + 0.18, lg, width=0.34, color=INK2, label="logged")
    ax[1].set(title="Time in gear", xlabel="gear", ylabel="%"); ax[1].legend(fontsize=8)
    bt = np.arange(0, 102, 5)
    ax[2].hist(p["throttle"], bins=bt, weights=dt / dt.sum() * 100, color=CAT[0], alpha=0.75, label="sim")
    ax[2].hist(L["tps"][mv], bins=bt, weights=dl[mv] / dl[mv].sum() * 100, histtype="step", color=INK, lw=1.6, label="logged")
    ax[2].set(title="Throttle", xlabel="%", ylabel="% of time"); ax[2].legend(fontsize=8)
    bv = np.arange(0, 125, 5)
    ax[3].hist(lr.v * 3.6, bins=bv, weights=dt / dt.sum() * 100, color=CAT[0], alpha=0.75, label=f"sim {lr.time:.1f} s")
    ax[3].hist(L["v"][mv] * 3.6, bins=bv, weights=dl[mv] / dl[mv].sum() * 100, histtype="step", color=INK, lw=1.6,
               label=f"logged {L['t'].iloc[-1]:.1f} s")
    ax[3].set(title="Speed", xlabel="km/h", ylabel="% of time"); ax[3].legend(fontsize=8)
    fig.suptitle(title)
    fig.tight_layout()
    return fig


def gg_diagram(lr_list, tggv, logged_df=None, speeds=(10, 15, 20, 25)):
    fig, ax = plt.subplots(1, 2, figsize=(13, 6))
    if logged_df is not None and "ay_imu" in logged_df:
        d = logged_df[logged_df["v_s"] > 4]
        ax[0].scatter(-d["ay_imu"], d["a"] / G0, s=1, color=INK2, alpha=0.08, label="logged (IMU lateral, GPS long.)")
    for i, lr in enumerate(lr_list):
        ax[0].scatter(lr.ay / G0, lr.ax / G0, s=3, color=CAT[i], alpha=0.5, label=f"sim: {lr.track.name}")
    for j, v in enumerate(speeds):
        aym = float(tggv.ay_lim(v))
        ays = np.linspace(-aym, aym, 121)
        acc = tggv.acc(np.full_like(ays, v), ays)
        brk = tggv.brk(np.full_like(ays, v), ays)
        ax[1].plot(ays / G0, acc / G0, color=CAT[j], label=f"{v} m/s")
        ax[1].plot(ays / G0, -brk / G0, color=CAT[j])
        ax[0].plot(ays / G0, acc / G0, color=CAT[j], lw=1, alpha=0.6)
        ax[0].plot(ays / G0, -brk / G0, color=CAT[j], lw=1, alpha=0.6)
    for a in ax:
        a.set(xlabel="lateral [g]", ylabel="longitudinal [g]")
        a.set_aspect("equal")
        a.legend(fontsize=8, loc="lower left")
    ax[0].set_title("G-G: simulated laps on the traction envelope")
    ax[1].set_title("Traction envelope (tires + diff) per speed")
    fig.tight_layout()
    return fig


# =========================================================================== COMPARISONS
def sprocket_comparison(df):
    events = [e for e in ("acceleration", "skidpad", "autocross", "endurance") if e in df]
    fig, ax = plt.subplots(1, len(events) + 2, figsize=(4.2 * (len(events) + 2), 4))
    labels = df["label"].tolist()
    cols = [CAT[i % 8] for i in range(len(df))]
    for a, e in zip(ax, events):
        best = df[e].min()
        a.bar(labels, df[e] - best, color=cols, width=0.6)
        for i, v in enumerate(df[e]):
            a.text(i, (v - best) + 0.002 * max(df[e].max() - best, 0.01), f"{v:.3f}", ha="center", va="bottom", fontsize=7.5, color=INK)
        a.set(title=f"{e} (Δ to best)", ylabel="s")
        a.tick_params(axis="x", rotation=45)
    a = ax[len(events)]
    if "pts_total" in df and df["pts_total"].notna().any():
        a.bar(labels, df["pts_total"] - df["pts_total"].min(), color=cols, width=0.6)
        a.set(title="dynamic points (Δ to worst)", ylabel="points")
    a.tick_params(axis="x", rotation=45)
    a = ax[-1]
    a.bar(labels, df["v_top_kph"], color=cols, width=0.6)
    a.set(title="top speed (rev limit / drag)", ylabel="km/h", ylim=(df["v_top_kph"].min() * 0.9, df["v_top_kph"].max() * 1.03))
    a.tick_params(axis="x", rotation=45)
    fig.suptitle("Sprocket comparison (front/rear)")
    fig.tight_layout()
    return fig


def heatmap(pivot, title, fmt="{:.3f}", cmap=SEQ + "_r", cbar="s"):
    fig, ax = plt.subplots(figsize=(1.1 * pivot.shape[1] + 3, 0.7 * pivot.shape[0] + 2))
    im = ax.imshow(pivot.values, cmap=cmap, aspect="auto")
    ax.set_xticks(range(pivot.shape[1]), [str(c) for c in pivot.columns])
    ax.set_yticks(range(pivot.shape[0]), [str(c) for c in pivot.index])
    ax.set(xlabel=pivot.columns.name, ylabel=pivot.index.name, title=title)
    ax.grid(False)
    best = np.unravel_index(np.nanargmin(pivot.values), pivot.shape)
    for i in range(pivot.shape[0]):
        for j in range(pivot.shape[1]):
            v = pivot.values[i, j]
            ax.text(j, i, fmt.format(v), ha="center", va="center", fontsize=8,
                    color="white" if v < np.nanpercentile(pivot.values, 35) else INK,
                    fontweight="bold" if (i, j) == best else None)
    fig.colorbar(im, ax=ax, label=cbar)
    fig.tight_layout()
    return fig


def diff_comparison(refs, drexler_best=None, events=("acceleration", "skidpad", "autocross")):
    df = refs.copy()
    if drexler_best is not None:
        df = pd.concat([df, pd.DataFrame([drexler_best])], ignore_index=True)
    fig, ax = plt.subplots(1, len(events), figsize=(5 * len(events), 4))
    for a, e in zip(ax, events):
        if e not in df:
            continue
        a.bar(df["type"], df[e], color=[CAT[i] for i in range(len(df))], width=0.6)
        lo, hi = df[e].min(), df[e].max()
        a.set(title=e, ylabel="s", ylim=(lo - 0.1 * (hi - lo + 1e-3) - 0.02, hi + 0.1 * (hi - lo + 1e-3) + 0.02))
        for i, v in enumerate(df[e]):
            a.text(i, v, f"{v:.3f}", ha="center", va="bottom", fontsize=8, color=INK)
    fig.suptitle("Differential type")
    fig.tight_layout()
    return fig


def sensitivity_tornado(sens, metric="d_autocross_s", title=None):
    s = sens.pivot(index="setting", columns="side", values=metric)
    s = s.reindex(s.abs().max(1).sort_values().index)
    fig, ax = plt.subplots(figsize=(9, 0.45 * len(s) + 1.5))
    y = np.arange(len(s))
    ax.barh(y, s["low"], color=CAT[0], height=0.6, label="low value")
    ax.barh(y, s["high"], color=CAT[1], height=0.6, label="high value")
    vals = sens.set_index(["setting", "side"])["value"]
    for i, k in enumerate(s.index):
        ax.text(s.loc[k].max() + 0.002, i, f"{vals[(k, 'low')]} / {vals[(k, 'high')]}", va="center", fontsize=7.5, color=INK2)
    ax.set_yticks(y, [k.replace("pt.", "").replace("vd.", "") for k in s.index])
    ax.axvline(0, color=INK, lw=1)
    ax.set(xlabel=f"change [{'points' if 'points' in metric else 's'}]", title=title or f"Sensitivity: {metric}")
    ax.legend(fontsize=8, loc="lower right")
    fig.tight_layout()
    return fig


# =========================================================================== DRIVELINE
def stage_losses(veh, gear=None):
    dt = veh.dt
    fig, ax = plt.subplots(1, 3, figsize=(17, 4.2))
    gear = gear or 2
    v = np.linspace(dt.v_at(veh.ptc.engine.min_drive_rpm, gear), dt.top_speed_in_gear(gear), 120)
    rpm = dt.rpm(v, gear)
    Tc = dt.crank_torque_wot(rpm)
    _, L = dt.transmit(Tc, rpm, np.full(v.shape, gear))
    ax[0].stackplot(v * 3.6, *[L.losses[s] for s in STAGES], colors=CAT[:len(STAGES)], edgecolor="white", lw=0.6,
                    labels=list(STAGES))
    ax[0].set(title=f"Driveline losses at WOT in gear {gear}", xlabel="km/h", ylabel="W")
    ax[0].legend(fontsize=8, loc="upper left")
    for k in range(1, dt.n_gears + 1):
        vv = np.linspace(dt.v_at(veh.ptc.engine.min_drive_rpm, k), dt.top_speed_in_gear(k), 60)
        r = dt.rpm(vv, k)
        T = dt.crank_torque_wot(r)
        T6, Lk = dt.transmit(T, r, np.full(vv.shape, k))
        ax[1].plot(r, 100 * Lk.power_out / Lk.power_in, color=gc(k), label=f"gear {k}")
    ax[1].set(title="Crank-to-tire efficiency at WOT", xlabel="rpm", ylabel="%")
    ax[1].legend(fontsize=8)
    # part load efficiency vs torque
    tq = np.linspace(5, 45, 40)
    for j, r in enumerate([6000, 9000, 12000]):
        _, Lp = dt.transmit(tq, np.full(tq.shape, r), np.full(tq.shape, gear))
        ax[2].plot(tq, 100 * Lp.power_out / Lp.power_in, color=CAT[j], label=f"{r} rpm")
    ax[2].set(title=f"Efficiency vs crank torque (gear {gear})", xlabel="crank torque [N m]", ylabel="%")
    ax[2].legend(fontsize=8)
    fig.tight_layout()
    return fig


def lap_energy(lr, veh):
    p = lr.pt
    dt = np.diff(lr.t, append=lr.t[-1])
    E = lambda x: float(np.sum(np.maximum(x, 0) * dt)) / 1e3
    fuel = E(p["fuel_power_kW"] * 1e3)
    brake = E(p["P_engine_kW"] * 1e3)
    stages = {s: E(p[f"loss_{s}_W"]) for s in STAGES}
    stages["diff plate slip"] = E(p["diff_plate_slip_W"])
    _, _, D = veh.aero(lr.v)
    drag = E(D * lr.v)
    rr = E((veh.resist(lr.v) - D) * lr.v)
    fig, ax = plt.subplots(1, 2, figsize=(15, 4.2))
    labels = ["fuel energy", "engine output"] + list(stages) + ["aero drag", "rolling + toe"]
    vals = [fuel, brake] + list(stages.values()) + [drag, rr]
    cols = [GRID, CAT[0]] + [CAT[1]] * len(stages) + [CAT[2], CAT[2]]
    ax[0].barh(labels, vals, color=cols, height=0.6)
    for i, v in enumerate(vals):
        ax[0].text(v, i, f" {v:.0f} kJ", va="center", fontsize=8, color=INK)
    ax[0].invert_yaxis()
    ax[0].set(title=f"Energy over the lap ({lr.track.name})", xlabel="kJ")
    sl = {k: v for k, v in stages.items()}
    ax[1].bar(list(sl), list(sl.values()), color=CAT[:len(sl)], width=0.6)
    ax[1].set(title="Driveline loss per stage over the lap", ylabel="kJ")
    ax[1].tick_params(axis="x", rotation=30)
    fig.tight_layout()
    return fig


def diff_behaviour(lr, veh):
    p = lr.pt
    fig, ax = plt.subplots(2, 2, figsize=(15, 8))
    ax[0, 0].plot(lr.s, p["F_rear_outer"], color=CAT[1], label="outside rear")
    ax[0, 0].plot(lr.s, p["F_rear_inner"], color=CAT[0], label="inside rear")
    ax[0, 0].set(title="Rear tire longitudinal force (diff split)", xlabel="distance [m]", ylabel="N")
    ax[0, 0].legend(fontsize=8)
    ax[0, 1].plot(lr.s, p["diff_Mz"], color=CAT[6])
    ax[0, 1].axhline(0, color=INK, lw=0.8)
    ax[0, 1].set(title="Diff yaw moment (+ helps rotation, - stabilises)", xlabel="distance [m]", ylabel="N m")
    on = p["F_drive"] > 50
    sc = ax[1, 0].scatter(np.abs(lr.ay[on]) / G0, p["diff_bias"][on], c=lr.v[on] * 3.6, s=6, cmap=SEQ)
    fig.colorbar(sc, ax=ax[1, 0], label="km/h")
    tbr = veh.diff.tbr()
    if np.isfinite(tbr):
        ax[1, 0].axhline(tbr, color=INK, ls="--", lw=1.2, label=f"TBR {tbr:.2f} (drive ramp {veh.ptc.differential.drive_ramp_deg:.0f}°)")
        ax[1, 0].legend(fontsize=8)
    ax[1, 0].set(title="Torque bias outside/inside on power", xlabel="|lateral| [g]", ylabel="F_out / F_in")
    ax[1, 1].plot(lr.s, p["diff_dT"], color=CAT[0], label="torque difference transferred")
    ax[1, 1].plot(lr.s, p["diff_lock_cap"], color=INK2, ls="--", lw=1.2, label="locking capacity")
    ax[1, 1].set(title="Locking torque", xlabel="distance [m]", ylabel="N m")
    ax[1, 1].legend(fontsize=8)
    fig.suptitle(f"Differential: {veh.ptc.differential.model} ({veh.diff.type}), preload {veh.ptc.differential.preload:.0f} N m")
    fig.tight_layout()
    return fig


def diff_lock_curves(pt):
    from .drivetrain import Differential
    t_in = np.linspace(0, 900, 100)
    fig, ax = plt.subplots(1, 2, figsize=(13, 4))
    for i, ramp in enumerate(pt.differential.ramp_options):
        p = pt.copy(); p.differential.drive_ramp_deg = ramp
        d = Differential(p)
        ax[0].plot(t_in, d.lock_torque(t_in), color=CAT[i], label=f"{ramp:.0f}°  TBR {d.tbr():.2f}")
    ax[0].set(title=f"Locking torque vs input (preload {pt.differential.preload:.0f} N m)", xlabel="axle input torque [N m]",
              ylabel="max torque difference [N m]")
    ax[0].legend(fontsize=8, title="drive ramp")
    for i, pre in enumerate(pt.differential.preload_options):
        p = pt.copy(); p.differential.preload = pre
        ax[1].plot(t_in, Differential(p).lock_torque(t_in), color=CAT[i % 8], label=f"{pre:.0f} N m")
    ax[1].set(title=f"Preload (ramp {pt.differential.drive_ramp_deg:.0f}°)", xlabel="axle input torque [N m]", ylabel="N m")
    ax[1].legend(fontsize=8, title="preload")
    fig.tight_layout()
    return fig


def component_loads(lr, veh):
    p = lr.pt
    dt = np.diff(lr.t, append=lr.t[-1])
    fig, ax = plt.subplots(1, 4, figsize=(19, 3.8))
    ax[0].plot(lr.s, p["T_halfshaft_outer"], color=CAT[1], label="outside")
    ax[0].plot(lr.s, p["T_halfshaft_inner"], color=CAT[0], label="inside")
    ax[0].set(title="Halfshaft torque", xlabel="distance [m]", ylabel="N m")
    ax[0].legend(fontsize=8)
    T = np.r_[p["T_halfshaft_outer"], p["T_halfshaft_inner"]]
    ax[1].hist(T, bins=40, weights=np.r_[dt, dt], color=CAT[0], edgecolor="white")
    ax[1].set(title="Halfshaft torque duty (both shafts)", xlabel="N m", ylabel="s")
    ax[2].hist(p["chain_tension"][p["chain_tension"] > 0], bins=40, weights=dt[p["chain_tension"] > 0], color=CAT[2],
               edgecolor="white")
    ax[2].set(title=f"Chain tension ({veh.ptc.final_drive.chain})", xlabel="N", ylabel="s")
    ax[3].plot(lr.s, p["tau_halfshaft_MPa"], color=CAT[6])
    ax[3].set(title="Halfshaft shear stress (QSS, no shock)", xlabel="distance [m]", ylabel="MPa")
    fig.tight_layout()
    return fig


def wheel_slip(lr):
    p = lr.pt
    fig, ax = plt.subplots(figsize=(15, 3.4))
    ax.plot(lr.s, 100 * p["slip_outer"], color=CAT[1], label="outside rear")
    ax.plot(lr.s, 100 * p["slip_inner"], color=CAT[0], label="inside rear")
    ax.set(title="Rear slip ratio estimate (force / longitudinal stiffness)", xlabel="distance [m]", ylabel="slip [%]")
    ax.legend(fontsize=8)
    fig.tight_layout()
    return fig


def transient(r_tc, r_no=None, dm=None):
    c = r_tc.ch
    fig, ax = plt.subplots(3, 2, figsize=(15, 10), sharex=True)
    ax[0, 0].plot(r_tc.t, c["rpm"], color=CAT[0], label="engine")
    road = c["v"] / dm.r * dm.dt.overall[np.clip(c["gear"], 1, 6) - 1] * 30 / np.pi if dm else None
    if road is not None:
        ax[0, 0].plot(r_tc.t, road, color=INK2, ls="--", lw=1.2, label="road speed x ratio")
    ax[0, 0].set(title="Engine speed (launch control + clutch slip, then upshifts)", ylabel="rpm")
    ax[0, 0].legend(fontsize=8)
    ax[0, 1].plot(r_tc.t, c["v"] * 3.6, color=CAT[0], label="with traction control")
    ax[1, 0].plot(r_tc.t, c["T_hs_L"], color=CAT[0], label="with TC")
    ax[1, 1].plot(r_tc.t, 100 * c["slip_L"], color=CAT[0], label="with TC")
    ax[2, 0].plot(r_tc.t, c["clutch_T"] / dm.ip if dm else c["clutch_T"], color=CAT[0], label="clutch torque (crank)")
    ax[2, 0].plot(r_tc.t, c["engine_T"], color=CAT[1], label="engine torque")
    ax[2, 1].plot(r_tc.t, c["ax"] / G0, color=CAT[0], label="with TC")
    if r_no is not None:
        n = r_no.ch
        ax[0, 1].plot(r_no.t, n["v"] * 3.6, color=CAT[1], label="no traction control")
        ax[1, 0].plot(r_no.t, n["T_hs_L"], color=CAT[1], lw=1.2, label="no TC")
        ax[1, 1].plot(r_no.t, 100 * n["slip_L"], color=CAT[1], lw=1.2, label="no TC")
        ax[2, 1].plot(r_no.t, n["ax"] / G0, color=CAT[1], lw=1.2, label="no TC")
    ax[0, 1].set(title="Vehicle speed", ylabel="km/h"); ax[0, 1].legend(fontsize=8)
    ax[1, 0].set(title="Halfshaft torque (shift shock, wind-up)", ylabel="N m"); ax[1, 0].legend(fontsize=8)
    ax[1, 1].set(title="Rear wheel slip ratio", ylabel="%", ylim=(-20, 100)); ax[1, 1].legend(fontsize=8)
    ax[2, 0].set(title="Clutch vs engine torque", xlabel="time [s]", ylabel="N m"); ax[2, 0].legend(fontsize=8)
    ax[2, 1].set(title="Longitudinal acceleration", xlabel="time [s]", ylabel="g"); ax[2, 1].legend(fontsize=8)
    for a in ax.ravel():
        for t0 in r_tc.t[np.flatnonzero(np.diff(c["gear"]) > 0)]:
            a.axvline(t0, color=GRID, lw=1)
    fig.suptitle("Transient driveline: standing start and full-throttle upshifts" +
                 (f"  ·  first torsional mode {dm.natural_frequency_hz(1):.1f} Hz (1st gear)" if dm else ""))
    fig.tight_layout()
    return fig


# =========================================================================== FUEL / THERMAL / ELECTRICAL
def fuel_lap(lr):
    p = lr.pt
    dt = np.diff(lr.t, append=lr.t[-1])
    fig, ax = plt.subplots(1, 3, figsize=(17, 3.8))
    cum = np.cumsum(p["m_fuel_g_s"] * dt) / 1e3 / 0.74
    ax[0].plot(lr.s, cum * 1e3, color=CAT[0])
    ax[0].set(title=f"Cumulative fuel ({cum[-1] * 1e3:.0f} mL per lap)", xlabel="distance [m]", ylabel="mL")
    ax[1].plot(lr.s, p["m_fuel_g_s"], color=CAT[1])
    ax[1].set(title="Fuel mass flow", xlabel="distance [m]", ylabel="g/s")
    b = p["bsfc_g_kWh"]
    ok = np.isfinite(b) & (b < 1500)
    ax[2].hist(b[ok], bins=40, weights=dt[ok], color=CAT[2], edgecolor="white")
    ax[2].set(title="BSFC while driving", xlabel="g/kWh", ylabel="s")
    fig.tight_layout()
    return fig


def endurance_summary(df, laps, logged_thermal=None):
    fig, ax = plt.subplots(2, 3, figsize=(18, 8))
    t = np.concatenate([lr.pt["t_endurance"] for lr in laps]) / 60
    Tc = np.concatenate([lr.pt["coolant_C"] for lr in laps])
    To = np.concatenate([lr.pt["oil_C"] for lr in laps])
    fan = np.concatenate([lr.pt["fan"] for lr in laps])
    ax[0, 0].fill_between(t, 0, 1, where=fan > 0.5, color=GRID, alpha=0.7, transform=ax[0, 0].get_xaxis_transform(),
                          lw=0, label="fan on")
    ax[0, 0].plot(t, Tc, color=CAT[0], label="coolant")
    ax[0, 0].plot(t, To, color=CAT[1], label="oil")
    if logged_thermal is not None:
        ax[0, 0].plot((logged_thermal["t"] - logged_thermal["t"].iloc[0]) / 60, logged_thermal["ect_log"], color=INK2, ls="--",
                      lw=1.2, label="logged coolant (stint)")
    ax[0, 0].set(title="Engine temperatures over endurance", xlabel="time [min]", ylabel="°C")
    ax[0, 0].legend(fontsize=8)
    ax[0, 1].plot(df.index, df["lap_time_s"], "o-", color=CAT[0])
    ax[0, 1].set(title="Lap time", xlabel="lap", ylabel="s")
    ax[0, 2].bar(df.index, df["derate_%"], color=CAT[1], width=0.7)
    ax[0, 2].set(title="Engine torque derate from coolant temperature", xlabel="lap", ylabel="%")
    ax[1, 0].bar(df.index, df["fuel_L"] * 1e3, color=CAT[2], width=0.7)
    ax[1, 0].set(title=f"Fuel per lap (total {df['fuel_L'].sum():.2f} L)", xlabel="lap", ylabel="mL")
    ax[1, 1].plot(df.index, df["fuel_left_L"], "o-", color=CAT[2])
    ax[1, 1].axhline(0, color=LIMIT_COLORS["braking"], lw=1.2)
    ax[1, 1].set(title="Fuel left in the tank", xlabel="lap", ylabel="L", ylim=(min(0, df["fuel_left_L"].min()) - 0.2, None))
    ax[1, 2].plot(df.index, 100 * df["battery_soc"], "o-", color=CAT[6])
    ax[1, 2].set(title="Battery state of charge", xlabel="lap", ylabel="%")
    fig.suptitle(f"Endurance: {df['lap_time_s'].sum():.1f} s, {len(df)} laps")
    fig.tight_layout()
    return fig


def thermal_fit(fit_df, title="Coolant model vs logged endurance stint"):
    fig, ax = plt.subplots(2, 1, figsize=(15, 6.5), sharex=True, gridspec_kw={"height_ratios": [2, 1]})
    t = (fit_df["t"] - fit_df["t"].iloc[0]) / 60
    ax[0].fill_between(t, 0, 1, where=fit_df["fan"] > 0.5, color=GRID, alpha=0.7, transform=ax[0].get_xaxis_transform(), lw=0,
                       label="model fan on")
    ax[0].plot(t, fit_df["ect_log"], color=INK2, ls="--", lw=1.4, label="logged coolant")
    ax[0].plot(t, fit_df["ect_model"], color=CAT[0], label="model")
    ax[0].set(title=title, ylabel="°C")
    ax[0].legend(fontsize=8)
    ax[1].plot(t, fit_df["fuel_kW"], color=CAT[1], lw=1, label="fuel power (logged)")
    ax[1].plot(t, fit_df["Q_rad_kW"], color=CAT[0], lw=1, label="radiator heat rejection (model)")
    ax[1].set(xlabel="time [min]", ylabel="kW")
    ax[1].legend(fontsize=8)
    fig.tight_layout()
    return fig


def radiator_map(pt):
    from .thermal import Thermal
    th = Thermal(pt)
    v = np.linspace(0, 30, 61)
    fig, ax = plt.subplots(1, 2, figsize=(13, 4))
    for i, Tc in enumerate([85, 95, 105, 115]):
        q = [th.radiator(Tc, vv, 9000, False)[0] / 1e3 for vv in v]
        qf = [th.radiator(Tc, vv, 9000, True)[0] / 1e3 for vv in v]
        ax[0].plot(v * 3.6, q, color=CAT[i], label=f"{Tc} °C")
        ax[0].plot(v * 3.6, qf, color=CAT[i], ls="--", lw=1.2)
    ax[0].set(title="Radiator heat rejection (dashed: fan on)", xlabel="km/h", ylabel="kW")
    ax[0].legend(fontsize=8)
    Tc = np.linspace(60, 120, 61)
    ax[1].plot(Tc, 100 * th.thermostat(Tc), color=CAT[0])
    ax[1].set(title="Thermostat opening", xlabel="coolant °C", ylabel="% coolant flow to radiator")
    fig.tight_layout()
    return fig


def electrical(laps, veh):
    lr = laps[0] if isinstance(laps, list) else laps
    el = veh.elec
    r = np.linspace(2000, 13000, 100)
    fig, ax = plt.subplots(1, 3, figsize=(17, 3.8))
    ax[0].plot(r, el.available(r), color=CAT[0], label="alternator available")
    ax[0].axhline(el.load(False), color=CAT[1], ls="--", lw=1.4, label="load, fan off")
    ax[0].axhline(el.load(True), color=CAT[1], lw=1.4, label="load, fan on")
    ax[0].set(title="Alternator output vs load", xlabel="rpm", ylabel="W")
    ax[0].legend(fontsize=8)
    ax[1].plot(r, el.drag_torque(r, el.output(r, el.load(False))), color=CAT[0], label="fan off")
    ax[1].plot(r, el.drag_torque(r, el.output(r, el.load(True))), color=CAT[1], label="fan on")
    ax[1].set(title="Alternator drag at the crank", xlabel="rpm", ylabel="N m")
    ax[1].legend(fontsize=8)
    loads = veh.ptc.electrical.loads
    ks = [k for k, v in loads.items() if v] + ["fan (when on)"]
    vs = [v for v in loads.values() if v] + [veh.ptc.cooling.fan_power]
    ax[2].barh(ks, vs, color=CAT[0], height=0.6)
    ax[2].set(title="Electrical loads", xlabel="W")
    fig.tight_layout()
    return fig


def events_overview(res):
    t = res.table()
    fig, ax = plt.subplots(1, 2, figsize=(13, 3.8))
    tt = t["time_s"].dropna()
    ax[0].barh(tt.index, tt.values, color=CAT[0], height=0.6)
    for i, v in enumerate(tt.values):
        ax[0].text(v, i, f" {v:.3f} s", va="center", fontsize=8, color=INK)
    ax[0].set(title="Simulated event times", xscale="log", xlabel="s (log)")
    pts = t["points"].dropna()
    if len(pts):
        ax[1].barh(pts.index, pts.values, color=CAT[2], height=0.6)
        for i, v in enumerate(pts.values):
            ax[1].text(v, i, f" {v:.1f}", va="center", fontsize=8, color=INK)
    ax[1].set(title="Points (needs Tmin per event)", xlabel="points")
    fig.tight_layout()
    return fig


# =========================================================================== BINDER
def dyno_vs_model(pt, dyno, tq_bins=None, track_factor=None):
    """Motor dyno (binder) vs the engine model at the dyno ambient and at the track ambient."""
    from .identify import dyno_engine
    from .engine import Engine
    r = np.arange(3000, 14300, 50.0)
    ed = dyno_engine(pt); ed.e.rev_limit = 1e9
    p0 = pt.copy(); p0.engine.torque_scale = 1.0
    et = Engine(p0); et.e.rev_limit = 1e9
    fig, ax = plt.subplots(1, 2, figsize=(14, 4.6))
    ax[0].plot(dyno["rpm"], dyno["T_crank"], "o", color=INK2, ms=5, label="motor dyno (binder p.61)")
    ax[0].plot(r, ed.torque_wot(r), color=CAT[0], label=f"model at dyno ambient ({pt.engine.dyno_pressure / 1e3:.1f} kPa)")
    ax[0].plot(r, et.torque_wot(r), color=CAT[1], label=f"model at Michigan ({pt.ambient.pressure / 1e3:.1f} kPa, {pt.ambient.temperature:.0f} °C)")
    if track_factor:
        ax[0].plot(r, et.torque_wot(r) * track_factor, color=CAT[2], ls="--", label=f"x track factor {track_factor:.2f} (from logs)")
    if tq_bins is not None and len(tq_bins):
        ax[0].plot(tq_bins["rpm"], tq_bins["T_crank"], "s", color=CAT[2], ms=4, label="logged WOT (median)")
    ax[0].axvline(pt.engine.rev_limit, color=GRID, lw=1.2)
    ax[0].set(title="Crank torque: dyno, model, track", xlabel="rpm", ylabel="N m", ylim=(0, 65))
    ax[0].legend(fontsize=7.5, loc="lower center")
    ax[1].plot(dyno["rpm"], dyno["T_crank"] * dyno["rpm"] * np.pi / 30 / 745.7, "o", color=INK2, ms=5, label="motor dyno")
    ax[1].plot(r, ed.wot(r)["power"] / 745.7, color=CAT[0], label="model, dyno ambient")
    ax[1].plot(r, et.wot(r)["power"] / 745.7, color=CAT[1], label="model, Michigan")
    if pt.engine.hub_dyno_power:
        ax[1].plot(pt.engine.hub_dyno_rpm, pt.engine.hub_dyno_power / 745.7, "D", color=CAT[6], ms=8, label="hub dyno (binder p.63)")
    ax[1].set(title="Power [hp]", xlabel="rpm", ylabel="hp")
    ax[1].legend(fontsize=7.5, loc="lower right")
    fig.tight_layout()
    return fig


def binder_checks(rows):
    """Bar chart of model / binder ratio for every binder number checked."""
    df = pd.DataFrame(rows)
    fig, ax = plt.subplots(figsize=(11, 0.45 * len(df) + 1.5))
    ratio = df["model"] / df["binder"]
    cols = [CAT[0] if abs(r - 1) <= 0.1 else CAT[1] for r in ratio]
    ax.barh(df["check"], 100 * (ratio - 1), color=cols, height=0.6)
    for i, (m, b, u) in enumerate(zip(df["model"], df["binder"], df["unit"])):
        ax.text(max(100 * (ratio.iloc[i] - 1), 0) + 1, i, f"model {m:.4g} / binder {b:.4g} {u}", va="center", fontsize=7.5, color=INK2)
    ax.axvline(0, color=INK, lw=1)
    ax.axvspan(-10, 10, color=GRID, alpha=0.4, lw=0)
    ax.invert_yaxis()
    ax.set(xlabel="model vs binder [%]  (shaded: within 10 %)", title="Model against the powertrain design binder")
    fig.tight_layout()
    return fig
