"""Transient driveline model (time domain) - the powertrain block for a future
multibody vehicle model, and the source of launch / shift-shock loads.

Degrees of freedom
    w_e    crank (engine + clutch basket reflected to the crank)
    w_a    rear axle input (gearbox output, chain, sprocket, diff reflected to the axle)
    th_L, th_R  halfshaft twist (torsional springs + damping)
    w_L, w_R    rear wheels
    v      vehicle speed

    J_e dw_e/dt = T_eng(w_e, throttle, ignition cut) - T_clutch / i_p
    J_a dw_a/dt = eta * i_g i_fd T_clutch - (T_hsL + T_hsR)
    T_hs = k th + c (w_a - w_wheel)
    J_w dw/dt  = T_hs - Fx r - bearing drag
    m dv/dt    = Fx_L + Fx_R - R(v)
    Fx = D sin(C atan(B kappa)), kappa = (w r - v) / max(v, v_reg)  (rear loads incl. squat transfer)

Clutch (wet slipper clutch) and dog engagement share a smooth Coulomb law
T = T_cap * tanh(dw / w_s). Launch control: during the launch the clutch capacity
is driven to hold launch_rpm; after lock-up the capacity is the full clutch capacity
(which, as a slipper clutch, also limits the shift shock). An upshift cuts ignition
for upshift_time and swaps the ratio half-way through the cut.

``DrivelineModel.wheel_torques(x)`` / ``rhs(t, x, inputs)`` are the coupling points for
a multibody chassis: give it wheel speeds and loads, get halfshaft torques back.
"""
from __future__ import annotations

import dataclasses as dc

import numpy as np
from scipy.integrate import solve_ivp

from fsae_vd.units import G0

from .vehicle_pt import PTVehicle


@dc.dataclass
class TransientResult:
    t: np.ndarray
    x: np.ndarray
    ch: dict


class DrivelineModel:
    def __init__(self, veh: PTVehicle, mu_x=None, C=1.65):
        self.veh = veh
        pt, dt = veh.ptc, veh.dt
        self.pt, self.dt = pt, dt
        self.ip = dt.primary
        self.J_e = pt.engine.crank_inertia + pt.clutch.inertia / self.ip ** 2
        self.J_a = (pt.gearbox.output_inertia * dt.fd ** 2 + pt.final_drive.sprocket_inertia + pt.differential.inertia)
        self.J_w = pt.wheels.rear_corner_inertia + pt.halfshaft.inertia / 2
        self.k = pt.halfshaft.torsional_stiffness
        self.c = pt.halfshaft.damping
        self.r = dt.r
        self.m = veh.m + 2 * pt.wheels.front_corner_inertia / dt.r ** 2
        tire = veh.tire
        fz = veh.m * G0 * (1 - veh.ff) / 2
        self.mu_x = mu_x or float(tire.peak_fx(fz, 0.0, veh.p_r) / fz)
        self.Cmf = C
        self.k_s = pt.wheels.slip_stiffness_per_load
        self.eta = pt.gearbox.primary_efficiency * pt.gearbox.mesh_efficiency * dt.eta_chain() * \
            pt.differential.efficiency * dt.eta_cv()
        self.T_cap = pt.clutch.torque_capacity * self.ip         # at the clutch shaft
        self.w_s = 2.0                                           # rad/s smoothing of the Coulomb law
        w = np.arange(500, pt.engine.rev_limit + 600, 100.0)
        self._w = w * np.pi / 30
        self._T = veh.dt.crank_torque_wot(w)
        self._T[w > pt.engine.rev_limit] = -5.0
        self._fric = veh.engine.motoring_torque(w)

    # ------------------------------------------------------------ pieces
    def engine_torque(self, w_e, throttle, cut):
        T = np.interp(w_e, self._w, self._T)
        Tf = np.interp(w_e, self._w, self._fric)
        return np.where(cut, -Tf, throttle * T - (1 - throttle) * Tf)

    def tire_fx(self, w, v, fz):
        kap = (w * self.r - v) / max(abs(v), 1.5)
        D = self.mu_x * fz
        B = self.k_s / (self.Cmf * self.mu_x)
        return D * np.sin(self.Cmf * np.arctan(B * kap)), kap

    def rear_loads(self, ax):
        v = self.veh
        Wr = v.m * G0 * (1 - v.ff) + v.m * ax * v.h / v.L          # squat transfer (anti-squat changes pitch, not load)
        return Wr / 2, Wr / 2

    # ------------------------------------------------------------ ODE
    def rhs(self, t, x, gear, throttle, cut, clutch_cap, ax_prev):
        w_e, w_a, thL, thR, wL, wR, v = x
        ig = self.dt.gears[gear - 1]
        w_in = w_a * self.dt.fd * ig                             # gearbox input shaft = clutch inner hub
        dw = w_e / self.ip - w_in
        Tcl = clutch_cap * np.tanh(dw / self.w_s)
        Te = self.engine_torque(w_e, throttle, cut)
        TL = self.k * thL + self.c * (w_a - wL)
        TR = self.k * thR + self.c * (w_a - wR)
        fzL, fzR = self.rear_loads(ax_prev)
        FL, _ = self.tire_fx(wL, v, fzL)
        FR, _ = self.tire_fx(wR, v, fzR)
        bd = self.pt.wheels.bearing_drag
        dwe = (Te - Tcl / self.ip) / self.J_e
        dwa = (self.eta * Tcl * ig * self.dt.fd - TL - TR) / self.J_a
        dwL = (TL - FL * self.r - bd) / self.J_w
        dwR = (TR - FR * self.r - bd) / self.J_w
        dv = (FL + FR - float(self.veh.resist(max(v, 0.0)))) / self.m
        return np.array([dwe, dwa, w_a - wL, w_a - wR, dwL, dwR, dv])

    def wheel_torques(self, x):
        w_e, w_a, thL, thR, wL, wR, v = x
        return self.k * thL + self.c * (w_a - wL), self.k * thR + self.c * (w_a - wR)

    # ------------------------------------------------------------ manoeuvres
    def launch_and_shifts(self, t_end=5.0, shift_rpm=None, launch_rpm=None, dt_out=0.002,
                          traction_control=True, tc_target_slip=0.10, tc_gain=2.0):
        """Standing-start launch at launch_rpm and full-throttle upshifts.
        traction_control: engine torque is cut when the rear slip ratio exceeds tc_target_slip
        (Syvecs TC/launch strategy); False shows the uncontrolled wheel spin."""
        pt = self.pt
        lr = (launch_rpm or pt.engine.launch_rpm) * np.pi / 30
        sr = shift_rpm or self.dt.shift_rpms(self.veh.m, self.veh.resist)
        sr = np.atleast_1d(sr) * np.pi / 30
        if sr.size == 1:
            sr = np.repeat(sr, self.dt.n_gears - 1)
        x = np.array([lr, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        gear, t, cut_until, swap_at = 1, 0.0, -1.0, None
        locked = False
        T_out, X, CH = [], [], {k: [] for k in ("gear", "clutch_T", "engine_T", "Fx_L", "Fx_R", "slip_L", "slip_R",
                                                   "ax", "cut", "clutch_slip_rpm", "throttle")}
        ax_prev = 0.0
        integ = 0.0
        thr = 1.0
        while t < t_end:
            h = dt_out
            cut = t < cut_until
            if swap_at is not None and t >= swap_at:
                gear, swap_at = gear + 1, None
            ig = self.dt.gears[gear - 1]
            dw = x[0] / self.ip - x[1] * self.dt.fd * ig
            # traction control on the worst rear wheel
            if traction_control:
                kap = max((x[4] * self.r - x[6]) / max(x[6], 1.5), (x[5] * self.r - x[6]) / max(x[6], 1.5))
                thr_t = float(np.clip(1.0 - tc_gain * (kap - tc_target_slip) / tc_target_slip, 0.05, 1.0))
                thr = thr + (thr_t - thr) * min(h / 0.02, 1.0)          # 20 ms actuation lag (ignition cut)
            # launch control: hold launch rpm by modulating clutch capacity (PI) until it locks
            if not locked and gear == 1:
                err = x[0] - lr
                integ = np.clip(integ + err * h, -50, 50)
                Te = float(self.engine_torque(x[0], thr, False))
                cap = np.clip(Te * self.ip + 0.8 * err + 6.0 * integ, 0.0, self.T_cap)
                if dw < 2.0 and t > 0.3:
                    locked = True
            else:
                cap = self.T_cap
            sol = solve_ivp(lambda tt, xx: self.rhs(tt, xx, gear, thr, cut, cap, ax_prev), (t, t + h), x,
                            method="LSODA", rtol=1e-6, atol=1e-8, max_step=h)
            x = sol.y[:, -1]
            t += h
            d = self.rhs(t, x, gear, thr, cut, cap, ax_prev)
            ax_prev = 0.7 * ax_prev + 0.3 * d[-1]
            if gear < self.dt.n_gears and locked and not cut and swap_at is None and x[0] >= sr[gear - 1]:
                cut_until = t + pt.gearbox.upshift_time
                swap_at = t + 0.5 * pt.gearbox.upshift_time
            fzL, fzR = self.rear_loads(ax_prev)
            FL, kL = self.tire_fx(x[4], x[6], fzL)
            FR, kR = self.tire_fx(x[5], x[6], fzR)
            ig = self.dt.gears[gear - 1]
            dw = x[0] / self.ip - x[1] * self.dt.fd * ig
            T_out.append(t); X.append(x.copy())
            CH["gear"].append(gear); CH["clutch_T"].append(cap * np.tanh(dw / self.w_s))
            CH["engine_T"].append(float(self.engine_torque(x[0], thr, cut))); CH["Fx_L"].append(FL); CH["Fx_R"].append(FR)
            CH["throttle"].append(thr)
            CH["slip_L"].append(kL); CH["slip_R"].append(kR); CH["ax"].append(d[-1]); CH["cut"].append(cut)
            CH["clutch_slip_rpm"].append(dw * 30 / np.pi * self.ip)
        X = np.array(X)
        ch = {k: np.array(v) for k, v in CH.items()}
        ch["rpm"] = X[:, 0] * 30 / np.pi
        ch["v"] = X[:, 6]
        ch["T_hs_L"], ch["T_hs_R"] = self.wheel_torques(X.T)
        ch["s"] = np.r_[0, np.cumsum(0.5 * (X[1:, 6] + X[:-1, 6]) * np.diff(T_out))]
        return TransientResult(np.array(T_out), X, ch)

    def natural_frequency_hz(self, gear=1):
        """First torsional mode: halfshafts (2 in parallel) between the reflected driveline and wheels+car."""
        ig = self.dt.gears[gear - 1]
        J_drive = self.J_a + self.J_e * (self.ip * ig * self.dt.fd) ** 2
        J_load = 2 * self.J_w + self.m * self.r ** 2
        k = 2 * self.k
        return float(np.sqrt(k * (1 / J_drive + 1 / J_load)) / (2 * np.pi))
