"""Coupling to the suspension / vehicle-dynamics model (fsae_vd).

``PTVehicle`` *is* an ``fsae_vd.Vehicle`` (same load transfer, roll, camber,
kinematics from the CT17 hardpoints, tire model, aero) with three powertrain
additions:

1. rear drive split by the differential (Drexler LSD / open / spool / ideal)
   using each rear tire's own capacity, instead of the old load-proportional split;
2. the differential's yaw moment  Mz = (F_out - F_in) * t_r / 2  enters the
   yaw balance of the axles (on power and on the coast ramp under braking), so
   preload and ramp angles change the limit balance;
3. the tractive-force limit comes from the full engine/gearbox/chain model
   (best gear at each speed, rotating inertia), not a constant power.

The traction-only envelope (``traction_ggv``) is what the gear-by-gear lap
solver uses; ``ggv()`` (the fsae_vd method) includes the engine envelope and
plugs straight into every fsae_vd tool (plots, reports, adjust, optimize).
"""
from __future__ import annotations

import numpy as np

from fsae_vd.config import CarConfig
from fsae_vd.units import G0
from fsae_vd.vehicle import Vehicle

from .config import PTConfig
from .drivetrain import Drivetrain
from .electrical import Electrical
from .engine import Engine


class EnginePowertrain:
    """Drop-in for fsae_vd.vehicle.Powertrain: force(v) = best-gear WOT tractive force,
    reduced by the gear's rotating-inertia share so ax from the GGV is the vehicle's."""

    def __init__(self, dt: Drivetrain, m: float):
        self.dt, self.m = dt, m
        self.unlimited = False
        self.coolant_temp = None

    def available(self):
        return True

    def force(self, v):
        v = np.atleast_1d(np.asarray(v, float))
        if self.unlimited:
            return np.full(v.shape, np.inf)
        F = self.dt.forces_all_gears(v, self.coolant_temp)
        meq = np.array([self.dt.equivalent_mass(k, self.m) for k in range(1, self.dt.n_gears + 1)])
        Fe = F * (self.m / meq)[:, None]
        return Fe.max(0)

    def best_gear(self, v):
        v = np.atleast_1d(np.asarray(v, float))
        F = self.dt.forces_all_gears(v, self.coolant_temp)
        meq = np.array([self.dt.equivalent_mass(k, self.m) for k in range(1, self.dt.n_gears + 1)])
        return 1 + np.argmax(F / meq[:, None], axis=0)


class PTVehicle(Vehicle):
    def __init__(self, cfg: CarConfig, pt: PTConfig):
        cfg = cfg.copy()
        # resistances: the vd config wins; ASSUMED powertrain defaults only fill gaps
        self.assumed = []
        if cfg.aero.CdA is None and cfg.aero.model == "constant":
            cfg.aero.CdA = pt.resistance.assumed_CdA
            self.assumed.append(f"aero.CdA = {pt.resistance.assumed_CdA} m^2 (ASSUMED, fit a coast-down)")
        if cfg.tires.rolling_resistance is None:
            cfg.tires.rolling_resistance = pt.resistance.assumed_Crr
            self.assumed.append(f"tires.rolling_resistance = {pt.resistance.assumed_Crr} (ASSUMED)")
        cfg.powertrain.kind = "ICE"
        super().__init__(cfg, )
        self.ptc = pt
        self.engine = Engine(pt)
        self.elec = Electrical(pt)
        self.dt = Drivetrain(pt, cfg.tires.tire_radius, self.engine, self.elec)
        self.cfg.powertrain.final_drive_ratio = self.dt.fd * self.dt.primary
        self.pt = EnginePowertrain(self.dt, self.m)
        self.diff = self.dt.diff
        self.warnings += self.assumed

    # ---------------------------------------------------------------- drive split
    def _rear_caps(self, st):
        p = self.p_r
        ci = self.tire.peak_fx(st["Fz"]["ri"], st["camber"]["ri"], p)
        co = self.tire.peak_fx(st["Fz"]["ro"], st["camber"]["ro"], p)
        return np.asarray(ci, float), np.asarray(co, float)

    def _wheel_fx(self, v, ax, st=None):
        need = self.m * ax + (self.resist_state(st) if st is not None else self.resist(v))
        drive = np.maximum(need, 0.0)
        brk = np.maximum(-need, 0.0)
        bias = self.bias if self.bias is not None else 0.6
        fo = fi = brk * bias / 2
        if st is None:
            return {"fo": fo, "fi": fi, "ro": drive / 2 + brk * (1 - bias) / 2,
                    "ri": drive / 2 + brk * (1 - bias) / 2}, drive, brk
        kap_t = self.tr * np.abs(st["ay"]) / np.maximum(st["v"], 1.0) ** 2
        ci, co = self._rear_caps(st)
        Fi, Fo, ok = self.diff.split(drive, ci, co, st["Fz"]["ri"], st["Fz"]["ro"], kap_t, self.dt.r)
        # braking: coast ramp + preload, driven by engine braking through the driveline
        rb = brk * (1 - bias) / 2
        if np.any(brk > 0) and self.diff.type != "open":
            g = self.braking_gear(st["v"])
            t_eb = self.engine.motoring_torque(self.dt.rpm(st["v"], g)) * self.dt.overall[g - 1]
            # locked-axle scrub under braking, limited by the coast ramp + preload
            fi_k, fo_k = self.diff.locked_split(-2 * rb, ci, co, st["Fz"]["ri"], st["Fz"]["ro"], kap_t)
            lock_c = self.diff.lock_torque(t_eb, coast=True) / self.dt.r
            dF_c = np.where(brk > 0, np.minimum(np.maximum(fi_k - fo_k, 0.0), lock_c), 0.0)
        else:
            dF_c = np.zeros_like(drive)
        ro = np.where(brk > 0, rb + dF_c / 2, Fo)
        ri = np.where(brk > 0, np.abs(rb - dF_c / 2), Fi)
        self._diff_ok = np.where(brk > 0, True, ok)
        self._mz = np.where(brk > 0, -dF_c, Fo - Fi) * self.tr / 2
        return {"fo": fo, "fi": fi, "ro": ro, "ri": ri}, drive, brk

    def braking_gear(self, v):
        """Gear held while braking: the lowest gear below 92 % of the rev limit (drivers
        downshift to the exit gear)."""
        v = np.maximum(np.atleast_1d(np.asarray(v, float)), 0.5)
        rpm = np.stack([self.dt.rpm(v, k) for k in range(1, self.dt.n_gears + 1)])
        ok = rpm <= 0.92 * self.ptc.engine.rev_limit
        g = np.where(ok.any(0), np.argmax(ok, axis=0) + 1, self.dt.n_gears)
        return g.reshape(np.shape(v))

    def margins(self, v, ax, ay):
        st = self.state(v, ax, ay)
        fx, drive, _ = self._wheel_fx(st["v"], st["ax"], st)
        cap = self._capacity(st, fx)
        mz = self._mz
        req_f, req_r = self.axle_requirements(st, mz)
        capf, capr = cap["fo"] + cap["fi"], cap["ro"] + cap["ri"]
        xok = ~(cap["fo_xover"] | cap["fi_xover"] | cap["ro_xover"] | cap["ri_xover"]) & self._diff_ok
        mf = np.where(req_f > 1e-6, capf / np.maximum(req_f, 1e-6), np.inf)
        mr = np.where(req_r > 1e-6, capr / np.maximum(req_r, 1e-6), np.inf)
        mf = np.where(xok, mf, 0.0)
        mr = np.where(xok, mr, 0.0)
        if self.pt.unlimited or not np.any(drive > 0):
            mp = np.full_like(mf, np.inf)
        else:
            mp = np.where(drive > 0, self.pt.force(st["v"]) / np.maximum(drive, 1e-6), np.inf)
        st["diff_mz"] = mz
        return mf, mr, mp, st

    def diff_state(self, v, ax, ay):
        """Rear wheel forces, diff yaw moment and locking state for a solved lap (arrays)."""
        st = self.state(v, ax, ay)
        fx, drive, brk = self._wheel_fx(st["v"], st["ax"], st)
        return {"F_ri": fx["ri"], "F_ro": fx["ro"], "Mz": self._mz, "drive": drive, "brake": brk, "state": st}

    # ---------------------------------------------------------------- envelopes
    def traction_ggv(self, **kw):
        """GGV limited by tires + differential only (engine handled gear by gear in the solver)."""
        self.pt.unlimited = True
        try:
            return self.ggv(**kw)
        finally:
            self.pt.unlimited = False

    def resist_total(self, v):
        return self.resist(v)
