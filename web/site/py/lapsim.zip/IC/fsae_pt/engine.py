"""Restricted Yamaha R6 engine model (mean-value, quasi-steady).

Air path
    ambient (p0, T0) -> 20 mm restrictor venturi -> plenum (p_m, T_m) -> cylinders.
    Restrictor: isentropic nozzle flow at the throat with discharge coefficient Cd.
    The diffuser recovers part of the throat dynamic pressure, so the throat
    chokes while the plenum is still at ~0.8-0.9 p0 (as logged: MAP 0.74-0.85 bar
    at WOT and high rpm). Choked flow  m* = Cd A p0 sqrt(g/(R T0)) (2/(g+1))^((g+1)/(2(g-1))).
    Engine demand  m_e = VE(N) * p_m/(R T_m) * Vd * N/120.
    The plenum pressure is the p_m at which the two flows are equal.

Torque
    indicated power  = eta_ind * eta_lambda * (m_air/AFR) * LHV * min(1, 1/lambda)
    friction (Chen-Flynn form)  FMEP = a + b*Sp + c*Sp^2   [kPa], Sp mean piston speed
    pumping  PMEP = p_exhaust - p_plenum
    brake torque = (P_ind/omega) - (FMEP + PMEP) * Vd / (4 pi), times the
    coolant-temperature derate.

Part load is solved for the air flow that gives the requested brake torque,
which gives fuel flow and BSFC everywhere on the map. Everything is
vectorised over rpm.
"""
from __future__ import annotations

import numpy as np

from .config import PTConfig
from .fuel import props

R_AIR, GAMMA = 287.05, 1.4
_CRIT = (2 / (GAMMA + 1)) ** (GAMMA / (GAMMA - 1))          # p*/p0 = 0.528
_PSI_STAR = (2 / (GAMMA + 1)) ** ((GAMMA + 1) / (2 * (GAMMA - 1)))


def omega(rpm):
    return np.asarray(rpm, float) * 2 * np.pi / 60


class Engine:
    def __init__(self, pt: PTConfig):
        self.pt = pt
        e, a, i = pt.engine, pt.ambient, pt.intake
        self.e, self.i = e, i
        self.fuel = props(pt.fuel.type)
        self.p0 = a.pressure
        self.T0 = a.temperature + 273.15
        self.Tm = self.T0 + a.intake_temp_rise
        self.Vd = e.displacement
        self.A = np.pi * i.restrictor_diameter ** 2 / 4
        self._ve_rpm = np.asarray(e.ve_rpm, float)
        self._ve = np.asarray(e.ve, float)
        if self._ve_rpm.size == 0:
            raise ValueError("engine.ve_rpm / engine.ve table is empty")

    # ------------------------------------------------------------ air path
    def ve(self, rpm):
        """Volumetric efficiency incl. the runner/primary length what-if."""
        rpm = np.asarray(rpm, float)
        v = np.interp(rpm, self._ve_rpm, self._ve)
        e = self.e
        n_pk = self._ve_rpm[np.argmax(self._ve)]
        g = lambda n_t: np.exp(-0.5 * ((rpm - n_t) / 1800.0) ** 2)
        # intake runner: quarter-wave tuning, tuned rpm ~ 1 / length
        L, Lref = e.intake_runner_length, e.intake_runner_ref
        if L and Lref and abs(L - Lref) > 1e-6:
            v = v + e.tuning_amplitude * (g(n_pk * Lref / L) - g(n_pk))
        # exhaust primary: binder formula P[in] = 850 ED / rpm - 3  ->  tuned rpm = 850 ED / (P + 3)
        P, Pref = e.exhaust_primary_length / 0.0254, e.exhaust_primary_ref / 0.0254
        if P and Pref and abs(P - Pref) > 1e-4:
            v = v + e.tuning_amplitude * (g(n_pk * (Pref + 3) / (P + 3)) - g(n_pk))
        return np.maximum(v, 0.05)

    def choked_flow(self):
        return self.i.restrictor_cd * self.A * self.p0 * np.sqrt(GAMMA / (R_AIR * self.T0)) * _PSI_STAR

    def restrictor_flow(self, p_m):
        """Mass flow through the venturi for plenum pressure p_m (diffuser recovery included)."""
        p_m = np.asarray(p_m, float)
        rec = self.i.diffuser_recovery
        p_t = self.p0 - (self.p0 - p_m) / max(1 - rec, 1e-3)
        r = np.clip(p_t / self.p0, _CRIT, 1.0)
        psi = np.sqrt(np.maximum(2 * GAMMA / (GAMMA - 1) * (r ** (2 / GAMMA) - r ** ((GAMMA + 1) / GAMMA)), 0.0))
        return self.i.restrictor_cd * self.A * self.p0 / np.sqrt(R_AIR * self.T0) * psi

    def choke_map(self):
        """Plenum pressure below which the throat is sonic."""
        return self.p0 - (1 - self.i.diffuser_recovery) * (self.p0 - _CRIT * self.p0)

    def demand_coef(self, rpm):
        """Engine air demand per unit plenum pressure [kg/s/Pa]."""
        rpm = np.asarray(rpm, float)
        return self.ve(rpm) / (R_AIR * self.Tm) * self.Vd * rpm / 120.0

    def wot_air(self, rpm, n_iter=50):
        """(mass flow, plenum pressure, choked flag) at wide-open throttle."""
        rpm = np.atleast_1d(np.asarray(rpm, float))
        k = self.demand_coef(rpm)
        K = self.i.loss_coef
        lo, hi = np.full(rpm.shape, 0.2 * self.p0), np.full(rpm.shape, self.p0)
        for _ in range(n_iter):
            mid = 0.5 * (lo + hi)
            m = k * mid
            more = m < self.restrictor_flow(np.minimum(mid + K * m ** 2, self.p0))   # restrictor exit = plenum + losses
            lo = np.where(more, mid, lo)
            hi = np.where(more, hi, mid)
        pm = 0.5 * (lo + hi)
        p_exit = pm + K * (k * pm) ** 2
        return k * pm, pm, p_exit <= self.choke_map() + 1.0

    # ------------------------------------------------------------ torque parts
    def piston_speed(self, rpm):
        return 2 * self.e.stroke * np.asarray(rpm, float) / 60

    def fmep(self, rpm):
        sp = self.piston_speed(rpm)
        return 1e3 * (self.e.fmep_a + self.e.fmep_b * sp + self.e.fmep_c * sp ** 2)

    def friction_torque(self, rpm):
        return self.fmep(rpm) * self.Vd / (4 * np.pi)

    def pumping_torque(self, p_m):
        return (self.e.exhaust_back_pressure - np.asarray(p_m, float)) * self.Vd / (4 * np.pi)

    def _eta_lambda(self, lam):
        lam = np.asarray(lam, float)
        return np.clip(1.0 - 0.9 * (lam - 0.90) ** 2, 0.7, 1.0)

    def indicated_torque(self, rpm, m_air, lam):
        lam = np.asarray(lam, float)
        q = self.e.eta_indicated * self._eta_lambda(lam) * m_air / self.fuel.afr * self.fuel.lhv * np.minimum(1.0, 1.0 / lam)
        return q / np.maximum(omega(rpm), 1.0)

    def derate(self, coolant_temp=None):
        if coolant_temp is None:
            return 1.0
        e = self.e
        return np.clip(1.0 - e.derate_per_degC * np.maximum(np.asarray(coolant_temp, float) - e.derate_start_temp, 0.0), 0.3, 1.0)

    # ------------------------------------------------------------ full load
    def wot(self, rpm, coolant_temp=None):
        """Everything at wide-open throttle (dict of arrays)."""
        rpm = np.atleast_1d(np.asarray(rpm, float))
        m, pm, ch = self.wot_air(rpm)
        lam = np.full(rpm.shape, self.e.lambda_wot)
        Ti = self.indicated_torque(rpm, m, lam)
        Tf = self.friction_torque(rpm)
        Tp = self.pumping_torque(pm)
        Tb = (Ti - Tf - Tp) * self.derate(coolant_temp) * self.e.torque_scale
        Tb = np.where(rpm > self.e.rev_limit * 1.002, 0.0, Tb)
        P = Tb * omega(rpm)
        mf = self.e.fuel_scale * m / (self.fuel.afr * lam)
        return {"rpm": rpm, "torque": Tb, "power": P, "m_air": m, "map": pm, "choked": ch,
                "m_fuel": mf, "bsfc_g_kwh": mf * 3.6e9 / np.maximum(P, 1.0),
                "T_ind": Ti, "T_fric": Tf, "T_pump": Tp, "ve": self.ve(rpm),
                "demand_at_p0": self.demand_coef(rpm) * self.p0, "choked_flow": np.full(rpm.shape, self.choked_flow()),
                "lambda": lam}

    def torque_wot(self, rpm, coolant_temp=None):
        return self.wot(rpm, coolant_temp)["torque"]

    def motoring_torque(self, rpm):
        """Closed-throttle engine braking torque (positive number = drag)."""
        rpm = np.asarray(rpm, float)
        p_closed = 0.25 * self.p0
        return self.friction_torque(rpm) + self.pumping_torque(p_closed)

    # ------------------------------------------------------------ part load
    def operating_point(self, rpm, torque, coolant_temp=None):
        """Air flow, plenum pressure, throttle (air-flow fraction), fuel flow and BSFC that
        produce brake ``torque`` at ``rpm``. Torque above WOT is clipped to WOT."""
        rpm = np.atleast_1d(np.asarray(rpm, float))
        torque = np.broadcast_to(np.asarray(torque, float), rpm.shape).astype(float)
        w = self.wot(rpm, coolant_temp)
        der = self.derate(coolant_temp)
        Tq = np.minimum(torque, w["torque"])
        k = self.demand_coef(rpm)
        c4 = self.Vd / (4 * np.pi)
        lam = np.full(rpm.shape, self.e.lambda_part)
        m = w["m_air"].copy()
        for _ in range(3):
            frac = m / np.maximum(w["m_air"], 1e-9)
            lam = self.e.lambda_part + (self.e.lambda_wot - self.e.lambda_part) * np.clip((frac - 0.85) / 0.15, 0, 1)
            a = self.e.eta_indicated * self._eta_lambda(lam) / self.fuel.afr * self.fuel.lhv * np.minimum(1, 1 / lam) \
                / np.maximum(omega(rpm), 1.0)
            # Tb/der = a*m - Tf - (p_exh - m/k) * c4    -> linear in m
            m = (Tq / np.maximum(der * self.e.torque_scale, 1e-3) + self.friction_torque(rpm) + self.e.exhaust_back_pressure * c4) / (a + c4 / k)
            m = np.clip(m, 0.0, w["m_air"])
        pm = m / k
        overrun = torque <= 0.0
        cut = overrun & bool(self.e.overrun_fuel_cut) & (rpm > self.e.idle_rpm + 1000)
        mf = np.where(overrun, np.where(cut, 0.0, self.idle_fuel()), self.e.fuel_scale * m / (self.fuel.afr * lam))
        P = np.maximum(Tq, 0) * omega(rpm)
        return {"rpm": rpm, "torque": Tq, "power": P, "m_air": m, "map": pm,
                "throttle": np.clip(m / np.maximum(w["m_air"], 1e-9), 0, 1), "m_fuel": mf,
                "bsfc_g_kwh": np.where(P > 500, mf * 3.6e9 / np.maximum(P, 1.0), np.nan),
                "fuel_power": mf * self.fuel.lhv, "lambda": lam}

    def idle_fuel(self):
        return 0.12e-3                       # kg/s, ~0.6 L/h at idle

    def torque_map(self, rpm_grid, load_grid):
        """Brake torque and BSFC on an rpm x load (air-flow fraction) grid."""
        R, Lg = np.meshgrid(np.asarray(rpm_grid, float), np.asarray(load_grid, float), indexing="ij")
        w = self.wot(R.ravel())
        m = Lg.ravel() * w["m_air"]
        k = self.demand_coef(R.ravel())
        lam = self.e.lambda_part + (self.e.lambda_wot - self.e.lambda_part) * np.clip((Lg.ravel() - 0.85) / 0.15, 0, 1)
        Tb = self.indicated_torque(R.ravel(), m, lam) - self.friction_torque(R.ravel()) - self.pumping_torque(m / k)
        P = Tb * omega(R.ravel())
        mf = self.e.fuel_scale * m / (self.fuel.afr * lam)
        bsfc = np.where(P > 500, mf * 3.6e9 / np.maximum(P, 1), np.nan)
        return R, Lg, Tb.reshape(R.shape), bsfc.reshape(R.shape), (m / k).reshape(R.shape)

    def exhaust_tuned_rpm(self, length=None):
        """Binder header formula (PT27) solved for rpm: N = 850 ED / (P + 3), P in inches."""
        P = (length if length is not None else self.e.exhaust_primary_length) / 0.0254
        return 850 * self.e.exhaust_event_duration / (P + 3)

    def summary(self):
        r = np.arange(4000, self.e.rev_limit + 1, 50.0)
        w = self.wot(r)
        i, j = np.argmax(w["torque"]), np.argmax(w["power"])
        ch = np.flatnonzero(w["choked"])
        return {"peak_torque_Nm": float(w["torque"][i]), "at_rpm": float(r[i]),
                "peak_power_kW": float(w["power"][j] / 1e3), "peak_power_hp": float(w["power"][j] / 745.7),
                "at_rpm_power": float(r[j]), "restrictor_choked_flow_g_s": self.choked_flow() * 1e3,
                "choke_onset_rpm": float(r[ch[0]]) if ch.size else None,
                "min_bsfc_g_kWh": float(np.nanmin(w["bsfc_g_kwh"]))}
