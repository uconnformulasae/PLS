"""Low-voltage electrical system: alternator (stator + regulator), loads, battery.

The alternator's electrical output is taken from the crank:
    T_drag = T_friction + P_out / (eta_alt * omega)
so electrical load costs engine torque and fuel. The battery covers any deficit
(at low rpm, or with the fan on) and is recharged when there is spare output.
"""
from __future__ import annotations

import numpy as np

from .config import PTConfig


class Electrical:
    def __init__(self, pt: PTConfig):
        self.c = pt.electrical
        self.fan_power = pt.cooling.fan_power

    def base_load(self):
        return float(sum(v for v in self.c.loads.values() if v))

    def load(self, fan_on=False):
        return self.base_load() + self.fan_power * np.asarray(fan_on, float)

    def available(self, rpm):
        c = self.c
        return c.alternator_max_power * np.clip(np.asarray(rpm, float) / c.alternator_full_rpm, 0.0, 1.0) ** 1.5

    def output(self, rpm, demand):
        return np.minimum(self.available(rpm), np.asarray(demand, float))

    def drag_torque(self, rpm, p_out=None):
        """Crank torque taken by the alternator for electrical output p_out (default: base load)."""
        rpm = np.asarray(rpm, float)
        if p_out is None:
            p_out = self.output(rpm, self.base_load())
        w = np.maximum(rpm * 2 * np.pi / 60, 50.0)
        return self.c.alternator_drag + np.asarray(p_out, float) / (self.c.alternator_efficiency * w)

    def battery_step(self, soc, p_alt, p_load, dt):
        cap_j = self.c.battery_capacity_ah * 3600 * self.c.battery_voltage
        return float(np.clip(soc + (p_alt - p_load) * dt / cap_j, 0.0, 1.0))

    def voltage(self, soc, charging):
        """Indicative LiFePO4 terminal voltage."""
        v = 12.8 + 0.6 * (np.asarray(soc) - 0.5)
        return v + 0.6 * np.asarray(charging, float)
